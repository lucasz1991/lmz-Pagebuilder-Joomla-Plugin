<?php

defined('_JEXEC') or die;

$this->setHtml5(true);
?>
<!doctype html>
<html lang="<?php echo htmlspecialchars($this->language, ENT_QUOTES, 'UTF-8'); ?>" dir="<?php echo htmlspecialchars($this->direction, ENT_QUOTES, 'UTF-8'); ?>">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <jdoc:include type="head" />
</head>
<body class="rt-component-only">
    <jdoc:include type="message" />
    <jdoc:include type="component" />
</body>
</html>
