/**
 * RailTime - reversible Scroll-Story fuer Leistungen und Unternehmen.
 *
 * Beide Startseiten-Segmente behalten ihren normalen Dokumentfluss. Eine
 * gemeinsame GSAP-Erzaehlung verbindet die fuenf Leistungskacheln mit dem direkt
 * folgenden Teamkapitel; alle Bewegungen werden vom Scrollweg vor- und
 * rueckwaerts gesteuert.
 */
(() => {
  'use strict';

  const body = document.body;
  if (!body.classList.contains('is-home')) return;

  const services = document.querySelector('.sa-services');
  const servicesHead = services?.querySelector('.sa-section-head');
  const servicesGrid = services?.querySelector('.sa-services__grid');
  const cards = servicesGrid ? [...servicesGrid.querySelectorAll('.sa-service')] : [];
  const team = document.querySelector('.sa-team');
  const teamVisual = team?.querySelector('.sa-team__visual');
  const teamCopy = team?.querySelector('.sa-team__copy');
  if (!services || !servicesHead || cards.length !== 5 || !team || !teamVisual || !teamCopy) return;

  /* Motivbezogene v2-Crops werden vor der Motion-Initialisierung gesetzt.
     So verwenden Desktop und Mobile dieselben unveraenderten Motive, ohne
     breite 16:9-Dateien in den schmalen Teamspalten zu zerlegen. */
  const sprachTag = document.documentElement.lang.toLowerCase();
  const textFuerSprache = (deutsch, english, polski) => (
    sprachTag.startsWith('en') ? english : (sprachTag.startsWith('pl') ? polski : deutsch)
  );
  /* Motiv und Alt-Text kommen ausschliesslich aus dem LMZ Page Builder.
     Bildaenderungen im Builder werden damit unmittelbar sichtbar.
     Hier wird nur noch das Ladeverhalten vereinheitlicht; die noch
     uebergebenen Pfad- und Alt-Argumente werden absichtlich ignoriert.
     (Aufraeumen der inzwischen wirkungslosen Pfad-/Alt-Tabellen: offen.) */
  const setzeSerienbild = (bild, pfad, alt, eilig = false) => {
    if (!bild) return;
    bild.decoding = 'async';
    if (eilig) {
      bild.removeAttribute('loading');
      bild.fetchPriority = 'high';
    } else {
      bild.loading = 'lazy';
    }
  };

  setzeSerienbild(
    document.querySelector('.sa-intro__image img'),
    'serie/v2/rt-home-intro-einsatz.webp',
    textFuerSprache(
      'Einsatzteam bei der Vorbereitung eines Bahneinsatzes',
      'Field team preparing a rail operations assignment',
      'Zespół przygotowujący realizację zlecenia kolejowego',
    ),
    true,
  );

  const serviceBilder = [
    ['serie/v2/rt-home-card-wagenmeister.webp', 'Wagenmeister im Güterterminal', 'Wagon inspectors at the freight terminal', 'Rewidenci taboru na terminalu towarowym'],
    ['serie/v2/rt-home-card-notdienst.webp', 'Wagenmeister bei der Wagenprüfung im Abendlicht', 'Wagon inspector checking a freight wagon in evening light', 'Rewident taboru podczas kontroli wagonu w wieczornym świetle'],
    ['serie/v2/rt-home-card-kv-trailer.webp', 'Technische Kontrolle im kombinierten Verkehr', 'Technical inspection in combined transport', 'Kontrola techniczna w transporcie intermodalnym'],
    ['serie/v2/rt-home-card-sonderuntersuchung.webp', 'Prüfteam zwischen zwei Güterzügen', 'Inspection team between two freight trains', 'Zespół kontrolny między dwoma pociągami towarowymi'],
    ['serie/v2/rt-home-card-pufferteller.webp', 'Pufferteller eines Güterwagens vor der Wartung', 'Freight wagon buffer before maintenance', 'Zderzak wagonu towarowego przed konserwacją'],
  ];
  cards.forEach((karte, index) => {
    const eintrag = serviceBilder[index];
    if (!eintrag) return;
    setzeSerienbild(
      karte.querySelector('figure img'),
      eintrag[0],
      textFuerSprache(eintrag[1], eintrag[2], eintrag[3]),
    );
  });

  const teamBilder = [...teamVisual.querySelectorAll('figure img')];
  setzeSerienbild(
    teamBilder[0],
    'serie/v2/rt-home-team-psa.webp',
    textFuerSprache(
      'RailTime Wagenmeister in vollständiger Schutzausrüstung',
      'RailTime wagon inspector in full protective equipment',
      'Rewident taboru RailTime w pełnym wyposażeniu ochronnym',
    ),
  );
  setzeSerienbild(
    teamBilder[1],
    'serie/v2/rt-home-team-logo.webp',
    textFuerSprache(
      'RailTime Arbeitsjacke mit Firmenlogo',
      'RailTime work jacket with company logo',
      'Kurtka robocza RailTime z logo firmy',
    ),
  );

  /* Diese Markierung geschieht noch waehrend der Parser am Dokumentende ist.
     motion.js sieht dadurch beim DOMContentLoaded keine Ziele mehr, die schon
     dieser Story gehoeren. */
  body.classList.add('rt-home-story-enabled');
  services.dataset.rtMotionOwner = 'home-story';
  team.dataset.rtMotionOwner = 'home-story';

  const ownedContainers = [servicesHead, ...cards, teamVisual, teamCopy];
  ownedContainers.forEach((element) => {
    element.classList.remove('sa-motion-up', 'sa-motion-left', 'sa-motion-right', 'rt-motion-clip');
    element.classList.add('rt-home-story-owned');
  });
  [services, servicesGrid, team].forEach(element => element?.classList.remove('rt-motion-clip'));

  const createScan = (section) => {
    const existing = section.querySelector(':scope > .rt-home-story-scan');
    if (existing) return existing;
    const scan = document.createElement('span');
    scan.className = 'rt-home-story-scan';
    scan.setAttribute('aria-hidden', 'true');
    section.prepend(scan);
    return scan;
  };

  const servicesScan = createScan(services);
  const teamScan = createScan(team);

  const targets = [
    ...servicesHead.children,
    ...cards,
    ...cards.flatMap(card => [...card.children].filter(child => child.tagName !== 'FIGURE')),
    ...cards.map(card => card.querySelector('figure')).filter(Boolean),
    teamVisual,
    ...teamVisual.querySelectorAll('figure'),
    ...teamCopy.children,
    servicesScan,
    teamScan,
  ];

  const showStaticState = () => {
    services.dataset.rtStoryState = 'static';
    team.dataset.rtStoryState = 'static';
    services.classList.remove('is-rt-story-active');
    team.classList.remove('is-rt-story-active');
    if (window.gsap) {
      gsap.set(targets, {
        clearProps: 'transform,translate,rotate,scale,opacity,visibility,willChange,transformOrigin',
      });
    }
  };

  const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (!window.gsap || !window.ScrollTrigger || reducedMotion) {
    showStaticState();
    return;
  }

  gsap.registerPlugin(ScrollTrigger);
  gsap.config({ nullTargetWarn: false });

  let media = gsap.matchMedia();
  media.add({
    desktop: '(min-width: 851px)',
    mobile: '(max-width: 850px)',
  }, (context) => {
    const desktop = context.conditions.desktop;
    const headerParts = [...servicesHead.children];
    const cardFigures = cards.map(card => card.querySelector('figure')).filter(Boolean);
    const cardCopy = cards.flatMap(card => [
      card.querySelector(':scope > span'),
      card.querySelector(':scope > h3'),
      card.querySelector(':scope > .rt-action-arrow'),
    ].filter(Boolean));
    const teamFigures = [...teamVisual.querySelectorAll('figure')];
    const teamParts = [...teamCopy.children];
    const teamSeal = teamCopy.querySelector('.sa-team__seal');
    const teamNumber = teamSeal?.querySelector('strong');
    const numberMatch = teamNumber?.textContent.trim().match(/^(\d+)(\D*)$/);
    const numberState = { value: 0 };

    /* Alle Startwerte werden vorab gesetzt. Bei gestaffelten fromTo-Tweens
       wuerden spaetere Karten sonst bis zu ihrem eigenen Einsatz sichtbar
       bleiben und erst dann auf den Startwert springen. */
    gsap.set(headerParts, { autoAlpha: .08, y: desktop ? 56 : 30 });
    gsap.set(cards, {
      autoAlpha: .06,
      x: index => desktop ? (index % 3 === 0 ? -28 : index % 3 === 2 ? 28 : 0) : 0,
      y: index => (desktop ? 78 : 42) + (index % 2 ? 28 : 0),
      rotationX: desktop ? 8 : 0,
      rotationY: index => desktop ? (index % 2 ? -3.5 : 3.5) : 0,
      scale: desktop ? .93 : .97,
      transformOrigin: '50% 100%',
    });
    gsap.set(cardFigures, {
      scale: desktop ? 1.1 : 1.045,
      yPercent: desktop ? -4 : -2,
    });
    gsap.set(cardCopy, { autoAlpha: .12, y: desktop ? 24 : 14 });
    gsap.set(teamVisual, {
      autoAlpha: .08,
      x: desktop ? -92 : 0,
      y: desktop ? 24 : 34,
      rotationY: desktop ? 5 : 0,
      scale: desktop ? .94 : .97,
      transformOrigin: '0% 50%',
    });
    gsap.set(teamFigures, {
      xPercent: index => desktop ? (index ? 13 : -5) : 0,
      yPercent: index => index ? 6 : -7,
      scale: index => index ? 1.04 : 1.1,
      rotation: index => desktop ? (index ? 2.2 : -1.4) : 0,
    });
    gsap.set(teamParts.filter(part => part !== teamSeal), {
      autoAlpha: .08,
      x: desktop ? 64 : 0,
      y: desktop ? 0 : 28,
    });
    if (teamSeal) {
      gsap.set(teamSeal, { autoAlpha: .08, scale: .58, rotation: desktop ? -16 : -8 });
    }

    const servicesTimeline = gsap.timeline({
      defaults: { overwrite: 'auto' },
      scrollTrigger: {
        id: 'rt-home-services-motion',
        trigger: services,
        start: 'top 86%',
        end: 'bottom 20%',
        scrub: desktop ? .72 : .48,
        invalidateOnRefresh: true,
        onToggle: self => services.classList.toggle('is-rt-story-active', self.isActive),
        onUpdate: self => {
          services.dataset.rtStoryState = self.progress.toFixed(3);
        },
      },
    });

    servicesTimeline
      .fromTo(servicesScan,
        { autoAlpha: 0, y: 0 },
        {
          autoAlpha: .88,
          y: () => Math.max(0, services.offsetHeight - 2),
          duration: 3.2,
          ease: 'none',
        }, 0)
      .to(headerParts, {
          autoAlpha: 1,
          y: 0,
          duration: .82,
          ease: 'power3.out',
          stagger: .1,
        }, .06)
      .to(cards, {
          autoAlpha: 1,
          x: 0,
          y: 0,
          rotationX: 0,
          rotationY: 0,
          scale: 1,
          duration: 1.42,
          ease: 'power3.out',
          stagger: .19,
        }, .38)
      .to(cardFigures, {
          scale: 1,
          yPercent: 0,
          duration: 1.52,
          ease: 'power2.out',
          stagger: .19,
        }, .4)
      .to(cardCopy, {
          autoAlpha: 1,
          y: 0,
          duration: .76,
          ease: 'power3.out',
          stagger: .055,
        }, .58)
      .to(servicesScan, { autoAlpha: 0, duration: .25, ease: 'none' }, 2.95);

    const teamTimeline = gsap.timeline({
      defaults: { overwrite: 'auto' },
      scrollTrigger: {
        id: 'rt-home-team-motion',
        trigger: team,
        start: 'top 88%',
        end: 'bottom 14%',
        scrub: desktop ? .76 : .5,
        invalidateOnRefresh: true,
        onToggle: self => team.classList.toggle('is-rt-story-active', self.isActive),
        onUpdate: self => {
          team.dataset.rtStoryState = self.progress.toFixed(3);
        },
      },
    });

    teamTimeline
      .fromTo(teamScan,
        { autoAlpha: 0, y: 0 },
        {
          autoAlpha: .86,
          y: () => Math.max(0, team.offsetHeight - 2),
          duration: 2.45,
          ease: 'none',
        }, 0)
      .to(teamVisual, {
          autoAlpha: 1,
          x: 0,
          y: 0,
          rotationY: 0,
          scale: 1,
          duration: 1.25,
          ease: 'power3.out',
        }, .08)
      .to(teamFigures, {
          xPercent: 0,
          yPercent: 0,
          scale: 1,
          rotation: 0,
          duration: 1.42,
          ease: 'power2.out',
          stagger: .13,
        }, .12)
      .to(teamParts.filter(part => part !== teamSeal), {
          autoAlpha: 1,
          x: 0,
          y: 0,
          duration: .88,
          ease: 'power3.out',
          stagger: .1,
        }, .3);

    if (teamSeal) {
      teamTimeline.to(teamSeal, {
          autoAlpha: 1,
          scale: 1,
          rotation: 0,
          duration: 1.05,
          ease: 'back.out(1.35)',
        }, .78);
    }
    if (numberMatch && teamNumber) {
      const target = Number(numberMatch[1]);
      const suffix = numberMatch[2];
      teamTimeline.to(numberState, {
        value: target,
        duration: 1.05,
        ease: 'power2.out',
        onUpdate: () => {
          teamNumber.textContent = `${Math.round(numberState.value)}${suffix}`;
        },
      }, .72);
    }
    teamTimeline.to(teamScan, { autoAlpha: 0, duration: .22, ease: 'none' }, 2.22);

    return () => {
      services.classList.remove('is-rt-story-active');
      team.classList.remove('is-rt-story-active');
      if (numberMatch && teamNumber) teamNumber.textContent = `${numberMatch[1]}${numberMatch[2]}`;
    };
  });

  /* Stillstandssicherung. Beide Erzaehlungen laufen ueber scrub-Trigger, deren
     Fortschritt vollstaendig am Bildtakt haengt. Steht der Takt still, blieben
     die fuenf Leistungskacheln und das Teamkapitel dauerhaft bei autoAlpha .06
     bis .12 stehen - lesbar ist da nichts mehr. */
  window.RailTimeStillstand?.(showStaticState);

  const refresh = () => requestAnimationFrame(() => ScrollTrigger.refresh());
  addEventListener('railtime:intro-complete', refresh, { once: true });
  addEventListener('pageshow', event => {
    if (event.persisted) refresh();
  });
  addEventListener('pagehide', event => {
    if (event.persisted) return;
    media.revert();
    media = null;
  }, { once: true });

  refresh();
})();
