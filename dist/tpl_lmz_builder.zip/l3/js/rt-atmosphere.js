/*
 * Hintergrundatmosphaere der Startseite.
 *
 * Drei sehr zurueckhaltende Ebenen hinter dem Inhalt: ein driftender roter
 * Signalschein, ein technisches Raster mit Parallaxe und eine feine Koernung.
 * Alles liegt fest im Viewport, ist nicht anklickbar und laeuft ueber
 * transform/opacity, damit kein Layout neu berechnet wird.
 *
 * Bewusst leise gehalten: Die Startseite traegt bereits Video, 3D-Logo und
 * Karte. Die Werte stehen als CSS-Variablen im Stylesheet und lassen sich
 * dort in einem Zug heller oder dunkler stellen.
 */
(() => {
  if (!document.body.classList.contains('is-home')) return;
  if (typeof gsap === 'undefined') return;
  if (matchMedia('(prefers-reduced-motion: reduce)').matches) return;

  const buehne = document.createElement('div');
  buehne.className = 'rt-atmo';
  buehne.setAttribute('aria-hidden', 'true');
  buehne.innerHTML =
    '<span class="rt-atmo__schein rt-atmo__schein--a"></span>' +
    '<span class="rt-atmo__schein rt-atmo__schein--b"></span>' +
    '<span class="rt-atmo__raster"></span>' +
    '<span class="rt-atmo__korn"></span>';
  document.body.prepend(buehne);

  const scheinA = buehne.querySelector('.rt-atmo__schein--a');
  const scheinB = buehne.querySelector('.rt-atmo__schein--b');
  const raster = buehne.querySelector('.rt-atmo__raster');

  /* --- Dauerbewegung ----------------------------------------------------- */

  // Zwei Scheine mit unterschiedlicher Dauer: die Ueberlagerung wiederholt
  // sich dadurch erst nach Minuten und wirkt nicht getaktet.
  gsap.to(scheinA, {
    xPercent: 16, yPercent: -12, scale: 1.18,
    duration: 19, ease: 'sine.inOut', repeat: -1, yoyo: true,
  });
  gsap.to(scheinB, {
    xPercent: -13, yPercent: 14, scale: 1.24,
    duration: 26, ease: 'sine.inOut', repeat: -1, yoyo: true,
  });

  /* --- Scrollkopplung ---------------------------------------------------- */

  if (typeof ScrollTrigger === 'undefined') return;

  // Das Raster zieht langsamer als der Inhalt und erzeugt Tiefe.
  gsap.to(raster, {
    yPercent: -14,
    ease: 'none',
    scrollTrigger: { start: 0, end: 'max', scrub: 1.1 },
  });

  // Der Schein wandert ueber die Seitenlaenge von der linken oberen in die
  // rechte untere Haelfte.
  gsap.to(scheinA, {
    '--rt-atmo-links': '68%',
    ease: 'none',
    scrollTrigger: { start: 0, end: 'max', scrub: 1.4 },
  });

  // Beim Verlassen des Heros wird die Atmosphaere etwas praesenter; im Hero
  // selbst wuerde sie mit Video und 3D-Logo konkurrieren.
  const hero = document.querySelector('.sa-hero, .rt-hero');
  if (hero) {
    gsap.fromTo(buehne,
      { opacity: .28 },
      {
        opacity: 1,
        ease: 'none',
        scrollTrigger: { trigger: hero, start: 'bottom 80%', end: 'bottom 20%', scrub: .8 },
      });
  }
})();
