/*
 * Sprachumschalter: Aufklappen, Tastaturbedienung, Schliessen.
 *
 * Das CSS oeffnet die Liste bereits ueber :focus-within, damit sie ohne
 * JavaScript erreichbar bleibt. Hier kommt das Verhalten dazu, das man von
 * einem Menue erwartet: Klick zum Oeffnen, Escape und Klick daneben zum
 * Schliessen, Pfeiltasten zum Wandern.
 */
(() => {
  const halter = document.querySelector('[data-rt-lang]');
  if (!halter) return;

  const knopf = halter.querySelector('.rt-lang__knopf');
  const liste = halter.querySelector('.rt-lang__liste');
  if (!knopf || !liste) return;

  const eintraege = [...liste.querySelectorAll('a')];

  const istOffen = () => halter.classList.contains('is-offen');

  const setzen = (offen) => {
    halter.classList.toggle('is-offen', offen);
    knopf.setAttribute('aria-expanded', String(offen));
  };

  const optionSichtbarHalten = eintrag => {
    if (!eintrag) return;

    const oben = eintrag.offsetTop;
    const unten = oben + eintrag.offsetHeight;
    if (oben < liste.scrollTop) {
      liste.scrollTop = oben;
    } else if (unten > liste.scrollTop + liste.clientHeight) {
      liste.scrollTop = unten - liste.clientHeight;
    }
  };

  const oeffnen = (fokusIndex = null) => {
    setzen(true);
    const zielEintrag = fokusIndex !== null
      ? eintraege[fokusIndex]
      : liste.querySelector('.is-active');

    requestAnimationFrame(() => optionSichtbarHalten(zielEintrag));
    if (fokusIndex !== null && zielEintrag) {
      zielEintrag.focus();
    }
  };

  const schliessen = ({ zurueckZumKnopf = false } = {}) => {
    setzen(false);
    // Der Fokus darf nicht in der unsichtbaren Liste haengen bleiben, sonst
    // haelt :focus-within sie offen und der Tabstopp laeuft ins Leere.
    if (zurueckZumKnopf || liste.contains(document.activeElement)) {
      knopf.focus();
    }
  };

  knopf.addEventListener('click', event => {
    event.preventDefault();
    istOffen() ? schliessen() : oeffnen();
  });

  knopf.addEventListener('keydown', event => {
    if (event.key === 'ArrowDown' || event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      oeffnen(0);
    } else if (event.key === 'ArrowUp') {
      event.preventDefault();
      oeffnen(eintraege.length - 1);
    }
  });

  liste.addEventListener('keydown', event => {
    const stelle = eintraege.indexOf(document.activeElement);

    if (event.key === 'ArrowDown') {
      event.preventDefault();
      const ziel = eintraege[(stelle + 1) % eintraege.length];
      ziel?.focus();
      optionSichtbarHalten(ziel);
    } else if (event.key === 'ArrowUp') {
      event.preventDefault();
      const ziel = eintraege[(stelle - 1 + eintraege.length) % eintraege.length];
      ziel?.focus();
      optionSichtbarHalten(ziel);
    } else if (event.key === 'Home') {
      event.preventDefault();
      eintraege[0]?.focus();
      optionSichtbarHalten(eintraege[0]);
    } else if (event.key === 'End') {
      event.preventDefault();
      eintraege[eintraege.length - 1]?.focus();
      optionSichtbarHalten(eintraege[eintraege.length - 1]);
    } else if (event.key === 'Tab') {
      // Verlaesst der Fokus die Liste, gehoert sie zu.
      setTimeout(() => {
        if (!halter.contains(document.activeElement)) setzen(false);
      }, 0);
    }
  });

  addEventListener('keydown', event => {
    if (event.key === 'Escape' && istOffen()) {
      event.preventDefault();
      schliessen({ zurueckZumKnopf: true });
    }
  });

  document.addEventListener('pointerdown', event => {
    if (istOffen() && !halter.contains(event.target)) {
      setzen(false);
    }
  });

  // Beim Wechsel auf eine andere Seite nicht offen zurueckbleiben.
  addEventListener('pagehide', () => setzen(false), { once: true });
})();
