/**
 * RailTime – eigener Seiten- und Motion-Owner fuer Leistungen / Services.
 *
 * Das vorhandene LMZ-Markup bleibt die Inhaltsquelle; nur die doppelte
 * Kacheluebersicht wird im Runtime-DOM entfernt. Das Skript ordnet Klassen und
 * vorhandene Webbilder zu, steuert das barrierearme
 * Akkordeon samt Hash-Navigation, baut reversible GSAP-Reveals auf und fuehrt
 * die Leistungsprofile auf grossen Viewports in einer angehefteten Buehne.
 * Tablet und Mobil erhalten einen eigenen, frei scrollbaren Bild-/Accordion-
 * Owner, sodass jede Darstellung dieselbe aktive Leistung abbildet.
 */
(() => {
  'use strict';

  if (!document.body.classList.contains('is-services')) return;

  const starten = () => {
    const wurzel = document.querySelector('.rt-x');
    if (!wurzel || wurzel.dataset.servicesInitialisiert) return;

    wurzel.dataset.servicesInitialisiert = 'true';
    wurzel.classList.add('rt-services');

    const eins = (auswahl, kontext = wurzel) => kontext.querySelector(auswahl);
    const alle = (auswahl, kontext = wurzel) => Array.from(kontext.querySelectorAll(auswahl));
    const sprachTag = document.documentElement.lang.toLowerCase();
    const englisch = sprachTag.startsWith('en');
    const polnisch = sprachTag.startsWith('pl');
    const textFuerSprache = (deutsch, english, polski) => (
      englisch ? english : (polnisch ? polski : deutsch)
    );
    const sparsam = matchMedia('(prefers-reduced-motion: reduce)').matches;
    const hatGsap = Boolean(window.gsap && window.ScrollTrigger && !sparsam);
    const aufraeumer = [];
    const hoere = (ziel, typ, funktion, optionen) => {
      ziel.addEventListener(typ, funktion, optionen);
      aufraeumer.push(() => ziel.removeEventListener(typ, funktion, optionen));
    };

    const vorhang = eins('.rt-x__vorhang');
    const hero = eins('.rt-x__hero');
    const heroText = eins('.rt-x__hero-text');
    const heroFigur = eins('.rt-x__hero-figur');
    const zahlen = eins('.rt-x__zahlen');
    const kachelRaster = eins('.rt-x__kacheln');
    const uebersicht = kachelRaster?.closest('.rt-x__section');
    const buehne = eins('.rt-x__buehne');
    const detail = buehne?.closest('.rt-x__section');
    const vitrine = eins('.rt-x__vitrine');
    const prozessSpur = eins('.rt-x__spur');
    const prozess = prozessSpur?.closest('.rt-x__section');
    const cta = eins('.rt-x__cta');

    if (vorhang) {
      vorhang.hidden = true;
      vorhang.style.display = 'none';
    }

    detail?.classList.add('rt-services-detail');
    prozess?.classList.add('rt-services-process');

    /* Die bisherige Kacheluebersicht wiederholt dieselben fuenf Inhalte. Sie
       wird vor jeder ScrollTrigger-Messung semantisch aus dem DOM entfernt;
       CSS blendet sie bereits waehrend des ersten Paints aus. */
    uebersicht?.remove();

    /* Wie auf Startseite und Ueber-uns sitzt das vorhandene Faktenmodul im
       unteren linken Hero-Feld. Es wird bewusst verschoben statt dupliziert,
       damit Seiteninhalte, Counter und Uebersetzungen die Quelle bleiben. */
    if (hero && zahlen && zahlen.parentElement !== hero) hero.append(zahlen);
    const zahlenCodes = textFuerSprache(
      ['01 / TEAM', '02 / BEREITSCHAFT', '03 / NETZ'],
      ['01 / TEAM', '02 / AVAILABILITY', '03 / NETWORK'],
      ['01 / ZESPÓŁ', '02 / GOTOWOŚĆ', '03 / SIEĆ'],
    );
    alle('.rt-x__zahl', zahlen).forEach((zahl, index) => {
      zahl.dataset.servicesCode = zahlenCodes[index] || String(index + 1).padStart(2, '0');
    });

    if (heroFigur) {
      heroFigur.dataset.servicesLabel = textFuerSprache(
        'EINSATZLEISTUNGEN / 01',
        'FIELD SERVICES / 01',
        'USŁUGI TERENOWE / 01',
      );
    }
    if (vitrine) {
      vitrine.dataset.servicesStageLabel = textFuerSprache(
        'LEISTUNGSPROFIL',
        'SERVICE PROFILE',
        'PROFIL USŁUGI',
      );

      const bildWischer = document.createElement('span');
      bildWischer.className = 'rt-services-image-scan';
      bildWischer.setAttribute('aria-hidden', 'true');
      vitrine.append(bildWischer);
    }

    /* Die Vitrine zeigt inzwischen die eigene, einheitlich veredelte
       Mitarbeiter-Bildserie direkt aus der Inhaltsdatenbank. Nur der Hero
       bekommt hier das 3:2-Serienmotiv mit hoher Ladeprioritaet. */
    /* Motiv und Alt-Text kommen ausschliesslich aus dem LMZ Page Builder.
       Bildaenderungen im Builder werden damit unmittelbar sichtbar.
       Hier wird nur noch das Ladeverhalten vereinheitlicht; die noch
       uebergebenen Pfad- und Alt-Argumente werden absichtlich ignoriert.
       (Aufraeumen der inzwischen wirkungslosen Pfad-/Alt-Tabellen: offen.) */
    const setzeBild = (bild, pfad, alt, eilig = false) => {
      if (!bild) return;
      bild.decoding = 'async';
      if (eilig) {
        bild.removeAttribute('loading');
        bild.setAttribute('fetchpriority', 'high');
      } else {
        bild.loading = 'lazy';
      }
    };

    /* Eigene Hochformat-Crops halten den aktiven Bildinhalt auf Desktop im
       hohen Vitrinenfenster und auf Mobile im mittigen Querformat-Ausschnitt. */
    const servicePfade = [
      'serie/v2/rt-service-wagenmeister.webp',
      'serie/v2/rt-service-notdienst.webp',
      'serie/v2/rt-service-kv-trailer.webp',
      'serie/v2/rt-service-sonderuntersuchung.webp',
      'serie/v2/rt-service-pufferteller.webp',
    ];
    const serviceAlts = textFuerSprache(
      [
        'Wagenmeister bei der digitalen Einsatzdokumentation im G\u00fcterbahnhof',
        'Mitarbeiter im Bahnbetrieb bereit f\u00fcr einen Notfalleinsatz am Gleis',
        'Technischer Au\u00dfeneinsatz im kombinierten Eisenbahnverkehr',
        'Pr\u00fcfteam bei einer Sonderuntersuchung an einem G\u00fcterwagen',
        'Pufferteller eines G\u00fcterwagens vor der Wartung',
      ],
      [
          'Wagon inspector documenting an assignment digitally at the freight yard',
          'Rail operations employee ready for an emergency assignment at the track',
          'Technical field assignment in combined rail transport',
          'Inspection team carrying out a special examination on a freight wagon',
          'Buffer plate on a freight wagon before maintenance',
      ],
      [
        'Rewident taboru podczas cyfrowej dokumentacji zlecenia na stacji towarowej',
        'Pracownik ruchu kolejowego gotowy do interwencji awaryjnej przy torze',
        'Techniczna realizacja zlecenia w terenie w transporcie intermodalnym',
        'Zespół kontrolny podczas badania specjalnego wagonu towarowego',
        'Tarcza zderzakowa wagonu towarowego przed konserwacją',
      ],
    );

    setzeBild(
      heroFigur?.querySelector('img'),
      'serie/v2/rt-services-hero-goldene-stunde.webp',
      textFuerSprache(
        'Wagenmeister bei der Wagenpr\u00fcfung im Abendlicht',
        'Wagon inspector checking a freight wagon in evening light',
        'Rewident taboru podczas kontroli wagonu w wieczornym świetle',
      ),
      true,
    );

    alle('.rt-x__vitrine figure img').forEach((bild, index) => {
      setzeBild(bild, servicePfade[index], serviceAlts[index]);
    });
    setzeBild(
      cta?.querySelector('img'),
      'serie/v2/rt-services-cta-einsatz.webp',
      textFuerSprache(
        'Einsatzteam bereitet den n\u00e4chsten Einsatz vor',
        'Field team preparing the next assignment',
        'Zespół przygotowujący kolejne zlecenie w terenie',
      ),
    );

    /* Alle Anfrage-Links auf das bereits korrekt geroutete Ziel der aktiven
       Navigation heben. So bleiben DE, EN und der Joomla-Unterordner korrekt. */
    const kontaktZiel = document.querySelector(
      '.rt-nav nav a[href$="/kontakt"], .rt-nav nav a[href$="/contact"]',
    );
    if (kontaktZiel) {
      alle('a').forEach((link) => {
        let pfad = '';
        try { pfad = new URL(link.href, location.href).pathname; } catch { return; }
        if (/(?:\/)(?:kontakt|contact)\/?$/u.test(pfad)) link.href = kontaktZiel.href;
      });
    }

    /* ---------------------------------------------------------------- *
     * Akkordeon, Bildwechsel und Hash-Navigation
     * ---------------------------------------------------------------- */

    const eintraege = alle('.rt-x__eintrag');
    const felder = eintraege.map((eintrag) => eintrag.querySelector('.rt-x__feld'));
    const koepfe = eintraege.map((eintrag) => eintrag.querySelector('.rt-x__kopf'));
    const bilder = alle('.rt-x__vitrine figure');
    const bildWischer = eins('.rt-services-image-scan');
    const grosseNummer = eins('.rt-x__vitrine-nr');
    const fortschritt = eins('.rt-x__fortschritt-spur i');
    const zaehler = eins('[data-x-zaehler]');
    const zweistellig = (wert) => String(wert).padStart(2, '0');
    let aktiverIndex = -1;
    let refreshFrame = 0;
    let detailAnheftung = null;
    let detailNavigation = null;
    let detailMedia = null;
    let programmatischesZiel = -1;
    let bildTimeline = null;

    const refresh = () => {
      /* Accordion-Hoehen duerfen die Desktop-Pin-Geometrie weder waehrend
         der Anheftung noch unmittelbar nach ihrem Verlassen neu vermessen.
         Reguläre ScrollTrigger-Refreshes (unter anderem bei Resize) bleiben
         davon unberuehrt, weil nur dieser Accordion-Helfer gesperrt wird. */
      if (!hatGsap || refreshFrame || detailAnheftung) return;
      refreshFrame = requestAnimationFrame(() => {
        refreshFrame = 0;
        ScrollTrigger.refresh();
      });
    };

    const indexAusHash = () => {
      if (!location.hash) return -1;
      let slug = location.hash.slice(1);
      try { slug = decodeURIComponent(slug); } catch { /* Rohwert pruefen. */ }
      return eintraege.findIndex((eintrag) => eintrag.id === slug);
    };

    const setzeHash = (index) => {
      const slug = index >= 0 ? eintraege[index]?.id : '';
      const ziel = `${location.pathname}${location.search}${slug ? `#${encodeURIComponent(slug)}` : ''}`;
      history.replaceState(null, '', ziel);
    };

    const setzeFeld = (feld, offen, sofort, offeneHoehe = 0, aktuelleHoehe = 0) => {
      if (!feld) return;

      feld.setAttribute('aria-hidden', String(!offen));
      feld.toggleAttribute('inert', !offen);

      /* Ein sofort erzwungener Scroll-/Leave-Zustand muss einen eventuell
         noch laufenden Hoehen-Tween zuerst beenden. Sonst schreibt dessen
         onComplete spaeter erneut die Hoehe und startet einen Refresh. */
      if (hatGsap) gsap.killTweensOf(feld);

      if (!hatGsap || sofort) {
        feld.style.height = offen ? 'auto' : '0px';
        return;
      }

      if (offen) {
        gsap.set(feld, { height: 0 });
        gsap.to(feld, {
          height: offeneHoehe,
          duration: .48,
          ease: 'power2.inOut',
          overwrite: 'auto',
          onComplete: () => {
            feld.style.height = 'auto';
            refresh();
          },
        });
      } else {
        gsap.set(feld, { height: aktuelleHoehe || feld.getBoundingClientRect().height });
        gsap.to(feld, {
          height: 0,
          duration: .38,
          ease: 'power2.inOut',
          overwrite: 'auto',
          onComplete: refresh,
        });
      }
    };

    const setzeBildzustand = (index, vorherigerIndex, sofort) => {
      const zielFigur = index >= 0 ? bilder[index] : null;
      const alteFigur = vorherigerIndex >= 0 && vorherigerIndex !== index
        ? bilder[vorherigerIndex]
        : null;
      const richtung = vorherigerIndex < 0 || index >= vorherigerIndex ? 1 : -1;

      bildTimeline?.kill();
      bildTimeline = null;

      bilder.forEach((figur, bildIndex) => {
        figur.classList.toggle('is-aktiv', bildIndex === index);
        if (hatGsap) gsap.killTweensOf([figur, figur.querySelector('img')].filter(Boolean));
      });

      if (!hatGsap || sofort || !zielFigur) {
        bilder.forEach((figur, bildIndex) => {
          const aktiv = bildIndex === index;
          if (hatGsap) {
            gsap.set(figur, {
              autoAlpha: aktiv ? 1 : 0,
              xPercent: 0,
              scale: 1,
              clipPath: 'inset(0 0% 0 0)',
              zIndex: aktiv ? 2 : 0,
            });
            const bild = figur.querySelector('img');
            if (bild) gsap.set(bild, { xPercent: 0, scale: 1 });
          } else {
            figur.style.opacity = aktiv ? '1' : '0';
            figur.style.visibility = aktiv ? 'visible' : 'hidden';
          }
        });
        if (hatGsap && bildWischer) gsap.set(bildWischer, { autoAlpha: 0 });
        return;
      }

      const zielBild = zielFigur.querySelector('img');
      const startMaske = richtung > 0
        ? 'inset(0 100% 0 0)'
        : 'inset(0 0 0 100%)';

      bilder.forEach((figur) => {
        if (figur !== zielFigur && figur !== alteFigur) {
          gsap.set(figur, { autoAlpha: 0, xPercent: 0, scale: 1, zIndex: 0 });
        }
      });

      if (alteFigur) {
        gsap.set(alteFigur, {
          autoAlpha: 1,
          xPercent: 0,
          scale: 1,
          clipPath: 'inset(0 0% 0 0)',
          zIndex: 1,
        });
      }
      gsap.set(zielFigur, {
        autoAlpha: 1,
        xPercent: richtung * 8,
        scale: 1.015,
        clipPath: startMaske,
        zIndex: 2,
      });
      if (zielBild) gsap.set(zielBild, { xPercent: richtung * 2.4, scale: 1.085 });

      bildTimeline = gsap.timeline({
        defaults: { overwrite: 'auto' },
        onComplete: () => {
          bilder.forEach((figur, bildIndex) => {
            gsap.set(figur, {
              autoAlpha: bildIndex === index ? 1 : 0,
              xPercent: 0,
              scale: 1,
              clipPath: 'inset(0 0% 0 0)',
              zIndex: bildIndex === index ? 2 : 0,
            });
          });
          if (bildWischer) gsap.set(bildWischer, { autoAlpha: 0 });
          bildTimeline = null;
        },
      });

      if (alteFigur) {
        bildTimeline.to(alteFigur, {
          autoAlpha: 0,
          xPercent: richtung * -4,
          scale: .985,
          duration: .44,
          ease: 'power2.inOut',
        }, 0);
      }
      bildTimeline.to(zielFigur, {
        xPercent: 0,
        scale: 1,
        clipPath: 'inset(0 0% 0 0)',
        duration: .72,
        ease: 'power3.inOut',
      }, .06);
      if (zielBild) {
        bildTimeline.to(zielBild, {
          xPercent: 0,
          scale: 1,
          duration: .96,
          ease: 'power3.out',
        }, .06);
      }
      if (bildWischer) {
        bildTimeline.fromTo(bildWischer, {
          autoAlpha: 0,
          xPercent: richtung > 0 ? -150 : 150,
        }, {
          autoAlpha: .72,
          xPercent: richtung > 0 ? 285 : -285,
          duration: .66,
          ease: 'power2.inOut',
        }, .08).to(bildWischer, { autoAlpha: 0, duration: .18 }, .55);
      }
    };

    const richteScrollzustandAus = (zielIndex, optionen = {}) => {
      requestAnimationFrame(() => {
        if (detailNavigation) {
          detailNavigation.springeZu(zielIndex, optionen);
        } else if (detailAnheftung) {
          const anteil = (zielIndex + .5) / eintraege.length;
          const zielY = detailAnheftung.start
            + (detailAnheftung.end - detailAnheftung.start) * anteil;
          scrollTo({
            top: zielY,
            left: 0,
            behavior: sparsam || optionen.sofort ? 'auto' : 'smooth',
          });
        } else {
          eintraege[zielIndex].scrollIntoView({
            behavior: sparsam || optionen.sofort ? 'auto' : 'smooth',
            block: 'start',
          });
        }
        if (optionen.fokus) koepfe[zielIndex]?.focus({ preventScroll: true });
      });
    };

    const aktiviere = (index, optionen = {}) => {
      const zielIndex = index >= 0 && index < eintraege.length ? index : -1;
      if (zielIndex === aktiverIndex && !optionen.erzwingen) {
        if (optionen.hash) setzeHash(zielIndex);
        if (optionen.scrollen && zielIndex >= 0) {
          detailNavigation?.vorbereiten(zielIndex);
          richteScrollzustandAus(zielIndex, optionen);
        }
        return;
      }

      /* Bei einer Klick- oder Hash-Navigation wird der Scrollzustand vor dem
         sichtbaren Akkordeonwechsel reserviert. So kann onLeaveBack den eben
         gewaehlten Index nicht im selben Frame wieder auf 01 zuruecksetzen. */
      if (optionen.scrollen && zielIndex >= 0) {
        detailNavigation?.vorbereiten(zielIndex);
      }

      const vorherigerIndex = aktiverIndex;
      const vorherigeHoehe = vorherigerIndex >= 0
        ? felder[vorherigerIndex]?.getBoundingClientRect().height || 0
        : 0;
      const offeneHoehe = zielIndex >= 0 ? felder[zielIndex]?.scrollHeight || 0 : 0;
      aktiverIndex = zielIndex;

      eintraege.forEach((eintrag, eintragIndex) => {
        const offen = eintragIndex === zielIndex;
        const feldSofort = Boolean(optionen.sofort)
          || (!offen && eintragIndex !== vorherigerIndex);
        eintrag.classList.toggle('is-offen', offen);
        koepfe[eintragIndex]?.setAttribute('aria-expanded', String(offen));
        setzeFeld(
          felder[eintragIndex],
          offen,
          feldSofort,
          offen ? offeneHoehe : 0,
          eintragIndex === vorherigerIndex ? vorherigeHoehe : 0,
        );
      });

      setzeBildzustand(zielIndex, vorherigerIndex, Boolean(optionen.sofort));
      if (grosseNummer) grosseNummer.textContent = zielIndex >= 0 ? zweistellig(zielIndex + 1) : '--';
      if (zaehler) zaehler.textContent = `${zielIndex >= 0 ? zweistellig(zielIndex + 1) : '00'} / ${zweistellig(eintraege.length)}`;

      const stand = zielIndex >= 0 && eintraege.length ? (zielIndex + 1) / eintraege.length : 0;
      /* Im angehefteten Desktop-Bereich ist ausschliesslich der reale
         ScrollTrigger-Fortschritt massgeblich. Ein Akkordeonklick darf die
         Leiste nicht vorab auf einen davon abweichenden Tab-Wert setzen. */
      if (fortschritt && !detailAnheftung) {
        if (hatGsap && !optionen.sofort) {
          gsap.to(fortschritt, {
            scaleX: stand,
            transformOrigin: 'left center',
            duration: .42,
            ease: 'power2.out',
            overwrite: 'auto',
          });
        } else {
          fortschritt.style.transformOrigin = 'left center';
          fortschritt.style.transform = `scaleX(${stand})`;
        }
      }

      if (optionen.hash) setzeHash(zielIndex);
      if (optionen.scrollen && zielIndex >= 0) {
        richteScrollzustandAus(zielIndex, optionen);
      }
    };

    const startIndex = indexAusHash();

    if (eintraege.length) {
      wurzel.dataset.servicesEnhanced = 'true';

      eintraege.forEach((eintrag, index) => {
        const kopf = koepfe[index];
        const feld = felder[index];
        if (!kopf || !feld) return;

        if (!kopf.id) kopf.id = `rt-services-head-${index + 1}`;
        if (!feld.id) feld.id = `rt-services-panel-${index + 1}`;
        kopf.setAttribute('aria-controls', feld.id);
        feld.setAttribute('role', 'region');
        feld.setAttribute('aria-labelledby', kopf.id);

        hoere(kopf, 'click', () => {
          const schliessen = !detailNavigation
            && index === aktiverIndex
            && eintrag.classList.contains('is-offen');
          aktiviere(schliessen ? -1 : index, {
            hash: true,
            scrollen: Boolean(detailNavigation),
          });
        });
      });

      const beiHashwechsel = () => {
        const index = indexAusHash();
        if (index >= 0) aktiviere(index, { scrollen: true, erzwingen: true });
      };
      hoere(window, 'hashchange', beiHashwechsel);

      /* Der Browser versucht einen Fragmentanker waehrend des Seitenaufbaus
         selbst anzuspringen. Der gewuenschte Index bleibt bis zur fertigen
         Desktop- oder Mobil-Geometrie reserviert, damit der native Sprung das
         Akkordeon nicht kurzzeitig auf einen Zwischenstand zuruecksetzt. */
      if (startIndex >= 0 && hatGsap) programmatischesZiel = startIndex;

      aktiviere(startIndex >= 0 ? startIndex : 0, { sofort: true, erzwingen: true });

      /* Ohne GSAP/Pin bleibt der native Ankerpfad erhalten. In der Desktop-
         Buehne wird der Startanker erst nach dem finalen Refresh auf die
         passende ScrollTrigger-Segmentmitte ausgerichtet. */
      if (startIndex >= 0 && !hatGsap) {
        const ankerAusrichten = () => requestAnimationFrame(() => {
          eintraege[startIndex].scrollIntoView({ behavior: 'auto', block: 'start' });
        });
        if (document.readyState === 'complete') ankerAusrichten();
        else hoere(window, 'load', ankerAusrichten, { once: true });
      }
    }

    /* ---------------------------------------------------------------- *
     * Einmalige GSAP-Reveals – keine Pins, kein Scrub
     * ---------------------------------------------------------------- */

    let bewegungsKontext = null;
    let heroNotausstieg = 0;

    const allesSichtbar = () => {
      clearTimeout(heroNotausstieg);
      if (!window.gsap) return;
      if (heroText) gsap.set([...heroText.children], { clearProps: 'transform,opacity,visibility' });
      if (heroFigur) gsap.set(heroFigur, { clearProps: 'transform,opacity,visibility,clipPath' });
      if (heroFigur?.firstElementChild) {
        gsap.set(heroFigur.firstElementChild, { clearProps: 'transform,opacity,visibility' });
      }
    };

    if (!hatGsap) {
      prozessSpur?.style.setProperty('--services-process-line', '1');
      wurzel.dataset.servicesBereit = 'statisch';
    } else {
      gsap.registerPlugin(ScrollTrigger);
      if (window.ScrollToPlugin) gsap.registerPlugin(ScrollToPlugin);
      gsap.config({ nullTargetWarn: false });
      wurzel.dataset.servicesBereit = 'gsap';

      try {
        bewegungsKontext = gsap.context(() => {
          const heroTeile = heroText ? [...heroText.children] : [];
          const heroBild = heroFigur?.querySelector('img');

          gsap.set(heroTeile, { autoAlpha: 0, y: 30 });
          if (heroFigur) {
            gsap.set(heroFigur, { autoAlpha: 0, clipPath: 'inset(0 0 100% 0)' });
          }
          if (heroBild) gsap.set(heroBild, { scale: 1.055, transformOrigin: '50% 50%' });

          const heroTimeline = gsap.timeline({
            defaults: { overwrite: 'auto' },
            onComplete: allesSichtbar,
          });
          heroTimeline.to(heroTeile, {
            autoAlpha: 1,
            y: 0,
            duration: .76,
            ease: 'power3.out',
            stagger: .07,
          }, 0);
          if (heroFigur) {
            heroTimeline.to(heroFigur, {
              autoAlpha: 1,
              clipPath: 'inset(0 0 0% 0)',
              duration: .9,
              ease: 'power3.inOut',
            }, .12);
          }
          if (heroBild) {
            heroTimeline.to(heroBild, {
              scale: 1,
              duration: 1.08,
              ease: 'power3.out',
            }, .18);
          }

          heroNotausstieg = window.setTimeout(allesSichtbar, 3200);

          if (zahlen) {
            const felderZahlen = [...zahlen.children];
            const zaehlerFeld = felderZahlen[0]?.querySelector('strong');
            const treffer = zaehlerFeld?.textContent.trim().match(/^(\d+)(\D*)$/);
            gsap.fromTo(felderZahlen,
              { autoAlpha: 0, y: 28 },
              {
                autoAlpha: 1,
                y: 0,
                duration: .72,
                ease: 'power3.out',
                stagger: .11,
                scrollTrigger: {
                  id: 'rt-services-facts',
                  trigger: zahlen,
                  start: 'top 92%',
                  toggleActions: 'play none none reverse',
                },
              });

            if (treffer) {
              const ziel = Number(treffer[1]);
              const anhang = treffer[2];
              const stand = { wert: 0 };
              ScrollTrigger.create({
                id: 'rt-services-counter',
                trigger: zahlen,
                start: 'top 92%',
                once: true,
                onEnter: () => gsap.to(stand, {
                  wert: ziel,
                  duration: 1.15,
                  ease: 'power2.out',
                  onUpdate: () => { zaehlerFeld.textContent = `${Math.round(stand.wert)}${anhang}`; },
                  onComplete: () => { zaehlerFeld.textContent = `${ziel}${anhang}`; },
                }),
              });
            }
          }

          if (detail && buehne) {
            const kopf = detail.querySelector('header');
            const detailTimeline = gsap.timeline({
              scrollTrigger: {
                id: 'rt-services-detail',
                trigger: detail,
                start: 'top 75%',
                toggleActions: 'play none none reverse',
              },
            });
            if (kopf) {
              detailTimeline.fromTo([...kopf.children],
                { autoAlpha: 0, y: 28 },
                { autoAlpha: 1, y: 0, duration: .66, ease: 'power3.out', stagger: .08 }, 0);
            }
            if (vitrine) {
              detailTimeline.fromTo(vitrine,
                { autoAlpha: 0, x: -30 },
                { autoAlpha: 1, x: 0, duration: .78, ease: 'power3.out' }, .12);
            }
            detailTimeline.fromTo(eintraege,
              { autoAlpha: 0, x: 28 },
              { autoAlpha: 1, x: 0, duration: .62, ease: 'power3.out', stagger: .065 }, .2);

            /* Desktop heftet die gesamte Buehne an. Tablet und Mobil behalten
               den Dokumentfluss, erhalten aber feste, reversible Wechselpunkte
               fuer Accordion, Bild, Fortschritt und Hash. */
            if (eintraege.length > 1) {
              detailMedia = gsap.matchMedia();
              detailMedia.add('(min-width: 1001px)', () => {
                buehne.classList.add('is-services-scroll-stage');
                const pinVersatz = () => Math.max(
                  104,
                  Math.round((window.innerHeight - buehne.offsetHeight) / 2),
                );
                const anzahl = eintraege.length;
                const mindestWechselabstand = 460;
                const segmentHysterese = .018;
                let anstehenderIndex = Math.max(0, aktiverIndex);
                let stabilerIndex = anstehenderIndex;
                let wechselTimer = 0;
                let letzterWechsel = 0;
                let navigationsTimer = 0;
                let navigationslauf = 0;

                const stoppeWechselTimer = () => {
                  if (!wechselTimer) return;
                  clearTimeout(wechselTimer);
                  wechselTimer = 0;
                };
                const stoppeNavigationsTimer = () => {
                  if (!navigationsTimer) return;
                  clearTimeout(navigationsTimer);
                  navigationsTimer = 0;
                };
                const begrenzeIndex = index => Math.max(0, Math.min(anzahl - 1, index));
                const indexOhneHysterese = fortschritt => begrenzeIndex(
                  Math.floor(Math.min(.999999, Math.max(0, fortschritt)) * anzahl),
                );
                const bereiteIndexzielVor = (index) => {
                  const zielIndex = begrenzeIndex(index);
                  stoppeWechselTimer();
                  stoppeNavigationsTimer();
                  programmatischesZiel = zielIndex;
                  anstehenderIndex = zielIndex;
                  stabilerIndex = zielIndex;
                };
                const indexMitHysterese = (fortschritt) => {
                  while (
                    stabilerIndex < anzahl - 1
                    && fortschritt >= ((stabilerIndex + 1) / anzahl) + segmentHysterese
                  ) stabilerIndex += 1;
                  while (
                    stabilerIndex > 0
                    && fortschritt < (stabilerIndex / anzahl) - segmentHysterese
                  ) stabilerIndex -= 1;
                  return stabilerIndex;
                };
                const uebernehmeAnstehendenIndex = (sofort = false) => {
                  stoppeWechselTimer();
                  if (programmatischesZiel >= 0 || anstehenderIndex === aktiverIndex) return;

                  const seitLetztemWechsel = performance.now() - letzterWechsel;
                  const rest = sofort ? 0 : Math.max(0, mindestWechselabstand - seitLetztemWechsel);
                  if (rest > 0) {
                    wechselTimer = window.setTimeout(
                      () => uebernehmeAnstehendenIndex(true),
                      rest,
                    );
                    return;
                  }

                  aktiviere(anstehenderIndex, { hash: true });
                  letzterWechsel = performance.now();
                };
                const planeIndexwechsel = (index, geschwindigkeit) => {
                  if (index === anstehenderIndex) return;
                  anstehenderIndex = index;
                  stoppeWechselTimer();

                  /* Schnelle Wheel-/Trackpad-Impulse werden auf den neuesten
                     Zielzustand zusammengefaltet. Dadurch blitzen nicht vier
                     Profile in 200 ms auf; nach einer kurzen Ruhephase folgt
                     genau ein sauberer Akkordeon- und Bildwechsel. */
                  const ruhephase = Math.abs(geschwindigkeit) > 1100 ? 210 : 105;
                  const seitLetztemWechsel = performance.now() - letzterWechsel;
                  const wartezeit = Math.max(
                    ruhephase,
                    mindestWechselabstand - seitLetztemWechsel,
                  );
                  wechselTimer = window.setTimeout(
                    () => uebernehmeAnstehendenIndex(true),
                    Math.max(0, wartezeit),
                  );
                };
                const beiScrollEnde = () => uebernehmeAnstehendenIndex(false);
                ScrollTrigger.addEventListener('scrollEnd', beiScrollEnde);

                const anheftung = ScrollTrigger.create({
                  id: 'rt-services-stage-scroll',
                  trigger: buehne,
                  start: () => `top top+=${pinVersatz()}`,
                  end: () => `+=${anzahl * 780}`,
                  pin: true,
                  pinSpacing: true,
                  anticipatePin: 1,
                  invalidateOnRefresh: true,
                  onUpdate: (selbst) => {
                    if (fortschritt) {
                      gsap.set(fortschritt, {
                        scaleX: selbst.progress,
                        transformOrigin: 'left center',
                      });
                    }
                    if (programmatischesZiel >= 0) {
                      anstehenderIndex = programmatischesZiel;
                      stabilerIndex = programmatischesZiel;
                      return;
                    }
                    planeIndexwechsel(
                      indexMitHysterese(selbst.progress),
                      selbst.getVelocity(),
                    );
                  },
                  onLeave: () => {
                    if (programmatischesZiel >= 0) return;
                    stoppeWechselTimer();
                    anstehenderIndex = anzahl - 1;
                    stabilerIndex = anzahl - 1;
                    aktiviere(anzahl - 1, { sofort: true, erzwingen: true, hash: true });
                  },
                  onLeaveBack: () => {
                    if (programmatischesZiel >= 0) return;
                    stoppeWechselTimer();
                    anstehenderIndex = 0;
                    stabilerIndex = 0;
                    aktiviere(0, { sofort: true, erzwingen: true, hash: true });
                  },
                });
                detailAnheftung = anheftung;
                const navigationszielAbschliessen = (index, lauf) => {
                  if (lauf !== navigationslauf) return;
                  stoppeNavigationsTimer();
                  anstehenderIndex = index;
                  stabilerIndex = index;
                  if (aktiverIndex !== index) {
                    aktiviere(index, { sofort: true, erzwingen: true });
                  }
                  programmatischesZiel = -1;
                  ScrollTrigger.update();
                  if (fortschritt) {
                    gsap.set(fortschritt, {
                      scaleX: anheftung.progress,
                      transformOrigin: 'left center',
                    });
                  }
                };
                const navigationszielAbbrechen = (lauf) => {
                  if (lauf !== navigationslauf || programmatischesZiel < 0) return;
                  stoppeNavigationsTimer();
                  programmatischesZiel = -1;

                  /* Ein echter Wheel-/Touch-/Tastaturimpuls gewinnt gegen
                     die Tab-Navigation. Accordion und Fortschritt werden auf
                     den real erreichten ScrollTrigger-Abschnitt abgeglichen,
                     ohne zur angeklickten Position zurueckzuspringen. */
                  const scrollIndex = indexOhneHysterese(anheftung.progress);
                  anstehenderIndex = scrollIndex;
                  stabilerIndex = scrollIndex;
                  if (aktiverIndex !== scrollIndex) {
                    aktiviere(scrollIndex, {
                      sofort: true,
                      erzwingen: true,
                      hash: true,
                    });
                  }
                  ScrollTrigger.update();
                  if (fortschritt) {
                    gsap.set(fortschritt, {
                      scaleX: anheftung.progress,
                      transformOrigin: 'left center',
                    });
                  }
                };
                /* Abbruchwache statt autoKill.
                   autoKill von ScrollToPlugin bricht ab, sobald die
                   Scrollposition von der erwarteten abweicht. Beim Klick
                   oeffnet sich aber im selben Moment das Akkordeonfeld, was
                   die Dokumenthoehe aendert - autoKill wertete das als
                   Benutzer-Scroll und brach den Sprung sofort ab (sichtbar
                   als kurzes Aufblitzen ohne Wirkung). Ein echter Abbruch
                   wird deshalb an konkreten Eingabe-Ereignissen erkannt. */
                let abbruchwache = null;
                const loeseAbbruchwache = () => {
                  if (!abbruchwache) return;
                  ['wheel', 'touchstart', 'keydown'].forEach(
                    art => window.removeEventListener(art, abbruchwache, true),
                  );
                  abbruchwache = null;
                };
                const setzeAbbruchwache = (tween, lauf) => {
                  loeseAbbruchwache();
                  const scrolltasten = [
                    'ArrowUp', 'ArrowDown', 'PageUp', 'PageDown', 'Home', 'End', ' ', 'Spacebar',
                  ];
                  abbruchwache = (ereignis) => {
                    if (ereignis.type === 'keydown' && !scrolltasten.includes(ereignis.key)) return;
                    loeseAbbruchwache();
                    tween.kill();
                    navigationszielAbbrechen(lauf);
                  };
                  ['wheel', 'touchstart', 'keydown'].forEach(
                    art => window.addEventListener(art, abbruchwache, { passive: true, capture: true }),
                  );
                };

                const springeZuIndex = (index, optionen = {}) => {
                  const zielIndex = begrenzeIndex(index);
                  const lauf = ++navigationslauf;
                  gsap.killTweensOf(window);
                  loeseAbbruchwache();
                  bereiteIndexzielVor(zielIndex);
                  if (aktiverIndex !== zielIndex) {
                    aktiviere(zielIndex, { sofort: true, erzwingen: true });
                  }
                  const anteil = (zielIndex + .5) / anzahl;
                  const zielY = anheftung.start
                    + (anheftung.end - anheftung.start) * anteil;
                  const sofort = sparsam || Boolean(optionen.sofort);

                  if (window.ScrollToPlugin && !sofort) {
                    const tween = gsap.to(window, {
                      scrollTo: { y: zielY, autoKill: false },
                      duration: .78,
                      ease: 'power2.inOut',
                      overwrite: 'auto',
                      onComplete: () => {
                        loeseAbbruchwache();
                        navigationszielAbschliessen(zielIndex, lauf);
                      },
                      onInterrupt: () => {
                        loeseAbbruchwache();
                        navigationszielAbbrechen(lauf);
                      },
                    });
                    setzeAbbruchwache(tween, lauf);
                    return;
                  }

                  scrollTo({
                    top: zielY,
                    left: 0,
                    behavior: sofort ? 'auto' : 'smooth',
                  });
                  if (sofort) navigationszielAbschliessen(zielIndex, lauf);
                  else {
                    navigationsTimer = window.setTimeout(
                      () => navigationszielAbschliessen(zielIndex, lauf),
                      850,
                    );
                  }
                };
                detailNavigation = {
                  vorbereiten: bereiteIndexzielVor,
                  springeZu: springeZuIndex,
                };
                wurzel.dataset.servicesScroll = 'pinned';
                wurzel.dataset.servicesScrollTempo = 'paced';

                return () => {
                  navigationslauf += 1;
                  loeseAbbruchwache();
                  stoppeWechselTimer();
                  stoppeNavigationsTimer();
                  ScrollTrigger.removeEventListener('scrollEnd', beiScrollEnde);
                  if (detailAnheftung === anheftung) detailAnheftung = null;
                  if (detailNavigation?.springeZu === springeZuIndex) detailNavigation = null;
                  programmatischesZiel = -1;
                  buehne.classList.remove('is-services-scroll-stage');
                  delete wurzel.dataset.servicesScroll;
                  delete wurzel.dataset.servicesScrollTempo;
                };
              });

              detailMedia.add('(max-width: 1000px)', () => {
                buehne.classList.add('is-services-mobile-scroll-stage');
                const anzahl = eintraege.length;
                const begrenzeIndex = index => Math.max(0, Math.min(anzahl - 1, index));
                const setzeMobileEintragshoehen = () => {
                  eintraege.forEach((eintrag, index) => {
                    const kopfHoehe = koepfe[index]?.getBoundingClientRect().height || 0;
                    const feldHoehe = felder[index]?.scrollHeight || 0;
                    eintrag.style.setProperty(
                      '--services-mobile-entry-height',
                      `${Math.ceil(kopfHoehe + feldHoehe + 1)}px`,
                    );
                  });
                };
                setzeMobileEintragshoehen();
                const aktivierungsLinie = () => Math.round(
                  Math.max(170, Math.min(innerHeight * .72, innerHeight - 88)),
                );
                const scrollZiel = index => Math.max(
                  0,
                  scrollY + koepfe[index].getBoundingClientRect().top - aktivierungsLinie(),
                );
                const scrollTrigger = [];
                let navigationsTimer = 0;
                let navigationslauf = 0;
                let letzteBreite = innerWidth;

                const stoppeNavigationsTimer = () => {
                  if (!navigationsTimer) return;
                  clearTimeout(navigationsTimer);
                  navigationsTimer = 0;
                };
                const bereiteIndexzielVor = (index) => {
                  stoppeNavigationsTimer();
                  gsap.killTweensOf(window);
                  programmatischesZiel = begrenzeIndex(index);
                };
                const uebernehmeScrollIndex = (index) => {
                  if (programmatischesZiel >= 0 || index === aktiverIndex) return;
                  aktiviere(begrenzeIndex(index), { hash: true });
                };
                const indexAusScrollposition = () => scrollTrigger.reduce(
                  (index, trigger, triggerIndex) => (
                    scrollY >= trigger.start ? triggerIndex : index
                  ),
                  0,
                );
                const navigationszielAbschliessen = (index, lauf) => {
                  if (lauf !== navigationslauf) return;
                  stoppeNavigationsTimer();

                  /* Accordion-Hoehen veraendern sich waehrend der Fahrt. Die
                     Geometrie wird deshalb zuerst final gemessen; erst danach
                     setzt die Korrektur den Kopf auf die Aktivierungslinie. */
                  ScrollTrigger.refresh();
                  const korrektur = scrollZiel(index);
                  if (Math.abs(scrollY - korrektur) > 2) {
                    scrollTo({ top: korrektur, left: 0, behavior: 'auto' });
                  }
                  if (aktiverIndex !== index) {
                    aktiviere(index, { sofort: true, erzwingen: true, hash: true });
                  }
                  programmatischesZiel = -1;
                  ScrollTrigger.update();
                };
                const navigationszielAbbrechen = (lauf) => {
                  if (lauf !== navigationslauf || programmatischesZiel < 0) return;
                  stoppeNavigationsTimer();
                  programmatischesZiel = -1;

                  /* Ein bewusstes Weiterwischen gewinnt auch mobil gegen den
                     Tab-Sprung. Der aktuelle Scrollabschnitt wird ohne finale
                     Zielkorrektur als neuer Accordion-Zustand uebernommen. */
                  const scrollIndex = begrenzeIndex(indexAusScrollposition());
                  if (aktiverIndex !== scrollIndex) {
                    aktiviere(scrollIndex, {
                      sofort: true,
                      erzwingen: true,
                      hash: true,
                    });
                  }
                  ScrollTrigger.update();
                };
                /* Gleiche Abbruchwache wie im Desktop-Zweig: autoKill wuerde
                   durch die Hoehenaenderung des sich oeffnenden Akkordeonfelds
                   sofort ausloesen und den Klick wirkungslos machen. */
                let abbruchwache = null;
                const loeseAbbruchwache = () => {
                  if (!abbruchwache) return;
                  ['wheel', 'touchstart', 'keydown'].forEach(
                    art => window.removeEventListener(art, abbruchwache, true),
                  );
                  abbruchwache = null;
                };
                const setzeAbbruchwache = (tween, lauf) => {
                  loeseAbbruchwache();
                  const scrolltasten = [
                    'ArrowUp', 'ArrowDown', 'PageUp', 'PageDown', 'Home', 'End', ' ', 'Spacebar',
                  ];
                  abbruchwache = (ereignis) => {
                    if (ereignis.type === 'keydown' && !scrolltasten.includes(ereignis.key)) return;
                    loeseAbbruchwache();
                    tween.kill();
                    navigationszielAbbrechen(lauf);
                  };
                  ['wheel', 'touchstart', 'keydown'].forEach(
                    art => window.addEventListener(art, abbruchwache, { passive: true, capture: true }),
                  );
                };

                const springeZuIndex = (index, optionen = {}) => {
                  const zielIndex = begrenzeIndex(index);
                  const lauf = ++navigationslauf;
                  loeseAbbruchwache();
                  bereiteIndexzielVor(zielIndex);
                  const zielY = scrollZiel(zielIndex);
                  const sofort = sparsam || Boolean(optionen.sofort);

                  if (window.ScrollToPlugin && !sofort) {
                    const tween = gsap.to(window, {
                      scrollTo: { y: zielY, autoKill: false },
                      duration: .72,
                      ease: 'power2.inOut',
                      overwrite: 'auto',
                      onComplete: () => {
                        loeseAbbruchwache();
                        navigationszielAbschliessen(zielIndex, lauf);
                      },
                      onInterrupt: () => {
                        loeseAbbruchwache();
                        navigationszielAbbrechen(lauf);
                      },
                    });
                    setzeAbbruchwache(tween, lauf);
                    return;
                  }

                  scrollTo({
                    top: zielY,
                    left: 0,
                    behavior: sofort ? 'auto' : 'smooth',
                  });
                  if (sofort) navigationszielAbschliessen(zielIndex, lauf);
                  else {
                    navigationsTimer = window.setTimeout(
                      () => navigationszielAbschliessen(zielIndex, lauf),
                      780,
                    );
                  }
                };

                koepfe.forEach((kopf, index) => {
                  if (!kopf) return;
                  scrollTrigger.push(ScrollTrigger.create({
                    id: `rt-services-mobile-${index + 1}`,
                    trigger: kopf,
                    start: () => `top ${aktivierungsLinie()}px`,
                    end: () => `bottom ${Math.max(84, aktivierungsLinie() - 52)}px`,
                    invalidateOnRefresh: true,
                    onEnter: () => uebernehmeScrollIndex(index),
                    onEnterBack: () => uebernehmeScrollIndex(index),
                  }));
                });

                const beiAnsichtsaenderung = () => {
                  if (Math.abs(innerWidth - letzteBreite) < 2) return;
                  letzteBreite = innerWidth;
                  requestAnimationFrame(() => {
                    setzeMobileEintragshoehen();
                    ScrollTrigger.refresh();
                  });
                };
                const beiAusrichtung = () => requestAnimationFrame(() => {
                  setzeMobileEintragshoehen();
                  ScrollTrigger.refresh();
                });
                addEventListener('resize', beiAnsichtsaenderung, { passive: true });
                addEventListener('orientationchange', beiAusrichtung, { passive: true });

                detailNavigation = {
                  vorbereiten: bereiteIndexzielVor,
                  springeZu: springeZuIndex,
                };
                wurzel.dataset.servicesScroll = 'mobile';
                wurzel.dataset.servicesScrollTempo = 'section-linked';

                return () => {
                  navigationslauf += 1;
                  loeseAbbruchwache();
                  stoppeNavigationsTimer();
                  gsap.killTweensOf(window);
                  scrollTrigger.forEach(trigger => trigger.kill());
                  removeEventListener('resize', beiAnsichtsaenderung);
                  removeEventListener('orientationchange', beiAusrichtung);
                  if (detailNavigation?.springeZu === springeZuIndex) detailNavigation = null;
                  programmatischesZiel = -1;
                  eintraege.forEach(eintrag => eintrag.style.removeProperty('--services-mobile-entry-height'));
                  buehne.classList.remove('is-services-mobile-scroll-stage');
                  delete wurzel.dataset.servicesScroll;
                  delete wurzel.dataset.servicesScrollTempo;
                };
              });
            }
          }

          if (cta) {
            const ctaText = cta.firstElementChild;
            const ctaBild = cta.querySelector('img');
            const ctaTimeline = gsap.timeline({
              scrollTrigger: {
                id: 'rt-services-cta',
                trigger: cta,
                start: 'top 82%',
                toggleActions: 'play none none reverse',
              },
            });
            ctaTimeline.fromTo(cta,
              { autoAlpha: 0, y: 40 },
              { autoAlpha: 1, y: 0, duration: .7, ease: 'power3.out' }, 0);
            if (ctaText) {
              ctaTimeline.fromTo([...ctaText.children],
                { autoAlpha: 0, y: 22 },
                { autoAlpha: 1, y: 0, duration: .58, ease: 'power3.out', stagger: .06 }, .14);
            }
            if (ctaBild) {
              ctaTimeline.fromTo(ctaBild,
                { scale: 1.05 },
                { scale: 1, duration: .9, ease: 'power3.out' }, .08);
            }
          }
        }, wurzel);

        const richteHashzustandAus = () => {
          ScrollTrigger.refresh();
          const hashIndex = indexAusHash();
          if (hashIndex < 0) {
            programmatischesZiel = -1;
            return;
          }
          programmatischesZiel = hashIndex;
          requestAnimationFrame(() => {
            if (indexAusHash() !== hashIndex) return;
            if (detailNavigation) {
              aktiviere(hashIndex, {
                sofort: true,
                scrollen: true,
                erzwingen: true,
              });
            } else {
              programmatischesZiel = -1;
              eintraege[hashIndex]?.scrollIntoView({ behavior: 'auto', block: 'start' });
            }
          });
        };

        ScrollTrigger.sort();
        requestAnimationFrame(richteHashzustandAus);

        /* Stillstandssicherung. allesSichtbar() deckt nur den Hero ab; Zahlen,
           Detailkopf, Vitrine und Akkordeoneintraege starten ebenfalls auf
           autoAlpha 0 und haengen an ScrollTriggern. Steht der Bildtakt still,
           bliebe die halbe Leistungsseite unsichtbar. Freigegeben wird gezielt,
           was GSAP als Inline-Stil versteckt hat - so bleiben Elemente
           unberuehrt, die nur per Klasse gestaltet sind. */
        window.RailTimeStillstand?.(() => {
          allesSichtbar();
          const versteckt = [...wurzel.querySelectorAll('*')].filter((element) => {
            const stil = element.style;
            if (stil.visibility === 'hidden') return true;
            return stil.opacity !== '' && Number(stil.opacity) < .9;
          });
          if (versteckt.length) {
            gsap.set(versteckt, {
              clearProps: 'transform,translate,rotate,scale,opacity,visibility,clipPath,willChange',
            });
          }
          prozessSpur?.style.setProperty('--services-process-line', '1');
          wurzel.dataset.servicesBereit = 'takt-notausstieg';
        }, { fertig: () => wurzel.dataset.servicesBereit === 'takt-notausstieg' });

        if (startIndex >= 0 && document.readyState !== 'complete') {
          hoere(window, 'load', () => requestAnimationFrame(richteHashzustandAus), { once: true });
        }
        hoere(window, 'pageshow', (ereignis) => {
          if (ereignis.persisted) requestAnimationFrame(richteHashzustandAus);
        });
      } catch (fehler) {
        allesSichtbar();
        prozessSpur?.style.setProperty('--services-process-line', '1');
        wurzel.dataset.servicesBereit = 'fehler-fallback';
        console.error('[rt-services]', fehler);
      }
    }

    const beenden = () => {
      clearTimeout(heroNotausstieg);
      if (refreshFrame) cancelAnimationFrame(refreshFrame);
      bildTimeline?.kill();
      detailMedia?.revert();
      bewegungsKontext?.revert();
      if (window.gsap) {
        gsap.killTweensOf([
          ...felder.filter(Boolean),
          ...bilder,
          ...bilder.map((figur) => figur.querySelector('img')).filter(Boolean),
          bildWischer,
          window,
        ].filter(Boolean));
      }
      aufraeumer.splice(0).forEach((funktion) => funktion());
    };
    hoere(window, 'pagehide', (ereignis) => {
      if (ereignis.persisted) {
        if (window.gsap) gsap.killTweensOf(window);
        return;
      }
      beenden();
    });
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', starten, { once: true });
  } else {
    starten();
  }
})();
