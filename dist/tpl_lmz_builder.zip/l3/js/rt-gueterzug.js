/**
 * RailTime - technische Gueterzug-Seitenansicht hinter dem Seiteninhalt.
 *
 * Der Scrollfortschritt bewegt alle lokalen Segment-Silhouetten synchron.
 * Jede Silhouette liegt innerhalb ihres Segments zwischen dessen visueller
 * Grundflaeche und dem eigentlichen Inhalt. Beim Hochscrollen laeuft die
 * Bewegung durch ScrollTrigger-Scrub exakt rueckwaerts.
 */
(() => {
  'use strict';

  const koerper = document.body.classList;
  if (!koerper.contains('rt-l3-page')) return;

  const skript = document.currentScript
    || document.querySelector('script[src*="/rt-gueterzug.js"]');
  const assetUrl = skript?.src
    ? new URL('../images/rt-gueterzug.svg?v=5', skript.src).href
    : 'templates/lmz_builder/l3/images/rt-gueterzug.svg?v=5';

  const farbeLesen = (wert) => {
    const treffer = String(wert || '').match(/rgba?\(([^)]+)\)/i);
    if (!treffer) return null;

    const teile = treffer[1].split(/[\s,\/]+/).filter(Boolean).map(Number);
    if (teile.length < 3 || teile.slice(0, 3).some(Number.isNaN)) return null;

    return {
      r: teile[0],
      g: teile[1],
      b: teile[2],
      a: Number.isFinite(teile[3]) ? teile[3] : 1,
    };
  };

  const luminanz = ({r, g, b}) => (.2126 * r) + (.7152 * g) + (.0722 * b);

  const segmentIstDunkel = (segment) => {
    let element = segment;

    while (element && element !== document.documentElement) {
      const stil = getComputedStyle(element);
      const grundfarbe = farbeLesen(stil.backgroundColor);

      if (grundfarbe && grundfarbe.a >= .35) {
        return luminanz(grundfarbe) < 145;
      }

      const verlaufsfarben = (stil.backgroundImage.match(/rgba?\([^)]+\)/gi) || [])
        .map(farbeLesen)
        .filter((farbe) => farbe && farbe.a >= .35)
        .map(luminanz)
        .sort((a, b) => a - b);

      if (verlaufsfarben.length) {
        return verlaufsfarben[Math.floor(verlaufsfarben.length / 2)] < 145;
      }

      element = element.parentElement;
    }

    return true;
  };

  const starten = () => {
    if (!window.gsap || !window.ScrollTrigger) return;
    if (matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    if (document.querySelector('[data-train-artwork="technical-side-view"]')) return;

    const inhalt = document.querySelector('#rt-main-content main')
      || document.querySelector('#rt-main-content');
    if (!inhalt) return;

    let segmente = Array.from(inhalt.children)
      .filter((element) => element.matches('section, article'))
      .filter((element) => element.getBoundingClientRect().height >= 260)
      .filter((element) => !getComputedStyle(element).backgroundImage.includes('url('));

    if (!segmente.length && inhalt.getBoundingClientRect().height >= 260) {
      segmente = [inhalt];
    }

    const eintraege = segmente.map((segment) => {
      const ebene = document.createElement('div');
      const gleis = document.createElement('span');
      const zug = document.createElement('div');
      const bild = document.createElement('img');

      segment.classList.add('rt-zug-segment-traeger');
      ebene.className = `rt-zug-ebene ${segmentIstDunkel(segment) ? 'rt-zug-ebene--dunkel' : 'rt-zug-ebene--hell'}`;
      ebene.dataset.trainArtwork = 'technical-side-view';
      ebene.setAttribute('aria-hidden', 'true');
      gleis.className = 'rt-zug-gleis';
      zug.className = 'rt-zug';
      bild.className = 'rt-zug__bild';
      bild.src = assetUrl;
      bild.alt = '';
      bild.decoding = 'async';
      bild.fetchPriority = 'low';

      zug.append(bild);
      ebene.append(gleis, zug);
      segment.prepend(ebene);

      return {segment, ebene, zug};
    });

    if (!eintraege.length) return;

    const zuege = eintraege.map(({zug}) => zug);
    const clipsAktualisieren = () => {
      const viewportHoehe = window.innerHeight;

      eintraege.forEach(({segment, ebene}) => {
        const rechteck = segment.getBoundingClientRect();
        if (rechteck.bottom <= 0 || rechteck.top >= viewportHoehe) {
          ebene.style.clipPath = 'inset(100% 0 0 0)';
          return;
        }

        const oben = Math.max(0, Math.min(viewportHoehe, rechteck.top));
        const unten = Math.max(0, Math.min(viewportHoehe, viewportHoehe - rechteck.bottom));
        ebene.style.clipPath = `inset(${oben}px 0 ${unten}px 0)`;
      });
    };

    window.gsap.registerPlugin(window.ScrollTrigger);
    const medien = window.gsap.matchMedia();

    /* Bewusst ohne Breiten-Schranke: die Fahrt laeuft auf allen Viewports,
       also auch auf dem Telefon. Der matchMedia-Kontext bleibt erhalten,
       damit GSAP den Tween bei einem Breakpoint-/Orientierungswechsel sauber
       neu aufbaut - die Startposition haengt an zug.offsetWidth, die sich
       mobil per CSS aendert. Reduzierte Bewegung wird schon oben abgefangen. */
    medien.add('(min-width: 1px)', () => {
      const tween = window.gsap.fromTo(
        zuege,
        {x: (index, zug) => -(zug.offsetWidth + 160)},
        {
          x: () => window.innerWidth + 160,
          ease: 'none',
          scrollTrigger: {
            start: 0,
            end: () => Math.max(1, window.ScrollTrigger.maxScroll(window)),
            scrub: .8,
            invalidateOnRefresh: true,
            id: 'rt-zug',
            onUpdate: clipsAktualisieren,
            onRefresh: clipsAktualisieren,
          },
        },
      );

      return () => tween.kill();
    });

    clipsAktualisieren();

    const erstesBild = segmente[0]?.querySelector('.rt-zug__bild');
    if (erstesBild && !erstesBild.complete) {
      erstesBild.addEventListener('load', () => window.ScrollTrigger.refresh(), {once: true});
    }
  };

  if (document.readyState === 'complete') {
    starten();
  } else {
    window.addEventListener('load', starten, {once: true});
  }
})();
