/*
 * RailTimeMotion — gemeinsame Bewegungsschicht auf GSAP ScrollTrigger.
 *
 * Die Schnittstelle (reveal/clip/ready) bleibt für bestehende RailTime-
 * Komponenten kompatibel. Dynamische Accordions lösen nach Größenänderungen
 * einen ScrollTrigger-Refresh aus.
 *
 * Die Umrechnung der alten Parameter:
 *   hook     0 = Oberkante Viewport, 1 = Unterkante  ->  start: "top <hook*100>%"
 *   duration Scrollweg in Pixeln                     ->  end:   "+=<duration>"
 */
/*
 * Stillstandswache - gemeinsame Absicherung fuer alle Bewegungsschichten.
 *
 * GSAP, ScrollTrigger und jede rAF-getriebene Animation haengen am Bildtakt
 * des Browsers. Steht der Takt still - Hintergrundtab, Energiesparmodus,
 * stark gedrosselte Mobilbrowser, automatisierte Umgebungen - dann feuert
 * kein onComplete, kein Scrub-Update und kein ScrollTrigger. Alles, was vorab
 * per opacity 0 oder visibility hidden versteckt wurde, bliebe dauerhaft
 * unsichtbar; Sperren blieben liegen.
 *
 * Die Wache misst in Abstaenden, ob gsap.ticker.frame ueberhaupt noch
 * vorrueckt, und stellt nur im nachgewiesenen Stillstand den uebergebenen
 * Endzustand direkt her. Laeuft der Takt, bleibt die scrollgesteuerte
 * Choreografie unberuehrt - eine blinde Frist wuerde sie zerstoeren. Sie
 * laeuft wiederholt, weil der Takt auch erst spaeter aussetzen kann, etwa
 * wenn der Nutzer nach einer Minute weiterscrollt.
 *
 * Bewusst wird document.hidden NICHT ausgenommen. Ein verborgener Tab ist
 * genau der haeufigste Stillstandsfall, und die Sichtbarkeit von Inhalten
 * wiegt schwerer als eine Einblendung, die beim Zurueckwechseln schon fertig
 * ist. Zwei aufeinanderfolgende Stillstandsmessungen sind noetig, damit ein
 * kurzer Tabwechsel die Choreografie nicht vorzeitig beendet.
 *
 * Rueckgabe: eine Funktion, die die Wache vorzeitig beendet.
 */
window.RailTimeStillstand = (endzustand, einstellungen) => {
  if (typeof endzustand !== 'function') return () => {};
  const {
    frist = 1600,
    stillstaende = 2,
    versuche = 40,
    fertig = null,
  } = einstellungen || {};
  let letzterTakt = window.gsap?.ticker?.frame ?? 0;
  let stillMessungen = 0;
  let offen = versuche;
  let timer = 0;

  const stoppen = () => {
    clearTimeout(timer);
    timer = 0;
    offen = 0;
  };

  const pruefen = () => {
    timer = 0;
    if (offen-- <= 0) return;
    if (typeof fertig === 'function') {
      let istFertig = false;
      try {
        istFertig = Boolean(fertig());
      } catch (_fehler) {
        istFertig = false;
      }
      if (istFertig) return;
    }

    const takt = window.gsap?.ticker?.frame ?? 0;
    if (takt - letzterTakt > 1) {
      stillMessungen = 0;
      letzterTakt = takt;
    } else if (++stillMessungen >= stillstaende) {
      try {
        endzustand();
      } catch (fehler) {
        console.error('[rt-stillstand]', fehler);
      }
      return;
    }
    timer = window.setTimeout(pruefen, frist);
  };

  timer = window.setTimeout(pruefen, frist);
  return stoppen;
};

window.RailTimeMotion = (() => {
  const root = document.documentElement;
  const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const hasGsap = typeof window.gsap !== 'undefined' && typeof window.ScrollTrigger !== 'undefined';
  const canAnimate = hasGsap && !reducedMotion;

  /* Der Vorhang rt-motion-pending versteckt ganze Abschnitte mit
     visibility:hidden !important. Seine Freigabe darf deshalb nicht allein am
     rAF-Takt haengen: steht der Takt still (Hintergrundtab, gedrosselter
     Mobilbrowser, Automatisierung), blieben die Inhalte unsichtbar. Die Frist
     stellt den Endzustand direkt her, das erste eintreffende rAF-Paar gewinnt. */
  let vorhangFrist = 0;

  const releaseCloak = (disableMotion = false) => {
    clearTimeout(window.__rtMotionCloakTimer);
    clearTimeout(vorhangFrist);
    vorhangFrist = 0;
    root.classList.remove('rt-motion-pending');
    if (disableMotion) root.classList.remove('rt-motion-enabled');
  };

  if (!canAnimate) {
    releaseCloak(true);
    return {
      available: false,
      reveal: () => {},
      clip: () => {},
      ready: () => releaseCloak(true),
      refresh: () => {}
    };
  }

  gsap.registerPlugin(ScrollTrigger);

  // Bilder aendern die Seitenhoehe, sobald sie eintreffen. Ohne Refresh zeigen
  // alle darunterliegenden Trigger auf veraltete Positionen.
  ScrollTrigger.config({ ignoreMobileResize: true });

  const clip = (element) => {
    element?.parentElement?.classList.add('rt-motion-clip');
  };

  const reveal = (
    selector,
    {
      axis = 'y',
      distance = 42,
      duration = 300,
      hook = .84,
      alternate = true
    } = {}
  ) => {
    const elemente = gsap.utils.toArray(selector);
    if (!elemente.length) return;

    elemente.forEach((element, index) => {
      const richtung = alternate && index % 2 ? -1 : 1;
      const x = axis === 'x' ? distance * richtung : 0;
      const y = axis === 'y' ? distance * richtung : 0;

      clip(element);

      gsap.fromTo(
        element,
        { opacity: .12, x, y, force3D: true },
        {
          opacity: 1,
          x: 0,
          y: 0,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: element,
            start: `top ${Math.round(hook * 100)}%`,
            end: `+=${duration}`,
            scrub: true
          }
        }
      );
    });

    /* Diese Einblendungen laufen mit scrub, ihr Fortschritt haengt also
       vollstaendig am Bildtakt. Steht der Takt, blieben alle Ziele bei
       opacity .12 stehen - lesbar ist da nichts. */
    window.RailTimeStillstand?.(() => {
      gsap.set(elemente, {
        clearProps: 'transform,translate,rotate,scale,opacity,visibility,willChange',
      });
    });
  };

  const refresh = () => ScrollTrigger.refresh();

  const ready = () => {
    clearTimeout(vorhangFrist);
    vorhangFrist = window.setTimeout(() => releaseCloak(false), 700);
    requestAnimationFrame(() => {
      requestAnimationFrame(() => releaseCloak(false));
    });
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', ready, { once: true });
  } else {
    ready();
  }

  addEventListener('load', () => ScrollTrigger.refresh(), { once: true });

  return { available: true, reveal, clip, ready, refresh };
})();
