/*
 * Einmalige Karten-Erzaehlung:
 *   pending -> revealing -> map-left -> content -> complete
 *
 * Der Ablauf ist eine einzige zeitbasierte GSAP-Timeline. ScrollTrigger
 * startet sie nur einmal, der Scrollwert steuert weder den Fortschritt noch
 * die Richtung. Waehrend der Timeline wird die aktuelle Scrollposition
 * gehalten; danach laeuft die Seite ohne Pin-Spacer normal weiter.
 */
(() => {
  'use strict';

  if (!document.body.classList.contains('is-home')) return;

  const sektion = document.querySelector('.sa-network');
  const karte = sektion?.querySelector('.sa-network__map');
  const text = sektion?.querySelector('.sa-network__copy');
  if (!sektion || !karte || !text) return;

  const standorte = Array.from(sektion.querySelectorAll('.rt-location'));

  /* Der Firmensitz ist eine inhaltliche Kartenfunktion und darf nicht vom
     Laden der Animationsbibliothek abhaengen. Eine Klasse oeffnet ihn ohne
     focus(), damit weder Tastaturfokus noch Scrollposition uebernommen wird. */
  const sprachTag = document.documentElement.lang.toLowerCase();
  const hauptsitz = standorte.find(standort =>
    standort.querySelector('.rt-location__tooltip strong')?.textContent.trim() === 'Winsen (Luhe)');
  if (hauptsitz) {
    const titel = hauptsitz.querySelector('.rt-location__tooltip strong')?.textContent.trim() || 'Winsen (Luhe)';
    const rolle = sprachTag.startsWith('en')
      ? 'Headquarters'
      : (sprachTag.startsWith('pl') ? 'Siedziba główna' : 'Hauptsitz');
    const hinweis = hauptsitz.querySelector('.rt-location__tooltip small');

    hauptsitz.classList.add('is-headquarters');
    hauptsitz.setAttribute('aria-label', `${rolle}: ${titel}`);
    if (hinweis) hinweis.textContent = rolle;
  }

  /* Auf Touchgeraeten kann der Browser den Fokus nach einem Tap sofort wieder
     abgeben. Der explizite Auswahlzustand haelt deshalb Logo und Pop-up bis
     zur naechsten Standortwahl stabil; Tastaturfokus aktualisiert ihn ebenso. */
  const standortAuswaehlen = (standort) => {
    standorte.forEach((eintrag) => eintrag.classList.remove('is-selected'));
    if (standort && standort !== hauptsitz) standort.classList.add('is-selected');
  };
  standorte.forEach((standort) => {
    standort.addEventListener('click', () => standortAuswaehlen(standort));
    standort.addEventListener('focus', () => standortAuswaehlen(standort));
  });

  if (!window.gsap || !window.ScrollTrigger) return;

  if (window.ScrollToPlugin) gsap.registerPlugin(ScrollTrigger, ScrollToPlugin);
  else gsap.registerPlugin(ScrollTrigger);

  const laender = gsap.utils.toArray(sektion.querySelectorAll('.rt-state'));
  const formen = gsap.utils.toArray(sektion.querySelectorAll('.rt-state-shape'));
  const beschriftungen = gsap.utils.toArray(sektion.querySelectorAll('.rt-labels > *'));
  const nadelKoepfe = standorte
    .map(standort => standort.querySelector('.rt-location__pin'))
    .filter(Boolean);
  const pulse = standorte
    .map(standort => standort.querySelector('.rt-location__pulse'))
    .filter(Boolean);
  const sparsam = matchMedia('(prefers-reduced-motion: reduce)');
  const desktop = matchMedia('(min-width: 981px) and (min-height: 620px)');

  let masterTimeline = null;
  let storyTrigger = null;
  let gestartet = false;
  let fertig = false;
  let gestartetBei = 0;
  let centerX = 0;
  let scrollGesperrt = false;
  let gesperrtePosition = 0;
  let korrekturAktiv = false;
  let notFreigabe = 0;
  /* Der Endzustand hing allein am onComplete der Master-Timeline. Blieb der
     GSAP-Takt aus, wurde die Scrollsperre nach 6,5 s zwar geloest, Karte,
     Beschriftungen, Nadeln und Text blieben aber auf autoAlpha 0 und der Text
     zusaetzlich inert - der ganze Abschnitt war unsichtbar und unbedienbar. */
  let notEndzustand = 0;
  let vorherigesScrollBehavior = '';
  let ausrichtungsTween = null;

  const scrollTasten = new Set([
    ' ', 'Spacebar', 'ArrowDown', 'ArrowUp', 'PageDown', 'PageUp', 'Home', 'End',
  ]);

  const istEingabe = (ziel) => Boolean(ziel?.closest?.(
    'input, textarea, select, button, [contenteditable="true"], [role="textbox"]',
  ));

  const scrollEreignisBlockieren = (ereignis) => {
    if (!scrollGesperrt) return;
    ereignis.preventDefault();
  };

  const scrollTasteBlockieren = (ereignis) => {
    if (!scrollGesperrt || !scrollTasten.has(ereignis.key) || istEingabe(ereignis.target)) return;
    ereignis.preventDefault();
  };

  const scrollPositionHalten = () => {
    if (!scrollGesperrt || korrekturAktiv || Math.abs(scrollY - gesperrtePosition) < 1) return;
    korrekturAktiv = true;
    scrollTo(0, gesperrtePosition);
    requestAnimationFrame(() => { korrekturAktiv = false; });
  };

  const scrollFreigeben = () => {
    if (!scrollGesperrt) return;
    scrollGesperrt = false;
    ausrichtungsTween?.kill();
    ausrichtungsTween = null;
    korrekturAktiv = false;
    clearTimeout(notFreigabe);
    removeEventListener('wheel', scrollEreignisBlockieren, true);
    removeEventListener('touchmove', scrollEreignisBlockieren, true);
    removeEventListener('keydown', scrollTasteBlockieren, true);
    removeEventListener('scroll', scrollPositionHalten);
    document.documentElement.style.scrollBehavior = vorherigesScrollBehavior;
    document.body.classList.remove('rt-map-scroll-locked');
    delete sektion.dataset.mapScrollLocked;
    sektion.removeAttribute('aria-busy');
  };

  const scrollSperren = () => {
    if (scrollGesperrt) return;

    vorherigesScrollBehavior = document.documentElement.style.scrollBehavior;
    document.documentElement.style.scrollBehavior = 'auto';

    /* Der Trigger startet schon beim ersten sichtbaren Abschnittsdrittel.
       Die Buehne faehrt deshalb kontrolliert an die Viewportkante, statt dort
       erst nach fast einer leeren Bildschirmhoehe hart einzurasten. */
    const zielPosition = Math.max(0, Math.round(scrollY + sektion.getBoundingClientRect().top));
    gesperrtePosition = Math.round(scrollY);

    scrollGesperrt = true;
    document.body.classList.add('rt-map-scroll-locked');
    sektion.dataset.mapScrollLocked = 'true';
    sektion.setAttribute('aria-busy', 'true');

    addEventListener('wheel', scrollEreignisBlockieren, { passive: false, capture: true });
    addEventListener('touchmove', scrollEreignisBlockieren, { passive: false, capture: true });
    addEventListener('keydown', scrollTasteBlockieren, true);
    const ausrichtungAbschliessen = () => {
      if (!scrollGesperrt) return;
      ausrichtungsTween = null;
      korrekturAktiv = false;
      gesperrtePosition = zielPosition;
      scrollTo(0, gesperrtePosition);
      addEventListener('scroll', scrollPositionHalten, { passive: true });
    };

    if (window.ScrollToPlugin && Math.abs(zielPosition - scrollY) > 2) {
      korrekturAktiv = true;
      ausrichtungsTween = gsap.to(window, {
        scrollTo: { y: zielPosition, autoKill: false },
        duration: desktop.matches ? .4 : .34,
        ease: 'power2.inOut',
        overwrite: 'auto',
        onUpdate: () => { gesperrtePosition = Math.round(scrollY); },
        onComplete: ausrichtungAbschliessen,
        onInterrupt: ausrichtungAbschliessen,
      });
    } else {
      ausrichtungAbschliessen();
    }

    /* Selbst bei einem unerwarteten GSAP-Abbruch bleibt die Seite nie
       dauerhaft gesperrt. */
    notFreigabe = window.setTimeout(scrollFreigeben, 6500);
  };

  const ausruestungVerbessern = () => {
    const absatz = [...text.children].find(element =>
      element.matches('p:not(.sa-eyebrow)') && !element.classList.contains('rt-network-equipment'));
    if (!absatz) return;

    const teile = absatz.textContent
      .split(/[\u00b7\u2022]/u)
      .map(teil => teil.trim())
      .filter(Boolean);
    if (teile.length < 2) return;

    absatz.textContent = '';
    absatz.classList.add('rt-network-equipment');
    teile.forEach((teil) => {
      const eintrag = document.createElement('span');
      eintrag.textContent = teil;
      absatz.append(eintrag);
    });
  };

  ausruestungVerbessern();
  const textKinder = [...text.children];

  const yPosition = (standort) => {
    const ausCss = Number.parseFloat(standort.style.getPropertyValue('--y'));
    if (Number.isFinite(ausCss)) return ausCss;

    try {
      const box = standort.getBBox();
      return box.y + box.height / 2;
    } catch (_fehler) {
      return standorte.indexOf(standort);
    }
  };

  const sortierteStandorte = [...standorte].sort((a, b) => yPosition(a) - yPosition(b));
  const sortiertePins = sortierteStandorte
    .map(standort => standort.querySelector('.rt-location__pin'))
    .filter(Boolean);
  const sortiertePulse = sortierteStandorte
    .map(standort => standort.querySelector('.rt-location__pulse'))
    .filter(Boolean);
  const minY = sortierteStandorte.length ? yPosition(sortierteStandorte[0]) : 0;
  const maxY = sortierteStandorte.length ? yPosition(sortierteStandorte[sortierteStandorte.length - 1]) : 1;
  const ySpanne = Math.max(1, maxY - minY);
  const wellenVersatz = (_index, element) => {
    const standort = element.closest?.('.rt-location') || element;
    return ((yPosition(standort) - minY) / ySpanne) * .64;
  };

  const fremdeOwnerEntfernen = () => {
    ScrollTrigger.getAll().forEach((andererTrigger) => {
      const ausloeser = andererTrigger.trigger;
      if (!ausloeser || (ausloeser !== sektion && !sektion.contains(ausloeser))) return;
      andererTrigger.animation?.kill();
      andererTrigger.kill();
    });

    karte.classList.remove('sa-motion-left');
    text.classList.remove('sa-motion-right');
    sektion.classList.remove('rt-motion-clip', 'rt-karte-sequenz');
    gsap.set([karte, text, ...textKinder], {
      clearProps: 'transform,opacity,visibility,pointerEvents,clipPath',
    });
  };

  const mitteMessen = () => {
    const vorher = Number(gsap.getProperty(karte, 'x')) || 0;
    gsap.set(karte, { x: 0 });
    const sektionBox = sektion.getBoundingClientRect();
    const karteBox = karte.getBoundingClientRect();
    const verschiebung = sektionBox.left + sektionBox.width / 2
      - (karteBox.left + karteBox.width / 2);
    gsap.set(karte, { x: vorher });
    return verschiebung;
  };

  const endzustand = () => {
    fertig = true;
    clearTimeout(notEndzustand);
    notEndzustand = 0;
    sektion.dataset.mapSequenceState = 'complete';
    sektion.dataset.mapSequenceElapsed = ((performance.now() - gestartetBei) / 1000).toFixed(2);
    text.inert = false;

    gsap.set([karte, text, ...textKinder], {
      clearProps: 'transform,opacity,visibility,pointerEvents,clipPath',
    });
    gsap.set([...laender, ...beschriftungen, ...standorte], {
      clearProps: 'opacity,visibility,pointerEvents',
    });
    gsap.set(formen, {
      clearProps: 'fillOpacity,stroke,strokeWidth,strokeDasharray,strokeDashoffset',
    });
    gsap.set(nadelKoepfe, {
      clearProps: 'transform,opacity,visibility,transformOrigin',
    });
    gsap.set(pulse, {
      clearProps: 'transform,visibility',
      opacity: 0,
    });

    scrollFreigeben();
    storyTrigger?.kill();
    sektion.dispatchEvent(new CustomEvent('rt:map-sequence-complete'));
  };

  const sofortAnzeigen = () => {
    sektion.classList.add('rt-map-story');
    gsap.set([karte, text, ...textKinder], {
      autoAlpha: 1,
      x: 0,
      y: 0,
      scale: 1,
      pointerEvents: 'auto',
    });
    gsap.set([...laender, ...beschriftungen, ...standorte], {
      autoAlpha: 1,
      pointerEvents: 'auto',
    });
    gsap.set(formen, { fillOpacity: 1, strokeDashoffset: 0 });
    gsap.set(nadelKoepfe, { autoAlpha: 1, y: 0, scale: 1 });
    gsap.set(pulse, { autoAlpha: 0, scale: 1 });
    if (!gestartetBei) gestartetBei = performance.now();
    endzustand();
  };

  const vorbereiten = (istDesktop) => {
    sektion.dataset.mapSequenceState = 'pending';
    sektion.classList.add('rt-map-story');
    text.inert = true;

    centerX = istDesktop ? mitteMessen() : 0;
    gsap.set(karte, {
      autoAlpha: 0,
      x: centerX,
      y: 14,
      scale: istDesktop ? 1.045 : .98,
      transformOrigin: '50% 50%',
    });
    gsap.set(text, {
      autoAlpha: 0,
      x: istDesktop ? 58 : 0,
      y: istDesktop ? 0 : 28,
      pointerEvents: 'none',
    });
    gsap.set(textKinder, { autoAlpha: 0, y: 18 });
    gsap.set(laender, { autoAlpha: 1 });

    formen.forEach((form) => {
      let laenge = 0;
      try {
        laenge = form.getTotalLength();
      } catch (_fehler) {
        const box = form.getBBox();
        laenge = (box.width + box.height) * 2;
      }
      laenge = Math.max(1, laenge);
      gsap.set(form, {
        fillOpacity: 0,
        stroke: 'rgba(197, 22, 46, .88)',
        strokeWidth: 1.6,
        strokeDasharray: `${laenge} ${laenge}`,
        strokeDashoffset: laenge,
      });
    });

    gsap.set(beschriftungen, { autoAlpha: 0 });
    gsap.set(standorte, { autoAlpha: 0, pointerEvents: 'none' });
    gsap.set(nadelKoepfe, {
      autoAlpha: 0,
      y: -14,
      scale: .18,
      transformOrigin: '50% 100%',
    });
    gsap.set(pulse, { autoAlpha: 0, scale: .25, transformOrigin: '50% 50%' });
  };

  const masterErstellen = (istDesktop) => {
    masterTimeline = gsap.timeline({
      paused: true,
      defaults: { overwrite: 'auto' },
      onStart: () => {
        gestartetBei = performance.now();
        sektion.dataset.mapSequenceState = 'revealing';
        scrollSperren();
        /* Absicherung gegen einen stehenden Takt: nach der eigenen Laufzeit
           plus Reserve wird der Endzustand direkt hergestellt, statt auf das
           onComplete zu warten. */
        clearTimeout(notEndzustand);
        notEndzustand = window.setTimeout(() => {
          if (fertig) return;
          sofortAnzeigen();
        }, Math.round((masterTimeline.duration() + 2.5) * 1000));
      },
      onComplete: endzustand,
      onInterrupt: scrollFreigeben,
    });

    masterTimeline.addLabel('karte', 0);
    masterTimeline.to(karte, {
      autoAlpha: 1,
      y: 0,
      duration: .28,
      ease: 'power3.out',
    }, 'karte');
    masterTimeline.to(formen, {
      strokeDashoffset: 0,
      duration: .52,
      ease: 'power2.inOut',
    }, 'karte+=.01');

    masterTimeline.addLabel('laender', .47);
    masterTimeline.to(formen, {
      fillOpacity: 1,
      stroke: '#aaa69d',
      strokeWidth: 2.2,
      duration: .24,
      ease: 'power2.out',
    }, 'laender');
    masterTimeline.to(beschriftungen, {
      autoAlpha: 1,
      duration: .2,
      ease: 'power2.out',
    }, 'laender+=.02');

    /* Die Standortwelle bekommt mehr Zeit als Kontur und Laender zusammen,
       bleibt aber deutlich kuerzer als in der vorherigen Fassung. */
    masterTimeline.addLabel('standorte', .72);
    masterTimeline.to(sortierteStandorte, {
      autoAlpha: 1,
      duration: .12,
      ease: 'power2.out',
      stagger: wellenVersatz,
    }, 'standorte');
    masterTimeline.to(sortiertePins, {
      autoAlpha: 1,
      y: 0,
      scale: 1,
      duration: .36,
      ease: 'back.out(1.7)',
      stagger: wellenVersatz,
    }, 'standorte');
    masterTimeline.fromTo(sortiertePulse,
      { autoAlpha: .58, scale: .3 },
      {
        autoAlpha: 0,
        scale: 2.45,
        duration: .48,
        ease: 'power2.out',
        stagger: wellenVersatz,
      }, 'standorte+=.02');
    masterTimeline.set(sortierteStandorte, { pointerEvents: 'auto' }, 'standorte+=1.12');

    masterTimeline.addLabel('karte-links', 'standorte+=1.14');
    masterTimeline.call(() => {
      sektion.dataset.mapSequenceState = 'map-left';
    }, null, 'karte-links');
    masterTimeline.to(karte, {
      x: 0,
      y: 0,
      scale: 1,
      duration: istDesktop ? .46 : .34,
      ease: 'power3.inOut',
    }, 'karte-links');

    /* Strikte Kante: Der rechte Inhalt beginnt erst, wenn die Bewegung der
       Karte vollstaendig abgeschlossen ist. */
    masterTimeline.addLabel('content', `karte-links+=${istDesktop ? .46 : .34}`);
    masterTimeline.call(() => {
      sektion.dataset.mapSequenceState = 'content';
    }, null, 'content');
    masterTimeline.to(text, {
      autoAlpha: 1,
      x: 0,
      y: 0,
      duration: .3,
      ease: 'power3.out',
    }, 'content');
    masterTimeline.to(textKinder, {
      autoAlpha: 1,
      y: 0,
      duration: .34,
      ease: 'power3.out',
      stagger: .035,
    }, 'content+=.06');
    masterTimeline.set(text, { pointerEvents: 'auto' });

    sektion.dataset.mapRevealDuration = masterTimeline.labels['karte-links'].toFixed(2);
    sektion.dataset.mapMoveDuration = (istDesktop ? .58 : .42).toFixed(2);
    sektion.dataset.mapSequenceDuration = masterTimeline.duration().toFixed(2);
  };

  const masterStarten = () => {
    if (gestartet) return;
    gestartet = true;
    masterTimeline.play(0);
  };

  const geschichte = (istDesktop) => {
    vorbereiten(istDesktop);
    masterErstellen(istDesktop);

    storyTrigger = ScrollTrigger.create({
      id: istDesktop ? 'rt-map-story' : 'rt-map-story-mobile',
      trigger: sektion,
      start: 'top 82%',
      once: true,
      invalidateOnRefresh: true,
      onEnter: masterStarten,
    });
  };

  const starten = () => {
    fremdeOwnerEntfernen();
    sektion.classList.add('rt-map-story');

    const box = sektion.getBoundingClientRect();
    if (sparsam.matches || (scrollY > 0 && box.top < 0)) {
      sofortAnzeigen();
      ScrollTrigger.refresh();
      return;
    }

    geschichte(desktop.matches);
    ScrollTrigger.sort();
    ScrollTrigger.refresh();

    /* Steht der Bildtakt still, feuert auch ScrollTrigger nicht. Dann bliebe
       die in vorbereiten() versteckte Karte fuer immer unsichtbar, ohne dass
       die Timeline ueberhaupt gestartet waere. Die Wache prueft den Takt
       wiederholt, weil er auch erst spaeter aussetzen kann - etwa genau dann,
       wenn der Nutzer bis zur Karte herunterscrollt. */
    window.RailTimeStillstand?.(sofortAnzeigen, { fertig: () => fertig });
  };

  let bootGestartet = false;
  const starteEinmal = () => {
    if (bootGestartet) return;
    bootGestartet = true;
    starten();
  };
  const boot = () => requestAnimationFrame(starteEinmal);
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot, { once: true });
  } else {
    boot();
  }
  /* Ohne rAF-Takt kaeme starten() nie zum Zug. */
  window.setTimeout(starteEinmal, 1600);

  addEventListener('railtime:intro-complete', () => ScrollTrigger.refresh(), { once: true });
  addEventListener('pagehide', () => {
    masterTimeline?.kill();
    storyTrigger?.kill();
    scrollFreigeben();
    if (!fertig) sofortAnzeigen();
  }, { once: true });
})();
