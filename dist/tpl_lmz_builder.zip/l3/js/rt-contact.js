/**
 * RailTime – eigener Motion-Owner fuer Kontakt / Contact.
 *
 * Kein Ladevorhang, kein Pin und kein Scrub. Die vorhandene Mailto-Form bleibt
 * vollstaendig nativ: Dieses Skript registriert bewusst keinen Submit-Handler.
 */
(() => {
  'use strict';

  if (!document.body.classList.contains('is-contact')) return;

  const starten = () => {
    const wurzel = document.querySelector('.rt-x');
    if (!wurzel || wurzel.dataset.contactInitialisiert) return;

    wurzel.dataset.contactInitialisiert = 'true';
    wurzel.classList.add('rt-contact');

    const eins = (auswahl, kontext = wurzel) => kontext.querySelector(auswahl);
    const alle = (auswahl, kontext = wurzel) => Array.from(kontext.querySelectorAll(auswahl));
    const vorhang = eins('.rt-x__vorhang');
    const hero = eins('.rt-x__hero');
    const heroText = eins('.rt-x__hero-text');
    const heroFigur = eins('.rt-x__hero-figur');
    /* Die fruehere KPI-Leiste gehoert nicht mehr zum Kontaktauftritt. Direkt
       entfernen, bevor GSAP Geometrien misst oder ScrollTrigger registriert. */
    eins('.rt-x__zahlen')?.remove();
    const formular = eins('form.rt-x__formular');
    const anfrage = formular?.closest('.rt-x__section');
    const kontaktDaten = anfrage?.querySelector('.rt-x__fliess');
    const cta = eins('.rt-x__cta');
    const hinweis = formular?.querySelector('.rt-x__hinweis');
    const sparsam = matchMedia('(prefers-reduced-motion: reduce)').matches;
    const sprachTag = document.documentElement.lang.toLowerCase();
    const englisch = sprachTag.startsWith('en');
    const polnisch = sprachTag.startsWith('pl');
    const textFuerSprache = (deutsch, english, polski) => (
      englisch ? english : (polnisch ? polski : deutsch)
    );

    if (vorhang) {
      vorhang.hidden = true;
      vorhang.style.display = 'none';
    }

    anfrage?.classList.add('rt-contact-request');
    cta?.classList.add('rt-contact-emergency');

    /* Der englische Seiteninhalt enthaelt im Hero einen doppelt maskierten
       Entity-Text. Nur diesen sichtbaren Rest dekodieren, ohne den
       eigentlichen Seiteninhalt oder seine Sprachzuordnung zu veraendern. */
    alle('.rt-x__eyebrow').forEach((zeile) => {
      if (/&amp;/iu.test(zeile.textContent || '')) {
        zeile.textContent = zeile.textContent.replace(/&amp;/giu, '&');
      }
    });

    if (hero) {
      hero.dataset.contactKicker = textFuerSprache(
        'EINSATZKOORDINATION / KONTAKT',
        'RAIL OPERATIONS / CONTACT',
        'OPERACJE KOLEJOWE / KONTAKT',
      );
    }

    if (heroFigur) {
      heroFigur.dataset.contactLabel = textFuerSprache(
        'EINSATZKOORDINATION / 01',
        'DEPLOYMENT DESK / 01',
        'KOORDYNACJA ZLECEŃ / 01',
      );
    }

    /* Vorhandene, weboptimierte Motive statt Portrait und Unfallschaden. */
    const heroBild = heroFigur?.querySelector('img');
    const ctaBild = cta?.querySelector('img');
    /* Motiv und Alt-Text von Hero und CTA-Bild kommen ausschliesslich aus
       dem LMZ Page Builder; hier werden sie nicht mehr ueberschrieben. */

    /* Sprachlosen Datenschutz-Link auf das bereits korrekt geroutete Ziel
       des Footers heben. Der gespeicherte Seiteninhalt bleibt unveraendert. */
    const datenschutzLink = hinweis?.querySelector('a[href]');
    const footerDatenschutz = Array.from(document.querySelectorAll('.rt-footer__legal a[href]'))
      .find((link) => {
        try {
          return /\/(?:datenschutzerklaerung|privacy|polityka-prywatnosci)\/?$/u.test(new URL(link.href).pathname);
        } catch (fehler) {
          return false;
        }
      });

    if (datenschutzLink && footerDatenschutz) {
      datenschutzLink.href = footerDatenschutz.href;
    }

    /* Der Hinweis beschreibt den externen Mailto-Transport. Bestehende
       aria-describedby-Bezuege werden nicht ueberschrieben. */
    if (formular && hinweis) {
      if (!hinweis.id) hinweis.id = 'rt-contact-mailto-hinweis';
      const beschriebenDurch = new Set(
        (formular.getAttribute('aria-describedby') || '').split(/\s+/u).filter(Boolean),
      );
      beschriebenDurch.add(hinweis.id);
      formular.setAttribute('aria-describedby', Array.from(beschriebenDurch).join(' '));
      formular.dataset.contactTransport = 'mailto';
    }

    /* Browser-Autofill verbessern, ohne Namen, Required-Zustand, Action,
       Methode, Encoding oder native Validierung des Formulars anzutasten. */
    const autocompleteSetzen = (auswahl, wert) => {
      const feld = formular?.querySelector(auswahl);
      if (feld && !feld.hasAttribute('autocomplete')) feld.setAttribute('autocomplete', wert);
    };

    autocompleteSetzen('input[name="Name"]', 'name');
    autocompleteSetzen('input[type="email"]', 'email');
    autocompleteSetzen('input[type="tel"]', 'tel');

    if (!window.gsap || !window.ScrollTrigger || sparsam) {
      wurzel.dataset.contactBereit = 'statisch';
      return;
    }

    gsap.registerPlugin(ScrollTrigger);
    gsap.config({ nullTargetWarn: false });
    wurzel.dataset.contactBereit = 'gsap';

    let kontext = null;
    let heroNotausstieg = 0;

    const heroElemente = () => [
      ...(heroText ? Array.from(heroText.children) : []),
      heroFigur,
      heroBild,
    ].filter(Boolean);

    const bewegteElemente = () => [
      ...heroElemente(),
      ...(kontaktDaten ? Array.from(kontaktDaten.children) : []),
      formular,
      ...(formular ? Array.from(formular.children) : []),
      cta,
      ...(cta?.firstElementChild ? Array.from(cta.firstElementChild.children) : []),
      ctaBild,
    ].filter(Boolean);

    const elementeSichtbar = (elemente) => {
      gsap.set(elemente, {
        clearProps: 'transform,opacity,visibility,clipPath',
      });
    };

    const heroSichtbar = () => {
      clearTimeout(heroNotausstieg);
      elementeSichtbar(heroElemente());
    };

    const allesSichtbar = () => {
      clearTimeout(heroNotausstieg);
      elementeSichtbar(bewegteElemente());
    };

    try {
      kontext = gsap.context(() => {
        /* ------------------------------------------------------------ *
         * Hero – sofort und ohne blockierenden Vorhang
         * ------------------------------------------------------------ */
        const heroTeile = heroText ? Array.from(heroText.children) : [];
        const heroTimeline = gsap.timeline({
          defaults: { ease: 'power3.out' },
          onComplete: heroSichtbar,
        });

        if (heroTeile.length) {
          heroTimeline.fromTo(
            heroTeile,
            { autoAlpha: 0, y: 32 },
            {
              autoAlpha: 1,
              y: 0,
              duration: .78,
              stagger: .07,
            },
            0,
          );
        }

        if (heroFigur) {
          heroTimeline.fromTo(
            heroFigur,
            {
              autoAlpha: 0,
              x: 34,
              clipPath: 'inset(0 0 0 100%)',
            },
            {
              autoAlpha: 1,
              x: 0,
              clipPath: 'inset(0 0 0 0%)',
              duration: .92,
            },
            .08,
          );
        }

        if (heroBild) {
          heroTimeline.fromTo(
            heroBild,
            { scale: 1.07 },
            { scale: 1, duration: 1.08, ease: 'power2.out' },
            .08,
          );
        }

        heroNotausstieg = window.setTimeout(heroSichtbar, 3200);

        /* ------------------------------------------------------------ *
         * Anfrage – erst Kontaktdaten, dann Formular
         * ------------------------------------------------------------ */
        if (anfrage) {
          const detailTeile = kontaktDaten ? Array.from(kontaktDaten.children) : [];
          const formularTeile = formular ? Array.from(formular.children) : [];
          const anfrageTimeline = gsap.timeline({
            defaults: { ease: 'power3.out' },
            scrollTrigger: {
              id: 'rt-contact-request',
              trigger: anfrage,
              start: 'top 78%',
              once: true,
            },
          });

          if (detailTeile.length) {
            anfrageTimeline.fromTo(
              detailTeile,
              { autoAlpha: 0, y: 28 },
              {
                autoAlpha: 1,
                y: 0,
                duration: .64,
                stagger: .075,
                clearProps: 'transform,opacity,visibility',
              },
              0,
            );
          }

          if (formular) {
            anfrageTimeline.fromTo(
              formular,
              { autoAlpha: 0, y: 38 },
              {
                autoAlpha: 1,
                y: 0,
                duration: .72,
                clearProps: 'transform,opacity,visibility',
              },
              .18,
            );
          }

          if (formularTeile.length) {
            anfrageTimeline.fromTo(
              formularTeile,
              { autoAlpha: 0, y: 18 },
              {
                autoAlpha: 1,
                y: 0,
                duration: .52,
                stagger: .045,
                clearProps: 'transform,opacity,visibility',
              },
              .34,
            );
          }
        }

        /* ------------------------------------------------------------ *
         * Notfallabschluss – kurze, einmalige Sequenz
         * ------------------------------------------------------------ */
        if (cta) {
          const ctaText = cta.firstElementChild;
          const ctaTeile = ctaText ? Array.from(ctaText.children) : [];
          const ctaTimeline = gsap.timeline({
            defaults: { ease: 'power3.out' },
            scrollTrigger: {
              id: 'rt-contact-emergency',
              trigger: cta,
              start: 'top 84%',
              once: true,
            },
          });

          ctaTimeline.fromTo(
            cta,
            { autoAlpha: 0, y: 42 },
            {
              autoAlpha: 1,
              y: 0,
              duration: .72,
              clearProps: 'transform,opacity,visibility',
            },
            0,
          );

          if (ctaTeile.length) {
            ctaTimeline.fromTo(
              ctaTeile,
              { autoAlpha: 0, y: 22 },
              {
                autoAlpha: 1,
                y: 0,
                duration: .58,
                stagger: .06,
                clearProps: 'transform,opacity,visibility',
              },
              .14,
            );
          }

          if (ctaBild) {
            ctaTimeline.fromTo(
              ctaBild,
              { scale: 1.06 },
              {
                scale: 1,
                duration: .95,
                ease: 'power2.out',
                clearProps: 'transform',
              },
              .08,
            );
          }
        }
      }, wurzel);

      ScrollTrigger.sort();
      requestAnimationFrame(() => ScrollTrigger.refresh());

      /* Stillstandssicherung. Der heroNotausstieg deckt nur den Hero ab.
         Kontaktdaten, Formular und CTA starten ebenfalls auf autoAlpha 0 und
         haengen an ScrollTriggern; steht der Bildtakt still, waere das
         Kontaktformular dauerhaft unsichtbar. */
      window.RailTimeStillstand?.(() => {
        allesSichtbar();
        wurzel.dataset.contactBereit = 'takt-notausstieg';
      }, { fertig: () => wurzel.dataset.contactBereit === 'takt-notausstieg' });
    } catch (fehler) {
      allesSichtbar();
      wurzel.dataset.contactBereit = 'fehler-fallback';
      console.error('[rt-contact]', fehler);
    }

    addEventListener('pagehide', () => {
      clearTimeout(heroNotausstieg);
      kontext?.revert();
    }, { once: true });
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', starten, { once: true });
  } else {
    starten();
  }
})();
