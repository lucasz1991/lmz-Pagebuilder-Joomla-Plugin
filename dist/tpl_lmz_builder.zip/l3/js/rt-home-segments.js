/* Einziger Motion-Owner fuer das erste Inhaltssegment der Startseite. */
(() => {
  'use strict';

  if (!document.body.classList.contains('is-home')) return;
  if (!window.gsap || !window.ScrollTrigger) return;

  gsap.registerPlugin(ScrollTrigger);
  if (window.SplitText) gsap.registerPlugin(SplitText);

  const sektion = document.querySelector('.sa-intro');
  const lead = sektion?.querySelector('.sa-intro__lead');
  const eyebrow = lead?.querySelector('.sa-eyebrow');
  const eyebrowLinie = eyebrow?.querySelector('span');
  const titel = lead?.querySelector('h1');
  const bild = sektion?.querySelector('.sa-intro__image');
  const bildElement = bild?.querySelector('img');
  const fakten = sektion?.querySelector('.sa-intro__facts');
  const faktEintraege = fakten ? [...fakten.children] : [];
  const aktion = sektion?.querySelector(':scope > .sa-arrow-link');
  if (!sektion || !lead || !titel || !bild || !fakten) return;

  const sparsam = matchMedia('(prefers-reduced-motion: reduce)').matches;
  let timeline = null;
  let trigger = null;
  let teilung = null;

  const fremdeOwnerEntfernen = () => {
    ScrollTrigger.getAll().forEach((andererTrigger) => {
      const ausloeser = andererTrigger.trigger;
      if (!ausloeser || (ausloeser !== sektion && !sektion.contains(ausloeser))) return;
      andererTrigger.animation?.kill();
      andererTrigger.kill();
    });

    [lead, bild, fakten].forEach(element => {
      element?.classList.remove('sa-motion-up', 'sa-motion-left', 'sa-motion-right');
    });
    sektion.classList.remove('rt-motion-clip');
    sektion.dataset.rtMotionOwner = 'home-segments';
    gsap.set([lead, eyebrow, eyebrowLinie, titel, bild, bildElement, fakten, ...faktEintraege, aktion].filter(Boolean), {
      clearProps: 'transform,translate,rotate,scale,opacity,visibility,clipPath,transformOrigin',
    });
  };

  /* Die per SplitText erzeugten Zeilen sind eigene Elemente und tragen den
     autoAlpha-0-Startwert der Ueberschrift. Sie muessen im Endzustand
     mitgemeint sein, sonst bleibt genau die H1 unsichtbar. */
  let titelZeilen = [titel];

  const allesSichtbar = () => {
    gsap.set([lead, eyebrow, titel, bild, bildElement, fakten, ...faktEintraege, aktion].filter(Boolean), {
      autoAlpha: 1,
      x: 0,
      y: 0,
      scale: 1,
      clearProps: 'clipPath',
    });
    gsap.set(titelZeilen.filter(Boolean), {
      autoAlpha: 1,
      yPercent: 0,
      y: 0,
      clearProps: 'clipPath',
    });
    if (eyebrowLinie) gsap.set(eyebrowLinie, { scaleX: 1 });
  };

  const aufbauen = () => {
    fremdeOwnerEntfernen();

    if (sparsam) {
      allesSichtbar();
      return;
    }

    titelZeilen = [titel];
    if (window.SplitText) {
      try {
        teilung = new SplitText(titel, {
          type: 'lines',
          linesClass: 'rt-intro-line',
          mask: 'lines',
        });
        if (teilung.lines?.length) titelZeilen = teilung.lines;
      } catch (_fehler) {
        teilung = null;
      }
    }

    const zahl = fakten.querySelector('strong');
    const zahlenTreffer = zahl?.textContent.trim().match(/^(\d+)(\D*)$/);
    const zaehler = { wert: 0 };
    const zahlenZiel = zahlenTreffer ? Number(zahlenTreffer[1]) : 0;
    const zahlenAnhang = zahlenTreffer?.[2] || '';

    gsap.set(eyebrow, { autoAlpha: 0, y: 14 });
    if (eyebrowLinie) gsap.set(eyebrowLinie, { scaleX: 0, transformOrigin: '0 50%' });
    gsap.set(titelZeilen, { autoAlpha: 0, yPercent: 112 });
    gsap.set(bild, { autoAlpha: 0, x: 62 });
    if (bildElement) gsap.set(bildElement, { scale: 1.085, clipPath: 'inset(0 0 0 18%)' });
    gsap.set(faktEintraege, { autoAlpha: 0, y: 24 });
    if (aktion) gsap.set(aktion, { autoAlpha: 0, y: 16 });
    if (zahl && zahlenTreffer) zahl.textContent = `0${zahlenAnhang}`;

    timeline = gsap.timeline({
      paused: true,
      defaults: { overwrite: 'auto' },
      onStart: () => { sektion.dataset.rtSegmentState = 'playing'; },
      onComplete: () => {
        sektion.dataset.rtSegmentState = 'complete';
        gsap.set([eyebrow, titelZeilen, bild, bildElement, ...faktEintraege, aktion].filter(Boolean), {
          clearProps: 'transform,translate,rotate,scale,opacity,visibility,clipPath,transformOrigin',
        });
        if (eyebrowLinie) gsap.set(eyebrowLinie, { clearProps: 'transform,transformOrigin' });
      },
    });

    timeline.addLabel('auftakt', 0);
    timeline.to(eyebrow, {
      autoAlpha: 1,
      y: 0,
      duration: .55,
      ease: 'power3.out',
    }, 'auftakt');
    if (eyebrowLinie) {
      timeline.to(eyebrowLinie, {
        scaleX: 1,
        duration: .72,
        ease: 'power3.out',
      }, 'auftakt+=.08');
    }
    timeline.to(titelZeilen, {
      autoAlpha: 1,
      yPercent: 0,
      duration: .92,
      ease: 'power4.out',
      stagger: .075,
    }, 'auftakt+=.12');
    timeline.to(bild, {
      autoAlpha: 1,
      x: 0,
      duration: 1.02,
      ease: 'power3.out',
    }, 'auftakt+=.24');
    if (bildElement) {
      timeline.to(bildElement, {
        scale: 1,
        clipPath: 'inset(0 0 0 0%)',
        duration: 1.28,
        ease: 'power3.out',
      }, 'auftakt+=.24');
    }
    timeline.to(faktEintraege, {
      autoAlpha: 1,
      y: 0,
      duration: .72,
      ease: 'power3.out',
      stagger: .11,
    }, 'auftakt+=.78');
    if (zahl && zahlenTreffer) {
      timeline.to(zaehler, {
        wert: zahlenZiel,
        duration: 1.15,
        ease: 'power2.out',
        onUpdate: () => { zahl.textContent = `${Math.round(zaehler.wert)}${zahlenAnhang}`; },
      }, 'auftakt+=.76');
    }
    if (aktion) {
      timeline.to(aktion, {
        autoAlpha: 1,
        y: 0,
        duration: .64,
        ease: 'power3.out',
      }, 'auftakt+=1.12');
    }

    sektion.dataset.rtSegmentState = 'pending';
    trigger = ScrollTrigger.create({
      id: 'rt-home-first-segment',
      trigger: sektion,
      start: 'top 78%',
      once: true,
      onEnter: () => timeline.play(0),
    });
    ScrollTrigger.refresh();
    stillstandSichern();
  };

  /* Stillstandssicherung. GSAP und ScrollTrigger haengen am Bildtakt. Steht er
     still, feuert weder der Trigger noch ein onComplete und die oben gesetzten
     autoAlpha-0-Zustaende blieben dauerhaft unsichtbar. */
  const stillstandSichern = () => {
    window.RailTimeStillstand?.(() => {
      allesSichtbar();
      sektion.dataset.rtSegmentState = 'notausstieg';
    }, { fertig: () => sektion.dataset.rtSegmentState === 'complete' });
  };

  let aufbauGestartet = false;
  const aufbauenEinmal = () => {
    if (aufbauGestartet) return;
    aufbauGestartet = true;
    aufbauen();
  };

  const fontsBereit = document.fonts?.ready || Promise.resolve();
  fontsBereit.then(() => requestAnimationFrame(aufbauenEinmal))
    .catch(() => requestAnimationFrame(aufbauenEinmal));
  /* Ohne rAF-Takt kaeme aufbauen() nie zum Zug; dann uebernimmt die Frist. */
  window.setTimeout(aufbauenEinmal, 1600);

  addEventListener('railtime:intro-complete', () => ScrollTrigger.refresh(), { once: true });
  addEventListener('pagehide', () => {
    trigger?.kill();
    timeline?.kill();
    teilung?.revert?.();
  }, { once: true });
})();
