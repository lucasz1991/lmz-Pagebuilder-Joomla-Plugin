/**
 * RailTime - gemeinsame Bewegungsschicht der Unterseiten.
 *
 * Eine Datei fuer alle Unterseiten. Jeder Baustein wird nur aufgebaut, wenn
 * er auf der Seite vorhanden ist; die Seiteninhalte bringen also nur Markup
 * mit und kein eigenes Skript mehr.
 *
 * Zwei Regeln, die aus Fehlern in frueheren Fassungen stammen:
 *  - Niemals transform/scale auf Elemente legen, deren Position selbst an
 *    einem CSS-Transform haengt (siehe Kartennadeln der Startseite).
 *  - Der Ladevorhang braucht eine Sicherung ueber setTimeout. GSAP haengt an
 *    requestAnimationFrame; steht der Ticker still, etwa beim Laden in einem
 *    Hintergrund-Tab, wuerde der Vorhang die Seite dauerhaft verdecken.
 */
(function () {
  'use strict';

  document.addEventListener('DOMContentLoaded', function () {
    var wurzel = document.querySelector('.rt-x');
    if (!wurzel) return;

    var alle = function (s) { return Array.prototype.slice.call(wurzel.querySelectorAll(s)); };
    var eins = function (s) { return wurzel.querySelector(s); };
    var vorhang = eins('.rt-x__vorhang');
    var sparsam = matchMedia('(prefers-reduced-motion: reduce)').matches;
    var rechtstext = document.body.classList.contains('is-legal');

    if (rechtstext && vorhang) {
      vorhang.hidden = true;
      vorhang.style.display = 'none';
      vorhang = null;
    }

    /* Notausgang: ohne GSAP oder bei reduzierter Bewegung alles statisch. */
    if (!window.gsap || !window.ScrollTrigger || sparsam) {
      if (vorhang) vorhang.style.display = 'none';
      alle('.rt-x__feld').forEach(function (f) { f.style.height = 'auto'; });
      alle('.rt-x__vitrine figure').forEach(function (f, i) { f.style.opacity = i ? '0' : '1'; });
      wurzel.dataset.xBereit = 'statisch';
      return;
    }

    gsap.registerPlugin(ScrollTrigger);
    if (window.ScrollToPlugin) gsap.registerPlugin(ScrollToPlugin);
    if (window.SplitText) gsap.registerPlugin(SplitText);
    gsap.config({ nullTargetWarn: false });
    ScrollTrigger.config({ ignoreMobileResize: true });
    wurzel.dataset.xBereit = 'gsap';

    var mm = gsap.matchMedia();
    var AUS = 'power3.out';

    /* ---------------------------------------------------------------- *
     * Hintergrund
     * ---------------------------------------------------------------- */

    alle('.rt-x__blob').forEach(function (b, i) {
      gsap.to(b, {
        xPercent: i % 2 ? -15 : 17, rotation: i % 2 ? 4 : -4,
        duration: 19 + i * 4, ease: 'sine.inOut', repeat: -1, yoyo: true
      });
      gsap.to(b, {
        yPercent: i % 2 ? -24 : 20, ease: 'none',
        scrollTrigger: { trigger: wurzel, start: 'top top', end: 'bottom bottom', scrub: 1.2 }
      });
    });

    /* ---------------------------------------------------------------- *
     * Ladevorhang und Einzug
     * ---------------------------------------------------------------- */

    var heroTeile = alle('.rt-x__hero-text > *');
    var heroFigur = eins('.rt-x__hero-figur');

    if (vorhang) {
      gsap.set(heroTeile, { y: 46, opacity: 0 });
      if (heroFigur) gsap.set(heroFigur, { y: 60, opacity: 0, scale: .94 });

      var einzug = gsap.timeline();
      einzug
        .to('.rt-x__ladebalken i', { scaleX: 1, duration: .85, ease: 'power2.inOut' })
        .to('.rt-x__vorhang img', { scale: .82, opacity: 0, duration: .4, ease: 'power2.in' }, '-=.15')
        .to(vorhang, { yPercent: -100, duration: .95, ease: 'power3.inOut' })
        .set(vorhang, { display: 'none' })
        .to(heroTeile, { y: 0, opacity: 1, duration: .95, ease: AUS, stagger: .085 }, '-=.55');

      if (heroFigur) {
        einzug.to(heroFigur, { y: 0, opacity: 1, scale: 1, duration: 1.05, ease: AUS }, '-=.75');
      }

      var notausstieg = window.setTimeout(function () {
        gsap.set(vorhang, { display: 'none' });
        gsap.set(heroTeile, { y: 0, opacity: 1 });
        if (heroFigur) gsap.set(heroFigur, { y: 0, opacity: 1, scale: 1 });
      }, 4000);
      einzug.eventCallback('onComplete', function () { window.clearTimeout(notausstieg); });
    }

    if (heroFigur) {
      gsap.to(heroFigur.querySelector('img'), {
        yPercent: 12, ease: 'none',
        scrollTrigger: { trigger: '.rt-x__hero', start: 'top top', end: 'bottom top', scrub: .8 }
      });
    }

    /* ---------------------------------------------------------------- *
     * Bausteine
     * ---------------------------------------------------------------- */

    /* Zahlen hochzaehlen - nur wo tatsaechlich eine Zahl steht. */
    alle('.rt-x__zahl strong').forEach(function (feld) {
      var t = feld.textContent.trim().match(/^(\d+)(\D*)$/);
      if (!t) return;                                  // "24/7" und "DE" bleiben
      var ziel = Number(t[1]), anhang = t[2], stand = { w: 0 };
      ScrollTrigger.create({
        trigger: feld, start: 'top 92%', once: true,
        onEnter: function () {
          gsap.to(stand, {
            w: ziel, duration: 1.5, ease: 'power2.out',
            onUpdate: function () { feld.textContent = Math.round(stand.w) + anhang; }
          });
        }
      });
    });

    /* Ueberschriften zeilenweise aus ihrer Maske. */
    alle('[data-x-split]').forEach(function (kopf) {
      var geteilt = false;

      if (window.SplitText) {
        try {
          SplitText.create(kopf, {
            type: 'lines',
            linesClass: 'rt-x__zeile',
            autoSplit: true,
            onSplit: function (selbst) {
              geteilt = true;
              kopf.classList.add('rt-x__split-host');
              return gsap.from(selbst.lines, {
                yPercent: 118,
                opacity: 0,
                duration: 1.05,
                ease: 'power4.out',
                stagger: .09,
                scrollTrigger: { trigger: kopf, start: 'top 88%', once: true },
              });
            }
          });
        } catch (e) {
          geteilt = false;
        }
      }

      if (!geteilt) {
        gsap.from(kopf, { y: 44, opacity: 0, duration: 1, ease: AUS,
          scrollTrigger: { trigger: kopf, start: 'top 88%', once: true } });
      }
    });

    /* Allgemeine Einblendung. */
    alle('[data-x-reveal]').forEach(function (el, i) {
      gsap.fromTo(el, { y: 52, opacity: 0 }, {
        y: 0, opacity: 1, duration: .95, ease: AUS,
        scrollTrigger: { trigger: el, start: 'top 90%', once: true }
      });
    });

    /* Gruppen laufen gestaffelt ein. */
    alle('[data-x-stagger]').forEach(function (gruppe) {
      var kinder = Array.prototype.slice.call(gruppe.children);
      if (!kinder.length) return;
      gsap.fromTo(kinder, { y: 60, opacity: 0 }, {
        y: 0, opacity: 1, duration: .95, ease: AUS, stagger: .1,
        scrollTrigger: { trigger: gruppe, start: 'top 86%', once: true }
      });
    });

    /* Bilder fahren aus der Vergroesserung heraus. */
    alle('[data-x-scale]').forEach(function (bild) {
      gsap.fromTo(bild, { scale: 1.12 }, {
        scale: 1, ease: 'none',
        scrollTrigger: { trigger: bild.closest('figure') || bild.parentElement || bild,
                         start: 'top bottom', end: 'bottom top', scrub: .8 }
      });
    });

    /* Tiefenversatz. */
    alle('[data-x-parallax]').forEach(function (el) {
      gsap.fromTo(el, { yPercent: -8 }, {
        yPercent: 8, ease: 'none',
        scrollTrigger: { trigger: el.closest('a, figure, section') || el.parentElement,
                         start: 'top bottom', end: 'bottom top', scrub: .7 }
      });
    });

    /* Kacheln: wechselseitig herein. */
    alle('.rt-x__kachel').forEach(function (kachel, i) {
      gsap.fromTo(kachel, { y: 74, opacity: 0, rotate: i % 2 ? 1.4 : -1.4 }, {
        y: 0, opacity: 1, rotate: 0, duration: 1, ease: AUS,
        scrollTrigger: { trigger: kachel, start: 'top 90%', once: true }
      });
    });

    /* ---------------------------------------------------------------- *
     * Stapelnde Karten
     * ---------------------------------------------------------------- */

    var stapel = eins('.rt-x__stapel');
    if (stapel) {
      var karten = Array.prototype.slice.call(stapel.querySelectorAll('.rt-x__karte'));

      karten.forEach(function (karte) {
        gsap.fromTo(karte.children, { y: 34, opacity: 0 }, {
          y: 0, opacity: 1, duration: .8, ease: AUS, stagger: .08,
          scrollTrigger: { trigger: karte, start: 'top 88%', once: true }
        });
      });

      if (karten.length > 1) {
        mm.add('(min-width: 1001px)', function () {
          var kopfabstand = 116, versatz = 26;
          karten.forEach(function (karte, i) {
            ScrollTrigger.create({
              trigger: karte,
              start: 'top ' + (kopfabstand + i * versatz),
              endTrigger: stapel,
              end: 'bottom top',
              pin: true, pinSpacing: false, invalidateOnRefresh: true
            });
            if (i < karten.length - 1) {
              gsap.to(Array.prototype.slice.call(karte.children), {
                opacity: .7, ease: 'none',
                scrollTrigger: {
                  trigger: karten[i + 1], start: 'top 78%',
                  end: 'top ' + (kopfabstand + (i + 1) * versatz),
                  scrub: .5, invalidateOnRefresh: true
                }
              });
            }
          });
        });
      }
    }

    /* ---------------------------------------------------------------- *
     * Angeheftete Buehne mit Akkordeon
     *
     * Geoeffnet wird ueber einen Index, nicht ueber eine gescrubbte
     * Zeitleiste: height:auto laesst sich nicht sauber scrubben und
     * springt beim Zurueckscrollen.
     * ---------------------------------------------------------------- */

    var buehne = eins('.rt-x__buehne');
    var eintraege = alle('.rt-x__eintrag');
    var anheftung = null;

    if (buehne && eintraege.length) {
      var felder = eintraege.map(function (e) { return e.querySelector('.rt-x__feld'); });
      var bilder = alle('.rt-x__vitrine figure');
      var grosseNr = eins('.rt-x__vitrine-nr');
      var balken = eins('.rt-x__fortschritt-spur i');
      var anzeige = eins('[data-x-zaehler]');
      var zz = function (n) { return (n < 10 ? '0' : '') + n; };
      var aktuell = -1;
      var indexAusHash = function () {
        if (!location.hash) return -1;
        var slug = location.hash.slice(1);
        try { slug = decodeURIComponent(slug); } catch (e) { /* unveraendert pruefen */ }
        return eintraege.findIndex(function (eintrag) { return eintrag.id === slug; });
      };
      var anfangsIndex = indexAusHash();

      var aktiviere = function (index, sofort) {
        if (index === aktuell) return;
        aktuell = index;

        eintraege.forEach(function (eintrag, k) {
          var offen = k === index;
          eintrag.classList.toggle('is-offen', offen);
          eintrag.querySelector('.rt-x__kopf').setAttribute('aria-expanded', String(offen));

          var feld = felder[k];
          gsap.killTweensOf(feld);
          if (offen) {
            gsap.to(feld, { height: 'auto', duration: sofort ? 0 : .6, ease: 'power2.inOut' });
            var inhalt = feld.querySelector('.rt-x__feld-inner').children;
            gsap.fromTo(inhalt, { y: 20, opacity: 0 },
              { y: 0, opacity: 1, duration: .55, ease: 'power2.out', stagger: .07, delay: sofort ? 0 : .14 });
          } else {
            gsap.to(feld, { height: 0, duration: sofort ? 0 : .45, ease: 'power2.inOut' });
          }
        });

        if (bilder.length) {
          bilder.forEach(function (f, k) {
            gsap.to(f, { opacity: k === index ? 1 : 0, duration: sofort ? 0 : .7, ease: 'power2.out' });
          });
          if (bilder[index]) {
            gsap.fromTo(bilder[index].querySelector('img'), { scale: 1.1 },
              { scale: 1, duration: 1.1, ease: AUS });
          }
        }
        if (grosseNr) grosseNr.textContent = index >= 0 ? zz(index + 1) : '--';
        if (anzeige) anzeige.textContent = (index >= 0 ? zz(index + 1) : '00') + ' / ' + zz(eintraege.length);
      };

      aktiviere(anfangsIndex >= 0 ? anfangsIndex : 0, true);

      mm.add('(min-width: 1001px)', function () {
        anheftung = ScrollTrigger.create({
          trigger: buehne,
          start: 'top top+=104',
          end: function () { return '+=' + (eintraege.length * 560); },
          pin: true, pinSpacing: true, invalidateOnRefresh: true,
          onUpdate: function (selbst) {
            var i = Math.floor(selbst.progress * eintraege.length);
            if (i > eintraege.length - 1) i = eintraege.length - 1;
            if (i < 0) i = 0;
            aktiviere(i);
            if (balken) gsap.set(balken, { scaleX: selbst.progress });
          }
        });
        return function () { anheftung = null; };
      });

      var springeZu = function (i, sofort, umschalten, elementScrollen) {
        if (i < 0 || i >= eintraege.length) return;

        if (!anheftung) {
          var zielIndex = umschalten && i === aktuell ? -1 : i;
          aktiviere(zielIndex, sofort);
          if (elementScrollen && zielIndex >= 0) {
            eintraege[zielIndex].scrollIntoView({ behavior: sofort ? 'auto' : 'smooth', block: 'start' });
          }
          return;
        }

        var ziel = anheftung.start + (anheftung.end - anheftung.start) * ((i + .5) / eintraege.length);
        if (sofort) {
          window.scrollTo(0, ziel);
          ScrollTrigger.update();
          aktiviere(i, true);
        } else if (window.ScrollToPlugin) {
          gsap.to(window, { scrollTo: { y: ziel }, duration: .8, ease: 'power2.inOut' });
        } else {
          window.scrollTo({ top: ziel, behavior: 'smooth' });
        }
      };

      var setzeHash = function (index) {
        var slug = index >= 0 ? eintraege[index].id : '';
        var ziel = location.pathname + location.search + (slug ? '#' + encodeURIComponent(slug) : '');
        history.replaceState(null, '', ziel);
      };

      eintraege.forEach(function (eintrag, i) {
        eintrag.querySelector('.rt-x__kopf').addEventListener('click', function () {
          var schliessen = !anheftung && i === aktuell;
          setzeHash(schliessen ? -1 : i);
          springeZu(i, false, true, false);
        });
      });
      alle('.rt-x__kachel').forEach(function (kachel) {
        kachel.addEventListener('click', function (ev) {
          var href = kachel.getAttribute('href') || '';
          var slug = href.charAt(0) === '#' ? href.slice(1) : '';
          var i = eintraege.findIndex(function (eintrag) { return eintrag.id === slug; });
          if (i < 0) return;
          ev.preventDefault();
          setzeHash(i);
          springeZu(i, false, false, true);
        });
      });

      addEventListener('hashchange', function () {
        var i = indexAusHash();
        if (i >= 0) springeZu(i, false, false, true);
      });

      if (anfangsIndex >= 0) {
        var anfangAnfahren = function () {
          window.setTimeout(function () {
            ScrollTrigger.refresh();
            springeZu(anfangsIndex, true, false, true);
          }, 0);
        };
        if (document.readyState === 'complete') anfangAnfahren();
        else addEventListener('load', anfangAnfahren, { once: true });
      }
    }

    /* ---------------------------------------------------------------- *
     * Ablaufspur
     * ---------------------------------------------------------------- */

    var spur = eins('.rt-x__spur');
    if (spur) {
      var schritte = alle('.rt-x__schritt');
      gsap.fromTo(schritte, { y: 42, opacity: 0 }, {
        y: 0, opacity: 1, duration: .85, ease: AUS, stagger: .12,
        scrollTrigger: { trigger: spur, start: 'top 86%', once: true }
      });
      /* Feste Strecke statt 'bottom ...': Die Spur ist flach, sonst laegen
         Anfang und Ende nur rund 250px auseinander. */
      ScrollTrigger.create({
        trigger: spur, start: 'top 84%', end: '+=620', scrub: .6,
        onUpdate: function (selbst) {
          spur.style.setProperty('--linie', selbst.progress.toFixed(4));
          var bis = Math.round(selbst.progress * schritte.length);
          schritte.forEach(function (s, k) { s.classList.toggle('is-aktiv', k < bis); });
        }
      });
    }

    /* ---------------------------------------------------------------- *
     * Handlungsaufruf
     * ---------------------------------------------------------------- */

    var cta = eins('.rt-x__cta');
    if (cta) {
      gsap.fromTo(cta, { y: 72, opacity: 0, scale: .97 }, {
        y: 0, opacity: 1, scale: 1, duration: 1.05, ease: AUS,
        scrollTrigger: { trigger: cta, start: 'top 88%', once: true }
      });
    }

    ScrollTrigger.sort();
    ScrollTrigger.refresh();
  });
})();
