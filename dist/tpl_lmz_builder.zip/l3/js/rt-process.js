(() => {
  'use strict';

  const starten = () => {
    const body = document.body;
    const istHome = body.classList.contains('is-home');
    const istAbout = body.classList.contains('is-about');
    const istServices = body.classList.contains('is-services');
    if (!istHome && !istAbout && !istServices) return;

    let sektion = null;
    let spur = null;

    if (istHome) {
      sektion = document.querySelector('.sa-process');
      spur = sektion?.querySelector('.sa-process__steps');
    } else if (istAbout) {
      spur = document.querySelector('.rt-x__scheiben');
      sektion = spur?.closest('.rt-x__section');
    } else {
      spur = document.querySelector('.rt-x__spur');
      sektion = spur?.closest('.rt-x__section');
    }

    const kopf = sektion?.querySelector(':scope > header');
    const schritte = spur ? [...spur.children].filter(element => element.matches('article')) : [];
    if (!sektion || !kopf || !spur || schritte.length === 0) return;

    sektion.classList.add(
      'rt-process-unified',
      istServices ? 'rt-process-unified--light' : 'rt-process-unified--dark',
    );
    kopf.classList.add('rt-process-header');
    spur.classList.add('rt-process-track');
    schritte.forEach(schritt => schritt.classList.add('rt-process-step'));

    /* Eyebrow und Titel kommen uebersetzt aus dem LMZ Page Builder und werden
       hier NICHT mehr ueberschrieben - sonst erschienen sie in allen Sprachen
       ausser de/en/pl auf Deutsch. Es werden nur noch die Layout-Klassen
       gesetzt. */
    const eyebrow = kopf.querySelector('.sa-eyebrow, .rt-x__eyebrow, p');
    const titel = kopf.querySelector('h2');
    if (eyebrow) {
      eyebrow.classList.add('rt-process-eyebrow');
    }

    /* Die Startseite hatte einen zweiten Reveal-Owner und einzelne Punkt-
       Spans. Beides wird vor dessen Initialisierung entfernt, damit nur diese
       gemeinsame Timeline Transform und Sichtbarkeit besitzt. */
    if (istHome) {
      [kopf, ...schritte].forEach(element => element.classList.remove('sa-motion-up'));
      schritte.forEach((schritt) => {
        [...schritt.children]
          .filter(element => element.tagName === 'SPAN' && !element.querySelector('svg'))
          .forEach(element => element.remove());
      });
    }

    const icons = [
      '<svg viewBox="0 0 24 24"><path d="M8.5 5.5H5v15h14v-15h-3.5"/><path d="M9 3.5h6v4H9zM8 12h8M8 16h5"/></svg>',
      '<svg viewBox="0 0 24 24"><path d="M4 6h16M4 12h16M4 18h16"/><circle cx="9" cy="6" r="2"/><circle cx="15" cy="12" r="2"/><circle cx="11" cy="18" r="2"/></svg>',
      '<svg viewBox="0 0 24 24"><path d="M12 3l7 3v5c0 4.8-3 8-7 10-4-2-7-5.2-7-10V6l7-3z"/><path d="m8.5 12 2.2 2.2 4.8-5"/></svg>',
      '<svg viewBox="0 0 24 24"><path d="M6 3h8l4 4v14H6zM14 3v5h5"/><path d="m9 14 2 2 4-4"/></svg>',
    ];

    schritte.forEach((schritt, index) => {
      let icon = schritt.querySelector(':scope > .rt-process-icon, :scope > .rt-services-step-icon');
      if (!icon) {
        icon = document.createElement('span');
        schritt.prepend(icon);
      }
      icon.classList.add('rt-process-icon', 'rt-services-step-icon');
      icon.setAttribute('aria-hidden', 'true');
      if (!icon.querySelector('svg')) icon.innerHTML = icons[index] || icons[icons.length - 1];
    });

    const kopfTeile = [...kopf.children];
    const finalzustand = () => {
      sektion.style.setProperty('--rt-process-line', '1');
      sektion.dataset.processState = 'complete';
      if (window.gsap) {
        gsap.set([...kopfTeile, ...schritte], {
          clearProps: 'transform,opacity,visibility,willChange',
        });
      }
    };

    const sparsam = matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (!window.gsap || !window.ScrollTrigger || sparsam) {
      finalzustand();
      return;
    }

    gsap.registerPlugin(ScrollTrigger);
    sektion.style.setProperty('--rt-process-line', '0');
    sektion.dataset.processState = 'pending';

    /* Stillstandssicherung. Kopf und Schritte starten auf autoAlpha 0 und
       werden nur von einer ScrollTrigger-Timeline sichtbar gemacht. Steht der
       Bildtakt still, feuert weder der Trigger noch das onComplete und der
       ganze Prozessabschnitt bleibt unsichtbar. */
    window.RailTimeStillstand?.(finalzustand, {
      fertig: () => sektion.dataset.processState === 'complete',
    });

    if (istAbout) {
      const iconsInSteps = schritte
        .map(schritt => schritt.querySelector('.rt-process-icon'))
        .filter(Boolean);
      const triggerId = 'rt-process-about';
      const altenTriggerEntfernen = () => {
        const trigger = ScrollTrigger.getById(triggerId);
        trigger?.animation?.kill();
        trigger?.kill();
      };
      altenTriggerEntfernen();

      const medien = gsap.matchMedia();
      medien.add({
        desktop: '(min-width: 761px)',
        mobile: '(max-width: 760px)',
      }, (context) => {
        const kompakt = context.conditions.mobile;

        gsap.set(kopfTeile, { autoAlpha: 0, y: kompakt ? 22 : 34 });
        gsap.set(schritte, {
          autoAlpha: 0,
          y: kompakt ? 24 : 42,
          scale: kompakt ? 1 : .975,
        });
        gsap.set(iconsInSteps, {
          scale: .58,
          rotation: index => kompakt ? -6 : (index % 2 ? 12 : -12),
        });

        const timeline = gsap.timeline({
          scrollTrigger: {
            id: triggerId,
            trigger: sektion,
            start: kompakt ? 'top 84%' : 'top 72%',
            end: kompakt ? 'bottom 28%' : 'bottom 38%',
            scrub: kompakt ? .42 : .64,
            invalidateOnRefresh: true,
            onToggle: self => sektion.classList.toggle('is-rt-process-motion-active', self.isActive),
            onUpdate: self => {
              sektion.dataset.processState = self.progress.toFixed(3);
            },
          },
        });

        timeline
          .to(kopfTeile, {
            autoAlpha: 1,
            y: 0,
            duration: .32,
            ease: 'power3.out',
            stagger: .06,
          }, 0)
          .fromTo(sektion,
            { '--rt-process-line': 0 },
            { '--rt-process-line': 1, duration: .62, ease: 'none' }, .14)
          .to(schritte, {
            autoAlpha: 1,
            y: 0,
            scale: 1,
            duration: .46,
            ease: 'power3.out',
            stagger: .1,
          }, .38)
          .to(iconsInSteps, {
            scale: 1,
            rotation: 0,
            duration: .4,
            ease: 'back.out(1.35)',
            stagger: .1,
          }, .5);

        return () => {
          sektion.classList.remove('is-rt-process-motion-active');
        };
      });

      const refresh = () => requestAnimationFrame(() => ScrollTrigger.refresh());
      const beiPageshow = (event) => {
        if (event.persisted) refresh();
      };
      const beiPagehide = (event) => {
        if (event.persisted) return;
        removeEventListener('pageshow', beiPageshow);
        removeEventListener('pagehide', beiPagehide);
        medien.revert();
        altenTriggerEntfernen();
      };
      addEventListener('pageshow', beiPageshow);
      addEventListener('pagehide', beiPagehide);
      refresh();
      return;
    }

    if (istServices) {
      const iconsInSteps = schritte
        .map(schritt => schritt.querySelector('.rt-process-icon'))
        .filter(Boolean);
      const kompakt = () => matchMedia('(max-width: 760px)').matches;
      const scrollDistance = () => kompakt()
        ? gsap.utils.clamp(260, 460, innerHeight * .46)
        : gsap.utils.clamp(340, 640, innerHeight * .58);

      gsap.set(kopfTeile, { autoAlpha: .08, y: () => kompakt() ? 20 : 30 });
      gsap.set(schritte, {
        autoAlpha: .06,
        y: () => kompakt() ? 26 : 38,
        scale: () => kompakt() ? .99 : .975,
      });
      gsap.set(iconsInSteps, {
        scale: .62,
        rotation: index => kompakt() ? (index % 2 ? 5 : -5) : (index % 2 ? 10 : -10),
      });

      const timeline = gsap.timeline({
        scrollTrigger: {
          id: 'rt-process-services',
          trigger: sektion,
          start: 'top 90%',
          end: () => `+=${scrollDistance()}`,
          scrub: .62,
          invalidateOnRefresh: true,
          onToggle: self => sektion.classList.toggle('is-rt-process-motion-active', self.isActive),
          onUpdate: self => {
            sektion.dataset.processState = self.progress.toFixed(3);
          },
        },
      });

      timeline
        .fromTo(sektion,
          { '--rt-process-line': 0 },
          { '--rt-process-line': 1, duration: 1.25, ease: 'none' }, 0)
        .to(kopfTeile, {
          autoAlpha: 1,
          y: 0,
          duration: .82,
          ease: 'power3.out',
          stagger: .09,
        }, .03)
        .to(schritte, {
          autoAlpha: 1,
          y: 0,
          scale: 1,
          duration: .9,
          ease: 'power3.out',
          stagger: .11,
        }, .2)
        .to(iconsInSteps, {
          scale: 1,
          rotation: 0,
          duration: .82,
          ease: 'back.out(1.3)',
          stagger: .11,
        }, .29);

      requestAnimationFrame(() => ScrollTrigger.refresh());
      addEventListener('pageshow', event => {
        if (event.persisted) requestAnimationFrame(() => ScrollTrigger.refresh());
      });
      addEventListener('pagehide', event => {
        if (event.persisted) return;
        timeline.scrollTrigger?.kill();
        timeline.kill();
      }, { once: true });
      return;
    }

    const timeline = gsap.timeline({
      scrollTrigger: {
        id: `rt-process-${istHome ? 'home' : istAbout ? 'about' : 'services'}`,
        trigger: sektion,
        start: 'top 74%',
        once: true,
        toggleActions: 'play none none none',
      },
      onStart: () => { sektion.dataset.processState = 'running'; },
      onComplete: finalzustand,
    });

    timeline.fromTo(kopfTeile,
      { autoAlpha: 0, y: 28, willChange: 'transform,opacity' },
      { autoAlpha: 1, y: 0, duration: .68, ease: 'power3.out', stagger: .08 }, 0);
    timeline.to(sektion, {
      '--rt-process-line': 1,
      duration: .82,
      ease: 'power2.inOut',
    }, .12);
    timeline.fromTo(schritte,
      { autoAlpha: 0, y: 30, willChange: 'transform,opacity' },
      { autoAlpha: 1, y: 0, duration: .62, ease: 'power3.out', stagger: .1 }, .3);

    requestAnimationFrame(() => ScrollTrigger.refresh());
    addEventListener('pagehide', () => timeline.kill(), { once: true });
  };

  let startGelaufen = false;
  const starteEinmal = () => {
    if (startGelaufen) return;
    startGelaufen = true;
    starten();
  };

  if (document.readyState === 'loading') starteEinmal();
  else requestAnimationFrame(starteEinmal);
  /* Ohne rAF-Takt kaeme starten() nie zum Zug und die Prozesslinie bliebe
     ungesetzt. */
  window.setTimeout(starteEinmal, 1600);
})();
