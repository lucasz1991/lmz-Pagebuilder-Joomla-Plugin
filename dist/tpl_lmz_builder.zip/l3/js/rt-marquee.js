/*
 * Ruhig und autonom laufendes Signalband (.sa-rail).
 *
 * Vorher: eine CSS-Animation schob die Spur auf translateX(-22%) und sprang
 * dann hart auf 0 zurueck — nach dem letzten Begriff kam also nicht wieder
 * der erste. Zusaetzlich standen im Markup nur vier echte Begriffe plus eine
 * halbe Wiederholung, sodass rechts Leerraum blieb.
 *
 * Jetzt: Das Skript baut genau einen eindeutigen, weit aufgefaecherten Satz.
 * Nur eine zweite, fuer Screenreader verborgene Kopie bildet den nahtlosen
 * GSAP-Uebergang; Geschwindigkeit und Richtung sind vom Scrollen unabhaengig.
 */
(() => {
  const band = document.querySelector('.sa-rail');
  const spur = band?.querySelector('div');
  if (!band || !spur || typeof gsap === 'undefined') return;

  const sparsam = matchMedia('(prefers-reduced-motion: reduce)');

  const TEMPO = 50;
  const MINDEST_ABSTAND = 64;
  const ZUSATZ_RAUM = 120;

  // Die CSS-Animation wuerde die GSAP-Transformation ueberschreiben:
  // laufende Animationen haben Vorrang vor inline gesetzten Werten.
  spur.style.animation = 'none';

  /* --- Begriffe einsammeln ---------------------------------------------- */

  // Aus dem Markup nur die eindeutigen Begriffe uebernehmen; die vorhandene
  // Teilwiederholung faellt dabei weg.
  const begriffe = [];
  for (const el of spur.querySelectorAll('span')) {
    const text = el.textContent.trim();
    if (text && !begriffe.includes(text)) begriffe.push(text);
  }
  if (!begriffe.length) return;

  const satzBauen = (technischeKopie = false) => {
    const satz = document.createElement('span');
    satz.className = 'rt-rail-set';
    if (technischeKopie) satz.setAttribute('aria-hidden', 'true');

    for (const text of begriffe) {
      const wort = document.createElement('span');
      wort.textContent = text;
      const punkt = document.createElement('i');
      punkt.setAttribute('aria-hidden', 'true');
      satz.append(wort, punkt);
    }
    return satz;
  };

  /* --- Spur aufbauen ----------------------------------------------------- */

  let animation = null;
  let satzBreite = 0;

  const aufbauen = () => {
    if (animation) {
      gsap.killTweensOf(animation);
      animation.kill();
      animation = null;
    }
    gsap.killTweensOf(spur);
    gsap.set(spur, { x: 0 });
    band.classList.toggle('is-reduced-motion', sparsam.matches);
    spur.style.setProperty('--rt-rail-gap', '0px');
    spur.textContent = '';

    const sichtbarerSatz = satzBauen();
    spur.appendChild(sichtbarerSatz);

    band.dataset.railSpeed = String(TEMPO);
    band.dataset.railScroll = 'independent';
    band.dataset.railUnique = String(begriffe.length);

    if (sparsam.matches) {
      spur.style.removeProperty('--rt-rail-gap');
      return;
    }

    const natuerlicheBreite = sichtbarerSatz.scrollWidth;
    const groessterBegriff = Math.max(
      ...Array.from(sichtbarerSatz.querySelectorAll(':scope > span'), el => el.offsetWidth),
    );
    const zielBreite = Math.max(
      natuerlicheBreite,
      band.clientWidth + groessterBegriff + ZUSATZ_RAUM,
    );
    const luecken = Math.max(1, sichtbarerSatz.children.length);
    const abstand = Math.max(
      MINDEST_ABSTAND,
      Math.ceil((zielBreite - natuerlicheBreite) / luecken),
    );

    spur.style.setProperty('--rt-rail-gap', `${abstand}px`);
    satzBreite = Math.ceil(sichtbarerSatz.getBoundingClientRect().width);
    if (!satzBreite) return;

    // Nur diese technische Kopie ist fuer den nahtlosen Loop notwendig.
    spur.appendChild(satzBauen(true));

    animation = gsap.to(spur, {
      x: -satzBreite,
      duration: satzBreite / TEMPO,
      ease: 'none',
      repeat: -1,
    });
  };

  aufbauen();
  document.fonts?.ready.then(aufbauen);

  /* --- Zeigen und Ruhen --------------------------------------------------- */

  band.addEventListener('pointerenter', () => {
    if (animation) gsap.to(animation, { timeScale: .28, duration: .4, overwrite: true });
  });
  band.addEventListener('pointerleave', () => {
    if (animation) gsap.to(animation, { timeScale: 1, duration: .5, overwrite: true });
  });

  // Bei Breitenaenderung Satzbreite und ruhige Abstaende neu berechnen.
  let neuAufbau = 0;
  addEventListener('resize', () => {
    clearTimeout(neuAufbau);
    neuAufbau = setTimeout(aufbauen, 220);
  });

  sparsam.addEventListener?.('change', aufbauen);
})();
