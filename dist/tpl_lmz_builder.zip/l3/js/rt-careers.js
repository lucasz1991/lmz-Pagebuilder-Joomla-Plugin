/**
 * RailTime - Karriere / Careers
 *
 * Zustaendigkeiten:
 * - drei Bewerbungswege waehlen den stabilen application_area-Wert vor;
 * - barrierearme Vier-Schritt-Navigation ohne GSAP-Abhaengigkeit;
 * - Token-Bootstrap und einmaliger multipart-POST an com_ajax;
 * - einmalige, nicht scrollblockierende GSAP-Reveals als progressive
 *   Verbesserung. Es gibt bewusst kein Pinning, Scrub oder Scroll-Locking.
 */
(() => {
  'use strict';

  const starten = () => {
    const wurzel = document.querySelector('[data-rt-careers]');
    if (!wurzel || wurzel.dataset.careersInitialisiert === 'true') return;

    wurzel.dataset.careersInitialisiert = 'true';

    const eins = (auswahl, kontext = wurzel) => kontext?.querySelector(auswahl) || null;
    const alle = (auswahl, kontext = wurzel) => Array.from(kontext?.querySelectorAll(auswahl) || []);
    const sprachTag = (wurzel.dataset.language || document.documentElement.lang || 'de').toLowerCase();
    const sprache = sprachTag.startsWith('en') ? 'en' : (sprachTag.startsWith('pl') ? 'pl' : 'de');
    const sparsam = matchMedia('(prefers-reduced-motion: reduce)').matches;

    const texteNachSprache = {
      en: {
        step: 'Step', of: 'of', selected: 'Application route selected:',
        errorsTitle: 'Please review the following information:',
        invalid: 'Please complete this field correctly.',
        tokenError: 'The secure application form could not be prepared. Please try again.',
        endpointError: 'The secure application service is currently unavailable.',
        networkError: 'The application could not be sent. Please check your connection and try again.',
        responseError: 'The server response could not be processed. Please try again.',
        submitting: 'Your application is being sent securely.',
        success: 'Your application has been sent successfully.',
        reference: 'Reference', noFile: 'No file selected', filesSelected: 'Selected files:',
        reviewEmpty: 'Not specified', yes: 'Yes', no: 'No',
        labels: {
          application_area: 'Application route', desired_region: 'Preferred region',
          available_from: 'Earliest possible start', nationwide_ready: 'Available across Germany',
          first_name: 'First name', last_name: 'Last name', email: 'Email address', phone: 'Phone',
          postal_code: 'Postcode', city: 'City', qualification_status: 'Qualification status',
          experience: 'Professional experience', message: 'Message', cv: 'CV', certificates: 'Certificates',
        },
      },
      pl: {
        step: 'Krok', of: 'z', selected: 'Wybrana ścieżka zgłoszenia:',
        errorsTitle: 'Sprawdź następujące informacje:',
        invalid: 'Uzupełnij to pole prawidłowo.',
        tokenError: 'Nie udało się przygotować bezpiecznego formularza. Spróbuj ponownie.',
        endpointError: 'Bezpieczna usługa zgłoszeń jest obecnie niedostępna.',
        networkError: 'Nie udało się wysłać zgłoszenia. Sprawdź połączenie i spróbuj ponownie.',
        responseError: 'Nie udało się przetworzyć odpowiedzi serwera. Spróbuj ponownie.',
        submitting: 'Twoje zgłoszenie jest bezpiecznie wysyłane.',
        success: 'Twoje zgłoszenie zostało wysłane.',
        reference: 'Numer referencyjny', noFile: 'Nie wybrano pliku', filesSelected: 'Wybrane pliki:',
        reviewEmpty: 'Nie podano', yes: 'Tak', no: 'Nie',
        labels: {
          application_area: 'Ścieżka zgłoszenia', desired_region: 'Preferowany region',
          available_from: 'Najwcześniejszy termin rozpoczęcia', nationwide_ready: 'Gotowość do pracy w całych Niemczech',
          first_name: 'Imię', last_name: 'Nazwisko', email: 'Adres e-mail', phone: 'Telefon',
          postal_code: 'Kod pocztowy', city: 'Miejscowość', qualification_status: 'Status kwalifikacji',
          experience: 'Doświadczenie zawodowe', message: 'Wiadomość', cv: 'Życiorys', certificates: 'Zaświadczenia',
        },
      },
      de: {
        step: 'Schritt', of: 'von', selected: 'Bewerbungsweg ausgewählt:',
        errorsTitle: 'Bitte prüfen Sie die folgenden Angaben:',
        invalid: 'Bitte füllen Sie dieses Feld korrekt aus.',
        tokenError: 'Das sichere Bewerbungsformular konnte nicht vorbereitet werden. Bitte versuchen Sie es erneut.',
        endpointError: 'Der sichere Bewerbungsdienst ist momentan nicht erreichbar.',
        networkError: 'Die Bewerbung konnte nicht gesendet werden. Bitte prüfen Sie Ihre Verbindung und versuchen Sie es erneut.',
        responseError: 'Die Serverantwort konnte nicht verarbeitet werden. Bitte versuchen Sie es erneut.',
        submitting: 'Ihre Bewerbung wird sicher versendet.',
        success: 'Ihre Bewerbung wurde erfolgreich versendet.',
        reference: 'Referenz', noFile: 'Keine Datei ausgewählt', filesSelected: 'Ausgewählte Dateien:',
        reviewEmpty: 'Nicht angegeben', yes: 'Ja', no: 'Nein',
        labels: {
          application_area: 'Bewerbungsweg', desired_region: 'Wunschregion', available_from: 'Frühester Start',
          nationwide_ready: 'Deutschlandweit einsatzbereit', first_name: 'Vorname', last_name: 'Nachname',
          email: 'E-Mail-Adresse', phone: 'Telefon', postal_code: 'PLZ', city: 'Ort',
          qualification_status: 'Qualifikationsstatus', experience: 'Berufserfahrung', message: 'Nachricht',
          cv: 'Lebenslauf', certificates: 'Nachweise',
        },
      },
    };
    const texte = texteNachSprache[sprache];

    /* Die Prozess-Icons sind rein dekorativ. Ohne JavaScript bleibt die
       nummerierte Vier-Schritt-Darstellung vollstaendig lesbar. */
    const prozessIcons = [
      '<svg viewBox="0 0 24 24"><path d="M7 3h10v18H7z"/><path d="M9.5 7h5M9.5 11h5M9.5 15h3"/></svg>',
      '<svg viewBox="0 0 24 24"><circle cx="12" cy="8" r="3"/><path d="M5.5 20c.7-4 2.8-6 6.5-6s5.8 2 6.5 6"/><path d="m17 5 1.5 1.5L21 4"/></svg>',
      '<svg viewBox="0 0 24 24"><path d="M4 5h16v11H9l-5 4z"/><path d="M8 9h8M8 12h5"/></svg>',
      '<svg viewBox="0 0 24 24"><path d="M5 4h14v16H5z"/><path d="m8 12 2.4 2.4L16 9"/></svg>',
    ];

    alle('.rt-careers-process__step').forEach((schritt, index) => {
      if (schritt.querySelector(':scope > .rt-careers-process__icon')) return;
      const icon = document.createElement('span');
      icon.className = 'rt-careers-process__icon';
      icon.setAttribute('aria-hidden', 'true');
      icon.innerHTML = prozessIcons[index] || prozessIcons[prozessIcons.length - 1];
      schritt.prepend(icon);
    });

    const host = eins('[data-application-form-host]');
    const formular = eins('[data-application-form]', host);
    const bewerbungsSektion = host?.closest('.rt-careers-application') || null;
    const status = eins('[data-application-status]', host);
    const erfolg = eins('[data-application-success]', host);
    const fortschritt = eins('.rt-application__progress', formular);
    const schrittStatus = eins('[data-step-status]', formular);
    const fehlerZusammenfassung = eins('[data-error-summary]', formular);
    const review = eins('[data-review-output]', formular);
    const schritte = alle('[data-form-step]', formular)
      .sort((a, b) => Number(a.dataset.formStep) - Number(b.dataset.formStep));
    const indikatoren = alle('[data-step-indicator]', fortschritt);
    const wege = alle('[data-application-jump]');
    const erlaubteWege = new Set(['wagon_inspector', 'deployment_coordination', 'unsolicited']);
    let aktuellerSchritt = 0;
    let schrittWechselt = false;
    let sendet = false;
    let tokenAnfrage = null;
    let erfolgreichGesendet = false;
    const controller = typeof AbortController === 'function' ? new AbortController() : null;

    const statusSetzen = (nachricht = '') => {
      if (!status) return;
      status.textContent = nachricht;
      status.classList.toggle('is-ready', nachricht === '');
    };

    const sichereBasisUrl = () => {
      const basis = document.querySelector('base[href]');
      if (basis?.href) return basis.href;

      const asset = Array.from(document.querySelectorAll('link[href], script[src]'))
        .map(element => element.href || element.src || '')
        .find(url => /\/templates\/lmz_builder\//u.test(url));
      if (asset) {
        const assetUrl = new URL(asset, document.baseURI);
        const marker = assetUrl.pathname.indexOf('/templates/lmz_builder/');
        if (marker >= 0) {
          assetUrl.pathname = assetUrl.pathname.slice(0, marker + 1);
          assetUrl.search = '';
          assetUrl.hash = '';
          return assetUrl.href;
        }
      }

      return document.baseURI;
    };

    const endpointAufloesen = () => {
      const roh = document.body.dataset.rtApplicationEndpoint
        || host?.dataset.endpoint
        || formular?.getAttribute('action')
        || '';
      if (!roh) return null;

      try {
        const basis = document.body.dataset.rtApplicationEndpoint
          ? document.baseURI
          : sichereBasisUrl();
        const url = new URL(roh, basis);
        return url.origin === location.origin ? url : null;
      } catch (fehler) {
        return null;
      }
    };

    const endpoint = endpointAufloesen();
    endpoint?.searchParams.set('language', sprache);
    if (formular && endpoint) {
      formular.action = endpoint.href;
      formular.method = 'post';
      formular.enctype = 'multipart/form-data';
    }

    const joomlaDaten = (wrapper) => {
      let daten = wrapper?.data;
      while (Array.isArray(daten)) daten = daten[0];
      if (typeof daten === 'string') {
        try {
          daten = JSON.parse(daten);
        } catch (fehler) {
          daten = null;
        }
      }
      return daten && typeof daten === 'object' ? daten : null;
    };

    const nachrichtenSammeln = (wert, ergebnis = []) => {
      if (typeof wert === 'string' && wert.trim()) {
        ergebnis.push(wert.trim());
      } else if (Array.isArray(wert)) {
        wert.forEach(eintrag => nachrichtenSammeln(eintrag, ergebnis));
      } else if (wert && typeof wert === 'object') {
        Object.values(wert).forEach(eintrag => nachrichtenSammeln(eintrag, ergebnis));
      }
      return ergebnis;
    };

    const antwortLesen = async (antwort) => {
      const roh = await antwort.text();
      let wrapper = null;
      try {
        wrapper = roh ? JSON.parse(roh) : null;
      } catch (fehler) {
        wrapper = null;
      }

      const daten = joomlaDaten(wrapper);
      const wrapperNachrichten = nachrichtenSammeln(wrapper?.messages);
      const nachricht = daten?.message
        || wrapper?.message
        || wrapperNachrichten[0]
        || '';

      return {
        httpOk: antwort.ok,
        status: antwort.status,
        wrapper,
        daten,
        nachricht,
        gueltig: Boolean(wrapper && daten),
      };
    };

    const tokenUebernehmen = (daten) => {
      if (!formular || !daten || typeof daten !== 'object') return;

      const formularToken = formular.querySelector('[data-form-token], input[name="application_token"]');
      if (formularToken) {
        formularToken.name = 'application_token';
        if (typeof daten.form_token === 'string' && daten.form_token) {
          formularToken.value = daten.form_token;
        }
      }

      if (typeof daten.csrf_name === 'string' && daten.csrf_name) {
        let csrf = formular.querySelector('[data-csrf-token]');
        if (!csrf) {
          csrf = document.createElement('input');
          csrf.type = 'hidden';
          csrf.dataset.csrfToken = '';
          formular.prepend(csrf);
        }
        csrf.name = daten.csrf_name;
        csrf.value = String(daten.csrf_value ?? 1);
      }
    };

    const tokenVorhanden = () => {
      if (!formular) return false;
      const anwendungsToken = formular.querySelector('[data-form-token], input[name="application_token"]');
      const csrf = formular.querySelector('[data-csrf-token]');
      return Boolean(
        anwendungsToken?.value.trim()
        && csrf?.name
        && csrf?.value,
      );
    };

    const tokenLaden = async (erzwingen = false) => {
      if (!formular || !endpoint) return false;
      if (tokenAnfrage) return tokenAnfrage;
      if (!erzwingen && tokenVorhanden()) return true;

      tokenAnfrage = (async () => {
        try {
          const antwort = await fetch(endpoint.href, {
            method: 'GET',
            credentials: 'same-origin',
            headers: { Accept: 'application/json' },
            signal: controller?.signal,
          });
          const ergebnis = await antwortLesen(antwort);
          if (!ergebnis.httpOk || !ergebnis.daten?.ok) return false;
          tokenUebernehmen(ergebnis.daten);
          statusSetzen('');
          return tokenVorhanden();
        } catch (fehler) {
          return false;
        } finally {
          tokenAnfrage = null;
        }
      })();

      return tokenAnfrage;
    };

    const normalisierterName = name => String(name || '').replace(/\[\]$/u, '');

    const controlsFuerName = (name) => {
      if (!formular) return [];
      const gesucht = normalisierterName(name);
      return Array.from(formular.elements).filter((element) => (
        element instanceof HTMLElement
        && normalisierterName(element.getAttribute('name')) === gesucht
      ));
    };

    const controlFuerName = name => controlsFuerName(name)[0] || null;

    const controlIdSichern = (control, name) => {
      if (!control) return '';
      if (!control.id) {
        const sicher = normalisierterName(name).replace(/[^a-z0-9_-]+/giu, '-');
        control.id = `rt-application-${sicher}`;
      }
      return control.id;
    };

    const fehlerLeeren = () => {
      if (!formular) return;
      alle('[data-generated-field-error]', formular).forEach(element => element.remove());
      alle('[aria-invalid="true"]', formular).forEach((control) => {
        control.removeAttribute('aria-invalid');
        if (Object.prototype.hasOwnProperty.call(control.dataset, 'originalDescribedby')) {
          const original = control.dataset.originalDescribedby;
          if (original) control.setAttribute('aria-describedby', original);
          else control.removeAttribute('aria-describedby');
          delete control.dataset.originalDescribedby;
        }
      });
      if (fehlerZusammenfassung) {
        fehlerZusammenfassung.replaceChildren();
        fehlerZusammenfassung.hidden = true;
      }
    };

    const feldFehlerEintragen = (fehler, index) => {
      const controls = controlsFuerName(fehler.name);
      const control = fehler.control || controls[0] || null;
      if (!control) return;

      const id = `rt-field-error-${normalisierterName(fehler.name).replace(/[^a-z0-9_-]+/giu, '-')}-${index}`;
      const ausgabe = document.createElement('span');
      ausgabe.id = id;
      ausgabe.className = 'rt-application__field-error';
      ausgabe.dataset.generatedFieldError = '';
      ausgabe.textContent = fehler.message;

      const feld = control.closest('.rt-application__field, .rt-field, .rt-choice, label')
        || control.parentElement;
      feld?.append(ausgabe);

      (controls.length ? controls : [control]).forEach((element) => {
        element.setAttribute('aria-invalid', 'true');
        if (!Object.prototype.hasOwnProperty.call(element.dataset, 'originalDescribedby')) {
          element.dataset.originalDescribedby = element.getAttribute('aria-describedby') || '';
        }
        const beschrieben = new Set(
          (element.getAttribute('aria-describedby') || '').split(/\s+/u).filter(Boolean),
        );
        beschrieben.add(id);
        element.setAttribute('aria-describedby', Array.from(beschrieben).join(' '));
      });
    };

    const schrittIndexFuerControl = (control) => {
      const schritt = control?.closest('[data-form-step]');
      const index = schritte.indexOf(schritt);
      return index >= 0 ? index : aktuellerSchritt;
    };

    const fehlerAnzeigen = (fehler, fokus = true) => {
      if (!fehlerZusammenfassung || !fehler.length) return;

      fehler.forEach(feldFehlerEintragen);

      const titel = document.createElement('h3');
      titel.textContent = texte.errorsTitle;
      const liste = document.createElement('ul');

      fehler.forEach((eintrag) => {
        const punkt = document.createElement('li');
        const control = eintrag.control || controlFuerName(eintrag.name);
        if (control) {
          const link = document.createElement('a');
          link.href = `#${controlIdSichern(control, eintrag.name)}`;
          link.textContent = eintrag.message;
          link.addEventListener('click', async (event) => {
            event.preventDefault();
            await schrittZeigen(schrittIndexFuerControl(control), {
              fokus: false,
              ansagen: false,
            });
            control.focus({ preventScroll: false });
          });
          punkt.append(link);
        } else {
          punkt.textContent = eintrag.message;
        }
        liste.append(punkt);
      });

      fehlerZusammenfassung.replaceChildren(titel, liste);
      fehlerZusammenfassung.hidden = false;
      if (fokus) requestAnimationFrame(() => fehlerZusammenfassung.focus({ preventScroll: false }));
    };

    const clientFehler = (schritt) => {
      if (!schritt) return [];
      const ergebnis = [];
      const gesehen = new Set();
      alle('input, select, textarea', schritt).forEach((control) => {
        if (control.disabled || !control.name || !control.willValidate) return;
        const name = normalisierterName(control.name);
        if (gesehen.has(name)) return;
        gesehen.add(name);
        if (!control.checkValidity()) {
          ergebnis.push({
            name,
            control,
            message: control.dataset.validationMessage
              || control.validationMessage
              || texte.invalid,
          });
        }
      });
      return ergebnis;
    };

    const serverFehler = (fehlerObjekt) => {
      if (!fehlerObjekt || typeof fehlerObjekt !== 'object') return [];
      return Object.entries(fehlerObjekt).flatMap(([name, meldungen]) => {
        const liste = Array.isArray(meldungen) ? meldungen : [meldungen];
        return liste
          .filter(meldung => typeof meldung === 'string' && meldung.trim())
          .map(meldung => ({
            name: normalisierterName(name),
            control: controlFuerName(name),
            message: meldung.trim(),
          }));
      });
    };

    const wertDarstellen = (name) => {
      const controls = controlsFuerName(name);
      if (!controls.length) return '';
      const erstes = controls[0];

      if (erstes instanceof HTMLInputElement && erstes.type === 'file') {
        return Array.from(erstes.files || []).map(datei => datei.name).join(', ');
      }
      if (erstes instanceof HTMLInputElement && erstes.type === 'radio') {
        const gewaehlt = controls.find(control => control.checked);
        if (!gewaehlt) return '';
        const beschriftung = gewaehlt.closest('label')?.textContent?.trim();
        return beschriftung || (gewaehlt.value === 'yes' ? texte.yes : texte.no);
      }
      if (erstes instanceof HTMLInputElement && erstes.type === 'checkbox') {
        return erstes.checked ? texte.yes : texte.no;
      }
      if (erstes instanceof HTMLSelectElement) {
        return erstes.selectedOptions[0]?.textContent?.trim() || '';
      }
      return String(erstes.value || '').trim();
    };

    const reviewAktualisieren = () => {
      if (!review) return;
      const reihenfolge = [
        'application_area',
        'desired_region',
        'available_from',
        'nationwide_ready',
        'first_name',
        'last_name',
        'email',
        'phone',
        'postal_code',
        'city',
        'qualification_status',
        'experience',
        'message',
        'cv',
        'certificates',
      ];
      const fragment = document.createDocumentFragment();

      reihenfolge.forEach((name) => {
        const wert = wertDarstellen(name);
        if (!wert && ['phone', 'postal_code', 'city', 'message', 'certificates'].includes(name)) return;
        const zeile = document.createElement('div');
        zeile.className = 'rt-application__review-row';
        const begriff = document.createElement('dt');
        const beschreibung = document.createElement('dd');
        begriff.textContent = texte.labels[name] || name;
        beschreibung.textContent = wert || texte.reviewEmpty;
        zeile.append(begriff, beschreibung);
        fragment.append(zeile);
      });

      review.replaceChildren(fragment);
    };

    const fortschrittAktualisieren = () => {
      const gesamt = schritte.length || 4;
      const nummer = aktuellerSchritt + 1;
      indikatoren.forEach((indikator, index) => {
        indikator.classList.toggle('is-current', index === aktuellerSchritt);
        indikator.classList.toggle('is-complete', index < aktuellerSchritt);
        if (index === aktuellerSchritt) indikator.setAttribute('aria-current', 'step');
        else indikator.removeAttribute('aria-current');
      });

      if (fortschritt) {
        fortschritt.setAttribute('role', 'progressbar');
        fortschritt.setAttribute('aria-valuemin', '1');
        fortschritt.setAttribute('aria-valuemax', String(gesamt));
        fortschritt.setAttribute('aria-valuenow', String(nummer));
        fortschritt.setAttribute('aria-valuetext', `${texte.step} ${nummer} ${texte.of} ${gesamt}`);
      }

      const legende = schritte[aktuellerSchritt]?.querySelector(':scope > legend')?.textContent?.trim();
      if (schrittStatus) {
        schrittStatus.textContent = `${texte.step} ${nummer} ${texte.of} ${gesamt}${legende ? `: ${legende.replace(/^\d+\.\s*/u, '')}` : ''}`;
      }
    };

    const animationAbwarten = async (element, keyframes, optionen) => {
      if (!element?.animate || sparsam) return;
      try {
        await element.animate(keyframes, optionen).finished;
      } catch (fehler) {
        /* Eine unterbrochene WAAPI-Animation darf die Navigation nie sperren. */
      }
    };

    async function schrittZeigen(index, optionen = {}) {
      if (!schritte.length) return;
      const zielIndex = Math.max(0, Math.min(index, schritte.length - 1));
      const fokus = optionen.fokus !== false;
      const ansagen = optionen.ansagen !== false;
      const alt = schritte[aktuellerSchritt];
      const ziel = schritte[zielIndex];
      const richtung = zielIndex >= aktuellerSchritt ? 1 : -1;

      if (schrittWechselt && zielIndex !== aktuellerSchritt) return;
      if (zielIndex === aktuellerSchritt) {
        fortschrittAktualisieren();
        if (zielIndex === schritte.length - 1) reviewAktualisieren();
        if (fokus) ziel.querySelector(':scope > legend')?.focus({ preventScroll: true });
        return;
      }

      schrittWechselt = true;
      try {
        if (alt && !alt.hidden) {
          await animationAbwarten(alt, [
            { opacity: 1, transform: 'translateX(0)' },
            { opacity: 0, transform: `translateX(${-richtung * 8}px)` },
          ], { duration: 90, easing: 'ease-in', fill: 'none' });
          alt.hidden = true;
          alt.inert = true;
          alt.setAttribute('aria-hidden', 'true');
        }

        aktuellerSchritt = zielIndex;
        ziel.hidden = false;
        ziel.inert = false;
        ziel.removeAttribute('aria-hidden');
        schritte.forEach((schritt, schrittIndex) => {
          if (schrittIndex === zielIndex) return;
          schritt.hidden = true;
          schritt.inert = true;
          schritt.setAttribute('aria-hidden', 'true');
        });

        fortschrittAktualisieren();
        if (zielIndex === schritte.length - 1) reviewAktualisieren();

        await animationAbwarten(ziel, [
          { opacity: 0, transform: `translateX(${richtung * 12}px)` },
          { opacity: 1, transform: 'translateX(0)' },
        ], { duration: 150, easing: 'cubic-bezier(.22,1,.36,1)', fill: 'none' });

        const legende = ziel.querySelector(':scope > legend');
        if (fokus) legende?.focus({ preventScroll: true });
        if (ansagen && schrittStatus) {
          schrittStatus.textContent = `${texte.step} ${zielIndex + 1} ${texte.of} ${schritte.length}: ${legende?.textContent?.replace(/^\d+\.\s*/u, '') || ''}`;
        }
      } finally {
        schrittWechselt = false;
      }
    }

    const dateinamenAktualisieren = (input) => {
      if (!(input instanceof HTMLInputElement) || input.type !== 'file') return;
      const name = normalisierterName(input.name);
      const ausgabe = formular?.querySelector(
        `[data-file-name="${name}"], [data-file-names="${name}"]`,
      );
      if (!ausgabe) return;
      const namen = Array.from(input.files || []).map(datei => datei.name);
      ausgabe.textContent = namen.length
        ? `${texte.filesSelected} ${namen.join(' · ')}`
        : texte.noFile;
    };

    const bereichSetzen = (bereich, ansagen = true) => {
      if (!formular || !erlaubteWege.has(bereich)) return false;
      const controls = controlsFuerName('application_area');
      if (!controls.length) return false;

      controls.forEach((control) => {
        if (control instanceof HTMLInputElement && ['radio', 'checkbox'].includes(control.type)) {
          control.checked = control.value === bereich;
        } else {
          control.value = bereich;
        }
        control.dispatchEvent(new Event('change', { bubbles: true }));
      });

      wege.forEach((weg) => {
        const aktiv = weg.dataset.applicationArea === bereich;
        weg.classList.toggle('is-selected', aktiv);
        weg.setAttribute('aria-pressed', String(aktiv));
      });

      if (ansagen) {
        const beschriftung = wertDarstellen('application_area');
        statusSetzen(`${texte.selected} ${beschriftung}`);
      }
      return true;
    };

    wege.forEach((weg) => {
      weg.setAttribute('aria-pressed', 'false');
      weg.addEventListener('click', async () => {
        const bereich = weg.dataset.applicationArea || '';
        if (!bereichSetzen(bereich)) return;
        await schrittZeigen(0, { fokus: false });
        bewerbungsSektion?.scrollIntoView({
          behavior: sparsam ? 'auto' : 'smooth',
          block: 'start',
        });
        const fokusVerzoegerung = sparsam ? 0 : 420;
        window.setTimeout(() => {
          schritte[0]?.querySelector(':scope > legend')?.focus({ preventScroll: true });
        }, fokusVerzoegerung);
      });
    });

    if (formular && schritte.length) {
      formular.noValidate = true;
      const sprachFeld = formular.querySelector('input[name="language"]');
      if (sprachFeld) sprachFeld.value = sprache;

      const honigtopf = formular.querySelector('input[name="website"]');
      if (honigtopf) {
        honigtopf.tabIndex = -1;
        honigtopf.autocomplete = 'off';
      }

      alle('input[type="file"]', formular).forEach((input) => {
        if (!input.accept) input.accept = '.pdf,application/pdf';
        dateinamenAktualisieren(input);
        input.addEventListener('change', () => dateinamenAktualisieren(input));
      });

      const bereichsFeld = controlFuerName('application_area');
      bereichsFeld?.addEventListener('change', () => {
        const wert = String(bereichsFeld.value || '');
        wege.forEach((weg) => {
          const aktiv = weg.dataset.applicationArea === wert;
          weg.classList.toggle('is-selected', aktiv);
          weg.setAttribute('aria-pressed', String(aktiv));
        });
      });

      schritte.forEach((schritt, index) => {
        const aktiv = index === 0;
        schritt.hidden = !aktiv;
        schritt.inert = !aktiv;
        if (aktiv) schritt.removeAttribute('aria-hidden');
        else schritt.setAttribute('aria-hidden', 'true');
        const legende = schritt.querySelector(':scope > legend');
        if (legende && !legende.hasAttribute('tabindex')) legende.tabIndex = -1;
      });
      fortschrittAktualisieren();

      formular.addEventListener('invalid', event => event.preventDefault(), true);

      formular.addEventListener('click', async (event) => {
        const weiter = event.target.closest('[data-step-next]');
        const zurueck = event.target.closest('[data-step-back]');
        if (weiter) {
          event.preventDefault();
          if (schrittWechselt) return;
          fehlerLeeren();
          const fehler = clientFehler(schritte[aktuellerSchritt]);
          if (fehler.length) {
            fehlerAnzeigen(fehler);
            return;
          }
          await schrittZeigen(aktuellerSchritt + 1);
        } else if (zurueck) {
          event.preventDefault();
          if (schrittWechselt) return;
          fehlerLeeren();
          await schrittZeigen(aktuellerSchritt - 1);
        }
      });

      formular.addEventListener('keydown', (event) => {
        if (
          event.key !== 'Enter'
          || aktuellerSchritt >= schritte.length - 1
          || event.target instanceof HTMLTextAreaElement
          || event.target instanceof HTMLButtonElement
        ) return;
        event.preventDefault();
        formular.querySelector(`[data-form-step="${aktuellerSchritt + 1}"] [data-step-next]`)?.click();
      });

      const sendenSperren = (aktiv) => {
        host?.setAttribute('aria-busy', String(aktiv));
        const knopf = formular.querySelector('[data-application-submit]');
        if (knopf) knopf.disabled = aktiv;
      };

      const erfolgAnzeigen = (daten) => {
        erfolgreichGesendet = true;
        host?.setAttribute('aria-busy', 'false');
        formular.reset();
        alle('input[type="file"]', formular).forEach(dateinamenAktualisieren);
        formular.hidden = true;
        if (fortschritt) fortschritt.hidden = true;
        if (schrittStatus) schrittStatus.hidden = true;
        fehlerLeeren();

        if (erfolg) {
          const referenz = erfolg.querySelector(
            '[data-application-reference], [data-success-reference]',
          );
          if (referenz) {
            referenz.textContent = daten.reference
              ? `${texte.reference}: ${daten.reference}`
              : '';
            referenz.hidden = !daten.reference;
          }
          const meldung = erfolg.querySelector('[data-success-message]');
          if (meldung && daten.message) meldung.textContent = daten.message;
          const naechsterSchritt = erfolg.querySelector('[data-success-next-step]');
          if (naechsterSchritt) {
            naechsterSchritt.textContent = daten.next_step || '';
            naechsterSchritt.hidden = !daten.next_step;
          }
          erfolg.hidden = false;
          erfolg.focus({ preventScroll: false });
        }
        statusSetzen(daten.message || texte.success);
      };

      formular.addEventListener('submit', async (event) => {
        event.preventDefault();
        if (sendet || erfolgreichGesendet || schrittWechselt) return;

        if (aktuellerSchritt < schritte.length - 1) {
          formular.querySelector(`[data-form-step="${aktuellerSchritt + 1}"] [data-step-next]`)?.click();
          return;
        }

        fehlerLeeren();
        const alleFehler = schritte.flatMap(clientFehler);
        if (alleFehler.length) {
          const ersterControl = alleFehler.find(fehler => fehler.control)?.control;
          await schrittZeigen(schrittIndexFuerControl(ersterControl), {
            fokus: false,
            ansagen: false,
          });
          fehlerAnzeigen(alleFehler);
          return;
        }

        if (!endpoint) {
          fehlerAnzeigen([{ name: '_form', control: null, message: texte.endpointError }]);
          return;
        }

        if (!tokenVorhanden()) {
          const tokenBereit = await tokenLaden(true);
          if (!tokenBereit) {
            statusSetzen(texte.tokenError);
            fehlerAnzeigen([{ name: '_form', control: null, message: texte.tokenError }]);
            return;
          }
        }

        sendet = true;
        sendenSperren(true);
        statusSetzen(texte.submitting);

        try {
          const antwort = await fetch(endpoint.href, {
            method: 'POST',
            credentials: 'same-origin',
            headers: { Accept: 'application/json' },
            body: new FormData(formular),
            signal: controller?.signal,
          });
          const ergebnis = await antwortLesen(antwort);
          if (ergebnis.daten) tokenUebernehmen(ergebnis.daten);

          if (ergebnis.httpOk && ergebnis.daten?.ok) {
            erfolgAnzeigen(ergebnis.daten);
            return;
          }

          const feldFehler = serverFehler(ergebnis.daten?.errors);
          const meldung = ergebnis.nachricht
            || (ergebnis.gueltig ? texte.responseError : texte.responseError);
          if (feldFehler.length) {
            const ersterControl = feldFehler.find(fehler => fehler.control)?.control;
            if (ersterControl) {
              await schrittZeigen(schrittIndexFuerControl(ersterControl), {
                fokus: false,
                ansagen: false,
              });
            }
            fehlerAnzeigen(feldFehler);
          } else {
            fehlerAnzeigen([{ name: '_form', control: null, message: meldung }]);
          }
          statusSetzen(meldung);
        } catch (fehler) {
          if (fehler?.name !== 'AbortError') {
            fehlerAnzeigen([{ name: '_form', control: null, message: texte.networkError }]);
            statusSetzen(texte.networkError);
          }
        } finally {
          sendet = false;
          if (!erfolgreichGesendet) sendenSperren(false);
        }
      });

      const queryWeg = new URLSearchParams(location.search).get('application_area');
      if (queryWeg && erlaubteWege.has(queryWeg)) bereichSetzen(queryWeg, false);

      tokenLaden().then((bereit) => {
        if (!bereit && !tokenVorhanden()) statusSetzen(texte.tokenError);
      });
    }

    /* -------------------------------------------------------------- *
     * Motion: ausschliesslich einmalige Reveals. Die Elemente sind im
     * Grundzustand sichtbar; erst nach erfolgreicher GSAP-Erkennung setzt
     * dieses Skript Startwerte. Damit bleibt die Seite ohne GSAP stabil.
     * -------------------------------------------------------------- */
    const bewegungStarten = () => {
      const hero = eins('.rt-careers-hero');
      const heroInhalt = eins('.rt-careers-hero__content, .rt-careers-hero__copy', hero);
      const heroMedium = eins('.rt-careers-hero__media, .rt-careers-hero__visual, figure', hero);
      const heroBild = heroMedium?.querySelector('img');
      const revealElemente = alle('[data-careers-reveal]')
        .filter(element => !hero?.contains(element) && !element.closest('.rt-application'));

      if (!window.gsap || !window.ScrollTrigger || sparsam) {
        wurzel.dataset.careersBewegung = sparsam ? 'reduziert' : 'statisch';
        return;
      }

      gsap.registerPlugin(ScrollTrigger);
      wurzel.dataset.careersBewegung = 'gsap';
      let kontext = null;

      try {
        kontext = gsap.context(() => {
          const heroTeile = heroInhalt ? Array.from(heroInhalt.children) : [];
          const heroTimeline = gsap.timeline({
            defaults: { ease: 'power3.out' },
            onComplete: () => {
              gsap.set([...heroTeile, heroMedium, heroBild].filter(Boolean), {
                clearProps: 'transform,opacity,visibility,clipPath,willChange',
              });
            },
          });

          if (heroTeile.length) {
            heroTimeline.fromTo(heroTeile,
              { autoAlpha: 0, y: 28, willChange: 'transform,opacity' },
              { autoAlpha: 1, y: 0, duration: .7, stagger: .07 }, 0);
          }
          if (heroMedium) {
            heroTimeline.fromTo(heroMedium,
              {
                autoAlpha: 0,
                x: 30,
                clipPath: 'inset(0 0 0 100%)',
                willChange: 'transform,opacity,clip-path',
              },
              {
                autoAlpha: 1,
                x: 0,
                clipPath: 'inset(0 0 0 0%)',
                duration: .92,
                ease: 'power3.inOut',
              }, .1);
          }
          if (heroBild) {
            heroTimeline.fromTo(heroBild,
              { scale: 1.055, transformOrigin: '50% 50%' },
              { scale: 1, duration: 1.08, ease: 'power3.out' }, .16);
          }

          if (revealElemente.length) {
            gsap.set(revealElemente, {
              autoAlpha: 0,
              y: 26,
              willChange: 'transform,opacity',
            });
            ScrollTrigger.batch(revealElemente, {
              id: 'rt-careers-reveals',
              start: 'top 86%',
              once: true,
              interval: .08,
              batchMax: 4,
              onEnter: (elemente) => {
                gsap.to(elemente, {
                  autoAlpha: 1,
                  y: 0,
                  duration: .62,
                  ease: 'power3.out',
                  stagger: .075,
                  overwrite: 'auto',
                  clearProps: 'transform,opacity,visibility,willChange',
                });
              },
            });
          }
        }, wurzel);

        ScrollTrigger.sort();
        requestAnimationFrame(() => ScrollTrigger.refresh());

        /* Stillstandssicherung. Hero-Teile und alle Reveal-Elemente starten auf
           autoAlpha 0 und werden nur von Timeline beziehungsweise
           ScrollTrigger.batch sichtbar gemacht. Steht der Bildtakt still,
           bliebe die Karriereseite bis auf das Grundgeruest leer - inklusive
           Bewerbungsformular. */
        window.RailTimeStillstand?.(() => {
          gsap.set(
            [...revealElemente, ...(heroInhalt ? Array.from(heroInhalt.children) : []), heroMedium, heroBild]
              .filter(Boolean),
            { clearProps: 'transform,opacity,visibility,clipPath,willChange' },
          );
          wurzel.dataset.careersBewegung = 'takt-notausstieg';
        }, { fertig: () => wurzel.dataset.careersBewegung === 'takt-notausstieg' });
      } catch (fehler) {
        if (window.gsap) {
          gsap.set(alle('[data-careers-reveal]'), {
            clearProps: 'transform,opacity,visibility,clipPath,willChange',
          });
        }
        wurzel.dataset.careersBewegung = 'fallback';
      }

      addEventListener('pagehide', () => kontext?.revert(), { once: true });
    };

    bewegungStarten();

    addEventListener('pagehide', () => controller?.abort(), { once: true });
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', starten, { once: true });
  } else {
    starten();
  }
})();
