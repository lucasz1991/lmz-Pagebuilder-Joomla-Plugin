(() => {
  'use strict';

  const mobileQuery = window.matchMedia('(max-width: 1120px)');
  let instanceIndex = 0;

  const focusableSelector = [
    'a[href]',
    'button:not([disabled])',
    'input:not([disabled])',
    'select:not([disabled])',
    'textarea:not([disabled])',
    '[tabindex]:not([tabindex="-1"])'
  ].join(',');

  const getPhoneLink = header => {
    const labelled = header.querySelector('.rt-nav__phone');
    return labelled || [...header.querySelectorAll('a[href^="tel:"]')].find(link => !link.closest('nav')) || null;
  };

  const getFocusable = element => [...element.querySelectorAll(focusableSelector)]
    .filter(item => !item.hasAttribute('disabled') && item.getClientRects().length);

  const translationsFor = header => {
    const language = (document.documentElement.lang || '').toLowerCase();
    const defaults = language.startsWith('en')
      ? {
          open: 'Open menu',
          close: 'Close menu',
          drawer: 'Mobile navigation',
          navigation: 'Main navigation',
          languages: 'Language',
          hotline: 'Emergency 24/7',
          claim: 'Safe. Flexible. Deployed nationwide.'
        }
      : language.startsWith('pl')
        ? {
            open: 'Otwórz menu',
            close: 'Zamknij menu',
            drawer: 'Nawigacja mobilna',
            navigation: 'Nawigacja główna',
            languages: 'Język',
            hotline: 'Pogotowie 24/7',
            claim: 'Bezpiecznie. Elastycznie. W całych Niemczech.'
          }
      : {
          open: 'Menü öffnen',
          close: 'Menü schließen',
          drawer: 'Mobile Navigation',
          navigation: 'Hauptnavigation',
          languages: 'Sprache',
          hotline: 'Notfall 24/7',
          claim: 'Sicher. Flexibel. Deutschlandweit im Einsatz.'
        };

    return {
      open: header.dataset.mobileMenuOpen || defaults.open,
      close: header.dataset.mobileMenuClose || defaults.close,
      drawer: header.dataset.mobileMenuDrawer || defaults.drawer,
      navigation: header.dataset.mobileMenuNavigation || defaults.navigation,
      languages: header.dataset.mobileMenuLanguages || defaults.languages,
      hotline: header.dataset.mobileMenuHotline || defaults.hotline,
      claim: header.dataset.mobileMenuClaim || defaults.claim
    };
  };

  const initNavigation = header => {
    if (header.dataset.mobileNavigationReady === 'true') return;

    const desktopLinks = header.querySelector('nav');
    if (!desktopLinks) return;

    const labels = translationsFor(header);

    header.dataset.mobileNavigationReady = 'true';
    instanceIndex += 1;

    let toggle = header.querySelector('.rt-nav__toggle');
    if (!toggle) {
      toggle = document.createElement('button');
      toggle.className = 'rt-nav__toggle';
      toggle.type = 'button';
      header.append(toggle);
    }

    const drawerId = `rt-mobile-drawer-${instanceIndex}`;
    toggle.type = 'button';
    toggle.classList.add('rt-nav__toggle');
    toggle.setAttribute('aria-label', labels.open);
    toggle.setAttribute('aria-expanded', 'false');
    toggle.setAttribute('aria-controls', drawerId);
    toggle.innerHTML = '<span></span><span></span><span></span>';
    header.append(toggle);

    const scrim = document.createElement('button');
    scrim.className = 'rt-mobile-menu__scrim';
    scrim.type = 'button';
    scrim.tabIndex = -1;
    scrim.setAttribute('aria-label', labels.close);

    const drawer = document.createElement('aside');
    drawer.id = drawerId;
    drawer.className = 'rt-mobile-drawer';
    drawer.setAttribute('aria-label', labels.drawer);
    drawer.setAttribute('aria-hidden', 'true');
    drawer.inert = true;
    drawer.innerHTML = [
      '<div class="rt-mobile-drawer__header">',
      '</div>',
      '<div class="rt-mobile-drawer__body"></div>'
    ].join('');

    const drawerHeader = drawer.querySelector('.rt-mobile-drawer__header');
    const drawerBody = drawer.querySelector('.rt-mobile-drawer__body');
    const brandSource = header.querySelector('.rt-nav__brand');
    const markSource = brandSource?.querySelector('.rt-brand-lockup__mark');
    const wordmarkSource = brandSource?.querySelector('.rt-brand-lockup__wordmark');
    const iconSource = markSource?.src || document.querySelector('link[rel="icon"]')?.href || '';
    const drawerBrand = document.createElement('a');
    drawerBrand.className = 'rt-mobile-drawer__brand';
    drawerBrand.href = brandSource?.href || '/';
    drawerBrand.setAttribute('aria-label', brandSource?.getAttribute('aria-label') || 'Rail Time');

    if (iconSource) {
      const mark = document.createElement('img');
      mark.className = 'rt-mobile-drawer__brand-mark';
      mark.src = iconSource;
      mark.alt = '';
      mark.setAttribute('aria-hidden', 'true');
      drawerBrand.append(mark);
    }
    if (wordmarkSource) {
      const wordmark = wordmarkSource.cloneNode(true);
      wordmark.className = 'rt-mobile-drawer__brand-wordmark';
      drawerBrand.append(wordmark);
    }
    drawerHeader.append(drawerBrand);

    const navigation = desktopLinks.cloneNode(true);
    navigation.className = 'rt-mobile-drawer__links';
    navigation.setAttribute('aria-label', labels.navigation);
    drawerBody.append(navigation);

    const phone = getPhoneLink(header);
    if (phone) {
      const hotline = phone.cloneNode(true);
      hotline.classList.add('rt-mobile-drawer__hotline');
      if (!hotline.querySelector('span, strong')) {
        const rawPhone = hotline.textContent.trim();
        const phoneNumber = rawPhone.replace(/^(?:notfall(?:dienst)?\s*)?24\s*\/\s*7\s*[·|–-]?\s*/i, '') || rawPhone;
        hotline.textContent = '';
        const label = document.createElement('span');
        label.textContent = labels.hotline;
        const number = document.createElement('strong');
        number.textContent = phoneNumber;
        hotline.append(label, number);
      }
      drawerBody.append(hotline);
    }

    const languageSource = header.querySelector('.rt-lang__liste');
    if (languageSource) {
      const languageRegion = document.createElement('section');
      languageRegion.className = 'rt-mobile-drawer__languages';
      const languageLabelId = `rt-mobile-language-label-${instanceIndex}`;
      const languageSelectId = `rt-mobile-language-select-${instanceIndex}`;
      languageRegion.setAttribute('aria-labelledby', languageLabelId);

      const languageTitle = document.createElement('label');
      languageTitle.id = languageLabelId;
      languageTitle.className = 'rt-mobile-drawer__languages-title';
      languageTitle.htmlFor = languageSelectId;
      languageTitle.textContent = labels.languages;

      const languageSelectShell = document.createElement('div');
      languageSelectShell.className = 'rt-mobile-drawer__language-select-shell';

      const languageSelect = document.createElement('select');
      languageSelect.id = languageSelectId;
      languageSelect.className = 'rt-mobile-drawer__language-select';
      languageSelect.dataset.rtMobileLanguageSelect = 'true';

      languageSource.querySelectorAll('a[href][hreflang]').forEach(link => {
        const href = link.getAttribute('href')?.trim() || '';
        const languageCode = link.getAttribute('hreflang')?.trim() || '';
        const languageName = link.querySelector('span')?.textContent.trim() || link.textContent.trim();
        let destination;

        if (!href || href === '#') return;

        try {
          destination = new URL(href, document.baseURI);
        } catch (_error) {
          return;
        }

        if (!languageName || !['http:', 'https:'].includes(destination.protocol)) return;

        const option = document.createElement('option');
        option.value = destination.href;
        option.textContent = languageName;
        if (languageCode) option.lang = languageCode;
        if (link.matches('.is-active, [aria-current]')) {
          option.selected = true;
          option.dataset.current = 'true';
        }
        languageSelect.append(option);
      });

      if (languageSelect.options.length > 1) {
        languageSelect.addEventListener('change', () => {
          const selected = languageSelect.selectedOptions[0];
          if (!selected || selected.dataset.current === 'true' || !selected.value) return;

          languageSelect.disabled = true;
          window.location.assign(selected.value);
        });

        languageSelectShell.append(languageSelect);
        languageRegion.append(languageTitle, languageSelectShell);
        drawerBody.append(languageRegion);
      }
    }

    const footer = document.createElement('p');
    footer.className = 'rt-mobile-drawer__footer';
    footer.textContent = labels.claim;
    drawerBody.append(footer);

    document.body.append(scrim, drawer);

    let lastFocused = null;
    let isOpen = false;
    /* Das Oeffnen sperrt den Seitenscroll sofort (body.rt-mobile-menu-open
       setzt overflow:hidden), die Schublade selbst wurde aber erst in einem
       requestAnimationFrame eingeblendet. Bleibt der Takt aus, stand die Seite
       gesperrt da, ohne dass ein Menue zu sehen war. Deshalb zusaetzlich eine
       Frist, die denselben Endzustand direkt herstellt. */
    let oeffnungsFrist = 0;

    const close = ({ restoreFocus = true } = {}) => {
      if (!isOpen) return;
      isOpen = false;
      clearTimeout(oeffnungsFrist);
      oeffnungsFrist = 0;
      document.body.classList.remove('rt-mobile-menu-open');
      document.documentElement.classList.remove('rt-mobile-menu-open');
      header.classList.remove('is-mobile-menu-open');
      toggle.classList.remove('is-open');
      toggle.setAttribute('aria-expanded', 'false');
      toggle.setAttribute('aria-label', labels.open);
      drawer.classList.remove('is-open');
      drawer.setAttribute('aria-hidden', 'true');
      drawer.inert = true;
      scrim.classList.remove('is-open');
      if (restoreFocus && lastFocused instanceof HTMLElement) lastFocused.focus({ preventScroll: true });
    };

    const open = () => {
      if (isOpen || !mobileQuery.matches) return;
      isOpen = true;
      lastFocused = document.activeElement instanceof HTMLElement ? document.activeElement : toggle;
      document.body.classList.add('rt-mobile-menu-open');
      document.documentElement.classList.add('rt-mobile-menu-open');
      header.classList.add('is-mobile-menu-open');
      toggle.classList.add('is-open');
      toggle.setAttribute('aria-expanded', 'true');
      toggle.setAttribute('aria-label', labels.close);
      drawer.inert = false;
      drawer.setAttribute('aria-hidden', 'false');
      scrim.classList.add('is-open');
      const schubladeZeigen = () => {
        if (!isOpen) return;
        clearTimeout(oeffnungsFrist);
        oeffnungsFrist = 0;
        drawer.classList.add('is-open');
        getFocusable(drawer)[0]?.focus({ preventScroll: true });
      };
      clearTimeout(oeffnungsFrist);
      oeffnungsFrist = window.setTimeout(schubladeZeigen, 120);
      requestAnimationFrame(schubladeZeigen);
    };

    toggle.addEventListener('click', () => (isOpen ? close() : open()));
    scrim.addEventListener('click', () => close());
    drawer.addEventListener('click', event => {
      if (event.target.closest('a')) close({ restoreFocus: false });
    });

    document.addEventListener('keydown', event => {
      if (!isOpen) return;
      if (event.key === 'Escape') {
        event.preventDefault();
        close();
        return;
      }
      if (event.key !== 'Tab') return;

      const drawerFocusable = getFocusable(drawer);
      if (!drawerFocusable.length) return;
      const first = drawerFocusable[0];
      const last = drawerFocusable[drawerFocusable.length - 1];
      if (document.activeElement === toggle) {
        event.preventDefault();
        (event.shiftKey ? last : first).focus();
      } else if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        toggle.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        toggle.focus();
      }
    });

    const closeAtDesktop = event => {
      if (!event.matches) close({ restoreFocus: false });
    };
    mobileQuery.addEventListener?.('change', closeAtDesktop);
  };

  const start = () => document.querySelectorAll('.rt-nav').forEach(initNavigation);
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start, { once: true });
  else start();
})();
