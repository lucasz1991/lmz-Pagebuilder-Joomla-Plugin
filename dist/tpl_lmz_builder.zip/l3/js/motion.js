document.addEventListener('DOMContentLoaded',()=>{
  // Die Navigation gehoert ausschliesslich mobile-navigation.js. Ein zweiter
  // Click-Owner schrieb hier gleichzeitig aria-expanded und eine Legacy-Klasse.
  if(!document.body.classList.contains('is-home')||!window.RailTimeMotion)return;
  if(document.querySelector('.sa-main')){
    // Intro und Karte haben eigene, einmalige GSAP-Timelines. Sie duerfen
    // weder den generischen Scrub-Owner noch dessen Clip-Container erhalten.
    RailTimeMotion.reveal('.sa-motion-up:not(.sa-intro__lead):not(.sa-intro__facts)',{distance:34,duration:260,hook:.76,alternate:false});
    RailTimeMotion.reveal('.sa-motion-left:not(.sa-network__map)',{axis:'x',distance:-42,duration:280,hook:.76,alternate:false});
    RailTimeMotion.reveal('.sa-motion-right:not(.sa-intro__image):not(.sa-network__copy)',{axis:'x',distance:42,duration:280,hook:.76,alternate:false});
    return;
  }
  RailTimeMotion.reveal('.ig-motion-up',{distance:58,duration:350,hook:.86,alternate:false});
  RailTimeMotion.reveal('.ig-motion-left',{axis:'x',distance:-62,duration:360,hook:.86,alternate:false});
  RailTimeMotion.reveal('.ig-motion-right',{axis:'x',distance:62,duration:360,hook:.86,alternate:false});
});
