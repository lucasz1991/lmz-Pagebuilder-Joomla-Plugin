/**
 * RailTime - eigener Motion-Owner fuer Ueber uns / About us.
 *
 * Das native LMZ-Seitenmarkup bleibt die Inhaltsquelle. Hero, Fakten, Profil und
 * Philosophie erhalten reversible ScrollTrigger-Timelines; der Ablauf bleibt
 * bewusst im alleinigen Besitz von rt-process.js.
 */
(() => {
  'use strict';

  if (!document.body.classList.contains('is-about')) return;

  const starten = () => {
    const wurzel = document.querySelector('.rt-x');
    if (!wurzel || wurzel.dataset.aboutInitialisiert) return;

    wurzel.dataset.aboutInitialisiert = 'true';
    wurzel.classList.add('rt-about');

    const eins = (auswahl, kontext = wurzel) => kontext?.querySelector(auswahl) || null;
    const alle = (auswahl, kontext = wurzel) => Array.from(kontext?.querySelectorAll(auswahl) || []);
    const vorhang = eins('.rt-x__vorhang');
    const hero = eins('.rt-x__hero');
    const heroText = eins('.rt-x__hero-text');
    const heroFigur = eins('.rt-x__hero-figur');
    const zahlen = eins('.rt-x__zahlen');
    const detailSplit = eins('.rt-x__split');
    const detailSektion = detailSplit?.closest('.rt-x__section');
    const werteStapel = eins('.rt-x__stapel');
    const werteSektion = werteStapel?.closest('.rt-x__section');
    const prozessSpur = eins('.rt-x__scheiben');
    const prozessSektion = prozessSpur?.closest('.rt-x__section');
    const sprachTag = document.documentElement.lang.toLowerCase();
    const englisch = sprachTag.startsWith('en');
    const polnisch = sprachTag.startsWith('pl');
    const textFuerSprache = (deutsch, english, polski) => (
      englisch ? english : (polnisch ? polski : deutsch)
    );

    if (!hero || !heroText || !heroFigur || !zahlen || !detailSektion || !werteSektion || !prozessSektion) {
      wurzel.dataset.aboutBereit = 'markup-fehlt';
      return;
    }

    if (vorhang) {
      vorhang.hidden = true;
      vorhang.style.display = 'none';
    }

    detailSektion.classList.add('rt-about-detail');
    werteSektion.classList.add('rt-about-values');
    prozessSektion.classList.add('rt-about-process');

    hero.dataset.aboutChapter = textFuerSprache('01 / UNTERNEHMEN', '01 / COMPANY', '01 / FIRMA');
    detailSektion.dataset.aboutChapter = textFuerSprache('02 / PROFIL', '02 / PROFILE', '02 / PROFIL');
    werteSektion.dataset.aboutChapter = textFuerSprache('03 / PRINZIPIEN', '03 / PRINCIPLES', '03 / ZASADY');
    prozessSektion.dataset.aboutChapter = textFuerSprache('04 / ABLAUF', '04 / WORKFLOW', '04 / PRZEBIEG');
    heroFigur.dataset.aboutLabel = textFuerSprache('IM EINSATZ / 01', 'FIELD OPERATIONS / 01', 'PRACA W TERENIE / 01');

    const faktenCodes = textFuerSprache(
      ['01 / TEAM', '02 / BEREITSCHAFT', '03 / NETZ'],
      ['01 / TEAM', '02 / AVAILABILITY', '03 / NETWORK'],
      ['01 / ZESPÓŁ', '02 / GOTOWOŚĆ', '03 / SIEĆ'],
    );
    alle('.rt-x__zahl', zahlen).forEach((feld, index) => {
      feld.dataset.aboutCode = faktenCodes[index] || String(index + 1).padStart(2, '0');
    });
    if (zahlen.parentElement !== hero) hero.append(zahlen);

    /* Vorhandene, weboptimierte Arbeitsmotive ersetzen die wiederholten
       Poster. Die Inhaltsdatenbank bleibt unangetastet. */
    const heroBild = heroFigur.querySelector('img');
    const detailBild = detailSplit?.querySelector('.rt-x__bild img');
    /* Motiv und Alt-Text von Hero und Detailbild kommen ausschliesslich aus
       dem LMZ Page Builder; hier werden sie nicht mehr ueberschrieben. */

    alle('.rt-x__scheibe').forEach(karte => karte.removeAttribute('tabindex'));

    const kontaktZiel = document.querySelector(
      '.rt-nav nav a[href$="/kontakt"], .rt-nav nav a[href$="/contact"]',
    );
    const heroKontakt = eins('.rt-x__hero .rt-x__btn--voll');
    if (kontaktZiel && heroKontakt) heroKontakt.href = kontaktZiel.href;

    const heroTeile = [...heroText.children];
    const fakten = [...zahlen.children];
    const detailBildRahmen = eins('.rt-x__bild', detailSplit);
    const detailText = eins('.rt-x__fliess', detailSplit);
    const detailTeile = detailText ? [...detailText.children] : [];
    const werteKopf = werteSektion.querySelector(':scope > header');
    const werteKopfTeile = werteKopf ? [...werteKopf.children] : [];
    const werte = alle('.rt-x__karte', werteStapel);
    const prozessKopf = prozessSektion.querySelector(':scope > header');
    /* Der globale Notfall-Abschluss wird vom Template direkt hinter dem
       Pagebuilder-Root ausgegeben. Er gehoert visuell zur About-Seite, liegt
       aber absichtlich nicht innerhalb von .rt-x. */
    const cta = eins('.rt-emergency-banner', document);
    const ctaInnen = cta?.querySelector('.rt-emergency-banner__inner') || null;
    const ctaKopieTeile = cta
      ? alle('.rt-emergency-banner__copy > *', cta)
      : [];
    const ctaAktionenTeile = cta
      ? alle('.rt-emergency-banner__actions > *', cta)
      : [];
    if (werteKopf) werteKopf.dataset.aboutChapter = werteSektion.dataset.aboutChapter;
    if (prozessKopf) prozessKopf.dataset.aboutChapter = prozessSektion.dataset.aboutChapter;

    const zaehlerFeld = fakten[0]?.querySelector('strong');
    const zaehlerTreffer = zaehlerFeld?.textContent.trim().match(/^(\d+)(\D*)$/);
    const eigeneZiele = [
      ...heroTeile,
      heroText,
      heroFigur,
      heroBild,
      zahlen,
      ...fakten,
      detailBildRahmen,
      detailBild,
      ...detailTeile,
      ...werteKopfTeile,
      ...werte,
      ctaInnen,
      ...ctaKopieTeile,
      ...ctaAktionenTeile,
    ].filter(Boolean);

    const kapitel = [hero, detailSektion, werteSektion, prozessSektion];

    const finalzustandSetzen = () => {
      if (window.gsap) {
        gsap.set(eigeneZiele, {
          clearProps: 'transform,translate,rotate,scale,opacity,visibility,clipPath,willChange,transformOrigin',
        });
      } else {
        eigeneZiele.forEach((element) => {
          ['transform', 'opacity', 'visibility', 'clip-path', 'will-change']
            .forEach(eigenschaft => element.style.removeProperty(eigenschaft));
        });
      }

      hero.style.setProperty('--about-grid-opacity', '1');
      hero.style.setProperty('--about-accent-scale', '1');
      zahlen.style.setProperty('--about-facts-line', '1');
      detailSektion.style.setProperty('--about-detail-line', '1');
      werteSektion.style.setProperty('--about-image-clip', '0%');
      werteSektion.style.setProperty('--about-values-sweep', '1');
      kapitel.forEach(section => section.classList.remove('is-rt-about-motion-active'));
      cta?.classList.remove('is-rt-about-motion-active');
      [hero, zahlen, detailSektion, werteSektion, cta].filter(Boolean).forEach((element) => {
        delete element.dataset.aboutMotionProgress;
      });
      if (zaehlerTreffer && zaehlerFeld) {
        zaehlerFeld.textContent = `${zaehlerTreffer[1]}${zaehlerTreffer[2]}`;
      }
    };

    const reduziert = matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (!window.gsap || !window.ScrollTrigger || reduziert) {
      finalzustandSetzen();
      wurzel.dataset.aboutBereit = reduziert ? 'reduziert' : 'statisch';
      requestAnimationFrame(() => dispatchEvent(new Event('resize')));
      return;
    }

    gsap.registerPlugin(ScrollTrigger);
    gsap.config({ nullTargetWarn: false });
    wurzel.dataset.aboutBereit = 'gsap-scroll';
    wurzel.dataset.aboutBewegung = 'aktiv';

    let medien = null;
    const triggerIds = [
      'rt-about-hero-scroll',
      'rt-about-facts',
      'rt-about-hero',
      'rt-about-detail',
      'rt-about-values',
      'rt-about-cta',
    ];
    const triggerEntfernen = () => {
      triggerIds.forEach((id) => {
        const trigger = ScrollTrigger.getById(id);
        trigger?.animation?.kill();
        trigger?.kill();
      });
    };

    try {
      triggerEntfernen();
      medien = gsap.matchMedia();
      medien.add({
        desktop: '(min-width: 761px)',
        mobile: '(max-width: 760px)',
      }, (context) => {
        const desktop = context.conditions.desktop;
        const scrub = desktop ? .68 : .42;

        gsap.set(hero, { '--about-grid-opacity': 1, '--about-accent-scale': 1 });
        gsap.set([heroText, heroFigur, zahlen, ...fakten], { autoAlpha: 1 });
        gsap.set(zahlen, { '--about-facts-line': 1 });
        gsap.set(detailSektion, { '--about-detail-line': 0 });
        gsap.set(detailTeile, {
          autoAlpha: 0,
          x: desktop ? 56 : 0,
          y: desktop ? 0 : 24,
        });
        gsap.set(werteKopfTeile, { autoAlpha: 0, y: desktop ? 36 : 24 });
        gsap.set(werte, {
          autoAlpha: 0,
          x: desktop ? 64 : 0,
          y: desktop ? 0 : 24,
          scale: desktop ? .97 : 1,
        });
        if (ctaInnen) gsap.set(ctaInnen, { y: desktop ? 30 : 20, scale: desktop ? .985 : 1 });
        gsap.set(ctaKopieTeile, { autoAlpha: 0, y: desktop ? 26 : 18 });
        gsap.set(ctaAktionenTeile, {
          autoAlpha: 0,
          x: desktop ? 34 : 0,
          y: desktop ? 0 : 18,
        });

        const heroTimeline = gsap.timeline({
          scrollTrigger: {
            id: 'rt-about-hero',
            trigger: hero,
            start: 'top top',
            end: 'bottom 35%',
            scrub,
            invalidateOnRefresh: true,
            onToggle: self => hero.classList.toggle('is-rt-about-motion-active', self.isActive),
            onUpdate: self => {
              hero.dataset.aboutMotionProgress = self.progress.toFixed(3);
            },
          },
        });
        heroTimeline
          .fromTo(heroText,
            { yPercent: 0, autoAlpha: 1 },
            { yPercent: desktop ? -14 : -7, autoAlpha: .58, duration: 1, ease: 'none' }, 0)
          .fromTo(heroFigur,
            { yPercent: 0, scale: 1, autoAlpha: 1 },
            {
              yPercent: desktop ? 12 : 6,
              scale: desktop ? .985 : .995,
              autoAlpha: .74,
              duration: 1,
              ease: 'none',
            }, 0)
          .fromTo(zahlen,
            { yPercent: 0, autoAlpha: 1 },
            { yPercent: desktop ? -9 : -4, autoAlpha: .48, duration: 1, ease: 'none' }, 0)
          .fromTo(hero,
            { '--about-grid-opacity': 1, '--about-accent-scale': 1 },
            {
              '--about-grid-opacity': .28,
              '--about-accent-scale': .62,
              duration: 1,
              ease: 'none',
            }, 0);

        const detailTimeline = gsap.timeline({
          scrollTrigger: {
            id: 'rt-about-detail',
            trigger: detailSektion,
            start: desktop ? 'top 76%' : 'top 84%',
            end: desktop ? 'bottom 42%' : 'bottom 30%',
            scrub,
            invalidateOnRefresh: true,
            onToggle: self => detailSektion.classList.toggle('is-rt-about-motion-active', self.isActive),
            onUpdate: self => {
              detailSektion.dataset.aboutMotionProgress = self.progress.toFixed(3);
            },
          },
        });
        detailTimeline.fromTo(detailSektion,
          { '--about-detail-line': 0 },
          {
            '--about-detail-line': 1,
            duration: .86,
            ease: 'none',
          }, 0);
        if (detailBildRahmen) {
          detailTimeline.fromTo(detailBildRahmen,
            {
              autoAlpha: 0,
              x: desktop ? -64 : -24,
              clipPath: 'inset(0 22% 0 0)',
            },
            {
              autoAlpha: 1,
              x: 0,
              clipPath: 'inset(0 0% 0 0)',
              duration: .62,
              ease: 'power3.out',
            }, 0);
        }
        if (detailBild) {
          detailTimeline.fromTo(detailBild,
            { scale: desktop ? 1.1 : 1.045, yPercent: desktop ? -4 : -1 },
            { scale: 1, yPercent: 0, duration: .7, ease: 'power2.out' }, .04);
        }
        detailTimeline.to(detailTeile, {
            autoAlpha: 1,
            x: 0,
            y: 0,
            duration: .48,
            ease: 'power3.out',
            stagger: .08,
          }, .25);

        const werteTimeline = gsap.timeline({
          scrollTrigger: {
            id: 'rt-about-values',
            trigger: werteSektion,
            start: desktop ? 'top 74%' : 'top 82%',
            end: desktop ? 'bottom 38%' : 'bottom 28%',
            scrub,
            invalidateOnRefresh: true,
            onToggle: self => werteSektion.classList.toggle('is-rt-about-motion-active', self.isActive),
            onUpdate: self => {
              werteSektion.dataset.aboutMotionProgress = self.progress.toFixed(3);
            },
          },
        });
        werteTimeline
          .fromTo(werteSektion,
            { '--about-image-clip': '100%', '--about-values-sweep': 0 },
            {
              '--about-image-clip': '0%',
              '--about-values-sweep': 1,
              duration: .72,
              ease: 'none',
            }, 0)
          .to(werteKopfTeile, {
              autoAlpha: 1,
              y: 0,
              duration: .38,
              ease: 'power3.out',
              stagger: .08,
            }, .04)
          .to(werte, {
              autoAlpha: 1,
              x: 0,
              y: 0,
              scale: 1,
              duration: .46,
              ease: 'power3.out',
              stagger: .1,
            }, .3);

        if (cta) {
          const ctaTimeline = gsap.timeline({
            scrollTrigger: {
              id: 'rt-about-cta',
              trigger: cta,
              start: desktop ? 'top 82%' : 'top 88%',
              end: desktop ? 'bottom 62%' : 'bottom 55%',
              scrub: desktop ? .58 : .4,
              invalidateOnRefresh: true,
              onToggle: self => cta.classList.toggle('is-rt-about-motion-active', self.isActive),
              onUpdate: self => {
                cta.dataset.aboutMotionProgress = self.progress.toFixed(3);
              },
            },
          });
          if (ctaInnen) {
            ctaTimeline.to(ctaInnen, {
              y: 0,
              scale: 1,
              duration: .54,
              ease: 'power2.out',
            }, 0);
          }
          ctaTimeline
            .to(ctaKopieTeile, {
              autoAlpha: 1,
              y: 0,
              duration: .42,
              ease: 'power3.out',
              stagger: .08,
            }, .08)
            .to(ctaAktionenTeile, {
              autoAlpha: 1,
              x: 0,
              y: 0,
              duration: .42,
              ease: 'power3.out',
              stagger: .1,
            }, .42);
        }

        return () => {
          kapitel.forEach(section => section.classList.remove(
            'is-rt-about-motion-active',
            'is-rt-about-facts-active',
          ));
          cta?.classList.remove('is-rt-about-motion-active');
          if (zaehlerTreffer && zaehlerFeld) {
            zaehlerFeld.textContent = `${zaehlerTreffer[1]}${zaehlerTreffer[2]}`;
          }
        };
      });

      requestAnimationFrame(() => ScrollTrigger.refresh());

      /* Stillstandssicherung. Detailteile, Wertekarten und der CTA starten auf
         autoAlpha 0 und werden nur von scrub-Triggern sichtbar gemacht. Steht
         der Bildtakt still, bliebe der halbe Seiteninhalt unsichtbar. */
      window.RailTimeStillstand?.(() => {
        medien?.revert();
        triggerEntfernen();
        finalzustandSetzen();
        wurzel.dataset.aboutBereit = 'takt-notausstieg';
      }, { fertig: () => wurzel.dataset.aboutBereit === 'takt-notausstieg' });
    } catch (fehler) {
      medien?.revert();
      triggerEntfernen();
      finalzustandSetzen();
      wurzel.dataset.aboutBereit = 'fehler-fallback';
      console.error('[rt-about]', fehler);
    }

    const refresh = () => requestAnimationFrame(() => ScrollTrigger.refresh());
    const beiPageshow = (event) => {
      if (event.persisted) refresh();
    };
    const beiPagehide = (event) => {
      if (event.persisted) return;
      removeEventListener('pageshow', beiPageshow);
      removeEventListener('pagehide', beiPagehide);
      medien?.revert();
      triggerEntfernen();
    };
    addEventListener('pageshow', beiPageshow);
    addEventListener('pagehide', beiPagehide);
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', starten, { once: true });
  } else {
    starten();
  }
})();
