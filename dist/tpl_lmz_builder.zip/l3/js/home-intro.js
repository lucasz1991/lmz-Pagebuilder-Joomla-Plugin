document.addEventListener('DOMContentLoaded', () => {
  const hero = document.querySelector('.rt-hero');
  const video = hero?.querySelector('[data-hero-video]');
  const logo = hero?.querySelector('.rt-intro-logo');
  const copy = hero?.querySelector('.rt-hero-copy');
  const nav = document.querySelector('.rt-nav');
  const target = document.querySelector('#content-start');
  if (!hero) return;

  if (video) {
    video.controls = false;
    ['controls', 'controlslist', 'allowfullscreen'].forEach(attribute => video.removeAttribute(attribute));
  }

  const introClipStart = .30;
  const introSpeedMultiplier = 1.15;

  const restoreAnchor = () => {
    if (!location.hash) return;
    const anchor = document.querySelector(location.hash);
    anchor?.scrollIntoView({ block: 'start' });
  };

  if (video?.dataset.heroPlayback === 'intro-once') {
    let completed = false;
    let logoRevealed = false;
    let dockStarted = false;
    let retryArmed = false;
    let clipPositioned = false;
    let clipStartTime = 0;
    let playPending = false;
    let playbackStarted = false;
    let firstVideoFrameVisible = false;
    let dockTimer = 0;
    let failOpenTimer = 0;
    let prepareFrameTimer = 0;
    let firstFrameTimer = 0;
    let firstFrameRaf = 0;
    let videoFrameCallback = 0;
    let flightTimeline = null;
    let impactTimeline = null;
    let settleTween = null;
    /* Der Intro-Ablauf darf die Seite unter keinen Umstaenden gesperrt
       zuruecklassen. Bleibt der Logo-Flug haengen (auf Mobil feuerte das
       onComplete der Flug-Timeline nicht, wodurch is-logo-flight-active
       stehenblieb und overflow:hidden auf html/body nie geloest wurde),
       schliesst dieser Wachhund den Handoff hart ab. */
    let handoffFertig = false;
    let handoffWachhund = 0;
    /* Autoplay ist nachweislich verboten. Dann laeuft kein Intro, die Seite
       wird nicht gesperrt und der Startknopf bleibt der einzige Weg hinein. */
    let autoplayGesperrt = false;
    let videoHoerenAktiv = false;
    let settleWachhund = 0;
    const handoffDuration = 1.18;
    const impactDuration = .72;

    const startButton = hero.querySelector('[data-intro-start]');
    /* Der vorhandene Wrapper bleibt die exakt vermessene GSAP-Flugbox. Das
       WebGL-Modell ist bewusst deaktiviert; im Hero fliegt ausschliesslich
       die normale farbige SVG-Marke aus dem nativen Hero. */
    const logoHost = hero.querySelector('.sa-logo-3d');
    const logoStage = hero.querySelector('.sa-logo-stage');
    const heroShade = hero.querySelector('.sa-hero__shade');
    const logoSlot = nav?.querySelector('[data-rt-nav-logo-slot]');
    const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)').matches;
    const blockedKeys = ['ArrowDown', 'ArrowUp', 'PageDown', 'PageUp', ' ', 'Home', 'End'];

    if (logoHost) {
      logoHost.classList.add('is-svg-flight');
      logoHost.removeAttribute('data-rt-logo-3d');
      logoHost.removeAttribute('data-logo-variant');
      logoHost.removeAttribute('data-logo-wait-for-reveal');
      logoHost.removeAttribute('data-model-src');
      logoHost.querySelector('canvas')?.remove();
    }
    logoStage?.classList.add('is-clean-logo-stage');
    logoStage?.querySelectorAll('.rt-logo-orbit, .rt-logo-scan')
      .forEach(element => element.remove());
    /* Auf der Startseite gibt es bewusst kein zweites Navigationsbild. Der
       einzige SVG-Host wird nach dem Flug selbst in diesen Slot eingesetzt. */
    logoSlot?.querySelector('.rt-nav__logo-static')?.remove();

    /* Heimatplatz des Flug-Hosts festhalten. Wird das Intro wegen einer
       Autoplay-Sperre uebersprungen, landet die Marke sofort in der
       Navigation. Ein spaeterer Start per Nutzergeste muss sie exakt an
       diese Stelle zuruecklegen koennen, sonst fliegt beim zweiten Versuch
       nichts mehr. */
    const logoHeimatEltern = logoHost?.parentElement || logoStage || null;
    const logoHeimatNachbar = logoHost?.nextElementSibling || null;

    const configuredRevealAt = Number.parseFloat(video.dataset.logoRevealAt || '5.08');
    const configuredDockDelay = Number.parseInt(video.dataset.heroDockDelay || '1500', 10);
    const configuredStartProgress = Number.parseFloat(video.dataset.heroStartProgress || '0');
    const configuredPlaybackRate = Number.parseFloat(video.dataset.heroPlaybackRate || '1');
    const logoRevealAt = Number.isFinite(configuredRevealAt) ? configuredRevealAt : 5.08;
    const dockDelay = Number.isFinite(configuredDockDelay) ? configuredDockDelay : 1500;
    const startProgress = Number.isFinite(configuredStartProgress)
      ? Math.min(.9, Math.max(0, configuredStartProgress))
      : 0;
    const playbackRate = Number.isFinite(configuredPlaybackRate)
      ? Math.min(2, Math.max(.5, configuredPlaybackRate))
      : 1;

    video.muted = true;
    video.defaultMuted = true;
    video.loop = false;
    video.autoplay = false;
    video.playsInline = true;
    video.preload = 'auto';
    video.defaultPlaybackRate = playbackRate;
    video.playbackRate = playbackRate;
    video.removeAttribute('autoplay');
    video.removeAttribute('loop');
    /* Safari verlangt muted und playsinline nachweislich vor play(), und es
       liest beides beim Aufsetzen der Ressource aus den HTML-Attributen.
       Nur die Eigenschaften zu setzen genuegt nicht, sobald spaeter noch ein
       load() folgt - dann stellt WebKit den Attributzustand wieder her. */
    video.setAttribute('muted', '');
    video.setAttribute('playsinline', '');
    video.setAttribute('webkit-playsinline', '');

    const posterSource = video.poster || video.dataset.heroPoster || '';
    const posterOverlay = posterSource ? document.createElement('img') : null;
    let posterAvailable = false;
    const posterReady = new Promise(resolve => {
      if (!posterOverlay) {
        resolve(false);
        return;
      }

      let settled = false;
      let loadTimer = 0;
      const settle = available => {
        if (settled) return;
        settled = true;
        clearTimeout(loadTimer);
        posterAvailable = available;
        hero.classList.toggle('is-video-poster-unavailable', !available);
        resolve(available);
      };

      posterOverlay.className = 'rt-hero-video-poster';
      posterOverlay.alt = '';
      posterOverlay.setAttribute('aria-hidden', 'true');
      posterOverlay.decoding = 'async';
      posterOverlay.fetchPriority = 'high';
      posterOverlay.addEventListener('load', () => settle(true), { once: true });
      posterOverlay.addEventListener('error', () => settle(false), { once: true });
      posterOverlay.src = posterSource;
      video.insertAdjacentElement('afterend', posterOverlay);
      hero.classList.add('is-video-frame-pending');

      if (posterOverlay.complete) settle(posterOverlay.naturalWidth > 0);
      else loadTimer = window.setTimeout(() => settle(false), 5000);
    });

    const preventTraversal = event => {
      if (event.cancelable) event.preventDefault();
    };
    const preventTraversalKey = event => {
      if (event.target === startButton) return;
      if (blockedKeys.includes(event.key) && event.cancelable) event.preventDefault();
    };
    const lockPage = () => {
      document.documentElement.classList.add('rt-intro-playing');
      document.body.classList.add('rt-intro-playing');
      addEventListener('wheel', preventTraversal, { passive: false });
      addEventListener('touchmove', preventTraversal, { passive: false });
      addEventListener('keydown', preventTraversalKey);
    };
    const unlockPage = () => {
      document.documentElement.classList.remove('rt-intro-playing');
      document.body.classList.remove('rt-intro-playing');
      removeEventListener('wheel', preventTraversal);
      removeEventListener('touchmove', preventTraversal);
      removeEventListener('keydown', preventTraversalKey);
    };

    const refreshLayout = () => {
      dispatchEvent(new Event('resize'));
      requestAnimationFrame(() => window.ScrollTrigger?.refresh());
      if (location.hash) restoreAnchor();
    };

    const impactAbschliessen = () => {
      const laufendeTimeline = impactTimeline;
      if (!laufendeTimeline) return;
      laufendeTimeline.progress(1);
      laufendeTimeline.kill();
      impactTimeline = null;
    };

    const clearFlightStyles = () => {
      if (!logoHost) return;
      if (window.gsap) {
        gsap.set(logoHost, { clearProps: 'transform,translate,rotate,scale' });
      }
      [
        'position', 'left', 'top', 'width', 'height', 'z-index', 'margin',
        'pointer-events', 'transform', 'transform-origin', 'translate', 'rotate', 'scale'
      ].forEach(property => logoHost.style.removeProperty(property));
    };

    const handoffFinalisieren = () => {
      if (handoffFertig) return;
      handoffFertig = true;
      clearTimeout(handoffWachhund);
      clearTimeout(settleWachhund);
      handoffWachhund = 0;
      settleWachhund = 0;
      settleTween = null;
      hero.classList.add('is-logo-handoff-complete');
      hero.classList.remove('is-logo-flight-active');
      if (window.gsap) {
        gsap.set(hero, { clearProps: 'height,minHeight,willChange' });
        if (heroShade) {
          gsap.set(heroShade, {
            clearProps: 'transform,transformOrigin,willChange,transition',
          });
        }
      } else {
        hero.style.removeProperty('height');
        hero.style.removeProperty('min-height');
        hero.style.removeProperty('will-change');
      }
      unlockPage();
      if (!location.hash) scrollTo({ top: 0, left: 0, behavior: 'auto' });
      refreshLayout();
      dispatchEvent(new CustomEvent('railtime:intro-complete'));
    };

    const completeHandoff = () => {
      if (logoHost && logoSlot) {
        const gelandeteBox = logoHost.getBoundingClientRect();
        logoSlot.append(logoHost);
        clearFlightStyles();
        logoHost.classList.remove('is-logo-flight');
        logoHost.classList.add('is-nav-docked', 'is-nav-tone');
        nav?.classList.add('is-logo-handoff', 'is-logo-handoff-complete');

        /* FLIP-Ausgleich: Reparenting und CSS-Endzustand passieren im selben
           Frame. Eine moegliche Subpixel-Differenz wird aus der gelandeten
           Geometrie heraus auf null animiert und kann daher nicht zucken. */
        if (window.gsap && gelandeteBox.width) {
          const dockBox = logoHost.getBoundingClientRect();
          if (dockBox.width && dockBox.height) {
            const deltaX = gelandeteBox.left - dockBox.left;
            const deltaY = gelandeteBox.top - dockBox.top;
            const scaleX = gelandeteBox.width / dockBox.width;
            const scaleY = gelandeteBox.height / dockBox.height;
            const abweichung = Math.max(
              Math.abs(deltaX), Math.abs(deltaY),
              Math.abs(1 - scaleX) * dockBox.width,
              Math.abs(1 - scaleY) * dockBox.height,
            );
            if (abweichung > .1) {
              gsap.set(logoHost, {
                x: deltaX,
                y: deltaY,
                scaleX,
                scaleY,
                transformOrigin: '0 0',
              });
              settleTween = gsap.to(logoHost, {
                x: 0,
                y: 0,
                scaleX: 1,
                scaleY: 1,
                duration: .16,
                ease: 'power2.out',
                force3D: false,
                clearProps: 'transform,transformOrigin',
                onComplete: handoffFinalisieren,
              });
              /* Auch dieser kurze Ausgleich haengt am GSAP-Takt. Steht der
                 Takt, feuerte sein onComplete nie und der Handoff blieb
                 unvollendet - ohne dockLogo() gibt es hier keinen zweiten
                 Wachhund, etwa wenn finishImmediately() direkt abschliesst.
                 Deshalb eine eigene, kurze Frist; handoffFinalisieren() ist
                 ueber handoffFertig idempotent. */
              clearTimeout(settleWachhund);
              settleWachhund = window.setTimeout(() => {
                if (handoffFertig) return;
                settleTween?.progress(1);
                settleTween?.kill();
                handoffFinalisieren();
              }, 400);
              return;
            }
          }
        }
      } else {
        nav?.classList.remove('is-logo-handoff');
      }
      handoffFinalisieren();
    };

    const dockLogo = (immediate = false) => {
      if (dockStarted) return;
      dockStarted = true;
      clearTimeout(dockTimer);
      clearTimeout(handoffWachhund);
      handoffWachhund = window.setTimeout(() => {
        if (handoffFertig) return;
        /* Bewusst nicht auf GSAP verlassen: bleibt der rAF-Takt aus
           (Hintergrundtab, Energiesparmodus, gedrosselte Mobilbrowser),
           feuert kein onComplete. Deshalb erst den regulaeren Abschluss
           versuchen und danach hart finalisieren. */
        completeHandoff();
        settleTween?.kill();
        handoffFinalisieren();
      }, 2500);
      impactAbschliessen();
      nav?.classList.remove('is-tucked');
      nav?.classList.add('is-visible');

      if (!logoHost || !logoSlot) {
        hero.classList.add('is-video-intro-docked');
        completeHandoff();
        return;
      }

      nav.classList.add('is-logo-handoff');
      if (immediate || !window.gsap) {
        hero.classList.add('is-video-intro-docked');
        completeHandoff();
        return;
      }

      const vorherigeNavTransition = nav?.style.transition || '';
      if (nav) {
        nav.style.transition = 'none';
        void nav.offsetWidth;
      }
      const source = logoHost.getBoundingClientRect();
      const destination = logoSlot.getBoundingClientRect();
      if (nav) nav.style.transition = vorherigeNavTransition;
      if (!source.width || !destination.width) {
        hero.classList.add('is-video-intro-docked');
        completeHandoff();
        return;
      }

      const heroStartHeight = hero.getBoundingClientRect().height;

      logoHost.classList.add('is-logo-flight');
      Object.assign(logoHost.style, {
        position: 'fixed',
        left: `${source.left}px`,
        top: `${source.top}px`,
        width: `${source.width}px`,
        height: `${source.height}px`,
        zIndex: '130',
        margin: '0',
        pointerEvents: 'none',
        transformOrigin: '0 0'
      });
      document.body.append(logoHost);

      /*
       * Hero und Logo werden von derselben GSAP-Timeline gesteuert. Die
       * fruehere CSS-Hoehentransition lief mit einer anderen Kurve als der
       * Logo-Flug und war dadurch sichtbar frueher fertig. Die Hilfsklasse
       * schaltet die CSS-Hoehentransition fuer genau diesen Messmoment ab.
       */
      hero.classList.add('is-logo-flight-active', 'is-video-intro-docked');
      const heroEndHeight = hero.getBoundingClientRect().height;
      gsap.set(hero, {
        height: heroStartHeight,
        minHeight: heroStartHeight,
        willChange: 'height',
      });

      const scale = destination.width / source.width;
      const deltaX = destination.left - source.left;
      const deltaY = destination.top - source.top;
      flightTimeline = gsap.timeline({
        defaults: { ease: 'power3.inOut' },
        onComplete: completeHandoff
      });
      flightTimeline.addLabel('dock', 0);
      flightTimeline.to(hero, {
        height: heroEndHeight,
        minHeight: heroEndHeight,
        duration: handoffDuration,
        ease: 'power3.inOut',
      }, 'dock');
      flightTimeline.to(logoHost, {
        x: deltaX,
        y: deltaY,
        scale,
        duration: handoffDuration,
        ease: 'power3.inOut',
        force3D: false
      }, 'dock');
      flightTimeline.call(
        () => logoHost.classList.add('is-nav-tone'),
        null,
        `dock+=${(handoffDuration - .28).toFixed(2)}`,
      );
    };

    const revealLogoAtImpact = () => {
      if (logoRevealed) return;
      logoRevealed = true;
      hero.classList.add('is-video-logo-visible');
      logo?.classList.add('is-visible');

      /* Der Zug kommt im Clip direkt auf die Kamera zu. Das Logo uebernimmt
         diese Bewegung streng monoton: sehr klein beginnen, bis zur vollen
         Groesse wachsen und dort ruhig stehen, bis der eigentliche Flug zur
         Navigation startet. Kein Overshoot und kein Zurueckfedern. */
      if (logo && window.gsap && !reducedMotion) {
        impactTimeline?.kill();
        hero.classList.remove('is-logo-impact-complete');
        hero.classList.add('is-logo-impact-active');
        gsap.set(logo, {
          transition: 'none',
          transformOrigin: '50% 50%',
          willChange: 'transform',
        });
        impactTimeline = gsap.timeline({
          onComplete: () => {
            gsap.set(logo, {
              clearProps: 'transform,transformOrigin,willChange,transition',
            });
            hero.classList.remove('is-logo-impact-active');
            hero.classList.add('is-logo-impact-complete');
            impactTimeline = null;
          },
        });
        impactTimeline
          .fromTo(logo, {
            scale: .01,
          }, {
            scale: 1,
            duration: impactDuration,
            ease: 'power3.out',
            force3D: true,
          });
        if (heroShade) {
          gsap.set(heroShade, {
            autoAlpha: .12,
            scale: 1.035,
            transition: 'none',
            transformOrigin: '68% 50%',
            willChange: 'transform,opacity',
          });
          impactTimeline.to(heroShade, {
            autoAlpha: 1,
            scale: 1,
            duration: .48,
            ease: 'power2.out',
          }, .74);
        }
      }

      dockTimer = window.setTimeout(() => dockLogo(false), dockDelay);
    };

    const maybeRevealLogo = mediaTime => {
      const current = Number.isFinite(mediaTime) ? mediaTime : Number(video.currentTime || 0);
      /* Die Marke erreicht exakt mit dem letzten Videoframe ihre volle
         Groesse. playbackRate ist hier wichtig, weil die GSAP-Dauer reale
         Sekunden, logoRevealAt dagegen Mediensekunden verwendet. */
      const synchronisedRevealAt = Number.isFinite(video.duration)
        ? Math.min(logoRevealAt, Math.max(0, video.duration - (impactDuration * playbackRate)))
        : logoRevealAt;
      if (current >= synchronisedRevealAt) revealLogoAtImpact();
    };

    const revealFirstVideoFrame = mediaTime => {
      if (completed || firstVideoFrameVisible || !playbackStarted) return false;
      const current = Number.isFinite(mediaTime) ? mediaTime : Number(video.currentTime || 0);
      if (Number.isFinite(current) && current + .08 < clipStartTime) return false;
      firstVideoFrameVisible = true;
      clearTimeout(firstFrameTimer);
      firstFrameTimer = 0;
      if (firstFrameRaf) cancelAnimationFrame(firstFrameRaf);
      firstFrameRaf = 0;
      hero.classList.remove('is-video-frame-pending', 'is-video-poster-fallback');
      hero.classList.add('is-video-frame-ready');
      return true;
    };

    const monitorVideoFrame = (_now, metadata) => {
      videoFrameCallback = 0;
      if (completed) return;
      revealFirstVideoFrame(Number(metadata?.mediaTime));
      maybeRevealLogo(Number(metadata?.mediaTime));
      if (!completed && video.requestVideoFrameCallback) {
        videoFrameCallback = video.requestVideoFrameCallback(monitorVideoFrame);
      }
    };

    const armImpactMonitor = () => {
      if (completed) return;
      maybeRevealLogo();
      if (video.requestVideoFrameCallback && !videoFrameCallback) {
        videoFrameCallback = video.requestVideoFrameCallback(monitorVideoFrame);
      }
      /* In Hintergrund-Tabs koennen die Frame-Callbacks stark gedrosselt
         werden. Nach playing ist das zuvor dekodierte Ziel-Frame bereit; zwei
         Paints beziehungsweise der kurze Zeit-Fallback verhindern dort, dass
         das Poster unnoetig lange stehen bleibt. Der erste Pfad gewinnt. */
      if (!firstVideoFrameVisible && !firstFrameRaf) {
        firstFrameRaf = requestAnimationFrame(() => {
          firstFrameRaf = requestAnimationFrame(() => {
            firstFrameRaf = 0;
            if (video.readyState >= 2) revealFirstVideoFrame();
          });
        });
      }
      if (!firstVideoFrameVisible && !firstFrameTimer) {
        firstFrameTimer = window.setTimeout(() => {
          firstFrameTimer = 0;
          if (video.readyState >= 2) revealFirstVideoFrame();
        }, 160);
      }
    };

    const handlePlaybackStarted = () => {
      if (completed) return;
      playbackStarted = true;
      armImpactMonitor();
    };

    const completeVideo = () => {
      if (completed) return;
      completed = true;
      clearTimeout(failOpenTimer);
      clearTimeout(prepareFrameTimer);
      clearTimeout(firstFrameTimer);
      if (firstFrameRaf) cancelAnimationFrame(firstFrameRaf);
      firstFrameRaf = 0;
      if (videoFrameCallback && video.cancelVideoFrameCallback) {
        video.cancelVideoFrameCallback(videoFrameCallback);
      }
      videoFrameCallback = 0;
      revealLogoAtImpact();
      hero.classList.remove('is-video-intro-playing', 'is-video-autoplay-blocked');
      hero.classList.add('is-video-intro-complete');
      // Der statische Navigations-Marker bleibt leer, bis dieselbe SVG-Marke
      // aus dem Hero dort landet. So bleibt der Flug durchgehend farbig.
      nav?.classList.add('is-visible', 'is-logo-handoff');
    };

    const failOpen = () => {
      video.pause();
      playbackStarted = false;
      hero.classList.remove('is-video-frame-ready');
      hero.classList.add('is-video-poster-fallback');
      hero.classList.toggle('is-video-poster-unavailable', !posterAvailable);
      completeVideo();
      dockLogo(false);
    };

    const positionIntroClip = () => {
      if (clipPositioned) return true;
      if (!Number.isFinite(video.duration) || video.duration <= 0) return false;
      const startAt = Math.min(video.duration - .05, video.duration * startProgress);
      clipStartTime = Math.max(0, startAt);
      if (startAt > 0 && Math.abs(video.currentTime - startAt) > .025) {
        video.currentTime = startAt;
      }
      clipPositioned = true;
      return true;
    };

    const armFailOpen = () => {
      clearTimeout(failOpenTimer);
      const remaining = Number.isFinite(video.duration)
        ? Math.max(0, video.duration - Number(video.currentTime || 0))
        : 0;
      const expectedMs = remaining > 0 ? (remaining / playbackRate) * 1000 : 0;
      failOpenTimer = window.setTimeout(failOpen, Math.max(9000, expectedMs + 6000));
    };

    const waitForPreparedFrame = () => {
      if (video.error) return Promise.reject(video.error);
      if (!video.seeking && video.readyState >= 2) return Promise.resolve();

      return new Promise((resolve, reject) => {
        let settled = false;
        const events = ['loadeddata', 'canplay', 'seeked'];
        const cleanup = () => {
          clearTimeout(prepareFrameTimer);
          prepareFrameTimer = 0;
          events.forEach(eventName => video.removeEventListener(eventName, checkReady));
          video.removeEventListener('error', rejectPreparation);
        };
        const settle = callback => value => {
          if (settled) return;
          settled = true;
          cleanup();
          callback(value);
        };
        const resolvePreparation = settle(resolve);
        const rejectPreparation = settle(reject);
        const checkReady = () => {
          if (!video.seeking && video.readyState >= 2) resolvePreparation();
        };

        events.forEach(eventName => video.addEventListener(eventName, checkReady));
        video.addEventListener('error', rejectPreparation, { once: true });
        prepareFrameTimer = window.setTimeout(
          () => rejectPreparation(new Error('Intro frame preparation timed out.')),
          7000
        );
        checkReady();
      });
    };

    /* Mobile Browser degradieren preload="auto" haeufig zu "metadata" oder
       "none" (Datensparmodus, iOS Low Power). Dann feuert loadedmetadata nie,
       video.duration bleibt NaN und positionIntroClip() verweigert den Start.
       Deshalb wird auf mehrere Bereitschaftsereignisse gehoert und der Start
       hart per Wachhund abgesichert, damit im Zweifel der statische Hero
       erscheint statt eines haengenden Startbilds. Sobald der Ablauf wirklich
       anlaeuft, uebernehmen waitForPreparedFrame und armFailOpen die
       Absicherung, der Wachhund darf dann nicht mehr dazwischenfunken. */
    const startBereitEvents = ['loadedmetadata', 'loadeddata', 'canplay'];
    let startWachhund = 0;
    const stoppeStartUeberwachung = () => {
      clearTimeout(startWachhund);
      startWachhund = 0;
      startBereitEvents.forEach(name => video.removeEventListener(name, playIntroVideo));
    };

    const playIntroVideo = async () => {
      if (completed || playPending || !positionIntroClip()) return;
      playPending = true;
      stoppeStartUeberwachung();

      try {
        const hasPoster = await posterReady;
        if (!hasPoster) throw new Error('Intro poster could not be loaded.');
        await waitForPreparedFrame();
      } catch (_error) {
        playPending = false;
        failOpen();
        return;
      }

      if (completed) {
        playPending = false;
        return;
      }

      video.defaultPlaybackRate = playbackRate;
      video.playbackRate = playbackRate;
      let attempt;
      try {
        attempt = video.play();
      } catch (_error) {
        attempt = Promise.reject(_error);
      }
      armFailOpen();

      try {
        if (attempt?.then) await attempt;
        hero.classList.remove('is-video-autoplay-blocked');
        handlePlaybackStarted();
      } catch (fehler) {
        playbackStarted = false;
        /* Sicherheitsnetz hinter der Vorabpruefung: schlaegt die echte
           Wiedergabe trotzdem fehl, darf die Seite keinen Augenblick laenger
           gesperrt bleiben. NotAllowedError ist die Autoplay-Schranke, jeder
           andere Fehler ist ein Medienproblem und gehoert in den
           Poster-Rueckfall. */
        clearTimeout(failOpenTimer);
        if (fehler?.name === 'NotAllowedError') autoplaySperreAnzeigen('play-abgelehnt');
        else failOpen();
      } finally {
        playPending = false;
      }
    };

    const finishImmediately = () => {
      completed = true;
      logoRevealed = true;
      video.pause();
      playbackStarted = false;
      hero.classList.remove('is-video-frame-ready');
      hero.classList.remove('is-video-intro-playing', 'is-video-autoplay-blocked');
      hero.classList.add(
        'is-video-poster-fallback',
        'is-video-intro-static',
        'is-video-logo-visible',
        'is-video-intro-complete',
        'is-video-intro-docked'
      );
      logo?.classList.add('is-visible');
      nav?.classList.add('is-visible');
      dockStarted = true;
      completeHandoff();
    };

    /* ================================================================ *
     * Vorabpruefung, BEVOR die Seite gesperrt wird
     *
     * Der fruehere Ablauf sperrte zuerst und stellte erst danach fest, dass
     * Autoplay verboten ist. Auf iOS im Stromsparmodus (WebKit blockiert
     * dort auch stumme Videos - WebKit-Bug 168985, absichtlich als
     * "Won't Fix" geschlossen), in Firefox mit media.autoplay.default=1 und
     * in Chrome mit --autoplay-policy=user-gesture-required blieb dadurch
     * ein gesperrtes Startbild stehen.
     *
     * Drei Stufen, jede fuer sich belastbar:
     *  1. navigator.getAutoplayPolicy - synchron und nebenwirkungsfrei,
     *     derzeit nur Firefox. Fuer ein stummes Video sind "allowed" und
     *     "allowed-muted" gleichwertig gut, allein "disallowed" sperrt.
     *  2. Probelauf am echten Hero-Video. Die Autoplay-Schranke wird beim
     *     play()-Aufruf geprueft und lehnt sofort mit NotAllowedError ab,
     *     lange bevor Videodaten vorliegen. Genau diese Ablehnung wird
     *     ausgewertet; jeder andere Fehler (AbortError beim Abbrechen,
     *     NotSupportedError beim Dekodieren) gilt als unklar und darf das
     *     Intro nicht verhindern. Ein eigenes Test-Video per data:-URI
     *     waere ungenauer, weil es einen anderen Codec-Pfad nimmt und den
     *     Stromsparmodus damit nicht zuverlaessig abbildet.
     *  3. Faellt die echte Wiedergabe spaeter doch durch, entsperrt der
     *     catch-Zweig in playIntroVideo() die Seite unmittelbar.
     * ================================================================ */

    const autoplayRichtlinieLesen = () => {
      if (typeof navigator.getAutoplayPolicy !== 'function') return '';
      try {
        /* Die Elementform beruecksichtigt, dass dieses Video stumm ist. */
        return navigator.getAutoplayPolicy(video) || '';
      } catch (_fehler) {
        try {
          return navigator.getAutoplayPolicy('mediaelement') || '';
        } catch (_zweiterFehler) {
          return '';
        }
      }
    };

    const autoplayProbelauf = () => new Promise(resolve => {
      let entschieden = false;
      const antworten = ergebnis => {
        if (entschieden) return;
        entschieden = true;
        clearTimeout(probeFrist);
        resolve(ergebnis);
      };
      /* Eine Ablehnung kommt sofort. Bleibt die Zusage aus, fehlen nur noch
         Videodaten - das ist kein Autoplay-Problem und darf nicht warten. */
      const probeFrist = window.setTimeout(() => antworten('unklar'), 300);
      let versuch;
      try {
        versuch = video.play();
      } catch (fehler) {
        antworten(fehler?.name === 'NotAllowedError' ? 'verboten' : 'unklar');
        return;
      }
      if (!versuch?.then) {
        antworten('unklar');
        return;
      }
      versuch
        .then(() => antworten('erlaubt'))
        .catch(fehler => antworten(fehler?.name === 'NotAllowedError' ? 'verboten' : 'unklar'));
    });

    /* Sparmodi: ausschliesslich Signale ohne Berechtigungsdialog. */
    const verbindung = navigator.connection
      || navigator.mozConnection
      || navigator.webkitConnection
      || null;
    const langsameVerbindung = ['slow-2g', '2g'].includes(verbindung?.effectiveType || '');
    const datensparmodus = verbindung?.saveData === true;

    const akkuSchwach = () => new Promise(resolve => {
      if (typeof navigator.getBattery !== 'function') {
        resolve(false);
        return;
      }
      let entschieden = false;
      const antworten = ergebnis => {
        if (entschieden) return;
        entschieden = true;
        clearTimeout(akkuFrist);
        resolve(ergebnis);
      };
      const akkuFrist = window.setTimeout(() => antworten(false), 220);
      try {
        navigator.getBattery()
          .then(akku => antworten(
            akku?.charging === false && Number(akku.level) <= .2,
          ))
          .catch(() => antworten(false));
      } catch (_fehler) {
        antworten(false);
      }
    });

    /* Im Sparmodus wird der 1,6-MB-Clip nicht gebraucht. Die Quelle wird erst
       geloest, wenn das Poster nachweislich vorliegt - sonst blieb im Hero
       eine leere Videoflaeche zurueck. */
    const videoQuelleLoesen = () => {
      posterReady.then(vorhanden => {
        if (!vorhanden) return;
        video.pause();
        video.removeAttribute('src');
        [...video.querySelectorAll('source')].forEach(quelle => quelle.remove());
        video.preload = 'none';
        try {
          video.load();
        } catch (_fehler) {
          /* Ein leeres load() meldet einen Medienfehler; hier hoert niemand
             darauf, der statische Hero steht bereits. */
        }
      }).catch(() => {});
    };

    const videoHoerenStarten = () => {
      if (videoHoerenAktiv) return;
      videoHoerenAktiv = true;
      video.addEventListener('playing', handlePlaybackStarted);
      video.addEventListener('timeupdate', () => maybeRevealLogo(), { passive: true });
      video.addEventListener('ended', completeVideo, { once: true });
      video.addEventListener('error', failOpen, { once: true });
    };

    /* Sichtbarer Intro-Zustand, aber ohne Sperre. So gibt es waehrend der
       Vorabpruefung kein Aufblitzen des Endzustands und die Seite bleibt
       bedienbar, falls die Pruefung Autoplay verwirft. */
    const introBuehneVorbereiten = () => {
      scrollTo({ top: 0, left: 0, behavior: 'auto' });
      hero.classList.remove(
        'is-video-intro-static',
        'is-video-logo-visible',
        'is-video-intro-complete',
        'is-video-intro-docked',
        'is-logo-handoff-complete',
        'is-logo-impact-active',
        'is-logo-impact-complete'
      );
      hero.classList.add('is-video-intro-playing');
      logo?.classList.remove('is-visible');
      nav?.classList.remove('is-visible', 'is-logo-handoff', 'is-logo-handoff-complete');
    };

    const introAblaufStarten = () => {
      introBuehneVorbereiten();
      lockPage();
      videoHoerenStarten();

      startBereitEvents.forEach(name => video.addEventListener(name, playIntroVideo));
      startWachhund = window.setTimeout(() => {
        stoppeStartUeberwachung();
        if (!completed && !playbackStarted) failOpen();
      }, 5000);

      if (video.readyState >= 1) playIntroVideo();
      else if (video.readyState === 0) video.load();
    };

    /* Sparmodus oder Anker: statischer Hero, keine Sperre, kein Clip. */
    const introUeberspringen = (grund) => {
      hero.dataset.introSkipped = grund;
      stoppeStartUeberwachung();
      unlockPage();
      finishImmediately();
    };

    /* Autoplay ist nachweislich verboten: kein lockPage(), kein haengendes
       Startbild. Der statische Hero erscheint sofort, der Startknopf bleibt
       sichtbar und traegt die Nutzergeste nach. */
    const autoplaySperreAnzeigen = (grund) => {
      autoplayGesperrt = true;
      hero.dataset.introAutoplay = grund;
      stoppeStartUeberwachung();
      clearTimeout(failOpenTimer);
      clearTimeout(prepareFrameTimer);
      unlockPage();
      finishImmediately();
      /* finishImmediately() raeumt die Blockade-Klasse auf, deshalb wird sie
         erst danach gesetzt - sonst waere der Knopf unsichtbar. */
      if (startButton) hero.classList.add('is-video-autoplay-blocked');
      else if (!retryArmed) {
        retryArmed = true;
        addEventListener('pointerdown', introPerGesteStarten, { once: true, passive: true });
      }
    };

    /* Rueckweg aus dem statischen Zustand ins Intro. Der Flug-Host muss dazu
       exakt an seinen Heimatplatz zurueck, sonst hat dockLogo() keine
       Quellgeometrie mehr und der Handoff waere sofort fertig. */
    const introZuruecksetzen = () => {
      clearTimeout(dockTimer);
      clearTimeout(failOpenTimer);
      clearTimeout(prepareFrameTimer);
      clearTimeout(firstFrameTimer);
      clearTimeout(handoffWachhund);
      clearTimeout(settleWachhund);
      handoffWachhund = 0;
      settleWachhund = 0;
      if (firstFrameRaf) cancelAnimationFrame(firstFrameRaf);
      firstFrameRaf = 0;
      if (videoFrameCallback && video.cancelVideoFrameCallback) {
        video.cancelVideoFrameCallback(videoFrameCallback);
      }
      videoFrameCallback = 0;
      flightTimeline?.kill();
      impactTimeline?.kill();
      settleTween?.kill();
      flightTimeline = null;
      impactTimeline = null;
      settleTween = null;

      if (logoHost && logoHeimatEltern && logoHost.parentElement !== logoHeimatEltern) {
        logoHeimatEltern.insertBefore(logoHost, logoHeimatNachbar);
      }
      clearFlightStyles();
      logoHost?.classList.remove('is-logo-flight', 'is-nav-docked', 'is-nav-tone');
      if (window.gsap) {
        gsap.set(hero, { clearProps: 'height,minHeight,willChange' });
        if (logo) {
          gsap.set(logo, { clearProps: 'transform,transformOrigin,willChange,transition' });
        }
        if (heroShade) {
          gsap.set(heroShade, {
            clearProps: 'transform,transformOrigin,willChange,transition,opacity,visibility',
          });
        }
      }
      hero.classList.remove(
        'is-video-intro-static',
        'is-video-intro-complete',
        'is-video-intro-docked',
        'is-video-logo-visible',
        'is-logo-handoff-complete',
        'is-logo-flight-active',
        'is-logo-impact-active',
        'is-logo-impact-complete',
        'is-video-poster-fallback',
        'is-video-frame-ready',
        'is-video-autoplay-blocked'
      );
      hero.classList.add('is-video-frame-pending');
      logo?.classList.remove('is-visible');
      nav?.classList.remove('is-visible', 'is-logo-handoff', 'is-logo-handoff-complete');
      delete hero.dataset.introSkipped;

      completed = false;
      logoRevealed = false;
      dockStarted = false;
      handoffFertig = false;
      clipPositioned = false;
      playbackStarted = false;
      firstVideoFrameVisible = false;
      playPending = false;
      retryArmed = false;
      videoHoerenAktiv = false;
    };

    const introPerGesteStarten = () => {
      if (!autoplayGesperrt) {
        playIntroVideo();
        return;
      }
      autoplayGesperrt = false;
      introZuruecksetzen();
      introAblaufStarten();
    };

    startButton?.addEventListener('click', introPerGesteStarten);

    if (location.hash || reducedMotion || datensparmodus || langsameVerbindung) {
      introUeberspringen(
        location.hash ? 'anker'
          : reducedMotion ? 'reduzierte-bewegung'
            : datensparmodus ? 'datensparmodus' : 'langsame-verbindung'
      );
      videoQuelleLoesen();
      return;
    }

    const richtlinie = autoplayRichtlinieLesen();
    if (richtlinie === 'disallowed') {
      autoplaySperreAnzeigen('richtlinie-disallowed');
      return;
    }

    /* Buehne sofort, Sperre erst nach der Pruefung. Das Laden laeuft parallel,
       damit die Pruefung keine Ladezeit kostet. */
    introBuehneVorbereiten();
    if (video.readyState === 0) video.load();

    (async () => {
      if (await akkuSchwach()) {
        introUeberspringen('akku-schwach');
        videoQuelleLoesen();
        return;
      }

      const probe = await autoplayProbelauf();
      /* Der Probelauf startet notgedrungen bei Sekunde 0. Das Poster liegt
         darueber, sichtbar wird davon nichts; positionIntroClip() setzt den
         Startpunkt danach ohnehin neu. */
      video.pause();
      if (probe === 'verboten') {
        autoplaySperreAnzeigen('probelauf-verboten');
        return;
      }

      hero.dataset.introAutoplay = richtlinie || probe;
      introAblaufStarten();
    })();

    const resumeIntroVideo = () => {
      if (autoplayGesperrt || completed || document.hidden || !video.paused) return;
      playIntroVideo();
    };
    document.addEventListener('visibilitychange', resumeIntroVideo);

    addEventListener('pagehide', () => {
      stoppeStartUeberwachung();
      clearTimeout(handoffWachhund);
      clearTimeout(settleWachhund);
      document.removeEventListener('visibilitychange', resumeIntroVideo);
      startButton?.removeEventListener('click', introPerGesteStarten);
      video.removeEventListener('playing', handlePlaybackStarted);
      if (videoFrameCallback && video.cancelVideoFrameCallback) {
        video.cancelVideoFrameCallback(videoFrameCallback);
      }
      clearTimeout(dockTimer);
      clearTimeout(failOpenTimer);
      clearTimeout(prepareFrameTimer);
      clearTimeout(firstFrameTimer);
      if (firstFrameRaf) cancelAnimationFrame(firstFrameRaf);
      impactTimeline?.kill();
      flightTimeline?.kill();
      settleTween?.kill();
      unlockPage();
    }, { once: true });
    return;
  }

  const usesInertialScrollVideo = ['theme-1', 'theme-3', 'theme-5'].some(theme => document.body.classList.contains(theme));

  if (usesInertialScrollVideo && video && window.RailTimeScrollVideo?.createScrollScrub) {
    let touchY = 0;
    let finished = false;
    let finishTimer = 0;

    hero.classList.add('is-video-ready', 'is-scroll-scrub');
    hero.style.setProperty('--rt-video-progress', '0');
    video.removeAttribute('autoplay');
    video.removeAttribute('loop');
    video.muted = true;
    video.playsInline = true;
    video.preload = 'auto';
    video.pause();
    video.load();
    scrollTo({ top: 0, left: 0, behavior: 'auto' });
    document.documentElement.classList.add('rt-intro-playing');
    document.body.classList.add('rt-intro-playing');

    const renderProgress = progress => {
      hero.style.setProperty('--rt-video-progress', progress.toFixed(4));
      hero.classList.toggle('is-video-scroll-engaged', progress > .04);
      hero.classList.toggle('is-video-logo-visible', progress >= .62);
      logo?.classList.toggle('is-visible', progress >= .62);
      hero.classList.toggle('is-video-near-end', progress >= .86);
    };

    const removeInput = () => {
      removeEventListener('wheel', onWheel);
      removeEventListener('touchstart', onTouchStart);
      removeEventListener('touchmove', onTouchMove);
      removeEventListener('keydown', onKeyDown);
      removeEventListener('railtime:preview-scroll', onPreviewScroll);
      removeEventListener('railtime:preview-sync', onPreviewSync);
    };

    const unlock = () => {
      document.body.classList.remove('rt-intro-playing');
      document.documentElement.classList.remove('rt-intro-playing');
      hero.classList.remove('is-video-finishing');
      hero.classList.add('is-video-complete');
      nav?.classList.add('is-visible');
      dispatchEvent(new Event('resize'));
    };

    const finish = () => {
      if (finished) return;
      finished = true;
      removeInput();
      hero.style.setProperty('--rt-video-progress', '1');
      hero.classList.remove('is-video-ready');
      hero.classList.add('is-video-scroll-engaged', 'is-video-logo-visible', 'is-video-finishing');
      logo?.classList.add('is-visible');
      copy?.classList.remove('is-visible', 'is-interactive');
      finishTimer = window.setTimeout(unlock, 1160);
    };

    const scrubber = window.RailTimeScrollVideo.createScrollScrub(video, {
      scrollDistance: 4200,
      minPlaybackRate: .65,
      maxPlaybackRate: 1,
      mediaStartProgress: introClipStart,
      speedMultiplier: introSpeedMultiplier,
      maxLeadSeconds: .55,
      idleGraceMs: 140,
      coastSeconds: .22,
      rateSmoothingMs: 120,
      eventCap: 600,
      onProgress: renderProgress,
      onComplete: finish
    });

    function onWheel(event) {
      if (finished) return;
      if (event.cancelable) event.preventDefault();
      const modeFactor = event.deltaMode === 1 ? 16 : event.deltaMode === 2 ? innerHeight : 1;
      scrubber.addDelta(event.deltaY * modeFactor);
    }
    function onTouchStart(event) { touchY = event.touches[0]?.clientY || 0; }
    function onTouchMove(event) {
      if (finished) return;
      const nextY = event.touches[0]?.clientY || touchY;
      if (event.cancelable) event.preventDefault();
      scrubber.addDelta((touchY - nextY) * 2.1);
      touchY = nextY;
    }
    function onKeyDown(event) {
      if (finished) return;
      const deltas = { ArrowDown: 120, PageDown: 520, ' ': 420, ArrowUp: -120, PageUp: -520 };
      if (event.key === 'End' || event.key === 'Home') {
        if (event.cancelable) event.preventDefault();
        scrubber.setProgress(event.key === 'End' ? 1 : 0);
        return;
      }
      if (!(event.key in deltas)) return;
      if (event.cancelable) event.preventDefault();
      scrubber.addDelta(deltas[event.key]);
    }
    function onPreviewScroll(event) {
      if (finished) return;
      const delta = Number(event.detail?.deltaY || 0);
      if (Number.isFinite(delta) && delta) scrubber.addDelta(delta);
    }
    function onPreviewSync() {
      if (finished) return;
      scrubber.jumpTo(0);
      renderProgress(0);
    }

    addEventListener('wheel', onWheel, { passive: false });
    addEventListener('touchstart', onTouchStart, { passive: true });
    addEventListener('touchmove', onTouchMove, { passive: false });
    addEventListener('keydown', onKeyDown);
    addEventListener('railtime:preview-scroll', onPreviewScroll);
    addEventListener('railtime:preview-sync', onPreviewSync);

    if (location.hash || matchMedia('(prefers-reduced-motion: reduce)').matches) {
      finished = true;
      removeInput();
      scrubber.jumpTo(1);
      hero.style.setProperty('--rt-video-progress', '1');
      hero.classList.remove('is-video-ready', 'is-video-finishing');
      hero.classList.add('is-video-scroll-engaged', 'is-video-complete', 'is-video-logo-visible');
      logo?.classList.add('is-visible');
      copy?.classList.remove('is-visible', 'is-interactive');
      nav?.classList.add('is-visible');
      document.body.classList.remove('rt-intro-playing');
      document.documentElement.classList.remove('rt-intro-playing');
      dispatchEvent(new Event('resize'));
      if (location.hash) setTimeout(restoreAnchor, 80);
    }

    addEventListener('pagehide', event => {
      if (event.persisted) return;
      clearTimeout(finishTimer);
      removeInput();
      scrubber.destroy();
    });
    return;
  }

  if (usesInertialScrollVideo && video && window.RailTimeScrollVideo?.createOneShot) {
    let started = false;
    let attempting = false;
    let finished = false;
    let collapseTimer = 0;
    let touchStartY = 0;

    hero.classList.add('is-video-ready');
    hero.style.setProperty('--rt-video-progress', '0');
    video.removeAttribute('autoplay');
    video.removeAttribute('loop');
    video.muted = true;
    video.playsInline = true;
    video.preload = 'metadata';
    video.pause();
    video.load();

    const blockedKeys = ['ArrowDown', 'ArrowUp', 'PageDown', 'PageUp', ' ', 'Home', 'End'];
    const preventPageTraversal = event => {
      if (event.cancelable) event.preventDefault();
    };
    const preventTraversalKey = event => {
      if (blockedKeys.includes(event.key) && event.cancelable) event.preventDefault();
    };
    const lockPage = () => {
      document.documentElement.classList.add('rt-intro-playing');
      document.body.classList.add('rt-intro-playing');
      addEventListener('wheel', preventPageTraversal, { passive: false });
      addEventListener('touchmove', preventPageTraversal, { passive: false });
      addEventListener('keydown', preventTraversalKey);
    };
    const unlockPage = () => {
      document.body.classList.remove('rt-intro-playing');
      document.documentElement.classList.remove('rt-intro-playing');
      removeEventListener('wheel', preventPageTraversal);
      removeEventListener('touchmove', preventPageTraversal);
      removeEventListener('keydown', preventTraversalKey);
    };

    const finishIntro = (immediate = false) => {
      if (finished) return;
      finished = true;
      attempting = false;
      hero.style.setProperty('--rt-video-progress', '1');
      hero.classList.add('is-video-logo-visible');
      logo?.classList.add('is-visible');
      copy?.classList.remove('is-visible', 'is-interactive');
      nav?.classList.add('is-visible');

      if (immediate) {
        hero.classList.remove('is-video-playing', 'is-video-finishing');
        hero.classList.add('is-video-complete');
        unlockPage();
        dispatchEvent(new Event('resize'));
        return;
      }

      hero.classList.remove('is-video-playing');
      hero.classList.add('is-video-finishing');
      collapseTimer = window.setTimeout(() => {
        hero.classList.remove('is-video-finishing');
        hero.classList.add('is-video-complete');
        unlockPage();
        scrollTo({ top: 0, left: 0, behavior: 'auto' });
        dispatchEvent(new Event('resize'));
      }, 1150);
    };

    const player = window.RailTimeScrollVideo.createOneShot(video, {
      playbackRate: introSpeedMultiplier,
      mediaStartProgress: introClipStart,
      onProgress: progress => {
        hero.style.setProperty('--rt-video-progress', progress.toFixed(4));
        if (progress >= .58) {
          hero.classList.add('is-video-logo-visible');
          logo?.classList.add('is-visible');
        }
        if (progress >= .82) hero.classList.add('is-video-near-end');
      },
      onComplete: () => finishIntro(false)
    });

    const removeStartListeners = () => {
      removeEventListener('wheel', onWheel);
      removeEventListener('touchstart', onTouchStart);
      removeEventListener('touchmove', onTouchMove);
      removeEventListener('keydown', onKeyDown);
      removeEventListener('scroll', onScroll);
    };

    const startIntro = async () => {
      if (started || attempting || finished) return;
      if (matchMedia('(prefers-reduced-motion: reduce)').matches) {
        removeStartListeners();
        finishIntro(true);
        return;
      }
      attempting = true;
      scrollTo({ top: 0, left: 0, behavior: 'auto' });
      lockPage();
      hero.classList.remove('is-video-ready');
      hero.classList.add('is-video-playing');
      const playing = await player.start();
      if (!playing) {
        attempting = false;
        hero.classList.remove('is-video-playing');
        hero.classList.add('is-video-ready');
        unlockPage();
        return;
      }
      started = true;
      attempting = false;
      removeStartListeners();
    };

    const onWheel = event => {
      if (event.deltaY > 8) startIntro();
    };
    const onTouchStart = event => {
      touchStartY = event.touches[0]?.clientY || 0;
    };
    const onTouchMove = event => {
      const currentY = event.touches[0]?.clientY || touchStartY;
      if (touchStartY - currentY > 10) startIntro();
    };
    const onKeyDown = event => {
      if (['ArrowDown', 'PageDown', ' ', 'End'].includes(event.key)) startIntro();
    };
    const onScroll = () => {
      if (scrollY > 12) startIntro();
    };

    addEventListener('wheel', onWheel, { passive: true });
    addEventListener('touchstart', onTouchStart, { passive: true });
    addEventListener('touchmove', onTouchMove, { passive: true });
    addEventListener('keydown', onKeyDown);
    addEventListener('scroll', onScroll, { passive: true });

    if (location.hash) {
      removeStartListeners();
      finishIntro(true);
      setTimeout(restoreAnchor, 80);
    }

    addEventListener('pagehide', () => {
      clearTimeout(collapseTimer);
      player.destroy();
    }, { once: true });
    return;
  }

  let revealed = false;
  const reveal = () => {
    if (revealed) return;
    revealed = true;
    logo?.classList.add('is-visible');
    setTimeout(() => {
      logo?.classList.add('is-docked');
      copy?.classList.add('is-visible', 'is-interactive');
    }, 850);
    setTimeout(() => target?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 3000);
  };
  video?.addEventListener('ended', reveal, { once: true });
  setTimeout(reveal, 7200);
  const sync = () => nav?.classList.toggle('is-visible', scrollY > innerHeight * .28);
  addEventListener('scroll', sync, { passive: true });
  sync();
  setTimeout(restoreAnchor, 320);
});
