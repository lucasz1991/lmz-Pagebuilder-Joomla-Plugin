/**
 * Scroll-Gestaltung auf GSAP - Ebene ueber RailTimeMotion.
 *
 * scroll-motion.js uebersetzt die Einblendungen der .sa-motion-* / .ig-motion-*
 * Klassen nach ScrollTrigger und verwaltet den Sichtbarkeits-Vorhang. Diese
 * Datei ergaenzt nur zusaetzliche Effekte und fasst weder den Vorhang noch
 * window.RailTimeMotion an.
 *
 * Regel fuer alles hier: Niemals dieselbe Eigenschaft desselben Elements
 * animieren, das schon eine .sa-motion-* Klasse traegt. Sonst schreiben zwei
 * Tweens gegeneinander. Deshalb greifen die Effekte unten grundsaetzlich auf
 * innere Elemente (Bild, Linie, Siegel) statt auf die Container.
 */
(() => {
  'use strict';

  const body = document.body;
  const istHome = body.classList.contains('is-home');
  const sparsam = matchMedia('(prefers-reduced-motion: reduce)').matches;

  if (!window.gsap || !window.ScrollTrigger || sparsam) return;

  gsap.registerPlugin(ScrollTrigger);
  if (window.ScrollToPlugin) gsap.registerPlugin(ScrollToPlugin);
  gsap.config({ nullTargetWarn: false });

  const AUS = 'power3.out';
  const alle = (auswahl, wurzel = document) => Array.from(wurzel.querySelectorAll(auswahl));

  /* Jedes Ziel, das hier mit opacity 0 vorbereitet wird, wird mitgeschrieben.
     Steht der Bildtakt still, feuert kein ScrollTrigger und diese Elemente
     blieben dauerhaft unsichtbar - beim Fuss betraf das jede Seite, weil seine
     Spalten vor dem Erreichen des Triggers auf opacity 0 stehen. */
  const versteckteZiele = new Set();
  const merken = (ziele) => {
    (Array.isArray(ziele) ? ziele : [ziele]).forEach((ziel) => {
      if (ziel) versteckteZiele.add(ziel);
    });
  };
  const endzustandHerstellen = () => {
    const ziele = [...versteckteZiele];
    if (!ziele.length) return;
    gsap.set(ziele, {
      clearProps: 'transform,translate,rotate,scale,opacity,visibility,willChange',
    });
  };

  /* ------------------------------------------------------------------ *
   * Wiederverwendbare Bausteine
   * ------------------------------------------------------------------ */

  /** Ebene laeuft langsamer als der Text davor. */
  const parallaxe = (element, weite, ausloeser) => {
    if (!element) return;
    gsap.fromTo(element,
      { yPercent: -weite / 2 },
      {
        yPercent: weite / 2,
        ease: 'none',
        scrollTrigger: {
          trigger: ausloeser || element.closest('section') || element.parentElement,
          start: 'top bottom',
          end: 'bottom top',
          scrub: .6,
          invalidateOnRefresh: true,
        },
      });
  };

  /** Bild faehrt beim Durchscrollen sachte aus der Vergroesserung heraus. */
  const bildBeruhigen = (bild, von = 1.14) => {
    if (!bild) return;
    gsap.fromTo(bild,
      { scale: von },
      {
        scale: 1,
        ease: 'none',
        scrollTrigger: {
          trigger: bild.closest('figure') || bild.parentElement || bild,
          start: 'top bottom',
          end: 'bottom top',
          scrub: .8,
        },
      });
  };

  /** Trennlinie waechst aus ihrer linken Kante. */
  const linieZiehen = (linie, ausloeser) => {
    if (!linie) return;
    const breite = linie.getBoundingClientRect().width;
    if (breite < 4) return;                       // reine Abstandshalter auslassen
    gsap.fromTo(linie,
      { scaleX: 0, transformOrigin: 'left center' },
      {
        scaleX: 1,
        duration: .9,
        ease: AUS,
        scrollTrigger: { trigger: ausloeser || linie, start: 'top 90%', once: true },
      });
  };

  /** Zahl laeuft hoch - nur wo tatsaechlich eine Zahl steht. */
  const hochzaehlen = element => {
    const treffer = element.textContent.trim().match(/^(\d+)(\D*)$/);
    if (!treffer) return;                         // "24/7" und "DE" bleiben unveraendert

    const ziel = Number(treffer[1]);
    const anhang = treffer[2];
    const zaehler = { wert: 0 };

    ScrollTrigger.create({
      trigger: element,
      start: 'top 88%',
      once: true,
      onEnter: () => gsap.to(zaehler, {
        wert: ziel,
        duration: 1.4,
        ease: 'power2.out',
        onUpdate: () => { element.textContent = Math.round(zaehler.wert) + anhang; },
      }),
    });
  };

  /** Ueberschrift faehrt zeilenweise aus ihrer Maske. */
  const zeilenAufloesen = element => {
    if (!window.SplitText || !element || element.dataset.rtSplit) return;

    let geteilt;
    try {
      geteilt = new SplitText(element, { type: 'lines', linesClass: 'rt-split-line' });
    } catch (fehler) {
      return;                                     // ohne Aufteilung bleibt die Ueberschrift normal sichtbar
    }
    if (!geteilt.lines || !geteilt.lines.length) return;

    element.dataset.rtSplit = '1';
    element.classList.add('rt-split-host');
    gsap.set(geteilt.lines, { yPercent: 115, opacity: 0 });
    merken(geteilt.lines);

    ScrollTrigger.create({
      trigger: element,
      start: 'top 90%',
      once: true,
      onEnter: () => gsap.to(geteilt.lines, {
        yPercent: 0,
        opacity: 1,
        duration: 1,
        ease: 'power4.out',
        stagger: .085,
      }),
    });
  };

  /* ------------------------------------------------------------------ *
   * Startseite
   * ------------------------------------------------------------------ */

  const startseite = () => {
    const storyOwner = body.classList.contains('rt-home-story-enabled');

    // Das Laufband liegt jetzt in rt-marquee.js: dort laeuft es endlos und
    // nimmt die Scrollrichtung ueber timeScale auf. Eine zweite
    // Transformation auf derselben Spur wuerde damit kollidieren.

    // Leistungszeilen: Die Kachel selbst blendet scroll-motion.js ein
    // (sie traegt sa-motion-*). Hier bewegt sich nur das Bild darin.
    if (!storyOwner) {
      alle('.sa-service figure img').forEach(bild => bildBeruhigen(bild, 1.14));
    }

    // Pfeile ruecken beim Erscheinen kurz nach
    const pfeile = storyOwner ? [] : alle('.sa-service .rt-action-arrow');
    if (pfeile.length) {
      merken(pfeile);
      gsap.fromTo(pfeile,
        { x: -8, opacity: .35 },
        {
          x: 0, opacity: 1, duration: .7, ease: AUS, stagger: .07,
          scrollTrigger: { trigger: '.sa-services__grid', start: 'top 76%', once: true },
        });
    }

    // Die Deutschlandkarte gehoert rt-map-sequence.js.
    //
    // Hier lag frueher eine eigene Animation fuer Nadeln und Bundeslaender.
    // Sie lief gegen die dortige gepinnte Sequenz - zwei Systeme schrieben
    // dieselben Eigenschaften, mit dem Ergebnis falsch stehender oder
    // unsichtbarer Nadeln. Die Karte hat genau einen Besitzer; hier bleibt
    // sie unangetastet.

    // Siegel im Teambereich setzt sich mit leichtem Schwung
    const siegel = storyOwner ? null : document.querySelector('.sa-team__seal');
    if (siegel) {
      merken(siegel);
      gsap.fromTo(siegel,
        { scale: .74, rotate: -7, opacity: 0 },
        {
          scale: 1, rotate: 0, opacity: 1, duration: 1, ease: 'back.out(1.5)',
          scrollTrigger: { trigger: siegel, start: 'top 88%', once: true },
        });
    }

    // Orbitringe um das Logo drehen sich beim Verlassen des Heros
    alle('.rt-logo-orbit').forEach((ring, i) => {
      gsap.to(ring, {
        rotate: i % 2 ? -130 : 130,
        ease: 'none',
        scrollTrigger: { trigger: '.sa-hero', start: 'top top', end: 'bottom top', scrub: 1 },
      });
    });

    // Ruhige Tiefenwirkung
    if (!storyOwner) parallaxe(document.querySelector('.sa-team__visual img'), 12);
    parallaxe(document.querySelector('.sa-hero__shade'), 8);
    bildBeruhigen(document.querySelector('.sa-intro__image img'), 1.1);

    // Linien in Rubriken und Prozessschritten
    alle('.sa-eyebrow > span')
      .filter(linie => !linie.closest('[data-rt-motion-owner="home-story"]'))
      .forEach(l => linieZiehen(l, l.closest('.sa-section-head') || l.parentElement));
    alle('.sa-process__steps article > span:not(.rt-process-icon)')
      .forEach(l => linieZiehen(l, l.parentElement));

    // Ueberschriften und Kennzahlen
    alle('.sa-section-head h2:not(.rt-process-header h2)')
      .filter(titel => !titel.closest('[data-rt-motion-owner="home-story"]'))
      .forEach(zeilenAufloesen);
    alle('.sa-intro__facts strong, .sa-team__seal strong')
      .filter(zahl => !zahl.closest('[data-rt-motion-owner="home-story"]'))
      .forEach(hochzaehlen);
  };

  /* ------------------------------------------------------------------ *
   * Unterseiten
   * ------------------------------------------------------------------ */

  const unterseite = () => {
    const kacheln = alle('.ig-panel');
    if (kacheln.length) {
      merken(kacheln);
      gsap.fromTo(kacheln,
        { opacity: 0, y: 40 },
        {
          opacity: 1, y: 0, duration: .85, ease: AUS, stagger: .08,
          scrollTrigger: { trigger: kacheln[0], start: 'top 88%', once: true },
        });
    }

    alle('.ig-legal-hero h1, .ig-subpage > section h2').forEach(zeilenAufloesen);
  };

  /* ------------------------------------------------------------------ *
   * Navigationsleiste und Fusszeile - auf allen Seiten
   * ------------------------------------------------------------------ */

  const rahmen = () => {
    const nav = document.querySelector('.rt-nav');
    if (nav) {
      ScrollTrigger.create({
        start: 'top -120',
        end: 99999,
        onUpdate: selbst => {
          // Waehrend des Intros ist die Seite gesperrt - Finger weg.
          if (body.classList.contains('rt-intro-playing')) return;
          const runter = selbst.direction === 1;
          nav.classList.toggle('is-tucked', runter && selbst.scroll() > 260);
          nav.classList.toggle('is-condensed', selbst.scroll() > 120);
        },
      });
    }

    const fuss = document.querySelector('.rt-footer');
    if (!fuss) return;

    const saeulen = alle(':scope > div, :scope > small', fuss);
    if (!saeulen.length) return;
    merken(saeulen);
    gsap.fromTo(saeulen,
      { opacity: 0, y: 34 },
      {
        opacity: 1, y: 0, duration: .85, ease: AUS, stagger: .09,
        scrollTrigger: { trigger: fuss, start: 'top 94%', once: true },
      });
  };

  /* ------------------------------------------------------------------ */

  const starten = () => {
    try {
      rahmen();
      if (istHome) startseite();
      else unterseite();
      ScrollTrigger.refresh();
      window.RailTimeStillstand?.(endzustandHerstellen);
    } catch (fehler) {
      // Ein Fehler hier darf die Seite nie verschlucken. Der Vorhang haengt
      // an scroll-motion.js und bleibt davon unberuehrt.
      console.error('[rt-scroll-design]', fehler);
    }
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', starten, { once: true });
  } else {
    starten();
  }

  // Nach dem Intro stimmen die Messpunkte nicht mehr: Der Hero schrumpft
  // von 100svh auf das Kopfband und verschiebt alles darunter.
  addEventListener('load', () => ScrollTrigger.refresh(), { once: true });
})();
