<?php

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Uri\Uri;

$app = Factory::getApplication();
$language = $app->getLanguage();
$language->load('tpl_lmz_builder', __DIR__);
$assetBase = rtrim(Uri::root(true), '/') . '/templates/lmz_builder/l3';
$imageBase = rtrim(Uri::root(true), '/') . '/images/l3';
$offlineMessage = (string) $app->get('offline_message', '');
if ((int) $app->get('display_offline_message', 1) === 2 || trim($offlineMessage) === '') {
    $offlineMessage = Text::_('JOFFLINE_MESSAGE');
}
?>
<!doctype html>
<html lang="<?php echo htmlspecialchars($this->language, ENT_QUOTES, 'UTF-8'); ?>" dir="<?php echo htmlspecialchars($this->direction, ENT_QUOTES, 'UTF-8'); ?>">
<head>
    <jdoc:include type="metas" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/svg+xml" href="<?php echo $imageBase; ?>/logo/rt-logo.svg">
    <link rel="stylesheet" href="<?php echo $assetBase; ?>/css/system-pages.css?v=1">
    <jdoc:include type="styles" />
    <jdoc:include type="scripts" />
</head>
<body class="rt-system-page">
    <main class="rt-system-card">
        <div class="rt-system-brand">
            <img src="<?php echo $imageBase; ?>/logo/rt-logo.svg" alt="">
            <span>RT Rail Time GmbH</span>
        </div>
        <p class="rt-system-eyebrow"><?php echo htmlspecialchars(Text::_('JOFFLINE'), ENT_QUOTES, 'UTF-8'); ?></p>
        <h1><?php echo htmlspecialchars((string) $app->get('sitename'), ENT_QUOTES, 'UTF-8'); ?></h1>
        <p><?php echo strip_tags($offlineMessage, '<br><strong><em><a>'); ?></p>
        <jdoc:include type="message" />
        <form class="rt-system-form" action="<?php echo Route::_('index.php', true); ?>" method="post" id="form-login">
            <label for="username"><?php echo Text::_('JGLOBAL_USERNAME'); ?></label>
            <input name="username" id="username" type="text" autocomplete="username" required>
            <label for="password"><?php echo Text::_('JGLOBAL_PASSWORD'); ?></label>
            <input name="password" id="password" type="password" autocomplete="current-password" required>
            <button class="rt-system-button" type="submit" name="Submit"><?php echo Text::_('JLOGIN'); ?></button>
            <input type="hidden" name="option" value="com_users">
            <input type="hidden" name="task" value="user.login">
            <input type="hidden" name="return" value="<?php echo base64_encode(Uri::base()); ?>">
            <?php echo HTMLHelper::_('form.token'); ?>
        </form>
    </main>
</body>
</html>
