<?php

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Filesystem\File;
use Joomla\CMS\Filesystem\Folder;
use Joomla\Database\DatabaseInterface;

final class tpl_lmz_builderInstallerScript
{
    private ?string $installedVersion = null;

    public function preflight($type, $parent): bool
    {
        if (version_compare(PHP_VERSION, '8.1.0', '<')) {
            throw new RuntimeException('LMZ RailTime template requires PHP 8.1 or newer.');
        }

        if (!defined('JVERSION') || version_compare(JVERSION, '5.4.0', '<') || version_compare(JVERSION, '5.5.0', '>=')) {
            throw new RuntimeException('LMZ RailTime template supports Joomla 5.4.x.');
        }

        if ($type === 'update') {
            try {
                $db = Factory::getContainer()->get(DatabaseInterface::class);
                $query = $db->getQuery(true)
                    ->select($db->quoteName('manifest_cache'))
                    ->from($db->quoteName('#__extensions'))
                    ->where($db->quoteName('type') . ' = ' . $db->quote('template'))
                    ->where($db->quoteName('element') . ' = ' . $db->quote('lmz_builder'))
                    ->where($db->quoteName('client_id') . ' = 0');
                $manifest = json_decode((string) $db->setQuery($query, 0, 1)->loadResult(), true);
                $this->installedVersion = is_array($manifest) && isset($manifest['version'])
                    ? (string) $manifest['version']
                    : null;
            } catch (Throwable $error) {
                $this->installedVersion = null;
            }
        }

        return true;
    }

    public function postflight($type, $parent): bool
    {
        if (!in_array($type, ['install', 'update'], true)) {
            return true;
        }

        $runLegacyCutover = $type === 'install'
            || ($this->installedVersion !== null && version_compare($this->installedVersion, '5.2.2', '<'));

        if ($runLegacyCutover) {
            $this->removeLegacyTemplateFiles();
            $this->cleanLegacyStyleParameters(
                Factory::getContainer()->get(DatabaseInterface::class)
            );
        }

        return true;
    }

    /**
     * Joomla upgrades do not remove paths that disappeared from a manifest.
     * Delete only explicit children of this template which belonged to Helix,
     * old Joomla overrides, or the former third-party page builder.
     */
    private function removeLegacyTemplateFiles(): void
    {
        $templateRoot = JPATH_ROOT . '/templates/lmz_builder';

        foreach (['css', 'features', 'fonts', 'headers', 'html', 'images', 'js', 'scss', 'webfonts'] as $directory) {
            $path = $templateRoot . '/' . $directory;

            if (is_dir($path) && !Folder::delete($path)) {
                throw new RuntimeException('Could not remove legacy template directory: ' . $directory);
            }
        }

        foreach (['comingsoon.php', 'helper.php', 'options.json', 'options.xml'] as $file) {
            $path = $templateRoot . '/' . $file;

            if (is_file($path) && !File::delete($path)) {
                throw new RuntimeException('Could not remove legacy template file: ' . $file);
            }
        }

        $legacyLanguageFile = JPATH_ROOT . '/language/en-GB/en-GB.tpl_lmz_builder.ini';
        if (is_file($legacyLanguageFile) && !File::delete($legacyLanguageFile)) {
            throw new RuntimeException('Could not remove the legacy Helix template language file.');
        }
    }

    private function cleanLegacyStyleParameters(DatabaseInterface $db): void
    {
        // The native template has no style options. Clear only the unmistakable
        // Helix payload; future compact native parameters remain untouched.
        $query = $db->getQuery(true)
            ->update($db->quoteName('#__template_styles'))
            ->set($db->quoteName('params') . ' = ' . $db->quote('{}'))
            ->where($db->quoteName('template') . ' = ' . $db->quote('lmz_builder'))
            ->where($db->quoteName('client_id') . ' = 0')
            ->where('LENGTH(' . $db->quoteName('params') . ') > 2048');
        $db->setQuery($query)->execute();
    }
}
