<?php
/**
 * RailTime Signal Atlas template shell.
 *
 * Native RailTime shell for LMZ Page Builder pages.
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Language\LanguageHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Uri\Uri;
use Joomla\Component\Menus\Administrator\Helper\MenusHelper;
use Joomla\Database\DatabaseInterface;
use Joomla\Registry\Registry;
use LMZ\Component\Lmzpagebuilder\Site\Service\ContentRenderer;
use LMZ\Component\Lmzpagebuilder\Site\Service\TemplateSettingsService;

$app = Factory::getApplication();
$this->setHtml5(true);

$language = $app->getLanguage();
$language->load('tpl_lmz_builder', __DIR__);
$sprachTag = $language->getTag();
$veroeffentlichteSprachen = LanguageHelper::getLanguages('lang_code');
$aktiveSprache = $veroeffentlichteSprachen[$sprachTag] ?? null;
$sprachSef = $aktiveSprache && !empty($aktiveSprache->sef)
    ? (string) $aktiveSprache->sef
    : strtolower(substr($sprachTag, 0, 2));
$active = $app->getMenu()->getActive();
$root = rtrim(Uri::root(true), '/');
$assetBase = $root . '/templates/lmz_builder/l3';
$imageBase = $root . '/images/l3';

/* Die LMZ Template Settings sind eine fehlertolerante Projektion. Solange
   das Update noch nicht installiert oder ein Datensatz ungültig ist, bleiben
   alle bisherigen RailTime-Werte unverändert aktiv. */
$templateSettings = [
    'contact_id' => 0,
    'logos' => [
        'favicon' => '/images/l3/logo/rt-logo.svg',
        'mark' => '/images/l3/logo/rt-logo.svg',
        'navigation_wordmark' => '/images/l3/logo-txt-darkbg.png',
        'footer_wordmark' => '/images/l3/logo-txt-darkbg.png',
        'alt_text' => 'RT Rail Time GmbH',
    ],
    'navigation' => [
        'menu_type' => 'mainmenu',
        'hotline' => '04171 546803',
        'hotline_visible' => true,
        'background' => '#090c11',
        'text' => '#ffffff',
        'accent' => '#e4002b',
        'builder_enabled' => false,
    ],
    'footer' => [
        'company' => 'RT Rail Time GmbH',
        'email' => 'info@rail-time.de',
        'address' => "Borsteler Weg 29–31\n21423 Winsen (Luhe)",
        'background' => '#090c11',
        'text' => '#ffffff',
        'accent' => '#e4002b',
        'builder_enabled' => false,
    ],
];
if (class_exists(TemplateSettingsService::class)) {
    try {
        $templateDatabase = Factory::getContainer()->get(DatabaseInterface::class);
        $templateSettings = (new TemplateSettingsService($templateDatabase))->load();
    } catch (\Throwable $templateSettingsError) {
        // Der bisherige Template-Shell bleibt der sichere öffentliche Fallback.
    }
}

$templateAssetUrl = static function (string $url) use ($root): string {
    return preg_match('~^https?://~i', $url)
        ? $url
        : $root . '/' . ltrim($url, '/');
};
$templateLogos = $templateSettings['logos'];
$templateNavigation = $templateSettings['navigation'];
$templateFooter = $templateSettings['footer'];
$faviconUrl = $templateAssetUrl((string) $templateLogos['favicon']);
$faviconPath = strtolower((string) parse_url($faviconUrl, PHP_URL_PATH));
$faviconType = match (true) {
    str_ends_with($faviconPath, '.svg') => 'image/svg+xml',
    str_ends_with($faviconPath, '.png') => 'image/png',
    str_ends_with($faviconPath, '.webp') => 'image/webp',
    str_ends_with($faviconPath, '.ico') => 'image/x-icon',
    default => '',
};
$logoMarkUrl = $templateAssetUrl((string) $templateLogos['mark']);
$navigationWordmarkUrl = $templateAssetUrl((string) $templateLogos['navigation_wordmark']);
$footerWordmarkUrl = $templateAssetUrl((string) $templateLogos['footer_wordmark']);
$brandAlt = (string) $templateLogos['alt_text'];

/* --------------------------------------------------------------------- *
 * Seite, Sprache und Navigation
 * --------------------------------------------------------------------- */

$linkParameter = static function (?string $link, string $name): string {
    if (!$link) {
        return '';
    }

    $query = parse_url(html_entity_decode($link, ENT_QUOTES | ENT_HTML5, 'UTF-8'), PHP_URL_QUERY);
    if (!is_string($query)) {
        return '';
    }

    parse_str($query, $parameter);

    return isset($parameter[$name]) && is_scalar($parameter[$name]) ? (string) $parameter[$name] : '';
};

$aliasSeiten = [
    'home' => 'home', 'home-en' => 'home', 'start' => 'home',
    'ueber-uns' => 'about', 'about-us' => 'about', 'o-nas' => 'about',
    'leistungen' => 'services', 'services' => 'services', 'uslugi' => 'services',
    'kontakt' => 'contact', 'contact' => 'contact',
    'karriere' => 'careers', 'careers' => 'careers', 'kariera' => 'careers',
    'impressum' => 'imprint', 'legal-notice' => 'imprint', 'informacje-prawne' => 'imprint',
    'datenschutzerklaerung' => 'privacy', 'privacy' => 'privacy', 'polityka-prywatnosci' => 'privacy',
];
$activeLink = $active ? (string) $active->link : '';
$activeAlias = $active && isset($active->alias) ? (string) $active->alias : '';
$pageKey = $linkParameter($activeLink, 'page') ?: $app->input->getCmd('page');
$pageKey = $pageKey ?: ($aliasSeiten[$activeAlias] ?? '');
if ($pageKey === '' && $active && !empty($active->home)) {
    $pageKey = 'home';
}

$isHome = ($active && !empty($active->home)) || $pageKey === 'home';
$isAbout = $pageKey === 'about';
$isServices = $pageKey === 'services';
$isContact = $pageKey === 'contact';
$isCareers = $pageKey === 'careers';
$isLegal = in_array($pageKey, ['imprint', 'privacy'], true);

$menuItems = [];
$urlFuerSeite = [];
$menuEintraege = $app->getMenu()->getItems('menutype', (string) $templateNavigation['menu_type']) ?: [];

foreach ($menuEintraege as $eintrag) {
    if ((int) $eintrag->level !== 1) {
        continue;
    }

    $eintragSprache = isset($eintrag->language) ? (string) $eintrag->language : '*';
    if ($eintragSprache !== '*' && $eintragSprache !== $sprachTag) {
        continue;
    }

    $eintragKey = $linkParameter((string) $eintrag->link, 'page')
        ?: ($aliasSeiten[(string) $eintrag->alias] ?? '');
    $url = Route::_($eintrag->link . '&Itemid=' . $eintrag->id);
    /* Icon + "nur Icon" kommen aus den Menuepunkt-Parametern (editierbar im
       Joomla-Menuemanager via plg_system_lmzbuildermenu). -1 = nicht gesetzt. */
    $eintragParams = method_exists($eintrag, 'getParams') ? $eintrag->getParams() : null;
    $menuItems[] = [
        'id' => (int) $eintrag->id,
        'label' => $eintragKey === 'home' ? Text::_('TPL_LMZ_RAILTIME_NAV_HOME') : (string) $eintrag->title,
        'url' => $url,
        'alias' => (string) $eintrag->alias,
        'page_key' => $eintragKey,
        'icon' => $eintragParams ? trim((string) $eintragParams->get('lmz_menu_icon', '')) : '',
        'icon_only' => $eintragParams ? (string) $eintragParams->get('lmz_menu_icon_only', '') : '',
    ];
    if ($eintragKey !== '') {
        $urlFuerSeite[$eintragKey] = $url;
    }
}

/* Die Legal-Eintraege bleiben fuer Routen, Footer und Sprachwechsel bekannt,
   werden aber nicht mehr in der Hauptnavigation ausgegeben. */
$menuItems = array_values(array_filter(
    $menuItems,
    static fn (array $eintrag): bool => !in_array($eintrag['page_key'], ['imprint', 'privacy'], true)
));

/* Fallback-Routen bleiben sprachneutral konfiguriert und unterstützen jede
   veröffentlichte Builder-Sprache. */
$routen = match ($sprachTag) {
    'en-GB' => ['home' => '', 'about' => 'about-us', 'services' => 'services', 'careers' => 'careers', 'contact' => 'contact', 'imprint' => 'legal-notice', 'privacy' => 'privacy'],
    'pl-PL' => ['home' => '', 'about' => 'o-nas', 'services' => 'uslugi', 'careers' => 'kariera', 'contact' => 'kontakt', 'imprint' => 'informacje-prawne', 'privacy' => 'polityka-prywatnosci'],
    default => ['home' => '', 'about' => 'ueber-uns', 'services' => 'leistungen', 'careers' => 'karriere', 'contact' => 'kontakt', 'imprint' => 'impressum', 'privacy' => 'datenschutzerklaerung'],
};
$fallback = static fn (string $key): string => $root . '/' . $sprachSef . '/' . ($routen[$key] ?? '');
$homeUrl = $urlFuerSeite['home'] ?? $fallback('home');
$aboutUrl = $urlFuerSeite['about'] ?? $fallback('about');
$servicesUrl = $urlFuerSeite['services'] ?? $fallback('services');
$careersUrl = $urlFuerSeite['careers'] ?? $fallback('careers');
$contactUrl = $urlFuerSeite['contact'] ?? $fallback('contact');
$imprintUrl = $urlFuerSeite['imprint'] ?? $fallback('imprint');
$privacyUrl = $urlFuerSeite['privacy'] ?? $fallback('privacy');

$services = [
    ['wagenmeister-dienstleistungen', Text::_('TPL_LMZ_RAILTIME_SERVICE_WAGON')],
    ['notfalldienst-24-7', Text::_('TPL_LMZ_RAILTIME_SERVICE_EMERGENCY')],
    ['kv-trailer-service', Text::_('TPL_LMZ_RAILTIME_SERVICE_INTERMODAL')],
    ['sonderuntersuchungen', Text::_('TPL_LMZ_RAILTIME_SERVICE_SPECIAL')],
    ['pufferteller-schmieren', Text::_('TPL_LMZ_RAILTIME_SERVICE_BUFFER')],
];

$t = [
    'skip' => Text::_('TPL_LMZ_RAILTIME_SKIP'),
    'nav' => Text::_('TPL_LMZ_RAILTIME_NAV'),
    'menu' => Text::_('TPL_LMZ_RAILTIME_MENU_OPEN'),
    'emergency' => Text::_('TPL_LMZ_RAILTIME_EMERGENCY'),
    'home' => Text::_('TPL_LMZ_RAILTIME_HOME_LABEL'),
    'claim' => Text::_('TPL_LMZ_RAILTIME_CLAIM'),
    'services' => Text::_('TPL_LMZ_RAILTIME_SERVICES'),
    'company' => Text::_('TPL_LMZ_RAILTIME_COMPANY'),
    'contact' => Text::_('TPL_LMZ_RAILTIME_CONTACT'),
    'about' => Text::_('TPL_LMZ_RAILTIME_ABOUT'),
    'careers' => Text::_('TPL_LMZ_RAILTIME_CAREERS'),
    'request' => Text::_('TPL_LMZ_RAILTIME_REQUEST'),
    'rights' => Text::_('TPL_LMZ_RAILTIME_RIGHTS'),
    'imprint' => Text::_('TPL_LMZ_RAILTIME_IMPRINT'),
    'privacy' => Text::_('TPL_LMZ_RAILTIME_PRIVACY'),
    'langlabel' => Text::_('TPL_LMZ_RAILTIME_LANGUAGE'),
    'langswitch' => Text::_('TPL_LMZ_RAILTIME_LANGUAGE_SWITCH'),
    'mobile_close' => Text::_('TPL_LMZ_RAILTIME_MENU_CLOSE'),
    'mobile_drawer' => Text::_('TPL_LMZ_RAILTIME_MOBILE_NAV'),
    'mobile_claim' => Text::_('TPL_LMZ_RAILTIME_MOBILE_CLAIM'),
    'emergency_kicker' => Text::_('TPL_LMZ_RAILTIME_EMERGENCY_KICKER'),
    'emergency_title' => Text::_('TPL_LMZ_RAILTIME_EMERGENCY_TITLE'),
    'emergency_copy' => Text::_('TPL_LMZ_RAILTIME_EMERGENCY_COPY'),
    'emergency_hotline' => Text::_('TPL_LMZ_RAILTIME_EMERGENCY_HOTLINE'),
    'emergency_reach' => Text::_('TPL_LMZ_RAILTIME_EMERGENCY_REACH'),
];

/* --------------------------------------------------------------------- *
 * Sprachumschalter
 *
 * Der Joomla-Core-Helper ist hier absichtlich die fail-closed Routen-Whitelist.
 * Er liefert nur veröffentlichte Inhaltssprachen mit installiertem Site-Paket,
 * passender Zugriffsebene und eigener veröffentlichter Home-Route. Für die
 * aktuelle Seite bevorzugt er echte Joomla-Assoziationen und fällt erst dann
 * auf genau diese sprachspezifische Home-Route zurück. Die endgültige, query-
 * freie SEF-URL entsteht nur aus dem bestätigten Joomla-Menüeintrag. Eine
 * Sprache ohne Route wird nicht als scheinbar funktionierender Link ausgegeben.
 * --------------------------------------------------------------------- */
$sprachWechselSprachen = [];
$sprachAssoziationen = [];

try {
    $sprachModul = $app->bootModule('mod_languages', 'site');
    $sprachHelfer = $sprachModul->getHelper('LanguagesHelper');
    $sprachParameter = new Registry();

    if ($sprachHelfer && method_exists($sprachHelfer, 'getLanguages')) {
        $sprachWechselSprachen = $sprachHelfer->getLanguages($sprachParameter);
    }
} catch (\Throwable $sprachFehler) {
    // Fail-closed: ohne bestätigte Joomla-Route wird keine Option gerendert.
    $sprachWechselSprachen = [];
}

if ($active) {
    try {
        $sprachAssoziationen = MenusHelper::getAssociations((int) $active->id);
    } catch (\Throwable $assoziationsFehler) {
        // Die bereits vom Core geprüften Sprach-Startseiten bleiben verfügbar.
        $sprachAssoziationen = [];
    }
}

$sprachen = [];

/* Einzelne Sprachpakete tragen in <nativeName> nur einen Code statt des
   Landesnamens (pl-PL liefert "Polski (PL)"). Diese knappe Korrekturliste
   greift nur bei genau solchen Code-Klammern und ueberlebt damit
   Paket-Updates, die eine Aenderung an den Paketdateien zurueckdrehen
   wuerden. */
$landKorrekturen = ['pl-PL' => 'Polska'];

foreach ($sprachWechselSprachen as $sprache) {
    $code = isset($sprache->lang_code) ? trim((string) $sprache->lang_code) : '';
    $sef = isset($sprache->sef) ? trim((string) $sprache->sef, '/') : '';
    $coreLink = isset($sprache->link) ? trim((string) $sprache->link) : '';

    if ($code === '' || $sef === '' || $coreLink === '') {
        continue;
    }

    /* Der Core-Link bestaetigt, dass die Sprache grundsaetzlich erreichbar
       ist. Die kanonische SEF-Adresse wird anschliessend ausschliesslich aus
       einem realen, sprachgleichen Menueeintrag gebildet: aktuelle Route,
       assoziierte Route oder die vom Core bereits gepruefte Sprach-Startseite. */
    $zielEintrag = null;
    if ($active && (string) ($active->language ?? '') === $code) {
        $zielEintrag = $active;
    } elseif (!empty($sprachAssoziationen[$code])) {
        $zielEintrag = $app->getMenu()->getItem((int) $sprachAssoziationen[$code]);
    }
    if (!$zielEintrag) {
        $zielEintrag = $app->getMenu()->getDefault($code);
    }

    if (
        !$zielEintrag
        || (string) ($zielEintrag->language ?? '') !== $code
        || (isset($zielEintrag->published) && (int) $zielEintrag->published !== 1)
    ) {
        continue;
    }

    $istStartseite = (int) ($zielEintrag->home ?? 0) === 1;
    $zielAlias = $istStartseite ? '' : trim((string) ($zielEintrag->alias ?? ''), '/');
    if (!$istStartseite && $zielAlias === '') {
        continue;
    }

    $ziel = $root . '/' . rawurlencode($sef) . '/'
        . ($zielAlias !== '' ? rawurlencode($zielAlias) : '');

    $flaggenname = !empty($sprache->image)
        ? (string) $sprache->image
        : strtolower(str_replace('-', '_', $code));
    /* Im Umschalter steht nur der Landesname in der jeweiligen Sprache.
       Joomla liefert title_native durchgaengig als "Sprache (Land)", also
       etwa "Deutsch (Oesterreich)" oder "Tuerkce (Tuerkiye)"; davon wird
       ausschliesslich die Klammer verwendet. Das haelt die vier deutschen
       und die zwei niederlaendischen Varianten unterscheidbar - ein blosser
       Sprachname waere viermal "Deutsch". Fehlt die Klammer, bleibt der
       vollstaendige native Titel als Rueckfall stehen. */
    $nativerTitel = !empty($sprache->title_native)
        ? (string) $sprache->title_native
        : (!empty($sprache->title) ? (string) $sprache->title : $code);
    $sprachname = preg_match('~\(([^()]{2,})\)\s*$~u', $nativerTitel, $landTreffer)
        ? trim($landTreffer[1])
        : $nativerTitel;
    if (preg_match('~^[A-Za-z]{2,3}$~', $sprachname)) {
        $sprachname = $landKorrekturen[$code] ?? $nativerTitel;
    }
    $sprachen[] = [
        'code'   => $code,
        'kurz'   => strtoupper(substr($code, 0, 2)),
        'name'   => $sprachname,
        'flagge' => $root . '/media/mod_languages/images/' . $flaggenname . '.gif',
        'aktiv'  => !empty($sprache->active) || $code === $sprachTag,
        'url'    => $ziel,
    ];
}

/* Das Sprachfilter-Plugin kennt die native LMZ-Seitenzuordnung nicht und
   erzeugt deshalb Alternativen mit technischen Query-Parametern. Entferne
   nur diese hreflang-Einträge und gib darunter die bereits über die echten
   Menü-Assoziationen gebauten, kanonischen Sprach-URLs aus. */
$kopfDaten = method_exists($this, 'getHeadData') ? $this->getHeadData() : [];
$kopfLinks = $kopfDaten['links'] ?? [];
$kopfDaten['links'] = array_filter(
    $kopfLinks,
    static fn (array $kopfLink): bool => !in_array(
        ($kopfLink['relation'] ?? ''),
        ['alternate', 'canonical'],
        true
    )
);
$kopfDaten['custom'] = array_values(array_filter(
    $kopfDaten['custom'] ?? [],
    static fn (string $tag): bool => stripos($tag, 'hreflang="x-default"') === false
));

if (method_exists($this, 'setHeadData')) {
    $this->setHeadData($kopfDaten);
}

$standardSpracheUrl = $sprachen[0]['url'] ?? Uri::getInstance()->toString(['path', 'query']);
foreach ($sprachen as $sprache) {
    if ($sprache['code'] === 'de-DE') {
        $standardSpracheUrl = $sprache['url'];
        break;
    }
}
$kanonisch = Uri::getInstance()->toString(['scheme', 'host', 'port', 'path']);

/* --------------------------------------------------------------------- *
 * Visuelle Template-Regionen
 *
 * Der Builder gestaltet nur die Anordnung. Die sicherheits- und
 * routingrelevanten Fragmente bleiben serverseitig erzeugte Whitelist-Slots.
 * Fehlt ein Slot oder eine veröffentlichte Übersetzung, wird vollständig auf
 * den bisherigen Header beziehungsweise Footer zurückgefallen.
 * --------------------------------------------------------------------- */
$templateRegionRenderer = null;
$preparedNavigation = null;
$preparedFooter = null;

try {
    $templateRegionRenderer = new ContentRenderer(
        $app,
        Factory::getContainer()->get(DatabaseInterface::class)
    );
    if (!empty($templateNavigation['builder_enabled'])) {
        $preparedNavigation = $templateRegionRenderer->prepareTemplateRegion('navigation', $sprachTag);
        if ($preparedNavigation !== null && $preparedNavigation['css'] !== '') {
            $app->getDocument()->addStyleDeclaration((string) $preparedNavigation['css']);
        }
    }
    if (!empty($templateFooter['builder_enabled'])) {
        $preparedFooter = $templateRegionRenderer->prepareTemplateRegion('footer', $sprachTag);
        if ($preparedFooter !== null && $preparedFooter['css'] !== '') {
            $app->getDocument()->addStyleDeclaration((string) $preparedFooter['css']);
        }
    }
} catch (\Throwable $templateRegionError) {
    $preparedNavigation = null;
    $preparedFooter = null;
}

$h = static fn (mixed $value): string => htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
/* Optionales FontAwesome-Icon-Rendering: erwartet einen FA-Klassenstring
   (z. B. "fa-solid fa-phone"). Leeres/fehlendes Feld => kein Markup, kein Fehler.
   Gibt bei Bedarf ein dekoratives <i>-Element mit abschliessendem Leerzeichen zurueck. */
$rtIcon = static function (mixed $iconClass) use ($h): string {
    $iconClass = trim((string) $iconClass);
    return $iconClass !== ''
        ? '<i class="' . $h($iconClass) . '" aria-hidden="true"></i> '
        : '';
};
$navigationBrandMarkup = '<a class="rt-nav__brand" href="' . $h($homeUrl) . '" aria-label="' . $h($t['home']) . '">'
    . '<span class="rt-brand-lockup rt-brand-lockup--nav" role="img" aria-label="' . $h($brandAlt) . '">'
    . '<span class="rt-nav__logo-slot" data-rt-nav-logo-slot aria-hidden="true">'
    . (!$isHome ? '<img class="rt-brand-lockup__mark rt-nav__logo-static" src="' . $h($logoMarkUrl) . '" alt="" aria-hidden="true">' : '')
    . '</span><img class="rt-brand-lockup__wordmark" src="' . $h($navigationWordmarkUrl) . '" alt="" aria-hidden="true">'
    . '</span></a>';
$navigationToggleMarkup = '<button class="rt-nav__toggle" type="button" aria-label="' . $h($t['menu'])
    . '" aria-expanded="false"><span></span><span></span><span></span></button>';
/* Standardmaessig traegt nur der Start-Punkt ein Icon (nur Icon, kein Text).
   Die Unterseiten bleiben ohne Icon (reiner Text). Pro Menuepunkt kann im
   Joomla-Menuemanager trotzdem ein eigenes Icon gesetzt werden. */
$menuIconDefaults = [
    'home' => 'fa-solid fa-house',
];
$navigationMenuMarkup = '<nav aria-label="' . $h($t['nav']) . '">';
foreach ($menuItems as $entry) {
    $isActiveEntry = $active && (int) $active->id === $entry['id'];
    $icon = $entry['icon'] !== '' ? $entry['icon'] : ($menuIconDefaults[$entry['page_key']] ?? '');
    /* "nur Icon": expliziter Parameter gewinnt (1/0), sonst ist Start standardmaessig nur Icon. */
    $iconOnly = $entry['icon_only'] === '1'
        ? true
        : ($entry['icon_only'] === '0' ? false : $entry['page_key'] === 'home');
    $iconOnly = $iconOnly && $icon !== '';
    $iconMarkup = $icon !== '' ? '<i class="' . $h($icon) . '" aria-hidden="true"></i>' : '';
    $classes = trim(($isActiveEntry ? 'is-active ' : '') . ($iconOnly ? 'rt-nav__link--icon' : ($icon !== '' ? 'rt-nav__link--mit-icon' : '')));
    $navigationMenuMarkup .= '<a'
        . ($classes !== '' ? ' class="' . $h($classes) . '"' : '')
        . ($isActiveEntry ? ' aria-current="page"' : '')
        . ' href="' . $h($entry['url']) . '"'
        . ($iconOnly ? ' aria-label="' . $h($entry['label']) . '" title="' . $h($entry['label']) . '"' : '')
        . '>' . $iconMarkup
        . ($iconOnly ? '' : '<span data-text="' . $h($entry['label']) . '">' . $h($entry['label']) . '</span>')
        . '</a>';
}
$navigationMenuMarkup .= '</nav>';

$navigationLanguagesMarkup = '';
if (count($sprachen) > 1) {
    $aktuelleSprache = current(array_filter($sprachen, static fn ($s) => $s['aktiv'])) ?: $sprachen[0];
    $sprachKnopfId = 'rt-language-trigger';
    $sprachListeId = 'rt-language-options';
    $navigationLanguagesMarkup = '<div class="rt-lang" data-rt-lang>'
        . '<button id="' . $sprachKnopfId . '" class="rt-lang__knopf" type="button" aria-haspopup="menu" aria-controls="' . $sprachListeId
        . '" aria-expanded="false" aria-label="' . $h($t['langswitch']) . '">'
        . '<img class="rt-lang__flagge" src="' . $h($aktuelleSprache['flagge']) . '" width="18" height="12" alt="" aria-hidden="true">'
        . '<span class="rt-lang__kurz">' . $h($aktuelleSprache['kurz']) . '</span>'
        . '<svg class="rt-lang__pfeil" viewBox="0 0 10 6" aria-hidden="true"><path d="M1 1l4 4 4-4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>'
        . '</button><ul id="' . $sprachListeId . '" class="rt-lang__liste" role="menu" aria-labelledby="' . $sprachKnopfId . '">';
    foreach ($sprachen as $sprache) {
        $navigationLanguagesMarkup .= '<li role="none"><a role="menuitem" hreflang="' . $h($sprache['code'])
            . '" href="' . $h($sprache['url']) . '"'
            . ($sprache['aktiv'] ? ' class="is-active" aria-current="true"' : '') . '>'
            . '<img src="' . $h($sprache['flagge']) . '" width="18" height="12" alt="" aria-hidden="true">'
            . '<span>' . $h($sprache['name']) . '</span></a></li>';
    }
    $navigationLanguagesMarkup .= '</ul></div>';
}

$hotline = (string) $templateNavigation['hotline'];
$hotlineHref = preg_replace('/[^0-9+]/', '', $hotline) ?: '+494171546803';
if (str_starts_with($hotlineHref, '0')) {
    $hotlineHref = '+49' . substr($hotlineHref, 1);
}
/* Minimaler Notfall-Button: nur Beschriftung, keine sichtbare Nummer. Der
   tel:-Link bleibt fuer den Direktanruf erhalten, die Nummer steht per
   aria-label weiterhin fuer Screenreader zur Verfuegung. */
$navigationHotlineMarkup = !empty($templateNavigation['hotline_visible'])
    ? '<a class="rt-nav__phone rt-nav__phone--kompakt" href="tel:' . $h($hotlineHref) . '"'
        . ' aria-label="' . $h($t['emergency']) . ' ' . $h($hotline) . '">'
        /* Telefon-Icon + kurzer 24/7-Text (sprachneutral). Icon in den
           Template-Einstellungen (Kopfzeile) per hotline_icon ueberschreibbar.
           Das vollstaendige Label bleibt im aria-label. */
        . $rtIcon(($templateNavigation['hotline_icon'] ?? '') ?: 'fa-solid fa-phone')
        . '<span>24/7</span></a>'
    : '';
$navigationSlots = [
    'brand' => $navigationBrandMarkup,
    'toggle' => $navigationToggleMarkup,
    'menu' => $navigationMenuMarkup,
    'languages' => $navigationLanguagesMarkup,
    'hotline' => $navigationHotlineMarkup,
];
$navigationFallbackMarkup = implode('', $navigationSlots);
$navigationMarkup = $preparedNavigation !== null && $templateRegionRenderer instanceof ContentRenderer
    ? $templateRegionRenderer->fillTemplateRegion($preparedNavigation, $navigationSlots)
    : null;
$navigationMarkup = is_string($navigationMarkup) && $navigationMarkup !== ''
    ? $navigationMarkup
    : $navigationFallbackMarkup;

$footerBrandMarkup = '<div class="rt-footer__brand"><span class="rt-brand-lockup rt-brand-lockup--footer" role="img" aria-label="' . $h($brandAlt) . '">'
    . '<img class="rt-brand-lockup__mark" src="' . $h($logoMarkUrl) . '" alt="" aria-hidden="true">'
    . '<img class="rt-brand-lockup__wordmark" src="' . $h($footerWordmarkUrl) . '" alt="" aria-hidden="true">'
    . '</span><p>' . $t['claim'] . '</p></div>';
$footerServicesMarkup = '<div><b>' . $h($t['services']) . '</b>';
foreach ($services as [$slug, $label]) {
    $footerServicesMarkup .= '<a href="' . $h($servicesUrl . '#' . $slug) . '">' . $h($label) . '</a>';
}
$footerServicesMarkup .= '</div>';
$footerCompanyMarkup = '<div><b>' . $h($t['company']) . '</b>'
    . '<a href="' . $h($aboutUrl) . '">' . $h($t['about']) . '</a>'
    . '<a href="' . $h($servicesUrl) . '">' . $h($t['services']) . '</a>'
    . '<a href="' . $h($careersUrl) . '">' . $h($t['careers']) . '</a>'
    . '<a href="' . $h($contactUrl) . '">' . $h($t['contact']) . '</a></div>';
$footerContactMarkup = '<div><b>' . $h($t['contact']) . '</b>'
    . '<a href="mailto:' . $h($templateFooter['email']) . '">' . $rtIcon($templateFooter['email_icon'] ?? '') . $h($templateFooter['email']) . '</a>'
    . '<span>' . $rtIcon($templateFooter['address_icon'] ?? '') . nl2br($h($templateFooter['address']), false) . '</span>'
    . '<a href="' . $h($contactUrl) . '">' . $h($t['request']) . '</a></div>';
$footerLegalMarkup = '<small><span>© ' . date('Y') . ' ' . $h($templateFooter['company']) . ' · ' . $h($t['rights']) . '</span>'
    . '<span class="rt-footer__legal"><a href="' . $h($imprintUrl) . '">' . $h($t['imprint']) . '</a>'
    . '<a href="' . $h($privacyUrl) . '">' . $h($t['privacy']) . '</a></span></small>';
$footerSlots = [
    'brand' => $footerBrandMarkup,
    'services' => $footerServicesMarkup,
    'company' => $footerCompanyMarkup,
    'contact' => $footerContactMarkup,
    'legal' => $footerLegalMarkup,
];
$footerFallbackMarkup = implode('', $footerSlots);
$footerMarkup = $preparedFooter !== null && $templateRegionRenderer instanceof ContentRenderer
    ? $templateRegionRenderer->fillTemplateRegion($preparedFooter, $footerSlots)
    : null;
$footerMarkup = is_string($footerMarkup) && $footerMarkup !== '' ? $footerMarkup : $footerFallbackMarkup;

?>
<!doctype html>
<html lang="<?php echo htmlspecialchars($this->language, ENT_QUOTES, 'UTF-8'); ?>" dir="<?php echo htmlspecialchars($this->direction, ENT_QUOTES, 'UTF-8'); ?>">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#090c11">
    <meta name="referrer" content="strict-origin-when-cross-origin">
    <jdoc:include type="head" />
    <link rel="canonical" href="<?php echo htmlspecialchars($kanonisch, ENT_QUOTES, 'UTF-8'); ?>">
    <?php foreach ($sprachen as $sprache): ?>
    <link rel="alternate" hreflang="<?php echo htmlspecialchars($sprache['code'], ENT_QUOTES, 'UTF-8'); ?>" href="<?php echo htmlspecialchars($sprache['url'], ENT_QUOTES, 'UTF-8'); ?>">
    <?php endforeach; ?>
    <link rel="alternate" hreflang="x-default" href="<?php echo htmlspecialchars($standardSpracheUrl, ENT_QUOTES, 'UTF-8'); ?>">
    <link rel="icon"<?php echo $faviconType !== '' ? ' type="' . $h($faviconType) . '"' : ''; ?> href="<?php echo $h($faviconUrl); ?>">
    <link rel="stylesheet" href="<?php echo $assetBase; ?>/css/rt-fonts.css?v=1">
    <link rel="stylesheet" href="<?php echo $assetBase; ?>/css/rt-fontawesome.css?v=1">
    <link rel="stylesheet" href="<?php echo $assetBase; ?>/css/tailwind.min.css?v=1">
    <link rel="stylesheet" href="<?php echo $assetBase; ?>/css/design-system.css?v=1">
    <link rel="stylesheet" href="<?php echo $assetBase; ?>/css/layout-polish.css?v=13">
    <link rel="stylesheet" href="<?php echo $assetBase; ?>/css/logo-3d.css?v=1">
    <link rel="stylesheet" href="<?php echo $assetBase; ?>/css/layout.css?v=2">
    <link rel="stylesheet" href="<?php echo $assetBase; ?>/css/motion-stability.css?v=6">
    <link rel="stylesheet" href="<?php echo $assetBase; ?>/css/brand-lockup.css?v=11">
    <link rel="stylesheet" href="<?php echo $assetBase; ?>/css/mobile-navigation.css?v=13">
    <link rel="stylesheet" href="<?php echo $assetBase; ?>/css/joomla-integration.css?v=7">
    <link rel="stylesheet" href="<?php echo $assetBase; ?>/css/rt-motion.css?v=7">
    <link rel="stylesheet" href="<?php echo $assetBase; ?>/css/rt-footer.css?v=7">
    <link rel="stylesheet" href="<?php echo $assetBase; ?>/css/rt-language.css?v=4">
    <link rel="stylesheet" href="<?php echo $assetBase; ?>/css/template-settings-runtime.css?v=2">
<?php if ($isHome): ?>
    <link rel="stylesheet" href="<?php echo $assetBase; ?>/css/rt-germany-map.css?v=1">
    <link rel="stylesheet" href="<?php echo $assetBase; ?>/css/home-first-segment.css?v=23">
<?php endif; ?>
<?php if (!$isHome): ?>
    <link rel="stylesheet" href="<?php echo $assetBase; ?>/css/rt-system.css?v=5">
    <?php if ($isAbout): ?>
    <link rel="stylesheet" href="<?php echo $assetBase; ?>/css/rt-about.css?v=12">
    <?php endif; ?>
    <?php if ($isServices): ?>
    <link rel="stylesheet" href="<?php echo $assetBase; ?>/css/rt-services.css?v=14">
    <?php endif; ?>
    <?php if ($isContact): ?>
    <link rel="stylesheet" href="<?php echo $assetBase; ?>/css/rt-contact.css?v=5">
    <?php endif; ?>
    <?php if ($isCareers): ?>
    <link rel="stylesheet" href="<?php echo $assetBase; ?>/css/rt-careers.css?v=3">
    <?php endif; ?>
<?php endif; ?>
<?php if ($isHome || $isAbout || $isServices || $isCareers): ?>
    <link rel="stylesheet" href="<?php echo $assetBase; ?>/css/rt-process.css?v=5">
<?php endif; ?>
    <link rel="stylesheet" href="<?php echo $assetBase; ?>/css/rt-gueterzug.css?v=10">
<?php if (!$isLegal): ?>
    <script>
    (function () {
        if (matchMedia('(prefers-reduced-motion: reduce)').matches) return;
        document.documentElement.classList.add('rt-motion-enabled', 'rt-motion-pending');
        window.__rtMotionCloakTimer = window.setTimeout(function () {
            document.documentElement.classList.remove('rt-motion-enabled', 'rt-motion-pending');
        }, 4000);
    })();
    </script>
<?php endif; ?>
</head>
<body class="rt-shell theme-3 rt-l3-page <?php echo $isHome ? 'is-home' : 'is-subpage'; ?><?php echo $isAbout ? ' is-about' : ''; ?><?php echo $isServices ? ' is-services' : ''; ?><?php echo $isContact ? ' is-contact' : ''; ?><?php echo $isCareers ? ' is-careers' : ''; ?><?php echo $isLegal ? ' is-legal' : ''; ?> antialiased"
      style="--rt-settings-nav-background:<?php echo $h($templateNavigation['background']); ?>;--rt-settings-nav-text:<?php echo $h($templateNavigation['text']); ?>;--rt-settings-nav-accent:<?php echo $h($templateNavigation['accent']); ?>;--rt-settings-footer-background:<?php echo $h($templateFooter['background']); ?>;--rt-settings-footer-text:<?php echo $h($templateFooter['text']); ?>;--rt-settings-footer-accent:<?php echo $h($templateFooter['accent']); ?>;"
      <?php if ($isCareers): ?> data-rt-application-endpoint="<?php echo htmlspecialchars($root . '/index.php?option=com_ajax&plugin=railtimeapplication&format=json&lang=' . $sprachSef, ENT_QUOTES, 'UTF-8'); ?>"<?php endif; ?>>
<a class="rt-skip-link" href="#rt-main-content"><?php echo htmlspecialchars($t['skip'], ENT_QUOTES, 'UTF-8'); ?></a>
<header class="rt-nav<?php echo $isHome ? '' : ' is-visible'; ?>"
        data-mobile-menu-open="<?php echo htmlspecialchars($t['menu'], ENT_QUOTES, 'UTF-8'); ?>"
        data-mobile-menu-close="<?php echo htmlspecialchars($t['mobile_close'], ENT_QUOTES, 'UTF-8'); ?>"
        data-mobile-menu-drawer="<?php echo htmlspecialchars($t['mobile_drawer'], ENT_QUOTES, 'UTF-8'); ?>"
        data-mobile-menu-navigation="<?php echo htmlspecialchars($t['nav'], ENT_QUOTES, 'UTF-8'); ?>"
        data-mobile-menu-languages="<?php echo htmlspecialchars($t['langlabel'], ENT_QUOTES, 'UTF-8'); ?>"
        data-mobile-menu-hotline="<?php echo htmlspecialchars($t['emergency'], ENT_QUOTES, 'UTF-8'); ?>"
        data-mobile-menu-claim="<?php echo htmlspecialchars($t['mobile_claim'], ENT_QUOTES, 'UTF-8'); ?>"
        data-lmz-template-settings
        data-lmz-template-region-active="<?php echo $preparedNavigation !== null ? 'true' : 'false'; ?>"
        style="--rt-settings-nav-background:<?php echo $h($templateNavigation['background']); ?>;--rt-settings-nav-text:<?php echo $h($templateNavigation['text']); ?>;--rt-settings-nav-accent:<?php echo $h($templateNavigation['accent']); ?>;">
    <?php echo $navigationMarkup; ?>
</header>

<div id="rt-main-content" class="rt-l3-component">
    <jdoc:include type="message" />
    <jdoc:include type="component" />
</div>

<footer class="rt-footer"
        data-lmz-template-settings
        data-lmz-template-region-active="<?php echo $preparedFooter !== null ? 'true' : 'false'; ?>"
        style="--rt-settings-footer-background:<?php echo $h($templateFooter['background']); ?>;--rt-settings-footer-text:<?php echo $h($templateFooter['text']); ?>;--rt-settings-footer-accent:<?php echo $h($templateFooter['accent']); ?>;">
    <?php echo $footerMarkup; ?>
</footer>

<script src="<?php echo $assetBase; ?>/js/vendor/gsap.min.js?v=3.15.0"></script>
<script src="<?php echo $assetBase; ?>/js/vendor/ScrollTrigger.min.js?v=3.15.0"></script>
<script src="<?php echo $assetBase; ?>/js/vendor/SplitText.min.js?v=3.15.0"></script>
<script src="<?php echo $assetBase; ?>/js/vendor/ScrollToPlugin.min.js?v=3.15.0"></script>
<script src="<?php echo $assetBase; ?>/js/scroll-motion.js?v=6"></script>
<script src="<?php echo $assetBase; ?>/js/mobile-navigation.js?v=7"></script>
<script src="<?php echo $assetBase; ?>/js/rt-language.js?v=3"></script>
<?php if ($isHome || $isAbout || $isServices || $isCareers): ?>
<script src="<?php echo $assetBase; ?>/js/rt-process.js?v=12"></script>
<?php endif; ?>
<?php if ($isHome): ?>
    <script src="<?php echo $assetBase; ?>/js/scroll-video-engine.js?v=1"></script>
    <script src="<?php echo $assetBase; ?>/js/home-intro.js?v=26"></script>
    <script src="<?php echo $assetBase; ?>/js/rt-marquee.js?v=2"></script>
    <script src="<?php echo $assetBase; ?>/js/rt-atmosphere.js?v=1"></script>
    <script src="<?php echo $assetBase; ?>/js/rt-home-story.js?v=7"></script>
<?php else: ?>
    <?php if ($isAbout): ?>
<script src="<?php echo $assetBase; ?>/js/rt-about.js?v=15"></script>
    <?php elseif ($isServices): ?>
<script src="<?php echo $assetBase; ?>/js/rt-services.js?v=16"></script>
    <?php elseif ($isContact): ?>
<script src="<?php echo $assetBase; ?>/js/rt-contact.js?v=9"></script>
    <?php elseif ($isCareers): ?>
    <script src="<?php echo $assetBase; ?>/js/rt-careers.js?v=5"></script>
    <?php else: ?>
    <script src="<?php echo $assetBase; ?>/js/rt-system.js?v=3"></script>
    <?php endif; ?>
<?php endif; ?>
<script src="<?php echo $assetBase; ?>/js/rt-gueterzug.js?v=10"></script>
<script src="<?php echo $assetBase; ?>/js/motion.js?v=3"></script>
<script src="<?php echo $assetBase; ?>/js/rt-scroll-design.js?v=8"></script>
<?php if ($isHome): ?>
    <script src="<?php echo $assetBase; ?>/js/rt-home-segments.js?v=3"></script>
    <script src="<?php echo $assetBase; ?>/js/rt-map-sequence.js?v=18"></script>
<?php endif; ?>
<jdoc:include type="modules" name="debug" style="none" />
</body>
</html>
