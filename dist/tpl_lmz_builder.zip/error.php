<?php

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Uri\Uri;

$app = Factory::getApplication();
$language = $app->getLanguage();
$language->load('tpl_lmz_builder', __DIR__);
$code = (int) $this->error->getCode();
$message = $code === 404
    ? Text::_('JERROR_LAYOUT_PAGE_NOT_FOUND')
    : Text::_('JERROR_LAYOUT_ERROR_HAS_OCCURRED_WHILE_PROCESSING_YOUR_REQUEST');
$home = rtrim(Uri::root(), '/') . '/';
$assetBase = rtrim(Uri::root(true), '/') . '/templates/lmz_builder/l3';
$imageBase = rtrim(Uri::root(true), '/') . '/images/l3';
?>
<!doctype html>
<html lang="<?php echo htmlspecialchars($this->language, ENT_QUOTES, 'UTF-8'); ?>" dir="<?php echo htmlspecialchars($this->direction, ENT_QUOTES, 'UTF-8'); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex,follow">
    <title><?php echo $code; ?> · <?php echo htmlspecialchars($message, ENT_QUOTES, 'UTF-8'); ?></title>
    <link rel="icon" type="image/svg+xml" href="<?php echo $imageBase; ?>/logo/rt-logo.svg">
    <link rel="stylesheet" href="<?php echo $assetBase; ?>/css/system-pages.css?v=1">
</head>
<body class="rt-system-page">
    <main class="rt-system-card">
        <a class="rt-system-brand" href="<?php echo htmlspecialchars($home, ENT_QUOTES, 'UTF-8'); ?>">
            <img src="<?php echo $imageBase; ?>/logo/rt-logo.svg" alt="">
            <span>RT Rail Time GmbH</span>
        </a>
        <p class="rt-system-eyebrow"><?php echo $code; ?></p>
        <h1><?php echo htmlspecialchars($message, ENT_QUOTES, 'UTF-8'); ?></h1>
        <p><?php echo htmlspecialchars($this->error->getMessage(), ENT_QUOTES, 'UTF-8'); ?></p>
        <a class="rt-system-button" href="<?php echo htmlspecialchars($home, ENT_QUOTES, 'UTF-8'); ?>"><?php echo Text::_('JERROR_LAYOUT_HOME_PAGE'); ?></a>
        <?php if ($this->debug) : ?>
            <details class="rt-system-debug"><summary>Debug</summary><?php echo $this->renderBacktrace(); ?></details>
        <?php endif; ?>
    </main>
</body>
</html>
