<?php
/**
 * LMZ Page Builder - Dashboard-Widget (Admin-Modul).
 */

defined('_JEXEC') or die;

use Joomla\CMS\Extension\Service\Provider\Module;
use Joomla\CMS\Extension\Service\Provider\ModuleDispatcherFactory;
use Joomla\CMS\Extension\Service\Provider\HelperFactory;
use Joomla\DI\Container;
use Joomla\DI\ServiceProviderInterface;

return new class () implements ServiceProviderInterface {
    public function register(Container $container): void
    {
        $container->registerServiceProvider(new ModuleDispatcherFactory('\\LMZ\\Module\\LmzpagebuilderDashboard'));
        $container->registerServiceProvider(new HelperFactory('\\LMZ\\Module\\LmzpagebuilderDashboard\\Administrator\\Helper'));
        $container->registerServiceProvider(new Module());
    }
};
