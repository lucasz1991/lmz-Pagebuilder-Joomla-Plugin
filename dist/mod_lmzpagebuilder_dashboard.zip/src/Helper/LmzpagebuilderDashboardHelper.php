<?php
/**
 * Sammelt die Kennzahlen fuer das LMZ-Page-Builder-Dashboard-Widget.
 */

namespace LMZ\Module\LmzpagebuilderDashboard\Administrator\Helper;

defined('_JEXEC') or die;

use Joomla\CMS\Application\CMSApplicationInterface;
use Joomla\Database\DatabaseInterface;
use Joomla\Registry\Registry;

final class LmzpagebuilderDashboardHelper
{
    /**
     * Liefert alle Kennzahlen, fehlertolerant: fehlt eine Tabelle, bleibt der
     * jeweilige Wert 0/leer, das Widget bricht nie.
     */
    public function sammle(Registry $params, CMSApplicationInterface $app): array
    {
        $db = \Joomla\CMS\Factory::getContainer()->get(DatabaseInterface::class);

        $skalar = function (string $sql) use ($db): int {
            try {
                return (int) $db->setQuery($sql)->loadResult();
            } catch (\Throwable) {
                return 0;
            }
        };

        $seiten       = $skalar('SELECT COUNT(*) FROM #__lmzpagebuilder_pages');
        $seitenPubl   = $skalar('SELECT COUNT(*) FROM #__lmzpagebuilder_pages WHERE state = 1');
        $sprachen     = $skalar('SELECT COUNT(DISTINCT language) FROM #__lmzpagebuilder_page_translations');
        $uebersInsg   = $skalar('SELECT COUNT(*) FROM #__lmzpagebuilder_page_translations');
        $uebersPubl   = $skalar('SELECT COUNT(*) FROM #__lmzpagebuilder_page_translations WHERE state = 1');
        $shared       = $skalar('SELECT COUNT(*) FROM #__lmzpagebuilder_elements');
        $revisionen   = $skalar('SELECT COUNT(*) FROM #__lmzpagebuilder_page_revisions');
        $standorte    = $skalar('SELECT COUNT(*) FROM #__lmzstudio_map_locations WHERE state = 1');

        /* Uebersetzungsabdeckung: veroeffentlichte Uebersetzungen gegen das
           Soll (Seiten x Sprachen). */
        $soll = $seiten * $sprachen;
        $abdeckung = $soll > 0 ? (int) round($uebersPubl / $soll * 100) : 0;

        /* Seiten-Aufschluesselung: je Seite Titel (de-DE), Status, Anzahl
           veroeffentlichter Sprachen, letzte Aenderung. */
        $seitenListe = [];
        try {
            $rows = $db->setQuery(
                'SELECT p.id, p.page_key, p.state,'
                . ' (SELECT t2.title FROM #__lmzpagebuilder_page_translations t2 WHERE t2.page_id = p.id AND t2.language = ' . $db->quote('de-DE') . ' LIMIT 1) AS title,'
                . ' (SELECT COUNT(*) FROM #__lmzpagebuilder_page_translations t3 WHERE t3.page_id = p.id AND t3.state = 1) AS sprachen,'
                . ' (SELECT MAX(t4.modified) FROM #__lmzpagebuilder_page_translations t4 WHERE t4.page_id = p.id) AS modified'
                . ' FROM #__lmzpagebuilder_pages p ORDER BY p.ordering, p.id'
            )->loadAssocList();
            $seitenListe = \is_array($rows) ? $rows : [];
        } catch (\Throwable) {
            $seitenListe = [];
        }

        /* Status der Komponente aus den Extension-Params. */
        $config = new Registry();
        try {
            $roh = $db->setQuery(
                $db->getQuery(true)->select($db->quoteName('params'))->from($db->quoteName('#__extensions'))
                    ->where($db->quoteName('element') . ' = ' . $db->quote('com_lmzpagebuilder'))
                    ->where($db->quoteName('type') . ' = ' . $db->quote('component'))
            )->loadResult();
            $config = new Registry((string) $roh);
        } catch (\Throwable) {
        }

        /* Ist das lmz_builder-Template als Standard aktiv? */
        $templateAktiv = $skalar(
            "SELECT COUNT(*) FROM #__template_styles WHERE template = 'lmz_builder' AND client_id = 0 AND home = '1'"
        ) > 0;

        $zuletzt = [];
        if ((bool) $params->get('show_recent', 1)) {
            try {
                $rows = $db->setQuery(
                    'SELECT p.id AS page_id, p.page_key, t.language, t.title, t.modified'
                    . ' FROM #__lmzpagebuilder_page_translations t'
                    . ' JOIN #__lmzpagebuilder_pages p ON p.id = t.page_id'
                    . ' ORDER BY t.modified DESC',
                    0,
                    6
                )->loadAssocList();
                $zuletzt = \is_array($rows) ? $rows : [];
            } catch (\Throwable) {
                $zuletzt = [];
            }
        }

        return [
            'kacheln' => [
                ['label' => 'MOD_LMZPAGEBUILDER_DASHBOARD_PAGES', 'wert' => $seiten, 'zusatz' => $seitenPubl, 'icon' => 'icon-file', 'link' => 'index.php?option=com_lmzpagebuilder&view=projects'],
                ['label' => 'MOD_LMZPAGEBUILDER_DASHBOARD_LANGUAGES', 'wert' => $sprachen, 'zusatz' => null, 'icon' => 'icon-comments', 'link' => 'index.php?option=com_languages&view=languages'],
                ['label' => 'MOD_LMZPAGEBUILDER_DASHBOARD_TRANSLATIONS', 'wert' => $uebersInsg, 'zusatz' => $uebersPubl, 'icon' => 'icon-copy', 'link' => 'index.php?option=com_lmzpagebuilder&view=projects'],
                ['label' => 'MOD_LMZPAGEBUILDER_DASHBOARD_LOCATIONS', 'wert' => $standorte, 'zusatz' => null, 'icon' => 'icon-location', 'link' => 'index.php?option=com_lmzstudiomodules&view=maps'],
            ],
            'abdeckung'   => $abdeckung,
            'shared'      => $shared,
            'revisionen'  => $revisionen,
            'zuletzt'     => $zuletzt,
            'seitenListe' => $seitenListe,
            'sprachenZiel' => $sprachen,
            'status'      => [
                'openrouter' => (int) $config->get('openrouter_enabled', 0) === 1,
                'assistent'  => (int) $config->get('assistant_admin_enabled', 0) === 1,
                'template'   => $templateAktiv,
            ],
        ];
    }
}
