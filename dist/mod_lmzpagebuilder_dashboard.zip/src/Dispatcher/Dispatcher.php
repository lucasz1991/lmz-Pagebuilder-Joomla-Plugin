<?php
/**
 * Dispatcher des LMZ-Page-Builder-Dashboard-Widgets.
 */

namespace LMZ\Module\LmzpagebuilderDashboard\Administrator\Dispatcher;

defined('_JEXEC') or die;

use Joomla\CMS\Dispatcher\AbstractModuleDispatcher;
use Joomla\CMS\Helper\HelperFactoryAwareInterface;
use Joomla\CMS\Helper\HelperFactoryAwareTrait;

final class Dispatcher extends AbstractModuleDispatcher implements HelperFactoryAwareInterface
{
    use HelperFactoryAwareTrait;

    protected function getLayoutData(): array
    {
        $data = parent::getLayoutData();

        $data['statistik'] = $this->getHelperFactory()
            ->getHelper('LmzpagebuilderDashboardHelper')
            ->sammle($data['params'], $this->getApplication());

        return $data;
    }
}
