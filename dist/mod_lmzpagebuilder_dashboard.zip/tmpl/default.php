<?php
/**
 * Layout des LMZ-Page-Builder-Dashboard-Widgets.
 *
 * @var array  $statistik  Kennzahlen aus dem Helper
 */

defined('_JEXEC') or die;

use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
use Joomla\CMS\HTML\HTMLHelper;

/* Modul-Layouts haben kein $this->escape() (das ist Komponenten-Views
   vorbehalten) - deshalb eine lokale Escape-Funktion. */
$esc = static fn ($v): string => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');

$kacheln     = $statistik['kacheln'] ?? [];
$abdeckung   = (int) ($statistik['abdeckung'] ?? 0);
$shared      = (int) ($statistik['shared'] ?? 0);
$revisionen  = (int) ($statistik['revisionen'] ?? 0);
$zuletzt     = $statistik['zuletzt'] ?? [];
$seitenListe = $statistik['seitenListe'] ?? [];
$sprachenZiel = (int) ($statistik['sprachenZiel'] ?? 0);
$status      = $statistik['status'] ?? [];

$statusChip = static function (bool $an, string $label) use ($esc): string {
    $cls = $an ? 'is-on' : 'is-off';
    $ico = $an ? 'icon-checkmark-circle' : 'icon-minus-circle';
    return '<span class="lmzpb-dash__chip ' . $cls . '"><span class="' . $ico . '" aria-hidden="true"></span>' . $esc($label) . '</span>';
};
?>
<div class="lmzpb-dash">
    <div class="lmzpb-dash__grid">
        <?php foreach ($kacheln as $k) : ?>
            <a class="lmzpb-dash__tile" href="<?php echo Route::_($k['link']); ?>">
                <span class="lmzpb-dash__tile-ico"><span class="<?php echo $esc($k['icon']); ?>" aria-hidden="true"></span></span>
                <span class="lmzpb-dash__tile-val"><?php echo (int) $k['wert']; ?></span>
                <span class="lmzpb-dash__tile-lbl"><?php echo Text::_($k['label']); ?></span>
                <?php if ($k['zusatz'] !== null) : ?>
                    <span class="lmzpb-dash__tile-sub"><?php echo Text::sprintf('MOD_LMZPAGEBUILDER_DASHBOARD_PUBLISHED_N', (int) $k['zusatz']); ?></span>
                <?php endif; ?>
            </a>
        <?php endforeach; ?>
    </div>

    <div class="lmzpb-dash__cols">
        <!-- Links: Seiten-Aufschluesselung -->
        <div class="lmzpb-dash__panel">
            <div class="lmzpb-dash__panel-head"><?php echo Text::_('MOD_LMZPAGEBUILDER_DASHBOARD_PAGES_TABLE'); ?></div>
            <table class="lmzpb-dash__table">
                <thead>
                    <tr>
                        <th><?php echo Text::_('MOD_LMZPAGEBUILDER_DASHBOARD_PAGE'); ?></th>
                        <th class="lmzpb-dash__num"><?php echo Text::_('MOD_LMZPAGEBUILDER_DASHBOARD_LANGS'); ?></th>
                        <th><?php echo Text::_('MOD_LMZPAGEBUILDER_DASHBOARD_UPDATED'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($seitenListe as $s) :
                        $langs = (int) $s['sprachen'];
                        $voll  = $sprachenZiel > 0 && $langs >= $sprachenZiel;
                        ?>
                        <tr>
                            <td>
                                <a href="<?php echo Route::_('index.php?option=com_lmzpagebuilder&view=projects'); ?>">
                                    <span class="lmzpb-dash__state <?php echo ((int) $s['state'] === 1) ? 'is-pub' : 'is-unpub'; ?>" aria-hidden="true"></span>
                                    <?php echo $esc($s['title'] ?: $s['page_key']); ?>
                                </a>
                            </td>
                            <td class="lmzpb-dash__num">
                                <span class="lmzpb-dash__langbadge <?php echo $voll ? 'is-full' : 'is-partial'; ?>">
                                    <?php echo $langs; ?><?php echo $sprachenZiel > 0 ? '/' . $sprachenZiel : ''; ?>
                                </span>
                            </td>
                            <td><time><?php echo $s['modified'] ? HTMLHelper::_('date.relative', $s['modified']) : '—'; ?></time></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <!-- Rechts: Abdeckung, Status, letzte Aktivitaet -->
        <div class="lmzpb-dash__side">
            <div class="lmzpb-dash__cover">
                <div class="lmzpb-dash__cover-head">
                    <span><?php echo Text::_('MOD_LMZPAGEBUILDER_DASHBOARD_COVERAGE'); ?></span>
                    <strong><?php echo $abdeckung; ?>%</strong>
                </div>
                <div class="lmzpb-dash__bar" role="progressbar" aria-valuenow="<?php echo $abdeckung; ?>" aria-valuemin="0" aria-valuemax="100">
                    <span style="width: <?php echo max(2, min(100, $abdeckung)); ?>%;"></span>
                </div>
                <div class="lmzpb-dash__meta">
                    <span><span class="icon-puzzle" aria-hidden="true"></span> <?php echo Text::sprintf('MOD_LMZPAGEBUILDER_DASHBOARD_SHARED_N', $shared); ?></span>
                    <span><span class="icon-history" aria-hidden="true"></span> <?php echo Text::sprintf('MOD_LMZPAGEBUILDER_DASHBOARD_REVISIONS_N', $revisionen); ?></span>
                </div>
            </div>

            <div class="lmzpb-dash__status">
                <?php
                echo $statusChip((bool) ($status['template'] ?? false), Text::_('MOD_LMZPAGEBUILDER_DASHBOARD_ST_TEMPLATE'));
                echo $statusChip((bool) ($status['openrouter'] ?? false), Text::_('MOD_LMZPAGEBUILDER_DASHBOARD_ST_OPENROUTER'));
                echo $statusChip((bool) ($status['assistent'] ?? false), Text::_('MOD_LMZPAGEBUILDER_DASHBOARD_ST_ASSISTANT'));
                ?>
            </div>

            <?php if (!empty($zuletzt)) : ?>
                <div class="lmzpb-dash__recent">
                    <div class="lmzpb-dash__recent-head"><?php echo Text::_('MOD_LMZPAGEBUILDER_DASHBOARD_RECENT'); ?></div>
                    <ul>
                        <?php foreach (array_slice($zuletzt, 0, 5) as $z) : ?>
                            <li>
                                <a href="<?php echo Route::_('index.php?option=com_lmzpagebuilder&view=projects'); ?>">
                                    <span class="lmzpb-dash__recent-title"><?php echo $esc($z['title'] ?: $z['page_key']); ?></span>
                                    <span class="lmzpb-dash__recent-lang"><?php echo $esc($z['language']); ?></span>
                                </a>
                                <time><?php echo HTMLHelper::_('date.relative', $z['modified']); ?></time>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <div class="lmzpb-dash__actions">
        <a class="btn btn-primary btn-sm" href="<?php echo Route::_('index.php?option=com_lmzpagebuilder&view=projects'); ?>">
            <span class="icon-list" aria-hidden="true"></span> <?php echo Text::_('MOD_LMZPAGEBUILDER_DASHBOARD_OPEN'); ?>
        </a>
        <a class="btn btn-outline-secondary btn-sm" href="<?php echo Route::_('index.php?option=com_lmzpagebuilder&view=templatesettings'); ?>">
            <span class="icon-picker" aria-hidden="true"></span> <?php echo Text::_('MOD_LMZPAGEBUILDER_DASHBOARD_TEMPLATE_SETTINGS'); ?>
        </a>
        <a class="btn btn-outline-secondary btn-sm" href="<?php echo Route::_('index.php?option=com_config&view=component&component=com_lmzpagebuilder'); ?>">
            <span class="icon-cog" aria-hidden="true"></span> <?php echo Text::_('MOD_LMZPAGEBUILDER_DASHBOARD_SETTINGS'); ?>
        </a>
    </div>
</div>

<style>
/* Volle Breite: das Widget ueberspannt alle Masonry-Spalten des Kontrollzentrums. */
.card-columns > .module-wrapper:has(.lmzpb-dash) { column-span: all; break-inside: avoid; width: 100%; }

.lmzpb-dash__grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 12px; }
.lmzpb-dash__tile {
    display: flex; flex-direction: column; gap: 2px; padding: 16px 16px 14px;
    border: 1px solid var(--template-bg-dark-7, #dee2e6); border-radius: 12px;
    background: var(--template-bg-light, #fff); text-decoration: none; color: inherit;
    position: relative; overflow: hidden; transition: transform .18s ease, box-shadow .18s ease, border-color .18s ease;
}
.lmzpb-dash__tile:hover { transform: translateY(-2px); border-color: #e4002b; box-shadow: 0 8px 22px -12px rgba(228,0,43,.5); }
.lmzpb-dash__tile-ico { position: absolute; top: 12px; right: 14px; font-size: 1.2rem; opacity: .26; }
.lmzpb-dash__tile-val { font-size: 2rem; font-weight: 800; line-height: 1; color: #e4002b; }
.lmzpb-dash__tile-lbl { font-size: .8rem; font-weight: 600; opacity: .82; }
.lmzpb-dash__tile-sub { font-size: .68rem; opacity: .6; }

.lmzpb-dash__cols { display: grid; grid-template-columns: 1.4fr 1fr; gap: 22px; margin-top: 20px; }
@media (max-width: 900px) { .lmzpb-dash__cols { grid-template-columns: 1fr; } }
.lmzpb-dash__panel-head, .lmzpb-dash__recent-head { font-size: .72rem; text-transform: uppercase; letter-spacing: .08em; opacity: .6; margin-bottom: 8px; }

.lmzpb-dash__table { width: 100%; border-collapse: collapse; font-size: .84rem; }
.lmzpb-dash__table th { text-align: left; font-size: .68rem; text-transform: uppercase; letter-spacing: .05em; opacity: .55; padding: 4px 8px; border-bottom: 1px solid rgba(0,0,0,.08); font-weight: 600; }
.lmzpb-dash__table td { padding: 8px; border-bottom: 1px solid rgba(0,0,0,.05); vertical-align: middle; }
.lmzpb-dash__table tr:last-child td { border-bottom: 0; }
.lmzpb-dash__table a { text-decoration: none; color: inherit; font-weight: 600; display: inline-flex; align-items: center; gap: 8px; }
.lmzpb-dash__table a:hover { color: #e4002b; }
.lmzpb-dash__num { text-align: right; white-space: nowrap; }
.lmzpb-dash__state { width: 8px; height: 8px; border-radius: 50%; flex: 0 0 auto; }
.lmzpb-dash__state.is-pub { background: #16a34a; }
.lmzpb-dash__state.is-unpub { background: #d1d5db; }
.lmzpb-dash__langbadge { font-size: .72rem; font-weight: 700; padding: 2px 8px; border-radius: 999px; }
.lmzpb-dash__langbadge.is-full { background: rgba(22,163,74,.12); color: #16a34a; }
.lmzpb-dash__langbadge.is-partial { background: rgba(228,0,43,.1); color: #e4002b; }
.lmzpb-dash__table time { opacity: .6; font-size: .76rem; }

.lmzpb-dash__cover-head { display: flex; justify-content: space-between; align-items: baseline; font-size: .8rem; margin-bottom: 5px; }
.lmzpb-dash__cover-head strong { font-size: 1.05rem; color: #e4002b; }
.lmzpb-dash__bar { height: 8px; border-radius: 999px; background: rgba(228,0,43,.12); overflow: hidden; }
.lmzpb-dash__bar span { display: block; height: 100%; border-radius: 999px; background: linear-gradient(90deg, #ff3355, #e4002b); transition: width .6s cubic-bezier(.19,1,.22,1); }
.lmzpb-dash__meta { display: flex; gap: 18px; margin-top: 8px; font-size: .74rem; opacity: .72; }

.lmzpb-dash__status { display: flex; flex-wrap: wrap; gap: 8px; margin-top: 16px; }
.lmzpb-dash__chip { display: inline-flex; align-items: center; gap: 6px; font-size: .74rem; font-weight: 600; padding: 4px 10px; border-radius: 999px; }
.lmzpb-dash__chip.is-on { background: rgba(22,163,74,.12); color: #16a34a; }
.lmzpb-dash__chip.is-off { background: rgba(0,0,0,.06); opacity: .7; }

.lmzpb-dash__recent { margin-top: 18px; }
.lmzpb-dash__recent ul { list-style: none; margin: 0; padding: 0; }
.lmzpb-dash__recent li { display: flex; align-items: center; justify-content: space-between; gap: 10px; padding: 6px 0; border-bottom: 1px solid rgba(0,0,0,.06); }
.lmzpb-dash__recent li:last-child { border-bottom: 0; }
.lmzpb-dash__recent a { display: flex; align-items: center; gap: 8px; text-decoration: none; color: inherit; min-width: 0; }
.lmzpb-dash__recent-title { font-weight: 600; font-size: .82rem; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.lmzpb-dash__recent-lang { font-size: .62rem; font-weight: 700; padding: 1px 6px; border-radius: 999px; background: rgba(228,0,43,.1); color: #e4002b; flex: 0 0 auto; }
.lmzpb-dash__recent time { font-size: .7rem; opacity: .55; flex: 0 0 auto; white-space: nowrap; }

.lmzpb-dash__actions { display: flex; gap: 8px; margin-top: 20px; flex-wrap: wrap; }
</style>
