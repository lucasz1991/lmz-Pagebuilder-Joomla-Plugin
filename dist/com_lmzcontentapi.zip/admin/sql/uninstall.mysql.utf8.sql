DROP TABLE IF EXISTS `#__lmzcontentapi_revisions`;
