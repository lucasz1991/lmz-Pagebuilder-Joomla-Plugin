CREATE TABLE IF NOT EXISTS `#__lmzcontentapi_revisions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `resource_type` varchar(64) NOT NULL,
  `resource_key` varchar(255) NOT NULL,
  `operation` varchar(32) NOT NULL,
  `before_payload` mediumtext NOT NULL,
  `before_hash` char(64) NOT NULL,
  `after_hash` char(64) NOT NULL,
  `note` varchar(255) NOT NULL DEFAULT '',
  `created_by` int unsigned NOT NULL DEFAULT 0,
  `created` datetime NOT NULL,
  `request_id` char(36) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_lmzcontentapi_resource` (`resource_type`, `resource_key`),
  KEY `idx_lmzcontentapi_created` (`created`),
  KEY `idx_lmzcontentapi_request` (`request_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;
