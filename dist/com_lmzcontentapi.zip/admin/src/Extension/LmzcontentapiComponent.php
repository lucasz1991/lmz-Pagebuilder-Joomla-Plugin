<?php

namespace LMZ\Component\Lmzcontentapi\Administrator\Extension;

defined('_JEXEC') or die;

use Joomla\CMS\Extension\MVCComponent;

final class LmzcontentapiComponent extends MVCComponent
{
}
