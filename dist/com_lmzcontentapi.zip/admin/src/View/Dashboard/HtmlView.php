<?php

namespace LMZ\Component\Lmzcontentapi\Administrator\View\Dashboard;

defined('_JEXEC') or die;

use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use Joomla\CMS\Toolbar\ToolbarHelper;

final class HtmlView extends BaseHtmlView
{
    public function display($tpl = null): void
    {
        ToolbarHelper::title('LMZ Content Studio API', 'pencil-alt');
        ToolbarHelper::preferences('com_lmzcontentapi');

        parent::display($tpl);
    }
}
