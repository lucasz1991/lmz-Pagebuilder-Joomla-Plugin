<?php

defined('_JEXEC') or die;

use Joomla\CMS\Language\Text;
use Joomla\CMS\Uri\Uri;

$apiRoot = rtrim(Uri::root(), '/') . '/api/index.php/v1';
?>
<div class="container-fluid">
    <div class="row">
        <div class="col-lg-8">
            <div class="card mb-4">
                <div class="card-body">
                    <h2 class="h4"><?php echo Text::_('COM_LMZCONTENTAPI_DASHBOARD_TITLE'); ?></h2>
                    <p><?php echo Text::_('COM_LMZCONTENTAPI_DASHBOARD_INTRO'); ?></p>
                    <dl class="row mb-0">
                        <dt class="col-sm-4"><?php echo Text::_('COM_LMZCONTENTAPI_DASHBOARD_API_ROOT'); ?></dt>
                        <dd class="col-sm-8"><code><?php echo htmlspecialchars($apiRoot, ENT_QUOTES, 'UTF-8'); ?></code></dd>
                        <dt class="col-sm-4"><?php echo Text::_('COM_LMZCONTENTAPI_DASHBOARD_AUTH'); ?></dt>
                        <dd class="col-sm-8"><?php echo Text::_('COM_LMZCONTENTAPI_DASHBOARD_AUTH_VALUE'); ?></dd>
                    </dl>
                </div>
            </div>
            <div class="alert alert-info" role="status">
                <?php echo Text::_('COM_LMZCONTENTAPI_DASHBOARD_SECURITY'); ?>
            </div>
        </div>
    </div>
</div>
