<?php

namespace LMZ\Component\Lmzstudiomodules\Administrator\View\Maps;

defined('_JEXEC') or die;

use Joomla\CMS\Helper\ContentHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\View\GenericDataException;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use Joomla\CMS\Toolbar\ToolbarHelper;

final class HtmlView extends BaseHtmlView
{
    protected array $items = [];
    protected $pagination;
    protected $state;

    public function display($tpl = null): void
    {
        $model = $this->getModel();
        $this->items = $model->getItems();
        $this->pagination = $model->getPagination();
        $this->state = $model->getState();

        if (count($errors = $model->getErrors())) {
            throw new GenericDataException(implode("\n", $errors), 500);
        }

        $this->addToolbar();
        parent::display($tpl);
    }

    private function addToolbar(): void
    {
        $canDo = ContentHelper::getActions('com_lmzstudiomodules');
        ToolbarHelper::title(Text::_('COM_LMZSTUDIOMODULES_MANAGER_MAPS'), 'location');

        if ($canDo->get('core.create')) {
            ToolbarHelper::addNew('map.add');
        }

        if ($canDo->get('core.edit.state')) {
            ToolbarHelper::publishList('maps.publish');
            ToolbarHelper::unpublishList('maps.unpublish');
            ToolbarHelper::checkin('maps.checkin');
        }

        if ($canDo->get('core.delete')) {
            ToolbarHelper::deleteList(
                Text::_('COM_LMZSTUDIOMODULES_CONFIRM_DELETE'),
                'maps.delete'
            );
        }

        if ($canDo->get('core.admin') || $canDo->get('core.options')) {
            ToolbarHelper::preferences('com_lmzstudiomodules');
        }
    }
}
