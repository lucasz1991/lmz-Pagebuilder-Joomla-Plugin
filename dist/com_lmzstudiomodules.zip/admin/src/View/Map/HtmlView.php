<?php

namespace LMZ\Component\Lmzstudiomodules\Administrator\View\Map;

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Helper\ContentHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\View\GenericDataException;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use Joomla\CMS\Toolbar\Toolbar;
use Joomla\CMS\Toolbar\ToolbarHelper;
use Joomla\Database\DatabaseInterface;
use Joomla\Database\ParameterType;

final class HtmlView extends BaseHtmlView
{
    protected $form;
    protected $item;
    protected $state;
    protected array $languages = [];

    public function display($tpl = null): void
    {
        $model = $this->getModel();
        $this->form = $model->getForm();
        $this->item = $model->getItem();
        $this->state = $model->getState();
        $this->languages = $this->getPublishedLanguages();

        if (count($errors = $model->getErrors())) {
            throw new GenericDataException(implode("\n", $errors), 500);
        }

        $this->addToolbar();
        parent::display($tpl);
    }

    private function addToolbar(): void
    {
        Factory::getApplication()->getInput()->set('hidemainmenu', true);
        $canDo = ContentHelper::getActions('com_lmzstudiomodules');
        $isNew = (int) $this->item->id === 0;
        $toolbar = $this->getDocument()->getToolbar();
        ToolbarHelper::title(
            $isNew
                ? Text::_('COM_LMZSTUDIOMODULES_MANAGER_MAP_NEW')
                : Text::_('COM_LMZSTUDIOMODULES_MANAGER_MAP_EDIT'),
            'location'
        );

        if (($isNew && $canDo->get('core.create')) || (!$isNew && $canDo->get('core.edit'))) {
            $toolbar->apply('map.apply');
            $saveGroup = $toolbar->dropdownButton('save-group');
            $saveGroup->configure(static function (Toolbar $childBar) use ($canDo): void {
                $childBar->save('map.save');

                if ($canDo->get('core.create')) {
                    $childBar->save2new('map.save2new');
                }
            });
        }

        $toolbar->cancel('map.cancel', $isNew ? 'JTOOLBAR_CANCEL' : 'JTOOLBAR_CLOSE');
    }

    private function getPublishedLanguages(): array
    {
        $db = Factory::getContainer()->get(DatabaseInterface::class);
        $published = 1;
        $query = $db->getQuery(true)
            ->select([
                $db->quoteName('lang_code'),
                $db->quoteName('title'),
                $db->quoteName('title_native'),
                $db->quoteName('image'),
            ])
            ->from($db->quoteName('#__languages'))
            ->where($db->quoteName('published') . ' = :published')
            ->order($db->quoteName('ordering') . ' ASC')
            ->bind(':published', $published, ParameterType::INTEGER);
        $db->setQuery($query);
        $languages = $db->loadAssocList();

        if ($languages === []) {
            $tag = Factory::getApplication()->getLanguage()->getTag();
            $languages[] = [
                'lang_code' => $tag,
                'title' => $tag,
                'title_native' => $tag,
                'image' => '',
            ];
        }

        return $languages;
    }
}
