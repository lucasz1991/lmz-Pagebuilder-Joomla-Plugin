<?php

namespace LMZ\Component\Lmzstudiomodules\Administrator\Extension;

defined('_JEXEC') or die;

use Joomla\CMS\Extension\MVCComponent;

final class LmzstudiomodulesComponent extends MVCComponent
{
}
