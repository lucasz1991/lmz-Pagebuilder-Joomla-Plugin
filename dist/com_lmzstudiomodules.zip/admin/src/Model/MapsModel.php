<?php

namespace LMZ\Component\Lmzstudiomodules\Administrator\Model;

defined('_JEXEC') or die;

use Joomla\CMS\MVC\Model\ListModel;
use Joomla\Database\ParameterType;
use Joomla\Database\QueryInterface;

final class MapsModel extends ListModel
{
    public function __construct($config = [], $factory = null)
    {
        if (empty($config['filter_fields'])) {
            $config['filter_fields'] = [
                'id', 'm.id',
                'title', 'm.title',
                'state', 'm.state',
                'ordering', 'm.ordering',
                'theme', 'm.theme',
                'modified', 'm.modified',
            ];
        }

        parent::__construct($config, $factory);
    }

    protected function populateState($ordering = 'm.ordering', $direction = 'ASC'): void
    {
        $this->setState('filter.search', $this->getUserStateFromRequest(
            $this->context . '.filter.search',
            'filter_search',
            '',
            'string'
        ));
        $this->setState('filter.state', $this->getUserStateFromRequest(
            $this->context . '.filter.state',
            'filter_state',
            '',
            'string'
        ));

        parent::populateState($ordering, $direction);
    }

    protected function getListQuery(): QueryInterface
    {
        $db = $this->getDatabase();
        $query = $db->getQuery(true)
            ->select([
                $db->quoteName('m.id'),
                $db->quoteName('m.title'),
                $db->quoteName('m.alias'),
                $db->quoteName('m.state'),
                $db->quoteName('m.access'),
                $db->quoteName('m.theme'),
                $db->quoteName('m.ordering'),
                $db->quoteName('m.checked_out'),
                $db->quoteName('m.checked_out_time'),
                $db->quoteName('m.modified'),
                $db->quoteName('u.name', 'editor'),
                '(SELECT COUNT(*) FROM ' . $db->quoteName('#__lmzstudio_map_locations', 'lc')
                    . ' WHERE ' . $db->quoteName('lc.map_id') . ' = ' . $db->quoteName('m.id') . ') AS '
                    . $db->quoteName('locations_count'),
                '(SELECT COUNT(*) FROM ' . $db->quoteName('#__lmzstudio_map_translations', 'tc')
                    . ' WHERE ' . $db->quoteName('tc.map_id') . ' = ' . $db->quoteName('m.id') . ') AS '
                    . $db->quoteName('translations_count'),
            ])
            ->from($db->quoteName('#__lmzstudio_maps', 'm'))
            ->join(
                'LEFT',
                $db->quoteName('#__users', 'u'),
                $db->quoteName('u.id') . ' = ' . $db->quoteName('m.checked_out')
            );

        $state = $this->getState('filter.state');

        if ($state !== '' && is_numeric($state)) {
            $state = (int) $state;
            $query->where($db->quoteName('m.state') . ' = :state')
                ->bind(':state', $state, ParameterType::INTEGER);
        } else {
            $query->where($db->quoteName('m.state') . ' IN (0, 1)');
        }

        $search = trim((string) $this->getState('filter.search'));

        if ($search !== '') {
            if (str_starts_with(strtolower($search), 'id:')) {
                $id = (int) substr($search, 3);
                $query->where($db->quoteName('m.id') . ' = :id')
                    ->bind(':id', $id, ParameterType::INTEGER);
            } else {
                $search = '%' . str_replace(' ', '%', $search) . '%';
                $query->where(
                    '(' . $db->quoteName('m.title') . ' LIKE :searchTitle'
                    . ' OR ' . $db->quoteName('m.alias') . ' LIKE :searchAlias)'
                )
                    ->bind(':searchTitle', $search)
                    ->bind(':searchAlias', $search);
            }
        }

        $order = $this->state->get('list.ordering', 'm.ordering');
        $direction = strtoupper((string) $this->state->get('list.direction', 'ASC')) === 'DESC' ? 'DESC' : 'ASC';
        $query->order($db->escape($order) . ' ' . $direction)
            ->order($db->quoteName('m.id') . ' ASC');

        return $query;
    }
}
