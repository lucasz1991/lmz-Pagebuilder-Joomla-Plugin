<?php

namespace LMZ\Component\Lmzstudiomodules\Administrator\Model;

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Form\Form;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Model\AdminModel;
use Joomla\CMS\Table\Table;
use Joomla\Database\ParameterType;
use Joomla\String\StringHelper;
use RuntimeException;

final class MapModel extends AdminModel
{
    protected $text_prefix = 'COM_LMZSTUDIOMODULES_MAP';

    public function getTable($type = 'Map', $prefix = 'Administrator', $config = []): Table
    {
        return parent::getTable($type, $prefix, $config);
    }

    public function getForm($data = [], $loadData = true): Form|false
    {
        return $this->loadForm(
            'com_lmzstudiomodules.map',
            'map',
            ['control' => 'jform', 'load_data' => $loadData]
        );
    }

    protected function loadFormData(): array|object
    {
        $app = Factory::getApplication();
        $data = $app->getUserState('com_lmzstudiomodules.edit.map.data', []);

        if (empty($data)) {
            $data = $this->getItem();
        }

        return $data;
    }

    public function getItem($pk = null)
    {
        $item = parent::getItem($pk);

        if (!$item) {
            return $item;
        }

        $item->translations_json = '{}';
        $item->locations_json = '[]';

        if ((int) $item->id === 0) {
            return $item;
        }

        $db = $this->getDatabase();
        $mapId = (int) $item->id;
        $query = $db->getQuery(true)
            ->select('*')
            ->from($db->quoteName('#__lmzstudio_map_translations'))
            ->where($db->quoteName('map_id') . ' = :mapId')
            ->order($db->quoteName('language') . ' ASC')
            ->bind(':mapId', $mapId, ParameterType::INTEGER);
        $db->setQuery($query);

        $translations = [];

        foreach ($db->loadAssocList() as $translation) {
            $language = (string) $translation['language'];
            $translations[$language] = [
                'title' => (string) $translation['title'],
                'eyebrow' => (string) $translation['eyebrow'],
                'intro' => (string) $translation['intro'],
                'note' => (string) $translation['note'],
            ];
        }

        $query = $db->getQuery(true)
            ->select('*')
            ->from($db->quoteName('#__lmzstudio_map_locations'))
            ->where($db->quoteName('map_id') . ' = :mapId')
            ->order($db->quoteName('ordering') . ' ASC, ' . $db->quoteName('id') . ' ASC')
            ->bind(':mapId', $mapId, ParameterType::INTEGER);
        $db->setQuery($query);
        $locations = $db->loadAssocList();
        $locationIds = array_map(static fn (array $row): int => (int) $row['id'], $locations);
        $locationTranslations = [];

        if ($locationIds !== []) {
            $query = $db->getQuery(true)
                ->select('*')
                ->from($db->quoteName('#__lmzstudio_map_location_translations'))
                ->where($db->quoteName('location_id') . ' IN (' . implode(',', $locationIds) . ')')
                ->order($db->quoteName('language') . ' ASC');
            $db->setQuery($query);

            foreach ($db->loadAssocList() as $translation) {
                $locationTranslations[(int) $translation['location_id']][(string) $translation['language']] = [
                    'name' => (string) $translation['name'],
                    'description' => (string) $translation['description'],
                    'label' => (string) $translation['label'],
                    'address' => (string) $translation['address'],
                ];
            }
        }

        $normalizedLocations = [];

        foreach ($locations as $location) {
            $id = (int) $location['id'];
            $normalizedLocations[] = [
                'id' => $id,
                'state_code' => (string) $location['state_code'],
                'x_percent' => (float) $location['x_percent'],
                'y_percent' => (float) $location['y_percent'],
                'tooltip_position' => (string) $location['tooltip_position'],
                'marker_label' => (string) $location['marker_label'],
                'is_headquarters' => (bool) $location['is_headquarters'],
                'is_default' => (bool) $location['is_default'],
                'state' => (int) $location['state'],
                'ordering' => (int) $location['ordering'],
                'translations' => $locationTranslations[$id] ?? [],
            ];
        }

        $item->translations_json = json_encode(
            $translations,
            JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR
        );
        $item->locations_json = json_encode(
            $normalizedLocations,
            JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR
        );

        return $item;
    }

    public function save($data): bool
    {
        try {
            $translations = $this->normalizeMapTranslations((string) ($data['translations_json'] ?? '{}'));
            $locations = $this->normalizeLocations((string) ($data['locations_json'] ?? '[]'));
        } catch (RuntimeException $exception) {
            $this->setError($exception->getMessage());

            return false;
        }

        unset($data['translations_json'], $data['locations_json']);
        $db = $this->getDatabase();

        try {
            $db->transactionStart();

            if (!parent::save($data)) {
                $db->transactionRollback();

                return false;
            }

            $mapId = (int) $this->getState($this->getName() . '.id');

            if ($mapId <= 0) {
                throw new RuntimeException(Text::_('COM_LMZSTUDIOMODULES_ERROR_SAVE_ID'));
            }

            $query = $db->getQuery(true)
                ->delete($db->quoteName('#__lmzstudio_map_translations'))
                ->where($db->quoteName('map_id') . ' = :mapId')
                ->bind(':mapId', $mapId, ParameterType::INTEGER);
            $db->setQuery($query)->execute();

            foreach ($translations as $language => $translation) {
                $record = (object) array_merge(
                    ['map_id' => $mapId, 'language' => $language],
                    $translation
                );
                $db->insertObject('#__lmzstudio_map_translations', $record);
            }

            $query = $db->getQuery(true)
                ->delete($db->quoteName('#__lmzstudio_map_locations'))
                ->where($db->quoteName('map_id') . ' = :mapId')
                ->bind(':mapId', $mapId, ParameterType::INTEGER);
            $db->setQuery($query)->execute();

            foreach ($locations as $ordering => $location) {
                $locationTranslations = $location['translations'];
                unset($location['translations'], $location['id']);
                $record = (object) array_merge(
                    ['map_id' => $mapId, 'ordering' => $ordering + 1],
                    $location
                );
                $db->insertObject('#__lmzstudio_map_locations', $record, 'id');
                $locationId = (int) $record->id;

                foreach ($locationTranslations as $language => $translation) {
                    $translationRecord = (object) array_merge(
                        ['location_id' => $locationId, 'language' => $language],
                        $translation
                    );
                    $db->insertObject('#__lmzstudio_map_location_translations', $translationRecord);
                }
            }

            $db->transactionCommit();
        } catch (\Throwable $exception) {
            $db->transactionRollback();
            $this->setError($exception->getMessage());

            return false;
        }

        return true;
    }

    protected function prepareTable($table): void
    {
        $date = Factory::getDate()->toSql();
        $userId = (int) Factory::getApplication()->getIdentity()->id;

        if (empty($table->id)) {
            $table->created = $date;
            $table->created_by = $userId;

            if ((int) $table->ordering === 0) {
                $table->ordering = (int) $table->getNextOrder();
            }
        } else {
            $table->modified = $date;
            $table->modified_by = $userId;
        }
    }

    protected function canDelete($record): bool
    {
        $user = Factory::getApplication()->getIdentity();

        return $user->authorise('core.manage', 'com_lmzstudiomodules')
            && $user->authorise('core.delete', 'com_lmzstudiomodules');
    }

    protected function canEditState($record): bool
    {
        $user = Factory::getApplication()->getIdentity();

        return $user->authorise('core.manage', 'com_lmzstudiomodules')
            && $user->authorise('core.edit.state', 'com_lmzstudiomodules');
    }

    private function normalizeMapTranslations(string $json): array
    {
        $decoded = json_decode($json, true);

        if (!is_array($decoded)) {
            throw new RuntimeException(Text::_('COM_LMZSTUDIOMODULES_ERROR_TRANSLATIONS_JSON'));
        }

        if (count($decoded) > 100) {
            throw new RuntimeException(Text::_('COM_LMZSTUDIOMODULES_ERROR_TOO_MANY_LANGUAGES'));
        }

        $normalized = [];

        foreach ($decoded as $language => $translation) {
            $language = $this->normalizeLanguage((string) $language);

            if (!is_array($translation)) {
                continue;
            }

            $normalized[$language] = [
                'title' => $this->plainText($translation['title'] ?? '', 255),
                'eyebrow' => $this->plainText($translation['eyebrow'] ?? '', 255),
                'intro' => $this->plainText($translation['intro'] ?? '', 4000),
                'note' => $this->plainText($translation['note'] ?? '', 4000),
            ];
        }

        if ($normalized === []) {
            throw new RuntimeException(Text::_('COM_LMZSTUDIOMODULES_ERROR_TRANSLATION_REQUIRED'));
        }

        return $normalized;
    }

    private function normalizeLocations(string $json): array
    {
        $decoded = json_decode($json, true);

        if (!is_array($decoded)) {
            throw new RuntimeException(Text::_('COM_LMZSTUDIOMODULES_ERROR_LOCATIONS_JSON'));
        }

        if (count($decoded) > 500) {
            throw new RuntimeException(Text::_('COM_LMZSTUDIOMODULES_ERROR_TOO_MANY_LOCATIONS'));
        }

        $normalized = [];
        $headquartersCount = 0;
        $defaultCount = 0;

        foreach ($decoded as $location) {
            if (!is_array($location)) {
                continue;
            }

            $stateCode = strtoupper(trim((string) ($location['state_code'] ?? '')));

            if ($stateCode !== '' && !preg_match('/^[A-Z]{2}-[A-Z0-9]{1,4}$/', $stateCode)) {
                throw new RuntimeException(Text::_('COM_LMZSTUDIOMODULES_ERROR_STATE_CODE'));
            }

            $x = filter_var($location['x_percent'] ?? null, FILTER_VALIDATE_FLOAT);
            $y = filter_var($location['y_percent'] ?? null, FILTER_VALIDATE_FLOAT);

            if ($x === false || $y === false || $x < 0 || $x > 100 || $y < 0 || $y > 100) {
                throw new RuntimeException(Text::_('COM_LMZSTUDIOMODULES_ERROR_COORDINATES'));
            }

            $tooltipPosition = (string) ($location['tooltip_position'] ?? 'auto');
            $tooltipPosition = in_array($tooltipPosition, ['auto', 'top', 'bottom'], true)
                ? $tooltipPosition
                : 'auto';
            $isHeadquarters = !empty($location['is_headquarters']) ? 1 : 0;
            $isDefault = !empty($location['is_default']) ? 1 : 0;
            $headquartersCount += $isHeadquarters;
            $defaultCount += $isDefault;
            $translations = [];

            foreach (($location['translations'] ?? []) as $language => $translation) {
                $language = $this->normalizeLanguage((string) $language);

                if (!is_array($translation)) {
                    continue;
                }

                $name = $this->plainText($translation['name'] ?? '', 255);

                if ($name === '') {
                    continue;
                }

                $translations[$language] = [
                    'name' => $name,
                    'description' => $this->plainText($translation['description'] ?? '', 500),
                    'label' => $this->plainText($translation['label'] ?? '', 255),
                    'address' => $this->plainText($translation['address'] ?? '', 500),
                ];
            }

            if ($translations === []) {
                throw new RuntimeException(Text::_('COM_LMZSTUDIOMODULES_ERROR_LOCATION_TRANSLATION_REQUIRED'));
            }

            $normalized[] = [
                'id' => (int) ($location['id'] ?? 0),
                'state_code' => $stateCode,
                'x_percent' => round((float) $x, 4),
                'y_percent' => round((float) $y, 4),
                'tooltip_position' => $tooltipPosition,
                'marker_label' => $this->plainText($location['marker_label'] ?? 'RT', 12) ?: 'RT',
                'is_headquarters' => $isHeadquarters,
                'is_default' => $isDefault,
                'state' => (int) !empty($location['state']),
                'translations' => $translations,
            ];
        }

        if ($headquartersCount > 1) {
            throw new RuntimeException(Text::_('COM_LMZSTUDIOMODULES_ERROR_ONE_HEADQUARTERS'));
        }

        if ($defaultCount > 1) {
            throw new RuntimeException(Text::_('COM_LMZSTUDIOMODULES_ERROR_ONE_DEFAULT'));
        }

        if ($normalized !== [] && $defaultCount === 0) {
            $normalized[0]['is_default'] = 1;
        }

        return $normalized;
    }

    private function normalizeLanguage(string $language): string
    {
        $language = trim($language);

        if ($language !== '*' && !preg_match('/^[a-z]{2,3}-[A-Z]{2}$/', $language)) {
            throw new RuntimeException(Text::_('COM_LMZSTUDIOMODULES_ERROR_LANGUAGE'));
        }

        return $language;
    }

    private function plainText(mixed $value, int $maxLength): string
    {
        $value = trim(strip_tags((string) $value));
        $value = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', $value) ?? '';

        return StringHelper::substr($value, 0, $maxLength);
    }
}
