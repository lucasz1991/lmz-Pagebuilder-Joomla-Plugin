<?php

namespace LMZ\Component\Lmzstudiomodules\Administrator\Table;

defined('_JEXEC') or die;

use Joomla\CMS\Filter\OutputFilter;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Table\Table;
use Joomla\Database\DatabaseDriver;
use Joomla\Database\ParameterType;

final class MapTable extends Table
{
    public function __construct(DatabaseDriver $db)
    {
        parent::__construct('#__lmzstudio_maps', 'id', $db);

        $this->setColumnAlias('published', 'state');
    }

    public function check(): bool
    {
        $this->title = trim((string) $this->title);

        if ($this->title === '') {
            $this->setError(Text::_('COM_LMZSTUDIOMODULES_ERROR_TITLE_REQUIRED'));

            return false;
        }

        $this->alias = trim((string) $this->alias);
        $this->alias = OutputFilter::stringURLSafe($this->alias !== '' ? $this->alias : $this->title);

        if ($this->alias === '') {
            $this->alias = (string) time();
        }

        $themes = ['default', 'gray', 'red', 'blue', 'green', 'custom'];
        $this->theme = in_array((string) $this->theme, $themes, true) ? (string) $this->theme : 'default';

        foreach (['color_background', 'color_map', 'color_accent', 'color_text', 'color_surface'] as $field) {
            $value = strtoupper(trim((string) $this->{$field}));

            if (!preg_match('/^#[0-9A-F]{6}$/', $value)) {
                $this->setError(Text::sprintf('COM_LMZSTUDIOMODULES_ERROR_INVALID_COLOR', $field));

                return false;
            }

            $this->{$field} = $value;
        }

        $db = $this->getDbo();
        $query = $db->getQuery(true)
            ->select($db->quoteName('id'))
            ->from($db->quoteName('#__lmzstudio_maps'))
            ->where($db->quoteName('alias') . ' = :alias')
            ->where($db->quoteName('id') . ' <> :id')
            ->bind(':alias', $this->alias)
            ->bind(':id', $this->id, ParameterType::INTEGER);
        $db->setQuery($query);

        if ((int) $db->loadResult() > 0) {
            $this->setError(Text::_('COM_LMZSTUDIOMODULES_ERROR_ALIAS_EXISTS'));

            return false;
        }

        return parent::check();
    }
}
