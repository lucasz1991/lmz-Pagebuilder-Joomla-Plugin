<?php

namespace LMZ\Component\Lmzstudiomodules\Administrator\Controller;

defined('_JEXEC') or die;

use Joomla\CMS\MVC\Controller\AdminController;

final class MapsController extends AdminController
{
    protected $text_prefix = 'COM_LMZSTUDIOMODULES_MAPS';

    public function getModel($name = 'Map', $prefix = 'Administrator', $config = ['ignore_request' => true])
    {
        return parent::getModel($name, $prefix, $config);
    }
}
