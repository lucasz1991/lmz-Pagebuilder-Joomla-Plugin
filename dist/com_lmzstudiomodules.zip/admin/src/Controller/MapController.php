<?php

namespace LMZ\Component\Lmzstudiomodules\Administrator\Controller;

defined('_JEXEC') or die;

use Joomla\CMS\MVC\Controller\FormController;

final class MapController extends FormController
{
    protected $text_prefix = 'COM_LMZSTUDIOMODULES_MAP';

    protected function allowAdd($data = []): bool
    {
        $user = $this->app->getIdentity();

        return $user->authorise('core.manage', 'com_lmzstudiomodules')
            && $user->authorise('core.create', 'com_lmzstudiomodules');
    }

    protected function allowEdit($data = [], $key = 'id'): bool
    {
        $user = $this->app->getIdentity();

        return $user->authorise('core.manage', 'com_lmzstudiomodules')
            && $user->authorise('core.edit', 'com_lmzstudiomodules');
    }
}
