UPDATE `#__lmzstudio_maps`
SET `color_background` = '#F7F8F5',
    `color_text` = '#10151B'
WHERE `theme` = 'default'
  AND `color_background` = '#101820'
  AND `color_text` = '#FFFFFF';
