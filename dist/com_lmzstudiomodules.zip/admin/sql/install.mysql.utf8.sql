CREATE TABLE IF NOT EXISTS `#__lmzstudio_maps` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `alias` varchar(191) NOT NULL,
  `state` tinyint NOT NULL DEFAULT 1,
  `access` int unsigned NOT NULL DEFAULT 1,
  `theme` varchar(32) NOT NULL DEFAULT 'default',
  `color_background` char(7) NOT NULL DEFAULT '#F7F8F5',
  `color_map` char(7) NOT NULL DEFAULT '#E7EAD0',
  `color_accent` char(7) NOT NULL DEFAULT '#E51F2B',
  `color_text` char(7) NOT NULL DEFAULT '#10151B',
  `color_surface` char(7) NOT NULL DEFAULT '#FFFFFF',
  `ordering` int NOT NULL DEFAULT 0,
  `checked_out` int unsigned DEFAULT NULL,
  `checked_out_time` datetime DEFAULT NULL,
  `created` datetime NOT NULL,
  `created_by` int unsigned NOT NULL DEFAULT 0,
  `modified` datetime DEFAULT NULL,
  `modified_by` int unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_lmzstudio_maps_alias` (`alias`),
  KEY `idx_lmzstudio_maps_state_access` (`state`,`access`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__lmzstudio_map_translations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `map_id` int unsigned NOT NULL,
  `language` varchar(12) NOT NULL,
  `title` varchar(255) NOT NULL DEFAULT '',
  `eyebrow` varchar(255) NOT NULL DEFAULT '',
  `intro` text NOT NULL,
  `note` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_lmzstudio_map_translation` (`map_id`,`language`),
  CONSTRAINT `fk_lmzstudio_map_translation_map` FOREIGN KEY (`map_id`) REFERENCES `#__lmzstudio_maps` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__lmzstudio_map_locations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `map_id` int unsigned NOT NULL,
  `state_code` varchar(12) NOT NULL DEFAULT '',
  `x_percent` decimal(7,4) NOT NULL DEFAULT 50.0000,
  `y_percent` decimal(7,4) NOT NULL DEFAULT 50.0000,
  `tooltip_position` varchar(12) NOT NULL DEFAULT 'auto',
  `marker_label` varchar(12) NOT NULL DEFAULT 'RT',
  `is_headquarters` tinyint NOT NULL DEFAULT 0,
  `is_default` tinyint NOT NULL DEFAULT 0,
  `state` tinyint NOT NULL DEFAULT 1,
  `ordering` int NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_lmzstudio_location_map_state` (`map_id`,`state`,`ordering`),
  CONSTRAINT `fk_lmzstudio_location_map` FOREIGN KEY (`map_id`) REFERENCES `#__lmzstudio_maps` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__lmzstudio_map_location_translations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `location_id` int unsigned NOT NULL,
  `language` varchar(12) NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `description` varchar(500) NOT NULL DEFAULT '',
  `label` varchar(255) NOT NULL DEFAULT '',
  `address` varchar(500) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_lmzstudio_location_translation` (`location_id`,`language`),
  CONSTRAINT `fk_lmzstudio_location_translation_location` FOREIGN KEY (`location_id`) REFERENCES `#__lmzstudio_map_locations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;
