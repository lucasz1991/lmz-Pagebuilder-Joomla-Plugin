DROP TABLE IF EXISTS `#__lmzstudio_map_location_translations`;
DROP TABLE IF EXISTS `#__lmzstudio_map_locations`;
DROP TABLE IF EXISTS `#__lmzstudio_map_translations`;
DROP TABLE IF EXISTS `#__lmzstudio_maps`;
