<?php

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Installer\Installer;
use Joomla\CMS\Installer\InstallerAdapter;
use Joomla\Database\DatabaseInterface;

final class Com_LmzstudiomodulesInstallerScript
{
    public function preflight(string $type, InstallerAdapter $parent): bool
    {
        if ($type === 'uninstall') {
            return true;
        }

        if (version_compare(JVERSION, '5.4.0', '<')) {
            Factory::getApplication()->enqueueMessage(
                'LMZ Studio Modules requires Joomla 5.4 or newer.',
                'error'
            );

            return false;
        }

        return true;
    }

    public function postflight(string $type, InstallerAdapter $parent): bool
    {
        if (!in_array($type, ['install', 'update'], true)) {
            return true;
        }

        $this->ensureSchema($parent);
        $this->seedDefaultMap($parent);

        return true;
    }

    private function ensureSchema(InstallerAdapter $parent): void
    {
        $sourcePath = (string) $parent->getParent()->getPath('source', '');
        $candidates = array_filter([
            __DIR__ . '/sql/install.mysql.utf8.sql',
            __DIR__ . '/admin/sql/install.mysql.utf8.sql',
            $sourcePath !== '' ? $sourcePath . '/admin/sql/install.mysql.utf8.sql' : '',
        ]);
        $path = '';

        foreach ($candidates as $candidate) {
            if (is_file($candidate)) {
                $path = $candidate;
                break;
            }
        }

        if ($path === '') {
            throw new RuntimeException('The LMZ Studio Modules schema file is missing.');
        }

        $db = Factory::getContainer()->get(DatabaseInterface::class);
        $sql = str_replace('#__', $db->getPrefix(), (string) file_get_contents($path));

        foreach (Installer::splitSql($sql) as $query) {
            if (trim($query) !== '') {
                $db->setQuery($query)->execute();
            }
        }
    }

    private function seedDefaultMap(InstallerAdapter $parent): void
    {
        $db = Factory::getContainer()->get(DatabaseInterface::class);
        $query = $db->getQuery(true)
            ->select('COUNT(*)')
            ->from($db->quoteName('#__lmzstudio_maps'));
        $db->setQuery($query);

        if ((int) $db->loadResult() > 0) {
            return;
        }

        $sourcePath = (string) $parent->getParent()->getPath('source', '');
        $candidates = array_filter([
            __DIR__ . '/data/default-map.json',
            __DIR__ . '/admin/data/default-map.json',
            $sourcePath !== '' ? $sourcePath . '/admin/data/default-map.json' : '',
        ]);
        $path = '';

        foreach ($candidates as $candidate) {
            if (is_file($candidate)) {
                $path = $candidate;
                break;
            }
        }

        if ($path === '') {
            throw new RuntimeException('The LMZ Studio Modules default map seed is missing.');
        }

        $payload = json_decode((string) file_get_contents($path), true, 512, JSON_THROW_ON_ERROR);
        $locations = $payload['locations'] ?? [];

        if (!is_array($locations) || $locations === []) {
            throw new RuntimeException('The LMZ Studio Modules default map seed contains no locations.');
        }

        $mapTranslations = [
            'de-DE' => [
                'title' => 'Deutschlandweit im Einsatz',
                'eyebrow' => 'Standortnetz',
                'intro' => 'Von Winsen (Luhe) aus koordinieren wir Einsätze im gesamten deutschen Schienennetz.',
                'note' => 'Die Markierungen zeigen eine Auswahl unserer Einsatzorte. Winsen (Luhe) ist der Hauptsitz.',
            ],
            'en-GB' => [
                'title' => 'Operating throughout Germany',
                'eyebrow' => 'Location network',
                'intro' => 'From Winsen (Luhe), we coordinate operations throughout the German rail network.',
                'note' => 'The markers show a selection of our project locations. Winsen (Luhe) is our headquarters.',
            ],
            'pl-PL' => [
                'title' => 'Działamy w całych Niemczech',
                'eyebrow' => 'Sieć lokalizacji',
                'intro' => 'Z Winsen (Luhe) koordynujemy działania w całej niemieckiej sieci kolejowej.',
                'note' => 'Znaczniki pokazują wybrane miejsca realizacji zleceń. Winsen (Luhe) jest siedzibą główną.',
            ],
        ];
        $mapTranslations['*'] = $mapTranslations['en-GB'];

        $stateNames = [
            'de-DE' => [
                'DE-SH' => 'Schleswig-Holstein',
                'DE-MV' => 'Mecklenburg-Vorpommern',
                'DE-NI' => 'Niedersachsen',
                'DE-HB' => 'Bremen',
                'DE-HH' => 'Hamburg',
                'DE-NW' => 'Nordrhein-Westfalen',
                'DE-ST' => 'Sachsen-Anhalt',
                'DE-BB' => 'Brandenburg',
                'DE-BE' => 'Berlin',
                'DE-SN' => 'Sachsen',
                'DE-HE' => 'Hessen',
                'DE-RP' => 'Rheinland-Pfalz',
                'DE-TH' => 'Thüringen',
                'DE-BW' => 'Baden-Württemberg',
                'DE-BY' => 'Bayern',
            ],
            'en-GB' => [
                'DE-SH' => 'Schleswig-Holstein',
                'DE-MV' => 'Mecklenburg-Western Pomerania',
                'DE-NI' => 'Lower Saxony',
                'DE-HB' => 'Bremen',
                'DE-HH' => 'Hamburg',
                'DE-NW' => 'North Rhine-Westphalia',
                'DE-ST' => 'Saxony-Anhalt',
                'DE-BB' => 'Brandenburg',
                'DE-BE' => 'Berlin',
                'DE-SN' => 'Saxony',
                'DE-HE' => 'Hesse',
                'DE-RP' => 'Rhineland-Palatinate',
                'DE-TH' => 'Thuringia',
                'DE-BW' => 'Baden-Württemberg',
                'DE-BY' => 'Bavaria',
            ],
            'pl-PL' => [
                'DE-SH' => 'Szlezwik-Holsztyn',
                'DE-MV' => 'Meklemburgia-Pomorze Przednie',
                'DE-NI' => 'Dolna Saksonia',
                'DE-HB' => 'Brema',
                'DE-HH' => 'Hamburg',
                'DE-NW' => 'Nadrenia Północna-Westfalia',
                'DE-ST' => 'Saksonia-Anhalt',
                'DE-BB' => 'Brandenburgia',
                'DE-BE' => 'Berlin',
                'DE-SN' => 'Saksonia',
                'DE-HE' => 'Hesja',
                'DE-RP' => 'Nadrenia-Palatynat',
                'DE-TH' => 'Turyngia',
                'DE-BW' => 'Badenia-Wirtembergia',
                'DE-BY' => 'Bawaria',
            ],
        ];
        $stateNames['*'] = $stateNames['en-GB'];

        $labels = [
            'de-DE' => ['location' => 'RT Rail Time Einsatzort', 'headquarters' => 'Hauptsitz'],
            'en-GB' => ['location' => 'RT Rail Time project location', 'headquarters' => 'Headquarters'],
            'pl-PL' => ['location' => 'Lokalizacja realizacji zlecenia RT Rail Time', 'headquarters' => 'Siedziba główna'],
            '*' => ['location' => 'RT Rail Time project location', 'headquarters' => 'Headquarters'],
        ];
        $date = Factory::getDate()->toSql();

        try {
            $db->transactionStart();
            $map = (object) [
                'title' => 'RailTime Deutschlandkarte',
                'alias' => 'railtime-deutschlandkarte',
                'state' => 1,
                'access' => 1,
                'theme' => 'default',
                'color_background' => '#F7F8F5',
                'color_map' => '#E7EAD0',
                'color_accent' => '#E51F2B',
                'color_text' => '#10151B',
                'color_surface' => '#FFFFFF',
                'ordering' => 1,
                'checked_out' => null,
                'checked_out_time' => null,
                'created' => $date,
                'created_by' => 0,
                'modified' => null,
                'modified_by' => 0,
            ];
            $db->insertObject('#__lmzstudio_maps', $map, 'id');
            $mapId = (int) $map->id;

            foreach ($mapTranslations as $language => $translation) {
                $record = (object) array_merge(
                    ['map_id' => $mapId, 'language' => $language],
                    $translation
                );
                $db->insertObject('#__lmzstudio_map_translations', $record);
            }

            foreach (array_values($locations) as $index => $location) {
                $isHeadquarters = !empty($location['is_headquarters']);
                $record = (object) [
                    'map_id' => $mapId,
                    'state_code' => (string) ($location['state_code'] ?? ''),
                    'x_percent' => (float) ($location['x_percent'] ?? 50),
                    'y_percent' => (float) ($location['y_percent'] ?? 50),
                    'tooltip_position' => (string) ($location['tooltip_position'] ?? 'auto'),
                    'marker_label' => (string) ($location['marker_label'] ?? 'RT'),
                    'is_headquarters' => (int) $isHeadquarters,
                    'is_default' => (int) !empty($location['is_default']),
                    'state' => 1,
                    'ordering' => $index + 1,
                ];
                $db->insertObject('#__lmzstudio_map_locations', $record, 'id');
                $locationId = (int) $record->id;
                $stateCode = (string) ($location['state_code'] ?? '');

                foreach (['de-DE', 'en-GB', 'pl-PL', '*'] as $language) {
                    $translationRecord = (object) [
                        'location_id' => $locationId,
                        'language' => $language,
                        'name' => (string) ($location['name'] ?? ''),
                        'description' => (string) ($stateNames[$language][$stateCode] ?? $stateCode),
                        'label' => $isHeadquarters
                            ? $labels[$language]['headquarters']
                            : $labels[$language]['location'],
                        'address' => $isHeadquarters
                            ? 'Borsteler Weg 29–31 · 21423 Winsen (Luhe)'
                            : '',
                    ];
                    $db->insertObject('#__lmzstudio_map_location_translations', $translationRecord);
                }
            }

            $db->transactionCommit();
        } catch (Throwable $exception) {
            $db->transactionRollback();
            throw $exception;
        }
    }
}
