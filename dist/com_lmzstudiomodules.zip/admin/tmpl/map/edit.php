<?php

defined('_JEXEC') or die;

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;

/** @var \LMZ\Component\Lmzstudiomodules\Administrator\View\Map\HtmlView $this */

$wa = $this->getDocument()->getWebAssetManager();
$wa->useScript('keepalive')
    ->useScript('form.validate')
    ->useStyle('com_lmzstudiomodules.admin')
    ->useScript('com_lmzstudiomodules.admin-editor');

$languages = array_map(
    static fn (array $language): array => [
        'code' => (string) $language['lang_code'],
        'title' => (string) ($language['title_native'] ?: $language['title']),
    ],
    $this->languages
);
$editorConfig = [
    'languages' => $languages,
    'newLocation' => Text::_('COM_LMZSTUDIOMODULES_NEW_LOCATION'),
    'confirmDelete' => Text::_('COM_LMZSTUDIOMODULES_CONFIRM_LOCATION_DELETE'),
    'emptyLocations' => Text::_('COM_LMZSTUDIOMODULES_NO_LOCATIONS'),
];
?>
<form action="<?php echo Route::_('index.php?option=com_lmzstudiomodules&layout=edit&id=' . (int) $this->item->id); ?>"
      method="post"
      name="adminForm"
      id="map-form"
      class="form-validate"
      aria-label="<?php echo Text::_('COM_LMZSTUDIOMODULES_MAP_EDITOR'); ?>">
    <div class="lmzstudio-editor"
         data-lmz-map-editor
         data-config="<?php echo htmlspecialchars(json_encode($editorConfig, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR), ENT_QUOTES, 'UTF-8'); ?>">
        <div class="lmzstudio-editor__topbar">
            <div>
                <span class="lmzstudio-kicker"><?php echo Text::_('COM_LMZSTUDIOMODULES_MAP_EDITOR'); ?></span>
                <h2><?php echo Text::_('COM_LMZSTUDIOMODULES_EDITOR_HEADING'); ?></h2>
                <p><?php echo Text::_('COM_LMZSTUDIOMODULES_EDITOR_INTRO'); ?></p>
            </div>
            <button type="button" class="btn btn-primary" data-action="add-location">
                <span class="icon-plus" aria-hidden="true"></span>
                <?php echo Text::_('COM_LMZSTUDIOMODULES_ADD_LOCATION'); ?>
            </button>
        </div>

        <div class="lmzstudio-editor__grid">
            <section class="lmzstudio-panel lmzstudio-panel--preview" aria-labelledby="lmz-map-preview-title">
                <div class="lmzstudio-panel__heading">
                    <div>
                        <span><?php echo Text::_('COM_LMZSTUDIOMODULES_LIVE_PREVIEW'); ?></span>
                        <h3 id="lmz-map-preview-title" data-map-preview-title></h3>
                    </div>
                    <span class="badge bg-info text-dark" data-location-count>0</span>
                </div>
                <div class="lmzstudio-map-preview" data-map-stage data-theme="default">
                    <img src="../media/com_lmzstudiomodules/images/germany-states.svg"
                         alt=""
                         class="lmzstudio-map-preview__base"
                         draggable="false">
                    <div class="lmzstudio-map-preview__tint" aria-hidden="true"></div>
                    <div class="lmzstudio-map-preview__markers" data-map-markers></div>
                </div>
                <p class="lmzstudio-editor__hint">
                    <?php echo Text::_('COM_LMZSTUDIOMODULES_DRAG_HINT'); ?>
                </p>
                <div class="visually-hidden" aria-live="polite" data-map-status></div>
            </section>

            <aside class="lmzstudio-panel lmzstudio-panel--locations" aria-labelledby="lmz-locations-title">
                <div class="lmzstudio-panel__heading">
                    <div>
                        <span><?php echo Text::_('COM_LMZSTUDIOMODULES_CONTENT'); ?></span>
                        <h3 id="lmz-locations-title"><?php echo Text::_('COM_LMZSTUDIOMODULES_LOCATIONS'); ?></h3>
                    </div>
                </div>
                <div class="lmzstudio-location-list" data-location-list></div>
            </aside>
        </div>

        <div class="lmzstudio-editor__settings">
            <section class="lmzstudio-panel" aria-labelledby="lmz-content-title">
                <div class="lmzstudio-panel__heading">
                    <div>
                        <span><?php echo Text::_('COM_LMZSTUDIOMODULES_MULTILINGUAL'); ?></span>
                        <h3 id="lmz-content-title"><?php echo Text::_('COM_LMZSTUDIOMODULES_MAP_CONTENT'); ?></h3>
                    </div>
                </div>
                <div class="lmzstudio-language-tabs" role="tablist" aria-label="<?php echo Text::_('JFIELD_LANGUAGE_LABEL'); ?>" data-language-tabs></div>
                <div class="row g-3 mt-1">
                    <div class="col-lg-6">
                        <label class="form-label" for="lmz-map-eyebrow"><?php echo Text::_('COM_LMZSTUDIOMODULES_FIELD_EYEBROW'); ?></label>
                        <input class="form-control" id="lmz-map-eyebrow" type="text" maxlength="255" data-map-field="eyebrow">
                    </div>
                    <div class="col-lg-6">
                        <label class="form-label" for="lmz-map-title"><?php echo Text::_('COM_LMZSTUDIOMODULES_FIELD_PUBLIC_TITLE'); ?></label>
                        <input class="form-control" id="lmz-map-title" type="text" maxlength="255" data-map-field="title">
                    </div>
                    <div class="col-lg-6">
                        <label class="form-label" for="lmz-map-intro"><?php echo Text::_('COM_LMZSTUDIOMODULES_FIELD_INTRO'); ?></label>
                        <textarea class="form-control" id="lmz-map-intro" rows="3" maxlength="4000" data-map-field="intro"></textarea>
                    </div>
                    <div class="col-lg-6">
                        <label class="form-label" for="lmz-map-note"><?php echo Text::_('COM_LMZSTUDIOMODULES_FIELD_NOTE'); ?></label>
                        <textarea class="form-control" id="lmz-map-note" rows="3" maxlength="4000" data-map-field="note"></textarea>
                    </div>
                </div>
            </section>

            <section class="lmzstudio-panel" aria-labelledby="lmz-location-editor-title" data-location-editor hidden>
                <div class="lmzstudio-panel__heading">
                    <div>
                        <span><?php echo Text::_('COM_LMZSTUDIOMODULES_SELECTED_LOCATION'); ?></span>
                        <h3 id="lmz-location-editor-title" data-selected-location-title></h3>
                    </div>
                    <button type="button" class="btn btn-sm btn-outline-danger" data-action="delete-location">
                        <span class="icon-trash" aria-hidden="true"></span>
                        <?php echo Text::_('JACTION_DELETE'); ?>
                    </button>
                </div>
                <div class="row g-3">
                    <div class="col-md-3">
                        <label class="form-label" for="lmz-location-state"><?php echo Text::_('COM_LMZSTUDIOMODULES_FIELD_STATE_CODE'); ?></label>
                        <input class="form-control" id="lmz-location-state" type="text" maxlength="12" placeholder="DE-NI" data-location-field="state_code">
                    </div>
                    <div class="col-md-2">
                        <label class="form-label" for="lmz-location-x"><?php echo Text::_('COM_LMZSTUDIOMODULES_FIELD_X'); ?></label>
                        <input class="form-control" id="lmz-location-x" type="number" min="0" max="100" step="0.0001" data-location-field="x_percent">
                    </div>
                    <div class="col-md-2">
                        <label class="form-label" for="lmz-location-y"><?php echo Text::_('COM_LMZSTUDIOMODULES_FIELD_Y'); ?></label>
                        <input class="form-control" id="lmz-location-y" type="number" min="0" max="100" step="0.0001" data-location-field="y_percent">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label" for="lmz-tooltip-position"><?php echo Text::_('COM_LMZSTUDIOMODULES_FIELD_TOOLTIP_POSITION'); ?></label>
                        <select class="form-select" id="lmz-tooltip-position" data-location-field="tooltip_position">
                            <option value="auto"><?php echo Text::_('COM_LMZSTUDIOMODULES_TOOLTIP_AUTO'); ?></option>
                            <option value="top"><?php echo Text::_('COM_LMZSTUDIOMODULES_TOOLTIP_TOP'); ?></option>
                            <option value="bottom"><?php echo Text::_('COM_LMZSTUDIOMODULES_TOOLTIP_BOTTOM'); ?></option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <label class="form-label" for="lmz-marker-label"><?php echo Text::_('COM_LMZSTUDIOMODULES_FIELD_MARKER_LABEL'); ?></label>
                        <input class="form-control" id="lmz-marker-label" type="text" maxlength="12" data-location-field="marker_label">
                    </div>
                    <div class="col-12">
                        <div class="lmzstudio-switches">
                            <label><input type="checkbox" data-location-field="state"> <?php echo Text::_('JPUBLISHED'); ?></label>
                            <label><input type="checkbox" data-location-field="is_headquarters"> <?php echo Text::_('COM_LMZSTUDIOMODULES_HEADQUARTERS'); ?></label>
                            <label><input type="checkbox" data-location-field="is_default"> <?php echo Text::_('COM_LMZSTUDIOMODULES_DEFAULT_LOCATION'); ?></label>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label" for="lmz-location-name"><?php echo Text::_('COM_LMZSTUDIOMODULES_FIELD_LOCATION_NAME'); ?></label>
                        <input class="form-control" id="lmz-location-name" type="text" maxlength="255" data-location-translation-field="name">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label" for="lmz-location-label"><?php echo Text::_('COM_LMZSTUDIOMODULES_FIELD_LOCATION_LABEL'); ?></label>
                        <input class="form-control" id="lmz-location-label" type="text" maxlength="255" data-location-translation-field="label">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label" for="lmz-location-description"><?php echo Text::_('JGLOBAL_DESCRIPTION'); ?></label>
                        <textarea class="form-control" id="lmz-location-description" rows="2" maxlength="500" data-location-translation-field="description"></textarea>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label" for="lmz-location-address"><?php echo Text::_('COM_LMZSTUDIOMODULES_FIELD_ADDRESS'); ?></label>
                        <textarea class="form-control" id="lmz-location-address" rows="2" maxlength="500" data-location-translation-field="address"></textarea>
                    </div>
                </div>
            </section>

            <section class="lmzstudio-panel" aria-labelledby="lmz-design-title">
                <div class="lmzstudio-panel__heading">
                    <div>
                        <span><?php echo Text::_('COM_LMZSTUDIOMODULES_APPEARANCE'); ?></span>
                        <h3 id="lmz-design-title"><?php echo Text::_('COM_LMZSTUDIOMODULES_DESIGN_AND_PUBLISHING'); ?></h3>
                    </div>
                </div>
                <div class="row g-3">
                    <div class="col-lg-4">
                        <?php echo $this->form->renderField('title'); ?>
                        <?php echo $this->form->renderField('alias'); ?>
                        <?php echo $this->form->renderField('theme'); ?>
                    </div>
                    <div class="col-lg-4">
                        <?php echo $this->form->renderField('color_background'); ?>
                        <?php echo $this->form->renderField('color_map'); ?>
                        <?php echo $this->form->renderField('color_accent'); ?>
                    </div>
                    <div class="col-lg-4">
                        <?php echo $this->form->renderField('color_text'); ?>
                        <?php echo $this->form->renderField('color_surface'); ?>
                        <?php echo $this->form->renderField('state'); ?>
                        <?php echo $this->form->renderField('access'); ?>
                    </div>
                </div>
            </section>
        </div>
    </div>

    <?php echo $this->form->getInput('id'); ?>
    <?php echo $this->form->getInput('translations_json'); ?>
    <?php echo $this->form->getInput('locations_json'); ?>
    <input type="hidden" name="task" value="">
    <?php echo HTMLHelper::_('form.token'); ?>
</form>
