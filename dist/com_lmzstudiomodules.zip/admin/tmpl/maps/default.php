<?php

defined('_JEXEC') or die;

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;

/** @var \LMZ\Component\Lmzstudiomodules\Administrator\View\Maps\HtmlView $this */

HTMLHelper::_('behavior.multiselect');
$user = $this->getCurrentUser();
$listOrder = $this->escape($this->state->get('list.ordering', 'm.ordering'));
$listDirn = $this->escape($this->state->get('list.direction', 'ASC'));
?>
<form action="<?php echo Route::_('index.php?option=com_lmzstudiomodules&view=maps'); ?>"
      method="post"
      name="adminForm"
      id="adminForm">
    <div class="row align-items-center mb-3">
        <div class="col-md-7">
            <label class="visually-hidden" for="filter_search"><?php echo Text::_('JSEARCH_FILTER'); ?></label>
            <div class="input-group">
                <input type="search"
                       name="filter_search"
                       id="filter_search"
                       value="<?php echo $this->escape((string) $this->state->get('filter.search')); ?>"
                       class="form-control"
                       placeholder="<?php echo Text::_('COM_LMZSTUDIOMODULES_SEARCH_HINT'); ?>">
                <button type="submit" class="btn btn-primary"><?php echo Text::_('JSEARCH_FILTER_SUBMIT'); ?></button>
                <button type="button"
                        class="btn btn-secondary"
                        onclick="document.getElementById('filter_search').value='';this.form.submit();">
                    <?php echo Text::_('JSEARCH_FILTER_CLEAR'); ?>
                </button>
            </div>
        </div>
        <div class="col-md-3 ms-auto">
            <label class="visually-hidden" for="filter_state"><?php echo Text::_('JSTATUS'); ?></label>
            <select name="filter_state" id="filter_state" class="form-select" onchange="this.form.submit()">
                <option value=""><?php echo Text::_('JOPTION_SELECT_PUBLISHED'); ?></option>
                <option value="1" <?php echo (string) $this->state->get('filter.state') === '1' ? 'selected' : ''; ?>>
                    <?php echo Text::_('JPUBLISHED'); ?>
                </option>
                <option value="0" <?php echo (string) $this->state->get('filter.state') === '0' ? 'selected' : ''; ?>>
                    <?php echo Text::_('JUNPUBLISHED'); ?>
                </option>
            </select>
        </div>
    </div>

    <div class="card">
        <div class="table-responsive">
            <table class="table table-striped align-middle mb-0">
                <caption class="visually-hidden"><?php echo Text::_('COM_LMZSTUDIOMODULES_MANAGER_MAPS'); ?></caption>
                <thead>
                    <tr>
                        <td class="w-1 text-center">
                            <?php echo HTMLHelper::_('grid.checkall'); ?>
                        </td>
                        <th scope="col"><?php echo Text::_('JGLOBAL_TITLE'); ?></th>
                        <th scope="col" class="text-center"><?php echo Text::_('JSTATUS'); ?></th>
                        <th scope="col"><?php echo Text::_('COM_LMZSTUDIOMODULES_FIELD_THEME'); ?></th>
                        <th scope="col" class="text-center"><?php echo Text::_('COM_LMZSTUDIOMODULES_LOCATIONS'); ?></th>
                        <th scope="col" class="text-center"><?php echo Text::_('COM_LMZSTUDIOMODULES_TRANSLATIONS'); ?></th>
                        <th scope="col" class="text-center"><?php echo Text::_('JGRID_HEADING_ID'); ?></th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($this->items as $i => $item) :
                    $canEdit = $user->authorise('core.edit', 'com_lmzstudiomodules');
                    ?>
                    <tr>
                        <td class="text-center">
                            <?php echo HTMLHelper::_('grid.id', $i, (int) $item->id); ?>
                        </td>
                        <th scope="row">
                            <?php if ($canEdit) : ?>
                                <a href="<?php echo Route::_('index.php?option=com_lmzstudiomodules&task=map.edit&id=' . (int) $item->id); ?>">
                                    <?php echo $this->escape($item->title); ?>
                                </a>
                            <?php else : ?>
                                <?php echo $this->escape($item->title); ?>
                            <?php endif; ?>
                            <div class="small text-muted"><?php echo $this->escape($item->alias); ?></div>
                        </th>
                        <td class="text-center">
                            <?php echo HTMLHelper::_('jgrid.published', (int) $item->state, $i, 'maps.', $user->authorise('core.edit.state', 'com_lmzstudiomodules')); ?>
                        </td>
                        <td><?php echo Text::_('COM_LMZSTUDIOMODULES_THEME_' . strtoupper((string) $item->theme)); ?></td>
                        <td class="text-center"><?php echo (int) $item->locations_count; ?></td>
                        <td class="text-center"><?php echo (int) $item->translations_count; ?></td>
                        <td class="text-center"><?php echo (int) $item->id; ?></td>
                    </tr>
                <?php endforeach; ?>
                <?php if ($this->items === []) : ?>
                    <tr>
                        <td colspan="7" class="text-center py-5">
                            <?php echo Text::_('COM_LMZSTUDIOMODULES_NO_MAPS'); ?>
                        </td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <?php echo $this->pagination->getListFooter(); ?>
    <input type="hidden" name="task" value="">
    <input type="hidden" name="boxchecked" value="0">
    <input type="hidden" name="filter_order" value="<?php echo $listOrder; ?>">
    <input type="hidden" name="filter_order_Dir" value="<?php echo $listDirn; ?>">
    <?php echo HTMLHelper::_('form.token'); ?>
</form>
