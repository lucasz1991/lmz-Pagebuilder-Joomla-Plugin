(() => {
    'use strict';

    const clamp = (value, min, max) => Math.min(max, Math.max(min, value));
    const parseJson = (value, fallback) => {
        try {
            const parsed = JSON.parse(value);
            return parsed && typeof parsed === 'object' ? parsed : fallback;
        } catch (error) {
            return fallback;
        }
    };

    const initialize = (root) => {
        const form = root.closest('form');
        const config = parseJson(root.dataset.config || '{}', {});
        const languages = Array.isArray(config.languages) && config.languages.length
            ? config.languages
            : [{code: document.documentElement.lang || 'en-GB', title: document.documentElement.lang || 'English'}];
        const translationsInput = form.querySelector('[name="jform[translations_json]"]');
        const locationsInput = form.querySelector('[name="jform[locations_json]"]');
        const translations = parseJson(translationsInput.value || '{}', {});
        const parsedLocations = parseJson(locationsInput.value || '[]', []);
        const locations = Array.isArray(parsedLocations) ? parsedLocations : [];
        const stage = root.querySelector('[data-map-stage]');
        const markers = root.querySelector('[data-map-markers]');
        const list = root.querySelector('[data-location-list]');
        const status = root.querySelector('[data-map-status]');
        const locationEditor = root.querySelector('[data-location-editor]');
        const selectedLocationTitle = root.querySelector('[data-selected-location-title]');
        const locationCount = root.querySelector('[data-location-count]');
        const previewTitle = root.querySelector('[data-map-preview-title]');
        const tabs = root.querySelector('[data-language-tabs]');
        const mapFields = Array.from(root.querySelectorAll('[data-map-field]'));
        const locationFields = Array.from(root.querySelectorAll('[data-location-field]'));
        const locationTranslationFields = Array.from(root.querySelectorAll('[data-location-translation-field]'));
        let activeLanguage = languages[0].code;
        let selectedKey = null;
        let keyCounter = 0;
        let dragState = null;

        const emptyMapTranslation = () => ({title: '', eyebrow: '', intro: '', note: ''});
        const emptyLocationTranslation = (name = '') => ({name, description: '', label: '', address: ''});
        const getLocationName = (location) => {
            const current = location.translations?.[activeLanguage];
            const fallback = location.translations?.['*'] || Object.values(location.translations || {})[0];
            return current?.name || fallback?.name || config.newLocation || 'New location';
        };
        const getSelected = () => locations.find((location) => location._key === selectedKey) || null;

        languages.forEach((language) => {
            translations[language.code] = Object.assign(emptyMapTranslation(), translations[language.code] || {});
        });

        locations.forEach((location) => {
            location._key = location.id ? `id-${Number(location.id)}` : `new-${++keyCounter}`;
            location.x_percent = clamp(Number(location.x_percent) || 50, 0, 100);
            location.y_percent = clamp(Number(location.y_percent) || 50, 0, 100);
            location.state = Number(location.state) === 0 ? 0 : 1;
            location.is_headquarters = Boolean(location.is_headquarters);
            location.is_default = Boolean(location.is_default);
            location.tooltip_position = ['auto', 'top', 'bottom'].includes(location.tooltip_position)
                ? location.tooltip_position
                : 'auto';
            location.marker_label = String(location.marker_label || 'RT').slice(0, 12);
            location.translations = location.translations && typeof location.translations === 'object'
                ? location.translations
                : {};
            languages.forEach((language) => {
                location.translations[language.code] = Object.assign(
                    emptyLocationTranslation(),
                    location.translations[language.code] || {}
                );
            });
        });

        const syncHiddenFields = () => {
            const cleanLocations = locations.map(({_key, ...location}, index) => ({
                ...location,
                ordering: index + 1,
            }));
            translationsInput.value = JSON.stringify(translations);
            locationsInput.value = JSON.stringify(cleanLocations);
        };

        const announce = (message) => {
            status.textContent = '';
            window.requestAnimationFrame(() => {
                status.textContent = message;
            });
        };

        const setSelected = (key, shouldFocus = false) => {
            selectedKey = key;
            render();

            if (shouldFocus) {
                root.querySelector(`[data-marker-key="${CSS.escape(key)}"]`)?.focus();
            }
        };

        const updateTheme = () => {
            const theme = form.querySelector('#jform_theme')?.value || 'default';
            const presets = {
                default: {background: '#F7F8F5', map: '#E7EAD0', accent: '#E51F2B', text: '#10151B'},
                gray: {background: '#252A2E', map: '#AAB1B7', accent: '#6F7880', text: '#FFFFFF'},
                red: {background: '#250D11', map: '#F1B4B8', accent: '#E51F2B', text: '#FFFFFF'},
                blue: {background: '#071C2F', map: '#AFCFE8', accent: '#1779BA', text: '#FFFFFF'},
                green: {background: '#0C251D', map: '#B7D9C8', accent: '#268B62', text: '#FFFFFF'},
            };
            const custom = {
                background: form.querySelector('#jform_color_background')?.value || '#F7F8F5',
                map: form.querySelector('#jform_color_map')?.value || '#E7EAD0',
                accent: form.querySelector('#jform_color_accent')?.value || '#E51F2B',
                text: form.querySelector('#jform_color_text')?.value || '#10151B',
            };
            const colors = theme === 'custom' ? custom : (presets[theme] || presets.default);
            stage.dataset.theme = theme;
            root.style.setProperty('--lmz-map-background', colors.background);
            root.style.setProperty('--lmz-map-fill', colors.map);
            root.style.setProperty('--lmz-map-accent', colors.accent);
            root.style.setProperty('--lmz-map-text', colors.text);
        };

        const renderTabs = () => {
            tabs.replaceChildren();

            languages.forEach((language) => {
                const button = document.createElement('button');
                button.type = 'button';
                button.role = 'tab';
                button.textContent = language.title;
                button.dataset.language = language.code;
                button.setAttribute('aria-selected', language.code === activeLanguage ? 'true' : 'false');
                button.addEventListener('click', () => {
                    activeLanguage = language.code;
                    render();
                });
                tabs.append(button);
            });
        };

        const renderMapFields = () => {
            const current = translations[activeLanguage] || emptyMapTranslation();
            mapFields.forEach((field) => {
                field.value = current[field.dataset.mapField] || '';
                field.lang = activeLanguage;
            });
            previewTitle.textContent = current.title || form.querySelector('#jform_title')?.value || '';
        };

        const renderLocationFields = () => {
            const location = getSelected();
            locationEditor.hidden = !location;

            if (!location) {
                return;
            }

            selectedLocationTitle.textContent = getLocationName(location);
            locationFields.forEach((field) => {
                const key = field.dataset.locationField;

                if (field.type === 'checkbox') {
                    field.checked = Boolean(location[key]);
                } else {
                    field.value = location[key] ?? '';
                }
            });
            const current = location.translations[activeLanguage] || emptyLocationTranslation();
            locationTranslationFields.forEach((field) => {
                field.value = current[field.dataset.locationTranslationField] || '';
                field.lang = activeLanguage;
            });
        };

        const createMarker = (location) => {
            const button = document.createElement('button');
            button.type = 'button';
            button.className = 'lmzstudio-preview-marker';
            button.dataset.markerKey = location._key;
            button.style.setProperty('--x', `${location.x_percent}%`);
            button.style.setProperty('--y', `${location.y_percent}%`);
            button.textContent = location.marker_label || 'RT';
            button.title = getLocationName(location);
            button.setAttribute('aria-label', getLocationName(location));

            if (location._key === selectedKey) {
                button.classList.add('is-selected');
            }

            if (location.is_headquarters) {
                button.classList.add('is-headquarters');
            }

            if (!location.state) {
                button.classList.add('is-unpublished');
            }

            button.addEventListener('pointerdown', (event) => {
                if (event.button !== 0) {
                    return;
                }

                dragState = {key: location._key, moved: false};
                button.setPointerCapture(event.pointerId);
                selectedKey = location._key;
                renderLocationFields();
                event.preventDefault();
            });
            button.addEventListener('pointermove', (event) => {
                if (!dragState || dragState.key !== location._key || !button.hasPointerCapture(event.pointerId)) {
                    return;
                }

                const rect = markers.getBoundingClientRect();
                location.x_percent = Number(clamp(((event.clientX - rect.left) / rect.width) * 100, 0, 100).toFixed(4));
                location.y_percent = Number(clamp(((event.clientY - rect.top) / rect.height) * 100, 0, 100).toFixed(4));
                dragState.moved = true;
                button.style.setProperty('--x', `${location.x_percent}%`);
                button.style.setProperty('--y', `${location.y_percent}%`);
                renderLocationFields();
                syncHiddenFields();
            });
            button.addEventListener('pointerup', (event) => {
                if (!dragState || dragState.key !== location._key) {
                    return;
                }

                const moved = dragState.moved;
                dragState = null;

                if (button.hasPointerCapture(event.pointerId)) {
                    button.releasePointerCapture(event.pointerId);
                }

                if (moved) {
                    announce(`${getLocationName(location)}: ${location.x_percent.toFixed(2)} / ${location.y_percent.toFixed(2)}`);
                } else {
                    setSelected(location._key);
                }
            });
            button.addEventListener('keydown', (event) => {
                const steps = {
                    ArrowLeft: [-0.25, 0],
                    ArrowRight: [0.25, 0],
                    ArrowUp: [0, -0.25],
                    ArrowDown: [0, 0.25],
                };

                if (!steps[event.key]) {
                    return;
                }

                event.preventDefault();
                const multiplier = event.shiftKey ? 4 : 1;
                location.x_percent = Number(clamp(location.x_percent + steps[event.key][0] * multiplier, 0, 100).toFixed(4));
                location.y_percent = Number(clamp(location.y_percent + steps[event.key][1] * multiplier, 0, 100).toFixed(4));
                button.style.setProperty('--x', `${location.x_percent}%`);
                button.style.setProperty('--y', `${location.y_percent}%`);
                renderLocationFields();
                syncHiddenFields();
            });

            return button;
        };

        const renderMarkers = () => {
            markers.replaceChildren(...locations.map(createMarker));
            locationCount.textContent = String(locations.length);
        };

        const renderList = () => {
            list.replaceChildren();

            if (!locations.length) {
                const empty = document.createElement('p');
                empty.className = 'text-muted mb-0';
                empty.textContent = config.emptyLocations || 'No locations';
                list.append(empty);
                return;
            }

            locations.forEach((location) => {
                const button = document.createElement('button');
                button.type = 'button';
                button.className = 'lmzstudio-location-card';

                if (location._key === selectedKey) {
                    button.classList.add('is-selected');
                }

                const pin = document.createElement('span');
                pin.className = 'lmzstudio-location-card__pin';
                pin.textContent = location.marker_label || 'RT';
                const copy = document.createElement('span');
                copy.className = 'lmzstudio-location-card__copy';
                const name = document.createElement('strong');
                name.textContent = getLocationName(location);
                const detail = document.createElement('small');
                detail.textContent = location.state_code || '—';
                copy.append(name, detail);
                const flags = document.createElement('span');
                flags.className = 'lmzstudio-location-card__flags';

                if (location.is_headquarters) {
                    const badge = document.createElement('span');
                    badge.textContent = 'HQ';
                    flags.append(badge);
                }

                if (location.is_default) {
                    const badge = document.createElement('span');
                    badge.textContent = '★';
                    flags.append(badge);
                }

                button.append(pin, copy, flags);
                button.addEventListener('click', () => setSelected(location._key, true));
                list.append(button);
            });
        };

        const render = () => {
            renderTabs();
            renderMapFields();
            renderMarkers();
            renderList();
            renderLocationFields();
            updateTheme();
            syncHiddenFields();
        };

        mapFields.forEach((field) => {
            field.addEventListener('input', () => {
                translations[activeLanguage][field.dataset.mapField] = field.value;
                renderMapFields();
                syncHiddenFields();
            });
        });

        locationFields.forEach((field) => {
            const eventName = field.type === 'checkbox' || field.tagName === 'SELECT' ? 'change' : 'input';
            field.addEventListener(eventName, () => {
                const location = getSelected();

                if (!location) {
                    return;
                }

                const key = field.dataset.locationField;
                let value = field.type === 'checkbox' ? field.checked : field.value;

                if (key === 'x_percent' || key === 'y_percent') {
                    value = clamp(Number(value) || 0, 0, 100);
                }

                if ((key === 'is_headquarters' || key === 'is_default') && value) {
                    locations.forEach((candidate) => {
                        candidate[key] = false;
                    });
                }

                location[key] = value;
                render();
            });
        });

        locationTranslationFields.forEach((field) => {
            field.addEventListener('input', () => {
                const location = getSelected();

                if (!location) {
                    return;
                }

                location.translations[activeLanguage][field.dataset.locationTranslationField] = field.value;
                renderMarkers();
                renderList();
                selectedLocationTitle.textContent = getLocationName(location);
                syncHiddenFields();
            });
        });

        root.querySelector('[data-action="add-location"]')?.addEventListener('click', () => {
            const location = {
                id: 0,
                _key: `new-${++keyCounter}`,
                state_code: '',
                x_percent: 50,
                y_percent: 50,
                tooltip_position: 'auto',
                marker_label: 'RT',
                is_headquarters: false,
                is_default: locations.length === 0,
                state: 1,
                translations: {},
            };

            languages.forEach((language) => {
                location.translations[language.code] = emptyLocationTranslation(config.newLocation || 'New location');
            });
            locations.push(location);
            setSelected(location._key, true);
            announce(config.newLocation || 'New location');
        });

        root.querySelector('[data-action="delete-location"]')?.addEventListener('click', () => {
            const location = getSelected();

            if (!location || !window.confirm(config.confirmDelete || 'Delete location?')) {
                return;
            }

            const index = locations.findIndex((candidate) => candidate._key === location._key);
            locations.splice(index, 1);
            selectedKey = locations[Math.min(index, locations.length - 1)]?._key || null;

            if (locations.length && !locations.some((candidate) => candidate.is_default)) {
                locations[0].is_default = true;
            }

            render();
        });

        ['theme', 'color_background', 'color_map', 'color_accent', 'color_text'].forEach((name) => {
            form.querySelector(`#jform_${name}`)?.addEventListener('input', updateTheme);
            form.querySelector(`#jform_${name}`)?.addEventListener('change', updateTheme);
        });
        form.querySelector('#jform_title')?.addEventListener('input', renderMapFields);
        form.addEventListener('submit', syncHiddenFields);

        selectedKey = locations.find((location) => location.is_default)?._key || locations[0]?._key || null;
        render();
    };

    const boot = () => {
        document.querySelectorAll('[data-lmz-map-editor]').forEach(initialize);
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot, {once: true});
    } else {
        boot();
    }
})();
