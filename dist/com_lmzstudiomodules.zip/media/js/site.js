(() => {
    'use strict';

    const TITLE_READY_STATES = new Set(['revealing', 'map-left', 'content', 'complete']);

    const prepareTitle = (map) => {
        const title = map.querySelector('.lmz-germany-map__title:not(.lmz-germany-map__title--assistive)');

        if (!title || title.dataset.lmzTitleAnimation) {
            return;
        }

        const text = title.textContent.replace(/\s+/g, ' ').trim();

        if (!text) {
            return;
        }

        const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
        let attempts = 0;

        const initializeAnimation = () => {
            if (!window.gsap && attempts < 180) {
                attempts += 1;
                window.requestAnimationFrame(initializeAnimation);
                return;
            }

            if (!window.gsap) {
                title.dataset.lmzTitleAnimation = 'fallback';
                return;
            }

            const fragment = document.createDocumentFragment();
            const characters = [];

            text.split(' ').forEach((word, wordIndex, words) => {
                const wordElement = document.createElement('span');
                wordElement.className = 'lmz-germany-map__title-word';
                wordElement.setAttribute('aria-hidden', 'true');

                Array.from(word).forEach((character) => {
                    const clip = document.createElement('span');
                    const characterElement = document.createElement('span');
                    clip.className = 'lmz-germany-map__title-character-clip';
                    characterElement.className = 'lmz-germany-map__title-character';
                    characterElement.textContent = character;
                    clip.append(characterElement);
                    wordElement.append(clip);
                    characters.push(characterElement);
                });

                fragment.append(wordElement);

                if (wordIndex < words.length - 1) {
                    fragment.append(document.createTextNode(' '));
                }
            });

            title.replaceChildren(fragment);
            title.setAttribute('aria-label', text);

            if (reducedMotion) {
                title.dataset.lmzTitleAnimation = 'reduced';
                return;
            }

            title.dataset.lmzTitleAnimation = 'prepared';
            const tween = window.gsap.fromTo(
                characters,
                {yPercent: 112},
                {
                    yPercent: 0,
                    duration: .64,
                    ease: 'power4.out',
                    stagger: .045,
                    paused: true,
                    overwrite: 'auto',
                    onStart: () => {
                        title.dataset.lmzTitleAnimation = 'running';
                    },
                    onComplete: () => {
                        title.dataset.lmzTitleAnimation = 'complete';
                        window.gsap.set(characters, {clearProps: 'willChange'});
                    },
                }
            );
            let played = false;

            const play = () => {
                if (played) {
                    return;
                }

                played = true;
                tween.play(0);
            };

            const story = map.closest('.sa-network');

            if (story) {
                const maybePlay = () => {
                    if (TITLE_READY_STATES.has(story.dataset.mapSequenceState || '')) {
                        play();
                        observer.disconnect();
                    }
                };
                const observer = new MutationObserver(maybePlay);
                observer.observe(story, {attributes: true, attributeFilter: ['data-map-sequence-state']});
                maybePlay();
                story.addEventListener('rt:map-sequence-complete', play, {once: true});
                return;
            }

            if (window.ScrollTrigger) {
                window.gsap.registerPlugin(window.ScrollTrigger);
                window.ScrollTrigger.create({
                    id: `lmz-map-title-${map.id || Math.random().toString(36).slice(2)}`,
                    trigger: title,
                    start: 'top 90%',
                    once: true,
                    onEnter: play,
                });
                return;
            }

            if ('IntersectionObserver' in window) {
                const observer = new IntersectionObserver((entries) => {
                    if (!entries.some((entry) => entry.isIntersecting)) {
                        return;
                    }

                    observer.disconnect();
                    play();
                }, {rootMargin: '0px 0px -10%'});
                observer.observe(title);
                return;
            }

            play();
        };

        initializeAnimation();
    };

    const initialize = (map) => {
        if (map.dataset.lmzMapInitialized === 'true') {
            return;
        }

        map.dataset.lmzMapInitialized = 'true';
        const markers = Array.from(map.querySelectorAll('[data-lmz-map-location]'));
        const stage = map.querySelector('.lmz-germany-map__stage');
        const defaultMarker = markers.find((marker) => marker.dataset.default === '1')
            || markers.find((marker) => marker.dataset.headquarters === '1')
            || markers[0]
            || null;
        let selectedMarker = null;
        let resizeFrame = 0;

        const setTooltipPosition = (marker) => {
            const tooltip = marker?.querySelector('.lmz-germany-map__tooltip');

            if (!marker || !tooltip || marker !== selectedMarker) {
                return;
            }

            const configuredPosition = marker.dataset.tooltipPosition || 'auto';
            const setBottom = (bottom) => {
                marker.classList.toggle('lmz-germany-map__location--bottom', bottom);
                marker.classList.toggle('rt-location--bottom', bottom);
            };

            marker.style.setProperty('--tooltip-shift', '0px');
            setBottom(configuredPosition === 'bottom');

            if (configuredPosition === 'auto') {
                setBottom(false);
                const topBoundary = (stage || map).getBoundingClientRect().top + 10;

                if (tooltip.getBoundingClientRect().top < topBoundary) {
                    setBottom(true);
                }
            }

            const boundary = map.getBoundingClientRect();
            const tooltipRect = tooltip.getBoundingClientRect();
            const padding = 12;
            let shift = 0;

            if (tooltipRect.left < boundary.left + padding) {
                shift += boundary.left + padding - tooltipRect.left;
            }

            if (tooltipRect.right + shift > boundary.right - padding) {
                shift -= tooltipRect.right + shift - (boundary.right - padding);
            }

            marker.style.setProperty('--tooltip-shift', `${Math.round(shift)}px`);
        };

        const select = (marker, focus = false) => {
            if (!marker) {
                return;
            }

            selectedMarker = marker;
            markers.forEach((candidate) => {
                const selected = candidate === marker;
                candidate.classList.toggle('is-selected', selected);
                candidate.setAttribute('aria-expanded', selected ? 'true' : 'false');
            });

            if (focus) {
                marker.focus({preventScroll: true});
            }

            window.requestAnimationFrame(() => setTooltipPosition(marker));
        };

        const selectAfterCompetingHandlers = (marker, focus = false) => {
            select(marker, focus);
            queueMicrotask(() => select(marker, false));
        };

        markers.forEach((marker) => {
            marker.addEventListener('click', () => selectAfterCompetingHandlers(marker));
            marker.addEventListener('focus', () => selectAfterCompetingHandlers(marker));
            marker.addEventListener('pointerenter', (event) => {
                if (event.pointerType === 'mouse' || event.pointerType === 'pen') {
                    selectAfterCompetingHandlers(marker);
                }
            });
            marker.addEventListener('keydown', (event) => {
                if (event.key === 'Escape' && defaultMarker) {
                    event.preventDefault();
                    selectAfterCompetingHandlers(defaultMarker, true);
                }
            });
        });

        const repositionSelected = () => {
            window.cancelAnimationFrame(resizeFrame);
            resizeFrame = window.requestAnimationFrame(() => setTooltipPosition(selectedMarker));
        };

        window.addEventListener('resize', repositionSelected, {passive: true});

        if ('ResizeObserver' in window && stage) {
            const observer = new ResizeObserver(repositionSelected);
            observer.observe(stage);
        }

        map.dataset.lmzMapReady = 'true';
        select(defaultMarker);
        prepareTitle(map);
    };

    const boot = () => document.querySelectorAll('[data-lmz-germany-map]').forEach(initialize);

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot, {once: true});
    } else {
        boot();
    }
})();
