<?php

declare(strict_types=1);

namespace LMZ\Component\Lmzpagebuilder\Site\View\Page;

defined('_JEXEC') or die;

use Joomla\CMS\Application\SiteApplication;
use Joomla\CMS\Factory;
use Joomla\CMS\MVC\View\GenericDataException;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Uri\Uri;
use Joomla\Database\DatabaseInterface;
use LMZ\Component\Lmzpagebuilder\Site\Service\ContentRenderer;

/**
 * Native page view.
 */
final class HtmlView extends BaseHtmlView
{
    /** @var \stdClass */
    protected $item;

    /** @var string */
    protected $content = '';

    /** @var bool */
    protected $showPageHeading = false;

    /** @var string */
    protected $pageHeading = '';

    /** @var string */
    protected $pageClassSuffix = '';

    public function display($tpl = null): void
    {
        if (count($errors = $this->get('Errors'))) {
            throw new GenericDataException(implode("\n", $errors), 500);
        }

        $this->item = $this->get('Item');

        $app = Factory::getApplication();

        if (!$app instanceof SiteApplication) {
            throw new \RuntimeException('LMZ Page Builder can only render in the Joomla site application.', 500);
        }

        $database = Factory::getContainer()->get(DatabaseInterface::class);
        $renderer = new ContentRenderer($app, $database);
        $rendered = $renderer->renderPage(
            (string) $this->item->published_html,
            (string) $this->item->published_css,
            (string) $this->item->language
        );

        $this->content = $rendered['html'];

        $params                = $app->getParams();
        $this->showPageHeading = (bool) $params->get('show_page_heading', false);
        $this->pageHeading     = trim((string) $params->get('page_heading', ''));
        $classSuffix = trim((string) $params->get('pageclass_sfx', ''));
        $classSuffix = trim((string) preg_replace('/[^a-z0-9_-]+/i', ' ', $classSuffix));
        $this->pageClassSuffix = $classSuffix === ''
            ? ''
            : ' ' . htmlspecialchars($classSuffix, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');

        if ($this->pageHeading === '') {
            $this->pageHeading = (string) $this->item->title;
        }

        $document = $this->getDocument();

        if ($rendered['css'] !== '' && method_exists($document, 'addStyleDeclaration')) {
            $document->addStyleDeclaration($rendered['css']);
        }

        $this->prepareDocument();

        parent::display($tpl);
    }

    private function prepareDocument(): void
    {
        $document = $this->getDocument();
        $title    = trim((string) $this->item->browser_title);

        if ($title === '') {
            $title = trim((string) $this->item->title);
        }

        if ($title === '') {
            $title = trim((string) $this->item->page_title);
        }

        $document->setTitle($this->plainMetadata($title));

        $description = $this->plainMetadata((string) $this->item->meta_description);
        $keywords    = $this->plainMetadata((string) $this->item->meta_keywords);
        $robots      = trim((string) $this->item->robots);

        if ($description !== '') {
            $document->setDescription($description);
        }

        if ($keywords !== '') {
            $document->setMetaData('keywords', $keywords);
        }

        if ($robots !== '' && preg_match('/^[a-z0-9 ,.:_-]+$/i', $robots)) {
            $document->setMetaData('robots', $robots);
        }

        if (method_exists($document, 'addHeadLink')) {
            $canonical = Route::_(
                'index.php?option=com_lmzpagebuilder&view=page&page='
                . rawurlencode((string) $this->item->page_key)
                . '&lang=' . rawurlencode((string) $this->item->language),
                false,
                Route::TLS_IGNORE,
                true
            );

            if (is_string($canonical) && $canonical !== '') {
                $uri = new Uri($canonical);
                $uri->setFragment('');
                $document->addHeadLink($uri->toString(), 'canonical');
            }
        }
    }

    private function plainMetadata(string $value): string
    {
        $value = html_entity_decode(strip_tags($value), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $value = (string) preg_replace('/\s+/u', ' ', $value);

        return trim($value);
    }
}
