<?php

declare(strict_types=1);

namespace LMZ\Component\Lmzpagebuilder\Site\Model;

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Model\BaseDatabaseModel;
use Joomla\Database\ParameterType;

/**
 * Loads exactly one published translation in the active content language.
 */
final class PageModel extends BaseDatabaseModel
{
    /** @var \stdClass|null */
    private $item;

    /** @var bool */
    private $itemLoaded = false;

    /**
     * Populate request-derived state without ever accepting a language override.
     */
    protected function populateState(): void
    {
        $app   = Factory::getApplication();
        $input = $app->getInput();

        $pageKey = $input->getCmd('page', '');

        if ($pageKey === '') {
            $pageKey = $input->getCmd('page_key', '');
        }

        $this->setState('page.id', $input->getUint('id', 0));
        $this->setState('page.key', $pageKey);
        $this->setState('page.language', $app->getLanguage()->getTag());
    }

    /**
     * @return \stdClass
     */
    public function getItem()
    {
        if ($this->itemLoaded) {
            if ($this->item === null) {
                throw new \RuntimeException(Text::_('JERROR_PAGE_NOT_FOUND'), 404);
            }

            return $this->item;
        }

        $this->itemLoaded = true;

        $id       = (int) $this->getState('page.id', 0);
        $pageKey  = trim((string) $this->getState('page.key', ''));
        $language = (string) $this->getState('page.language', '');

        if ($id < 1 && !$this->isValidPageKey($pageKey)) {
            throw new \RuntimeException(Text::_('JERROR_PAGE_NOT_FOUND'), 404);
        }

        if (!$this->isValidLanguageTag($language)) {
            throw new \RuntimeException(Text::_('JERROR_PAGE_NOT_FOUND'), 404);
        }

        $levels = array_values(array_unique(array_map(
            'intval',
            Factory::getApplication()->getIdentity()->getAuthorisedViewLevels()
        )));

        if ($levels === []) {
            $levels = [1];
        }

        $db    = $this->getDatabase();
        $query = $db->getQuery(true)
            ->select(
                [
                    $db->quoteName('p.id'),
                    $db->quoteName('p.page_key'),
                    $db->quoteName('p.title', 'page_title'),
                    $db->quoteName('p.access'),
                    $db->quoteName('t.id', 'translation_id'),
                    $db->quoteName('t.language'),
                    $db->quoteName('t.title'),
                    $db->quoteName('t.alias'),
                    $db->quoteName('t.browser_title'),
                    $db->quoteName('t.meta_description'),
                    $db->quoteName('t.meta_keywords'),
                    $db->quoteName('t.robots'),
                    $db->quoteName('t.published_html'),
                    $db->quoteName('t.published_css'),
                    $db->quoteName('t.published_hash'),
                ]
            )
            ->from($db->quoteName('#__lmzpagebuilder_pages', 'p'))
            ->join(
                'INNER',
                $db->quoteName('#__lmzpagebuilder_page_translations', 't')
                . ' ON ' . $db->quoteName('t.page_id') . ' = ' . $db->quoteName('p.id')
            )
            ->where($db->quoteName('p.state') . ' = 1')
            ->where($db->quoteName('t.state') . ' = 1')
            ->where($db->quoteName('t.language') . ' = :language')
            ->whereIn($db->quoteName('p.access'), $levels, ParameterType::INTEGER)
            ->bind(':language', $language, ParameterType::STRING)
            ->setLimit(1);

        if ($id > 0) {
            $query->where($db->quoteName('p.id') . ' = :pageId')
                ->bind(':pageId', $id, ParameterType::INTEGER);
        }

        // When both selectors are present they must identify the same page.
        if ($pageKey !== '') {
            if (!$this->isValidPageKey($pageKey)) {
                throw new \RuntimeException(Text::_('JERROR_PAGE_NOT_FOUND'), 404);
            }

            $query->where($db->quoteName('p.page_key') . ' = :pageKey')
                ->bind(':pageKey', $pageKey, ParameterType::STRING);
        }

        $db->setQuery($query);
        $this->item = $db->loadObject() ?: null;

        if ($this->item === null) {
            // A missing, unpublished, untranslated, or unauthorised page is
            // intentionally indistinguishable to public callers.
            throw new \RuntimeException(Text::_('JERROR_PAGE_NOT_FOUND'), 404);
        }

        return $this->item;
    }

    private function isValidPageKey(string $pageKey): bool
    {
        return (bool) preg_match('/^[a-z0-9][a-z0-9._-]{0,99}$/i', $pageKey);
    }

    private function isValidLanguageTag(string $language): bool
    {
        return (bool) preg_match('/^[a-z]{2,3}(?:-[A-Z]{2})?$/', $language);
    }
}
