<?php

declare(strict_types=1);

namespace LMZ\Component\Lmzpagebuilder\Site\Dispatcher;

defined('_JEXEC') or die;

use Joomla\CMS\Dispatcher\ComponentDispatcher;

/**
 * Site dispatcher for the native LMZ Page Builder frontend.
 */
final class Dispatcher extends ComponentDispatcher
{
}
