<?php

declare(strict_types=1);

namespace LMZ\Component\Lmzpagebuilder\Site\Controller;

defined('_JEXEC') or die;

use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Controller\BaseController;

/**
 * Read-only site controller.
 */
final class DisplayController extends BaseController
{
    /**
     * Display one published page translation.
     *
     * Deliberately disables component output caching here. Joomla's page cache
     * may still cache complete public responses, while this controller must not
     * reuse output between different authorised view-level sets.
     */
    public function display($cachable = false, $urlparams = [])
    {
        $view = $this->input->getCmd('view', 'page');

        if ($view !== 'page') {
            throw new \RuntimeException(Text::_('JERROR_PAGE_NOT_FOUND'), 404);
        }

        $this->input->set('view', 'page');

        return parent::display(
            false,
            [
                'id'       => 'UINT',
                'page'     => 'CMD',
                'page_key' => 'CMD',
                'Itemid'   => 'UINT',
                'lang'     => 'CMD',
            ]
        );
    }
}
