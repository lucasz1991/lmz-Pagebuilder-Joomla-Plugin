<?php

declare(strict_types=1);

namespace LMZ\Component\Lmzpagebuilder\Site\Service;

defined('_JEXEC') or die;

use DOMDocument;
use DOMElement;
use DOMNode;
use DOMXPath;
use Joomla\CMS\Application\SiteApplication;
use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Extension\ExtensionHelper;
use Joomla\CMS\Factory;
use Joomla\CMS\Helper\ModuleHelper;
use Joomla\CMS\Log\Log;
use Joomla\CMS\Plugin\PluginHelper;
use Joomla\CMS\Router\Route;
use Joomla\Database\DatabaseInterface;
use Joomla\Database\ParameterType;

/**
 * Resolves the declarative LMZ frontend markers in already sanitised published
 * content. Marker payload is always treated as an identifier, never as code.
 */
final class ContentRenderer
{
    private const MAX_SHARED_DEPTH = 12;
    private const MAX_MARKERS = 250;

    /** @var SiteApplication */
    private $application;

    /** @var DatabaseInterface */
    private $database;

    /** @var int[] */
    private $viewLevels = [];

    /** @var string[] */
    private $styleDeclarations = [];

    /** @var array<string,bool> */
    private $styleKeys = [];

    /** @var int */
    private $processedMarkers = 0;

    public function __construct(SiteApplication $application, DatabaseInterface $database)
    {
        $this->application = $application;
        $this->database    = $database;
        $this->viewLevels  = array_values(array_unique(array_map(
            'intval',
            $application->getIdentity()->getAuthorisedViewLevels()
        )));

        if ($this->viewLevels === []) {
            $this->viewLevels = [1];
        }
    }

    /**
     * @return array{html:string,css:string}
     */
    public function renderPage(string $html, string $css, string $language): array
    {
        if (!$this->isValidLanguageTag($language)) {
            throw new \InvalidArgumentException('Invalid LMZ content language.');
        }

        $this->styleDeclarations = [];
        $this->styleKeys         = [];
        $this->processedMarkers  = 0;

        $renderedHtml = $this->renderFragment(
            $this->sanitizePublishedHtml($html),
            $language,
            [],
            0
        );

        // Page CSS comes last so a page can deliberately refine a shared
        // element's defaults without injecting a raw <style> element.
        $this->addStyleDeclaration($css, 'page');

        return [
            'html' => $renderedHtml,
            'css'  => implode("\n", $this->styleDeclarations),
        ];
    }

    /**
     * Loads one of the two reserved template elements and verifies its exact
     * dynamic slot contract before the template is allowed to use it.
     *
     * @return array{region:string,html:string,css:string,required_slots:array<int,string>}|null
     */
    public function prepareTemplateRegion(string $region, string $language): ?array
    {
        $definitions = [
            'navigation' => [
                'key' => 'template-navigation',
                'slots' => ['brand', 'toggle', 'menu', 'languages', 'hotline'],
            ],
            'footer' => [
                'key' => 'template-footer',
                'slots' => ['brand', 'services', 'company', 'contact', 'legal'],
            ],
        ];

        if (!isset($definitions[$region]) || !$this->isValidLanguageTag($language)) {
            return null;
        }

        $definition = $definitions[$region];
        $this->styleDeclarations = [];
        $this->styleKeys = [];
        $this->processedMarkers = 0;

        try {
            $query = $this->database->getQuery(true)
                ->select([
                    $this->database->quoteName('e.id'),
                    $this->database->quoteName('t.published_html'),
                    $this->database->quoteName('t.published_css'),
                    $this->database->quoteName('t.published_hash'),
                ])
                ->from($this->database->quoteName('#__lmzpagebuilder_elements', 'e'))
                ->join(
                    'INNER',
                    $this->database->quoteName('#__lmzpagebuilder_element_translations', 't')
                    . ' ON ' . $this->database->quoteName('t.element_id') . ' = ' . $this->database->quoteName('e.id')
                )
                ->where($this->database->quoteName('e.element_key') . ' = :elementKey')
                ->where($this->database->quoteName('e.kind') . ' = ' . $this->database->quote('template'))
                ->where($this->database->quoteName('e.state') . ' = 1')
                ->where($this->database->quoteName('t.state') . ' = 1')
                ->where($this->database->quoteName('t.language') . ' = :language')
                ->whereIn($this->database->quoteName('e.access'), $this->viewLevels, ParameterType::INTEGER)
                ->bind(':elementKey', $definition['key'], ParameterType::STRING)
                ->bind(':language', $language, ParameterType::STRING)
                ->setLimit(1);
            $element = $this->database->setQuery($query)->loadObject();
        } catch (\Throwable $error) {
            $this->warn('LMZ template region lookup failed for ' . $this->safeLogToken($region) . '.');

            return null;
        }

        if (!$element || trim((string) $element->published_html) === '') {
            return null;
        }

        $html = $this->renderFragment(
            $this->sanitizePublishedHtml((string) $element->published_html),
            $language,
            [],
            0
        );
        $parsed = $this->parseFragment($html);
        if ($parsed === null) {
            return null;
        }

        [$document, $root] = $parsed;
        $xpath = new DOMXPath($document);
        $markers = $this->snapshotElements($xpath, '//*[@data-lmz-template-slot]');
        $found = [];

        foreach ($markers as $marker) {
            if (!$this->isAttachedToRoot($marker, $root)) {
                continue;
            }
            $slot = strtolower(trim($marker->getAttribute('data-lmz-template-slot')));
            if (!in_array($slot, $definition['slots'], true) || isset($found[$slot])) {
                $this->warn('LMZ template region rejected an unknown or duplicate slot in ' . $this->safeLogToken($region) . '.');

                return null;
            }
            $found[$slot] = true;
        }

        foreach ($definition['slots'] as $required) {
            if (!isset($found[$required])) {
                $this->warn('LMZ template region rejected a missing slot in ' . $this->safeLogToken($region) . '.');

                return null;
            }
        }

        $this->addStyleDeclaration(
            (string) $element->published_css,
            'template:' . (int) $element->id . ':' . (string) $element->published_hash
        );

        return [
            'region' => $region,
            'html' => $html,
            'css' => implode("\n", $this->styleDeclarations),
            'required_slots' => $definition['slots'],
        ];
    }

    /**
     * Substitutes trusted runtime fragments into a previously validated region.
     * The published builder HTML never receives PHP or arbitrary slot names.
     *
     * @param array{region:string,html:string,css:string,required_slots:array<int,string>} $prepared
     * @param array<string,string> $slots
     */
    public function fillTemplateRegion(array $prepared, array $slots): ?string
    {
        $required = $prepared['required_slots'] ?? [];
        if (!is_array($required) || !is_string($prepared['html'] ?? null)) {
            return null;
        }
        foreach ($required as $slot) {
            if (!is_string($slot) || !array_key_exists($slot, $slots) || !is_string($slots[$slot])) {
                return null;
            }
        }

        $parsed = $this->parseFragment((string) $prepared['html']);
        if ($parsed === null) {
            return null;
        }
        [$document, $root] = $parsed;
        $xpath = new DOMXPath($document);
        $markers = $this->snapshotElements($xpath, '//*[@data-lmz-template-slot]');
        $filled = [];

        foreach ($markers as $marker) {
            if (!$this->isAttachedToRoot($marker, $root)) {
                continue;
            }
            $slot = strtolower(trim($marker->getAttribute('data-lmz-template-slot')));
            if (!in_array($slot, $required, true) || isset($filled[$slot])) {
                return null;
            }
            $filled[$slot] = true;
            $this->replaceWithHtml($marker, $slots[$slot], $slot . ' slot empty');
        }

        return count($filled) === count($required) ? $this->innerHtml($root) : null;
    }

    /**
     * @param int[] $sharedStack
     */
    private function renderFragment(string $html, string $language, array $sharedStack, int $depth): string
    {
        if (strpos($html, 'data-lmz-') === false) {
            return $html;
        }

        $parsed = $this->parseFragment($html);

        if ($parsed === null) {
            $this->warn('LMZ marker processing skipped because the HTML fragment could not be parsed.');

            return $html;
        }

        [$document, $root] = $parsed;
        $xpath             = new DOMXPath($document);

        $sharedNodes = $this->snapshotElements($xpath, '//*[@data-lmz-shared-element]');

        foreach ($sharedNodes as $node) {
            if (!$this->isAttachedToRoot($node, $root)) {
                continue;
            }

            if (!$this->consumeMarkerBudget()) {
                $this->replaceWithFallback($node, 'shared marker limit reached');
                continue;
            }

            $reference = trim($node->getAttribute('data-lmz-shared-element'));
            $resolved  = $this->resolveSharedElement($reference, $language, $sharedStack, $depth);

            if ($resolved === null) {
                $this->replaceWithFallback($node, 'shared element unavailable');
                continue;
            }

            $this->replaceWithHtml($node, $resolved, 'shared element empty');
        }

        $pageRouteNodes = $this->snapshotElements($xpath, '//*[@data-lmz-page-route]');

        foreach ($pageRouteNodes as $node) {
            if (!$this->isAttachedToRoot($node, $root)) {
                continue;
            }

            if (!$this->consumeMarkerBudget()) {
                $node->setAttribute('href', '#');
                $node->removeAttribute('data-lmz-page-route');
                continue;
            }

            $pageKey = trim($node->getAttribute('data-lmz-page-route'));
            $route   = $this->resolvePageRoute($pageKey, $language);
            $node->setAttribute('href', $route ?? '#');
            $node->removeAttribute('data-lmz-page-route');
        }

        $embedNodes = $this->snapshotElements($xpath, '//*[@data-lmz-embed-kind]');

        foreach ($embedNodes as $node) {
            if (!$this->isAttachedToRoot($node, $root)) {
                continue;
            }

            if (!$this->consumeMarkerBudget()) {
                $this->replaceWithFallback($node, 'embed marker limit reached');
                continue;
            }

            $kind  = strtolower(trim($node->getAttribute('data-lmz-embed-kind')));
            $idRaw = trim($node->getAttribute('data-lmz-embed-id'));

            if (!preg_match('/^[1-9][0-9]{0,9}$/', $idRaw)) {
                $this->warn('LMZ embed rejected an invalid numeric identifier.');
                $this->replaceWithFallback($node, 'invalid embed identifier');
                continue;
            }

            $id       = (int) $idRaw;
            $rendered = null;

            if ($kind === 'article') {
                $rendered = $this->renderArticle($id, $language, $node);
            } elseif ($kind === 'module') {
                $rendered = $this->renderModule($id, $language);
            } elseif ($kind === 'smartslider') {
                $rendered = $this->renderSmartSlider($id);
            } else {
                $this->warn('LMZ embed rejected unsupported kind: ' . $this->safeLogToken($kind));
            }

            if ($rendered === null) {
                $this->replaceWithFallback($node, $kind !== '' ? $kind . ' unavailable' : 'embed unavailable');
                continue;
            }

            $this->replaceWithHtml($node, $rendered, $kind . ' empty');
        }

        return $this->innerHtml($root);
    }

    private function resolvePageRoute(string $pageKey, string $language): ?string
    {
        if (!$this->isValidPageKey($pageKey)) {
            $this->warn('LMZ page route rejected an invalid page key.');

            return null;
        }

        $query = $this->database->getQuery(true)
            ->select($this->database->quoteName('p.id'))
            ->from($this->database->quoteName('#__lmzpagebuilder_pages', 'p'))
            ->join(
                'INNER',
                $this->database->quoteName('#__lmzpagebuilder_page_translations', 't')
                . ' ON ' . $this->database->quoteName('t.page_id') . ' = ' . $this->database->quoteName('p.id')
            )
            ->where($this->database->quoteName('p.page_key') . ' = :pageKey')
            ->where($this->database->quoteName('p.state') . ' = 1')
            ->where($this->database->quoteName('t.state') . ' = 1')
            ->where($this->database->quoteName('t.language') . ' = :language')
            ->whereIn($this->database->quoteName('p.access'), $this->viewLevels, ParameterType::INTEGER)
            ->bind(':pageKey', $pageKey, ParameterType::STRING)
            ->bind(':language', $language, ParameterType::STRING)
            ->setLimit(1);
        $this->database->setQuery($query);

        if (!(int) $this->database->loadResult()) {
            $this->warn(
                'LMZ page route is missing, unpublished, untranslated, or unauthorised: '
                . $this->safeLogToken($pageKey) . '.'
            );

            return null;
        }

        $route = Route::_(
            'index.php?option=com_lmzpagebuilder&view=page&page=' . rawurlencode($pageKey)
            . '&lang=' . rawurlencode($language),
            false,
            Route::TLS_IGNORE,
            true
        );

        return is_string($route) && $route !== '' ? $route : null;
    }

    /**
     * @param int[] $sharedStack
     */
    private function resolveSharedElement(
        string $reference,
        string $language,
        array $sharedStack,
        int $depth
    ): ?string {
        if (!$this->isValidSharedReference($reference)) {
            $this->warn('LMZ shared element rejected an invalid reference.');

            return null;
        }

        if ($depth >= self::MAX_SHARED_DEPTH) {
            $this->warn('LMZ shared element recursion depth exceeded for ' . $this->safeLogToken($reference) . '.');

            return null;
        }

        $query = $this->database->getQuery(true)
            ->select(
                [
                    $this->database->quoteName('e.id'),
                    $this->database->quoteName('e.uuid'),
                    $this->database->quoteName('e.element_key'),
                    $this->database->quoteName('t.published_html'),
                    $this->database->quoteName('t.published_css'),
                    $this->database->quoteName('t.published_hash'),
                ]
            )
            ->from($this->database->quoteName('#__lmzpagebuilder_elements', 'e'))
            ->join(
                'INNER',
                $this->database->quoteName('#__lmzpagebuilder_element_translations', 't')
                . ' ON ' . $this->database->quoteName('t.element_id') . ' = ' . $this->database->quoteName('e.id')
            )
            ->where($this->database->quoteName('e.kind') . ' = ' . $this->database->quote('global'))
            ->where($this->database->quoteName('e.state') . ' = 1')
            ->where($this->database->quoteName('t.state') . ' = 1')
            ->where($this->database->quoteName('t.language') . ' = :language')
            ->whereIn($this->database->quoteName('e.access'), $this->viewLevels, ParameterType::INTEGER)
            ->bind(':language', $language, ParameterType::STRING)
            ->setLimit(1);

        if ($this->isUuid($reference)) {
            $normalisedUuid = strtolower($reference);
            $query->where('LOWER(' . $this->database->quoteName('e.uuid') . ') = :uuid')
                ->bind(':uuid', $normalisedUuid, ParameterType::STRING);
        } else {
            $query->where($this->database->quoteName('e.element_key') . ' = :elementKey')
                ->bind(':elementKey', $reference, ParameterType::STRING);
        }

        $this->database->setQuery($query);
        $element = $this->database->loadObject();

        if (!$element) {
            $this->warn(
                'LMZ shared element is missing, unpublished, untranslated, or unauthorised: '
                . $this->safeLogToken($reference) . '.'
            );

            return null;
        }

        $elementId = (int) $element->id;

        if (in_array($elementId, $sharedStack, true)) {
            $this->warn('LMZ shared element recursion cycle detected at element #' . $elementId . '.');

            return null;
        }

        $styleKey = 'shared:' . $elementId . ':' . (string) $element->published_hash;
        $this->addStyleDeclaration((string) $element->published_css, $styleKey);

        $sharedStack[] = $elementId;

        return $this->renderFragment(
            $this->sanitizePublishedHtml((string) $element->published_html),
            $language,
            $sharedStack,
            $depth + 1
        );
    }

    private function renderArticle(int $articleId, string $language, DOMElement $marker): ?string
    {
        $now   = Factory::getDate()->toSql();
        $query = $this->database->getQuery(true)
            ->select($this->database->quoteName('a.id'))
            ->from($this->database->quoteName('#__content', 'a'))
            ->join(
                'INNER',
                $this->database->quoteName('#__categories', 'c')
                . ' ON ' . $this->database->quoteName('c.id') . ' = ' . $this->database->quoteName('a.catid')
            )
            ->where($this->database->quoteName('a.id') . ' = :articleId')
            ->where($this->database->quoteName('a.state') . ' = 1')
            ->where($this->database->quoteName('c.published') . ' = 1')
            ->whereIn($this->database->quoteName('a.access'), $this->viewLevels, ParameterType::INTEGER)
            ->whereIn($this->database->quoteName('c.access'), $this->viewLevels, ParameterType::INTEGER)
            ->whereIn($this->database->quoteName('a.language'), [$language, '*'], ParameterType::STRING)
            ->whereIn($this->database->quoteName('c.language'), [$language, '*'], ParameterType::STRING)
            ->extendWhere(
                'AND',
                [
                    $this->database->quoteName('a.publish_up') . ' IS NULL',
                    $this->database->quoteName('a.publish_up') . ' <= :publishUp',
                ],
                'OR'
            )
            ->extendWhere(
                'AND',
                [
                    $this->database->quoteName('a.publish_down') . ' IS NULL',
                    $this->database->quoteName('a.publish_down') . ' >= :publishDown',
                ],
                'OR'
            )
            ->bind(':articleId', $articleId, ParameterType::INTEGER)
            ->bind(':publishUp', $now, ParameterType::STRING)
            ->bind(':publishDown', $now, ParameterType::STRING)
            ->setLimit(1);

        $this->database->setQuery($query);

        if (!(int) $this->database->loadResult()) {
            $this->warn('LMZ article embed is unavailable: #' . $articleId . '.');

            return null;
        }

        try {
            $component = $this->application->bootComponent('com_content');
            $model     = $component->getMVCFactory()->createModel(
                'Article',
                'Site',
                ['ignore_request' => true]
            );

            if (!$model) {
                throw new \RuntimeException('The Joomla article model is unavailable.');
            }

            // Force the public contract even for signed-in editors.
            $model->getState();
            $model->setState('filter.published', 1);
            $model->setState('filter.archived', 1);
            $model->setState('filter.language', true);
            $model->setState('params', clone ComponentHelper::getParams('com_content'));

            $item = $model->getItem($articleId);

            if (!$item || (int) $item->state !== 1) {
                return null;
            }

            $item->text = trim((string) $item->introtext . ' ' . (string) $item->fulltext);
            $params     = $item->params;

            PluginHelper::importPlugin('content');
            $this->application->triggerEvent(
                'onContentPrepare',
                ['com_content.article', &$item, &$params, 0]
            );

            $showTitle = !$marker->hasAttribute('data-lmz-show-title')
                || !in_array(
                    strtolower(trim($marker->getAttribute('data-lmz-show-title'))),
                    ['0', 'false', 'no', 'off'],
                    true
                );

            $title = $showTitle
                ? '<h2 class="lmz-embed__title">'
                    . htmlspecialchars((string) $item->title, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8')
                    . '</h2>'
                : '';

            return $this->sanitizeEmbeddedArticleHtml(
                '<article class="lmz-embed lmz-embed--article" data-lmz-article-id="'
                . $articleId . '">' . $title
                . '<div class="lmz-embed__content">' . (string) $item->text . '</div></article>'
            );
        } catch (\Throwable $error) {
            $this->warn(
                'LMZ article embed failed for #' . $articleId . ': '
                . $this->safeLogToken($error->getMessage())
            );

            return null;
        }
    }

    private function renderModule(int $moduleId, string $language): ?string
    {
        $now   = Factory::getDate()->toSql();
        $query = $this->database->getQuery(true)
            ->select(
                $this->database->quoteName(
                    [
                        'm.id',
                        'm.title',
                        'm.module',
                        'm.position',
                        'm.content',
                        'm.showtitle',
                        'm.params',
                    ]
                )
            )
            ->from($this->database->quoteName('#__modules', 'm'))
            ->join(
                'INNER',
                $this->database->quoteName('#__extensions', 'e')
                . ' ON ' . $this->database->quoteName('e.element') . ' = ' . $this->database->quoteName('m.module')
                . ' AND ' . $this->database->quoteName('e.type') . ' = ' . $this->database->quote('module')
                . ' AND ' . $this->database->quoteName('e.client_id') . ' = 0'
            )
            ->where($this->database->quoteName('m.id') . ' = :moduleId')
            ->where($this->database->quoteName('m.client_id') . ' = 0')
            ->where($this->database->quoteName('m.published') . ' = 1')
            ->where($this->database->quoteName('e.enabled') . ' = 1')
            ->whereIn($this->database->quoteName('m.access'), $this->viewLevels, ParameterType::INTEGER)
            ->whereIn($this->database->quoteName('m.language'), [$language, '*'], ParameterType::STRING)
            ->extendWhere(
                'AND',
                [
                    $this->database->quoteName('m.publish_up') . ' IS NULL',
                    $this->database->quoteName('m.publish_up') . ' <= :publishUp',
                ],
                'OR'
            )
            ->extendWhere(
                'AND',
                [
                    $this->database->quoteName('m.publish_down') . ' IS NULL',
                    $this->database->quoteName('m.publish_down') . ' >= :publishDown',
                ],
                'OR'
            )
            ->bind(':moduleId', $moduleId, ParameterType::INTEGER)
            ->bind(':publishUp', $now, ParameterType::STRING)
            ->bind(':publishDown', $now, ParameterType::STRING)
            ->setLimit(1);

        $this->database->setQuery($query);
        $module = $this->database->loadObject();

        if (!$module || !preg_match('/^mod_[a-z0-9_]+$/', (string) $module->module)) {
            $this->warn('LMZ module embed is unavailable: #' . $moduleId . '.');

            return null;
        }

        $module->name  = substr((string) $module->module, 4);
        $module->style = null;

        try {
            $output = ModuleHelper::renderModule(
                $module,
                ['style' => 'none', 'contentOnly' => true]
            );

            if ((string) $module->module === 'mod_custom') {
                $output = $this->sanitizeEmbeddedArticleHtml((string) $output);
            }

            return (string) $output;
        } catch (\Throwable $error) {
            $this->warn(
                'LMZ module embed failed for #' . $moduleId . ': '
                . $this->safeLogToken($error->getMessage())
            );

            return null;
        }
    }

    private function renderSmartSlider(int $sliderId): ?string
    {
        $pluginRecord = ExtensionHelper::getExtensionRecord('smartslider3', 'plugin', null, 'system');
        $moduleRecord = ExtensionHelper::getExtensionRecord('mod_smartslider3', 'module', 0);

        if (
            !$pluginRecord
            || !(int) $pluginRecord->enabled
            || !$moduleRecord
            || !(int) $moduleRecord->enabled
            || !PluginHelper::isEnabled('system', 'smartslider3')
        ) {
            $this->warn('LMZ Smart Slider embed requires the enabled Smart Slider 3 system plugin and site module.');

            return null;
        }

        try {
            $table = $this->database->replacePrefix('#__nextend2_smartslider3_sliders');

            if (!method_exists($this->database, 'getTableColumns')) {
                throw new \RuntimeException('The database driver cannot inspect the Smart Slider schema.');
            }

            $columns      = array_change_key_case($this->database->getTableColumns($table, false), CASE_LOWER);
            $statusColumn = isset($columns['slider_status'])
                ? 'slider_status'
                : (isset($columns['status']) ? 'status' : '');

            if ($statusColumn === '') {
                throw new \RuntimeException('The Smart Slider status column is missing.');
            }

            $query = $this->database->getQuery(true)
                ->select($this->database->quoteName('id'))
                ->from($this->database->quoteName('#__nextend2_smartslider3_sliders'))
                ->where($this->database->quoteName('id') . ' = :sliderId')
                ->where($this->database->quoteName($statusColumn) . ' = :published')
                ->bind(':sliderId', $sliderId, ParameterType::INTEGER)
                ->bind(':published', 'published', ParameterType::STRING)
                ->setLimit(1);

            $this->database->setQuery($query);

            if (!(int) $this->database->loadResult()) {
                $this->warn('LMZ Smart Slider embed is unavailable or unpublished: #' . $sliderId . '.');

                return null;
            }

            // Render through the installed Joomla module dispatcher. Its system
            // plugin replaces this trusted shortcode during onAfterRender.
            $module = (object) [
                'id'        => 0,
                'title'     => 'LMZ Smart Slider ' . $sliderId,
                'module'    => 'mod_smartslider3',
                'name'      => 'smartslider3',
                'position'  => 'lmzpagebuilder',
                'content'   => '',
                'showtitle' => 0,
                'params'    => json_encode(['slider' => (string) $sliderId], JSON_THROW_ON_ERROR),
                'style'     => null,
            ];

            $output = ModuleHelper::renderModule(
                $module,
                ['style' => 'none', 'contentOnly' => true]
            );

            return trim((string) $output) !== '' ? (string) $output : null;
        } catch (\Throwable $error) {
            $this->warn(
                'LMZ Smart Slider embed failed for #' . $sliderId . ': '
                . $this->safeLogToken($error->getMessage())
            );

            return null;
        }
    }

    /**
     * @return array{0:DOMDocument,1:DOMElement}|null
     */
    private function parseFragment(string $html): ?array
    {
        if (!class_exists(DOMDocument::class)) {
            return null;
        }

        try {
            $token = bin2hex(random_bytes(12));
        } catch (\Throwable $error) {
            $token = str_replace('.', '', uniqid('lmz', true));
        }

        $document = new DOMDocument('1.0', 'UTF-8');
        $previous = libxml_use_internal_errors(true);

        try {
            $loaded = $document->loadHTML(
                '<!doctype html><html><head><meta charset="utf-8"></head><body>'
                . '<div data-lmz-render-root="' . $token . '">' . $html . '</div>'
                . '</body></html>',
                LIBXML_NONET | LIBXML_NOERROR | LIBXML_NOWARNING
            );
        } finally {
            libxml_clear_errors();
            libxml_use_internal_errors($previous);
        }

        if (!$loaded) {
            return null;
        }

        $xpath = new DOMXPath($document);
        $nodes = $xpath->query('//*[@data-lmz-render-root="' . $token . '"]');
        $root  = $nodes && $nodes->length > 0 ? $nodes->item(0) : null;

        return $root instanceof DOMElement ? [$document, $root] : null;
    }

    /**
     * @return DOMElement[]
     */
    private function snapshotElements(DOMXPath $xpath, string $expression): array
    {
        $nodes = $xpath->query($expression);

        if (!$nodes) {
            return [];
        }

        $result = [];

        foreach ($nodes as $node) {
            if ($node instanceof DOMElement) {
                $result[] = $node;
            }
        }

        return $result;
    }

    private function replaceWithHtml(DOMElement $marker, string $html, string $emptyComment): void
    {
        $parent = $marker->parentNode;

        if (!$parent) {
            return;
        }

        if ($html === '') {
            $parent->replaceChild($marker->ownerDocument->createComment(' lmzpagebuilder: ' . $emptyComment . ' '), $marker);

            return;
        }

        $fragment = $this->parseFragment($html);

        if ($fragment === null) {
            $this->replaceWithFallback($marker, 'rendered fragment unavailable');

            return;
        }

        [, $sourceRoot] = $fragment;
        $children       = [];

        foreach ($sourceRoot->childNodes as $child) {
            $children[] = $child;
        }

        foreach ($children as $child) {
            $parent->insertBefore($marker->ownerDocument->importNode($child, true), $marker);
        }

        $parent->removeChild($marker);
    }

    private function replaceWithFallback(DOMElement $marker, string $reason): void
    {
        $parent = $marker->parentNode;

        if (!$parent) {
            return;
        }

        $comment = $marker->ownerDocument->createComment(
            ' lmzpagebuilder: ' . $this->safeCommentToken($reason) . ' '
        );
        $parent->replaceChild($comment, $marker);
    }

    private function innerHtml(DOMElement $element): string
    {
        $html = '';

        foreach ($element->childNodes as $child) {
            $html .= $element->ownerDocument->saveHTML($child);
        }

        return $html;
    }

    private function isAttachedToRoot(DOMNode $node, DOMElement $root): bool
    {
        $cursor = $node;

        while ($cursor) {
            if ($cursor->isSameNode($root)) {
                return true;
            }

            $cursor = $cursor->parentNode;
        }

        return false;
    }

    private function consumeMarkerBudget(): bool
    {
        ++$this->processedMarkers;

        if ($this->processedMarkers <= self::MAX_MARKERS) {
            return true;
        }

        if ($this->processedMarkers === self::MAX_MARKERS + 1) {
            $this->warn('LMZ marker limit exceeded; remaining markers were suppressed.');
        }

        return false;
    }

    private function addStyleDeclaration(string $css, string $key): void
    {
        $css = $this->sanitizeCss($css);

        if ($css === '') {
            return;
        }

        $dedupeKey = $key . ':' . hash('sha256', $css);

        if (isset($this->styleKeys[$dedupeKey])) {
            return;
        }

        $this->styleKeys[$dedupeKey] = true;
        $this->styleDeclarations[]   = $css;
    }

    private function sanitizeCss(string $css): string
    {
        $css = str_replace("\0", '', $css);
        $css = (string) preg_replace('/<\/?style\b[^>]*>/i', '', $css);
        $css = (string) preg_replace('/@import\s+(?:url\s*\()?[^;]+;/i', '', $css);
        $css = (string) preg_replace(
            '/(?:expression\s*\(|javascript\s*:|-moz-binding\s*:|data\s*:\s*(?:text\/html|application\/))/i',
            'blocked:',
            $css
        );

        return trim($css);
    }

    private function sanitizePublishedHtml(string $html): string
    {
        $html = str_replace("\0", '', $html);
        $html = (string) preg_replace('/<\?(?:php|=)?[\s\S]*?\?>/i', '', $html);
        $html = (string) preg_replace('#<script\b[^>]*>[\s\S]*?</script\s*>#i', '', $html);
        $html = (string) preg_replace('#</?script\b[^>]*>#i', '', $html);
        $html = (string) preg_replace('#<style\b[^>]*>[\s\S]*?</style\s*>#i', '', $html);
        $html = (string) preg_replace('#</?style\b[^>]*>#i', '', $html);
        $html = (string) preg_replace('#<(?:base|link|meta)\b[^>]*/?>#i', '', $html);
        $html = (string) preg_replace('#<(?:object|embed|applet)\b[^>]*>[\s\S]*?</(?:object|embed|applet)\s*>#i', '', $html);
        $html = (string) preg_replace('#<(?:object|embed|applet)\b[^>]*/?>#i', '', $html);
        $html = (string) preg_replace(
            '/\s+on[a-z0-9_-]+\s*=\s*(?:"[^"]*"|\'[^\']*\'|[^\s>]+)/i',
            '',
            $html
        );
        $html = (string) preg_replace(
            '/\s+srcdoc\s*=\s*(?:"[^"]*"|\'[^\']*\'|[^\s>]+)/i',
            '',
            $html
        );
        $html = (string) preg_replace(
            '/\s+(href|src|xlink:href)\s*=\s*(["\'])\s*(?:javascript\s*:|data\s*:\s*(?:text\/html|application\/))[\s\S]*?\2/i',
            ' $1="#"',
            $html
        );
        $html = (string) preg_replace(
            '/\s+(href|src|xlink:href)\s*=\s*(?:javascript\s*:|data\s*:\s*(?:text\/html|application\/))[^\s>]*/i',
            ' $1="#"',
            $html
        );

        return $html;
    }

    private function sanitizeEmbeddedArticleHtml(string $html): string
    {
        return $this->sanitizePublishedHtml($html);
    }

    private function isValidSharedReference(string $reference): bool
    {
        return $this->isUuid($reference)
            || $this->isValidPageKey($reference);
    }

    private function isValidPageKey(string $value): bool
    {
        return (bool) preg_match('/^[a-z0-9][a-z0-9._-]{0,99}$/i', $value);
    }

    private function isUuid(string $value): bool
    {
        return (bool) preg_match(
            '/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i',
            $value
        );
    }

    private function isValidLanguageTag(string $language): bool
    {
        return (bool) preg_match('/^[a-z]{2,3}(?:-[A-Z]{2})?$/', $language);
    }

    private function safeLogToken(string $value): string
    {
        $value = (string) preg_replace('/[^a-z0-9 ._:#-]+/i', '', $value);

        return substr($value, 0, 160);
    }

    private function safeCommentToken(string $value): string
    {
        $value = str_replace(['--', '<', '>'], '', $value);

        return substr($value, 0, 80);
    }

    private function warn(string $message): void
    {
        try {
            Log::add($message, Log::WARNING, 'com_lmzpagebuilder');
        } catch (\Throwable $error) {
            // Rendering must keep its safe empty fallback even when logging is
            // unavailable. Never expose the exception to public visitors.
        }
    }
}
