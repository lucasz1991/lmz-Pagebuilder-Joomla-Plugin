<?php

declare(strict_types=1);

namespace LMZ\Component\Lmzpagebuilder\Site\Service;

defined('_JEXEC') or die;

use Joomla\CMS\Application\SiteApplication;
use Joomla\CMS\Categories\CategoryFactoryInterface;
use Joomla\CMS\Component\Router\RouterView;
use Joomla\CMS\Component\Router\RouterViewConfiguration;
use Joomla\CMS\Component\Router\Rules\MenuRules;
use Joomla\CMS\Component\Router\Rules\NomenuRules;
use Joomla\CMS\Component\Router\Rules\StandardRules;
use Joomla\CMS\Language\LanguageHelper;
use Joomla\CMS\Menu\AbstractMenu;
use Joomla\Database\DatabaseInterface;
use Joomla\Database\ParameterType;

/**
 * Language-aware SEF router for native LMZ pages.
 */
final class Router extends RouterView
{
    /** @var SiteApplication */
    private $application;

    /** @var DatabaseInterface */
    private $database;

    public function __construct(
        SiteApplication $app,
        AbstractMenu $menu,
        ?CategoryFactoryInterface $categoryFactory,
        DatabaseInterface $database
    )
    {
        $this->application = $app;
        $this->database    = $database;

        $page = new RouterViewConfiguration('page');
        $page->setKey('id');
        $this->registerView($page);

        parent::__construct($app, $menu);

        $this->primeMenuPageIds($menu);
        $this->attachRule(new MenuRules($this));
        $this->attachRule(new StandardRules($this));
        $this->attachRule(new NomenuRules($this));
    }

    /**
     * Convert stable page_key links to the numeric router key before rules run.
     */
    public function preprocess($query)
    {
        $pageKey = !empty($query['page'])
            ? (string) $query['page']
            : (!empty($query['page_key']) ? (string) $query['page_key'] : '');

        if (empty($query['id']) && $pageKey !== '') {

            if ($this->isValidPageKey($pageKey)) {
                $id = $this->findPageIdByKey($pageKey, $this->queryLanguage($query));

                if ($id > 0) {
                    $query['id'] = $id;
                    unset($query['page']);
                    unset($query['page_key']);
                }
            }
        }

        return parent::preprocess($query);
    }

    /**
     * @return array<int,string>
     */
    public function getPageSegment($id, $query): array
    {
        $id = (int) explode(':', (string) $id, 2)[0];

        if ($id < 1) {
            return [];
        }

        $language = $this->queryLanguage($query);
        $dbQuery  = $this->database->getQuery(true)
            ->select(
                [
                    $this->database->quoteName('t.alias'),
                    $this->database->quoteName('p.page_key'),
                ]
            )
            ->from($this->database->quoteName('#__lmzpagebuilder_pages', 'p'))
            ->join(
                'INNER',
                $this->database->quoteName('#__lmzpagebuilder_page_translations', 't')
                . ' ON ' . $this->database->quoteName('t.page_id') . ' = ' . $this->database->quoteName('p.id')
            )
            ->where($this->database->quoteName('p.id') . ' = :pageId')
            ->where($this->database->quoteName('p.state') . ' = 1')
            ->where($this->database->quoteName('t.state') . ' = 1')
            ->where($this->database->quoteName('t.language') . ' = :language')
            ->bind(':pageId', $id, ParameterType::INTEGER)
            ->bind(':language', $language, ParameterType::STRING)
            ->setLimit(1);

        $this->database->setQuery($dbQuery);
        $row = $this->database->loadObject();

        if (!$row) {
            return [];
        }

        $segment = trim((string) $row->alias);

        if ($segment === '') {
            $segment = (string) $row->page_key;
        }

        return [$id => $segment];
    }

    /**
     * Resolve only aliases belonging to the active/requested language.
     *
     * @return int|false
     */
    public function getPageId($segment, $query)
    {
        $segment = trim((string) $segment);

        if ($segment !== '' && ctype_digit($segment)) {
            return (int) $segment;
        }

        if (!$this->isValidPageKey($segment)) {
            return false;
        }

        $language = $this->queryLanguage($query);
        $dbQuery  = $this->database->getQuery(true)
            ->select($this->database->quoteName('p.id'))
            ->from($this->database->quoteName('#__lmzpagebuilder_pages', 'p'))
            ->join(
                'INNER',
                $this->database->quoteName('#__lmzpagebuilder_page_translations', 't')
                . ' ON ' . $this->database->quoteName('t.page_id') . ' = ' . $this->database->quoteName('p.id')
            )
            ->where($this->database->quoteName('p.state') . ' = 1')
            ->where($this->database->quoteName('t.state') . ' = 1')
            ->where($this->database->quoteName('t.language') . ' = :language')
            ->extendWhere(
                'AND',
                [
                    $this->database->quoteName('t.alias') . ' = :alias',
                    $this->database->quoteName('p.page_key') . ' = :pageKey',
                ],
                'OR'
            )
            ->bind(':language', $language, ParameterType::STRING)
            ->bind(':alias', $segment, ParameterType::STRING)
            ->bind(':pageKey', $segment, ParameterType::STRING)
            ->setLimit(1);

        $this->database->setQuery($dbQuery);
        $id = (int) $this->database->loadResult();

        return $id > 0 ? $id : false;
    }

    private function findPageIdByKey(string $pageKey, string $language): int
    {
        $query = $this->database->getQuery(true)
            ->select($this->database->quoteName('p.id'))
            ->from($this->database->quoteName('#__lmzpagebuilder_pages', 'p'))
            ->join(
                'INNER',
                $this->database->quoteName('#__lmzpagebuilder_page_translations', 't')
                . ' ON ' . $this->database->quoteName('t.page_id') . ' = ' . $this->database->quoteName('p.id')
            )
            ->where($this->database->quoteName('p.page_key') . ' = :pageKey')
            ->where($this->database->quoteName('p.state') . ' = 1')
            ->where($this->database->quoteName('t.state') . ' = 1')
            ->where($this->database->quoteName('t.language') . ' = :language')
            ->bind(':pageKey', $pageKey, ParameterType::STRING)
            ->bind(':language', $language, ParameterType::STRING)
            ->setLimit(1);

        $this->database->setQuery($query);

        return (int) $this->database->loadResult();
    }

    /**
     * Enrich logical `page` menu links with a numeric id in memory. Joomla's
     * core MenuRules indexes RouterView keys numerically; no menu row is changed.
     */
    private function primeMenuPageIds(AbstractMenu $menu): void
    {
        $items = $menu->getItems('component', 'com_lmzpagebuilder');

        foreach ($items as $item) {
            if (!isset($item->query) || !is_array($item->query) || !empty($item->query['id'])) {
                continue;
            }

            $pageKey = !empty($item->query['page'])
                ? (string) $item->query['page']
                : (!empty($item->query['page_key']) ? (string) $item->query['page_key'] : '');

            if (!$this->isValidPageKey($pageKey)) {
                continue;
            }

            $language = !empty($item->language) && $item->language !== '*'
                ? (string) $item->language
                : $this->application->getLanguage()->getTag();
            $id = $this->findPageIdByKey($pageKey, $language);

            if ($id > 0) {
                $item->query['id'] = $id;
            }
        }
    }

    private function queryLanguage(array $query): string
    {
        $requested = isset($query['lang']) ? (string) $query['lang'] : '';

        if (preg_match('/^[a-z]{2,3}-[A-Z]{2}$/', $requested)) {
            return $requested;
        }

        if ($requested !== '') {
            $languages = LanguageHelper::getLanguages('sef');

            if (isset($languages[$requested]) && !empty($languages[$requested]->lang_code)) {
                return (string) $languages[$requested]->lang_code;
            }
        }

        return $this->application->getLanguage()->getTag();
    }

    private function isValidPageKey(string $value): bool
    {
        return (bool) preg_match('/^[a-z0-9][a-z0-9._-]{0,99}$/i', $value);
    }
}
