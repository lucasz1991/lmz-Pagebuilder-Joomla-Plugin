<?php

declare(strict_types=1);

namespace LMZ\Component\Lmzpagebuilder\Site\Service;

defined('_JEXEC') or die;

use Joomla\Database\DatabaseInterface;
use Throwable;

/** Read-only, fail-closed frontend projection of the template settings. */
final class TemplateSettingsService
{
    public function __construct(private DatabaseInterface $database)
    {
    }

    /** @return array<string, mixed> */
    public static function defaults(): array
    {
        return [
            'contact_id' => 0,
            'logos' => [
                'favicon' => '/images/l3/logo/rt-logo.svg',
                'mark' => '/images/l3/logo/rt-logo.svg',
                'navigation_wordmark' => '/images/l3/logo-txt-darkbg.png',
                'footer_wordmark' => '/images/l3/logo-txt-darkbg.png',
                'alt_text' => 'RT Rail Time GmbH',
            ],
            'navigation' => [
                'menu_type' => 'mainmenu',
                'hotline' => '04171 546803',
                'hotline_visible' => true,
                'hotline_icon' => '',
                'background' => '#090c11',
                'text' => '#ffffff',
                'accent' => '#e4002b',
                'builder_enabled' => false,
            ],
            'footer' => [
                'company' => 'RT Rail Time GmbH',
                'email' => 'info@rail-time.de',
                'address' => "Borsteler Weg 29–31\n21423 Winsen (Luhe)",
                'email_icon' => '',
                'address_icon' => '',
                'background' => '#090c11',
                'text' => '#ffffff',
                'accent' => '#e4002b',
                'builder_enabled' => false,
            ],
        ];
    }

    /** @return array<string, mixed> */
    public function load(): array
    {
        $defaults = self::defaults();

        try {
            if (!in_array(
                $this->database->replacePrefix('#__lmzpagebuilder_template_settings'),
                $this->database->getTableList(),
                true
            )) {
                return $defaults;
            }

            $query = $this->database->getQuery(true)
                ->select($this->database->quoteName(['contact_id', 'data_json']))
                ->from($this->database->quoteName('#__lmzpagebuilder_template_settings'))
                ->where($this->database->quoteName('id') . ' = 1');
            $row = $this->database->setQuery($query)->loadAssoc();
            if (!$row) {
                return $defaults;
            }
            $decoded = json_decode((string) $row['data_json'], true);
            if (is_array($decoded)) {
                $decoded['contact_id'] = (int) ($row['contact_id'] ?? $decoded['contact_id'] ?? 0);
            }

            $settings = is_array($decoded) ? $this->normalise($decoded, $defaults) : $defaults;

            return $this->applyContact($settings);
        } catch (Throwable $ignored) {
            return $defaults;
        }
    }

    /** @param array<string, mixed> $input @param array<string, mixed> $defaults */
    private function normalise(array $input, array $defaults): array
    {
        $logos = is_array($input['logos'] ?? null) ? $input['logos'] : [];
        $navigation = is_array($input['navigation'] ?? null) ? $input['navigation'] : [];
        $footer = is_array($input['footer'] ?? null) ? $input['footer'] : [];

        return [
            'contact_id' => max(0, (int) ($input['contact_id'] ?? 0)),
            'logos' => [
                'favicon' => $this->assetUrl($logos['favicon'] ?? null, $defaults['logos']['favicon']),
                'mark' => $this->assetUrl($logos['mark'] ?? null, $defaults['logos']['mark']),
                'navigation_wordmark' => $this->assetUrl($logos['navigation_wordmark'] ?? null, $defaults['logos']['navigation_wordmark']),
                'footer_wordmark' => $this->assetUrl($logos['footer_wordmark'] ?? null, $defaults['logos']['footer_wordmark']),
                'alt_text' => $this->plain($logos['alt_text'] ?? null, $defaults['logos']['alt_text'], 160),
            ],
            'navigation' => [
                'menu_type' => $this->menuType($navigation['menu_type'] ?? null, $defaults['navigation']['menu_type']),
                'hotline' => $this->phone($navigation['hotline'] ?? null, $defaults['navigation']['hotline']),
                'hotline_visible' => $this->boolean($navigation['hotline_visible'] ?? $defaults['navigation']['hotline_visible']),
                'hotline_icon' => $this->icon($navigation['hotline_icon'] ?? null),
                'background' => $this->colour($navigation['background'] ?? null, $defaults['navigation']['background']),
                'text' => $this->colour($navigation['text'] ?? null, $defaults['navigation']['text']),
                'accent' => $this->colour($navigation['accent'] ?? null, $defaults['navigation']['accent']),
                'builder_enabled' => $this->boolean($navigation['builder_enabled'] ?? false),
            ],
            'footer' => [
                'company' => $this->plain($footer['company'] ?? null, $defaults['footer']['company'], 190),
                'email' => $this->email($footer['email'] ?? null, $defaults['footer']['email']),
                'address' => $this->multiline($footer['address'] ?? null, $defaults['footer']['address']),
                'email_icon' => $this->icon($footer['email_icon'] ?? null),
                'address_icon' => $this->icon($footer['address_icon'] ?? null),
                'background' => $this->colour($footer['background'] ?? null, $defaults['footer']['background']),
                'text' => $this->colour($footer['text'] ?? null, $defaults['footer']['text']),
                'accent' => $this->colour($footer['accent'] ?? null, $defaults['footer']['accent']),
                'builder_enabled' => $this->boolean($footer['builder_enabled'] ?? false),
            ],
        ];
    }

    /** Sanitises a Font Awesome class string; unusable input yields ''. */
    private function icon(mixed $value): string
    {
        $value = is_scalar($value)
            ? strtolower(trim(preg_replace('/\s+/u', ' ', strip_tags((string) $value)) ?? ''))
            : '';
        if ($value === '') {
            return '';
        }
        $value = trim(preg_replace('/\s+/', ' ', (string) preg_replace('/[^a-z0-9 -]/', '', $value)) ?? '');

        return mb_substr($value, 0, 64);
    }

    private function assetUrl(mixed $value, string $fallback): string
    {
        $value = is_scalar($value) ? trim(html_entity_decode((string) $value, ENT_QUOTES | ENT_HTML5, 'UTF-8')) : '';
        if ($value === '' || strlen($value) > 500 || str_contains($value, "\0") || preg_match('/[<>"\']/', $value)
            || str_starts_with($value, '//')
            || (preg_match('/^[a-z][a-z0-9+.-]*:/i', $value) && !preg_match('~^https?://~i', $value))) {
            return $fallback;
        }
        if (preg_match('~^https?://~i', $value) && !filter_var($value, FILTER_VALIDATE_URL)) {
            return $fallback;
        }

        return preg_match('~^https?://~i', $value) || str_starts_with($value, '/')
            ? $value
            : '/' . ltrim($value, '/');
    }

    private function menuType(mixed $value, string $fallback): string
    {
        $value = is_scalar($value) ? trim((string) $value) : '';
        if (!preg_match('/^[a-z0-9][a-z0-9_-]{0,47}$/i', $value)) {
            return $fallback;
        }

        try {
            $query = $this->database->getQuery(true)
                ->select('COUNT(*)')
                ->from($this->database->quoteName('#__menu_types'))
                ->where($this->database->quoteName('menutype') . ' = ' . $this->database->quote($value));

            return (int) $this->database->setQuery($query)->loadResult() > 0 ? $value : $fallback;
        } catch (Throwable $ignored) {
            return $fallback;
        }
    }

    private function phone(mixed $value, string $fallback): string
    {
        $value = is_scalar($value) ? trim(preg_replace('/\s+/u', ' ', strip_tags((string) $value)) ?? '') : '';

        return preg_match('/^\+?[0-9][0-9 ()\/.-]{4,39}$/', $value) ? $value : $fallback;
    }

    private function colour(mixed $value, string $fallback): string
    {
        $value = is_scalar($value) ? strtolower(trim((string) $value)) : '';
        if (preg_match('/^#([a-f0-9]{3})$/', $value, $match)) {
            return '#' . $match[1][0] . $match[1][0] . $match[1][1] . $match[1][1] . $match[1][2] . $match[1][2];
        }

        return preg_match('/^#[a-f0-9]{6}$/', $value) ? $value : $fallback;
    }

    private function plain(mixed $value, string $fallback, int $limit): string
    {
        $value = is_scalar($value) ? trim(preg_replace('/\s+/u', ' ', strip_tags((string) $value)) ?? '') : '';

        return $value === '' ? $fallback : mb_substr($value, 0, $limit);
    }

    private function email(mixed $value, string $fallback): string
    {
        $value = is_scalar($value) ? mb_strtolower(trim((string) $value)) : '';

        return filter_var($value, FILTER_VALIDATE_EMAIL) && mb_strlen($value) <= 254 ? $value : $fallback;
    }

    private function multiline(mixed $value, string $fallback): string
    {
        if (!is_scalar($value)) {
            return $fallback;
        }
        $value = str_replace(["\r\n", "\r"], "\n", strip_tags((string) $value));
        $lines = array_map(static fn (string $line): string => trim(preg_replace('/\s+/u', ' ', $line) ?? ''), explode("\n", $value));
        $value = trim(implode("\n", array_filter($lines, static fn (string $line): bool => $line !== '')));

        return $value === '' ? $fallback : mb_substr($value, 0, 500);
    }

    private function boolean(mixed $value): bool
    {
        return in_array($value, [true, 1, '1', 'true', 'on', 'yes'], true);
    }

    /**
     * A selected com_contact record is a public projection, not a copied
     * source. Unpublishing it or emptying an individual field immediately
     * activates that field's already validated Template Settings fallback.
     *
     * @param array<string, mixed> $settings
     * @return array<string, mixed>
     */
    private function applyContact(array $settings): array
    {
        $contactId = (int) ($settings['contact_id'] ?? 0);
        if ($contactId < 1) {
            return $settings;
        }

        try {
            $query = $this->database->getQuery(true)
                ->select($this->database->quoteName([
                    'c.name', 'c.telephone', 'c.email_to', 'c.address',
                    'c.suburb', 'c.state', 'c.postcode', 'c.country',
                ]))
                ->from($this->database->quoteName('#__contact_details', 'c'))
                ->innerJoin($this->database->quoteName('#__categories', 'cat') . ' ON ' . $this->database->quoteName('cat.id') . ' = ' . $this->database->quoteName('c.catid'))
                ->where($this->database->quoteName('c.id') . ' = ' . $contactId)
                ->where($this->database->quoteName('c.published') . ' = 1')
                ->where($this->database->quoteName('cat.published') . ' = 1')
                ->where($this->database->quoteName('c.access') . ' = 1')
                ->where($this->database->quoteName('cat.access') . ' = 1')
                ->setLimit(1);
            $contact = $this->database->setQuery($query)->loadAssoc();
        } catch (Throwable $ignored) {
            return $settings;
        }

        if (!$contact) {
            return $settings;
        }

        $settings['footer']['company'] = $this->plain(
            $contact['name'] ?? null,
            (string) $settings['footer']['company'],
            190
        );
        $settings['navigation']['hotline'] = $this->phone(
            $contact['telephone'] ?? null,
            (string) $settings['navigation']['hotline']
        );
        $settings['footer']['email'] = $this->email(
            $contact['email_to'] ?? null,
            (string) $settings['footer']['email']
        );

        $addressLines = [];
        $street = trim((string) ($contact['address'] ?? ''));
        $locality = trim(implode(' ', array_filter([
            trim((string) ($contact['postcode'] ?? '')),
            trim((string) ($contact['suburb'] ?? '')),
        ])));
        $state = trim((string) ($contact['state'] ?? ''));
        $country = trim((string) ($contact['country'] ?? ''));
        foreach ([$street, $locality, $state, $country] as $line) {
            if ($line !== '' && !in_array($line, $addressLines, true)) {
                $addressLines[] = $line;
            }
        }
        if ($addressLines !== []) {
            $settings['footer']['address'] = $this->multiline(
                implode("\n", $addressLines),
                (string) $settings['footer']['address']
            );
        }

        return $settings;
    }
}
