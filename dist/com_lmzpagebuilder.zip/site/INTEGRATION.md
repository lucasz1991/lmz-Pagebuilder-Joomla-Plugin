# Native site component integration

This directory is the read-only Joomla 4.4 frontend for LMZ Page Builder v2.
It does not create or migrate tables and has no third-party page-builder dependency.

## Package manifest

Add the site payload to `administrator/components/com_lmzpagebuilder/lmzpagebuilder.xml`:

```xml
<files folder="site">
    <folder>src</folder>
    <folder>tmpl</folder>
    <filename>INTEGRATION.md</filename>
</files>
```

The existing namespace declaration remains:

```xml
<namespace path="src">LMZ\Component\Lmzpagebuilder</namespace>
```

Joomla maps the `Site` namespace to this directory and the `Administrator`
namespace to the administrator directory.

## Router service

The administrator component extension is also Joomla's component boot object.
It must implement `Joomla\CMS\Component\Router\RouterServiceInterface`, use
`Joomla\CMS\Component\Router\RouterServiceTrait`, and receive a router factory.

In `services/provider.php` register:

```php
$container->registerServiceProvider(
    new Joomla\CMS\Extension\Service\Provider\RouterFactory('\\LMZ\\Component\\Lmzpagebuilder')
);
```

Then call `setRouterFactory()` on the component with
`Joomla\CMS\Component\Router\RouterFactoryInterface` from the container.

## Routes and template bridge

Supported internal routes are:

```text
index.php?option=com_lmzpagebuilder&view=page&id=12
index.php?option=com_lmzpagebuilder&view=page&page=services
index.php?option=com_lmzpagebuilder&view=page&page_key=services
```

The active Joomla content language is authoritative. A page or shared element
without an exact translation returns/supplies no content; there is deliberately
no cross-language fallback. Menu items should use the canonical `page` request
field; `page_key` remains accepted as an upgrade-compatible alias.

The site template continues to render the component normally:

```html
<jdoc:include type="component" />
```

Replace former bridge selectors with the native wrappers
`#lmz-page-builder`, `.lmz-page-builder`, and `.lmz-page-content` before the SP
Page Builder extension and overrides are removed.

## Declarative runtime markers

```html
<div data-lmz-shared-element="550e8400-e29b-41d4-a716-446655440000"></div>
<div data-lmz-shared-element="site-footer"></div>
<div data-lmz-embed-kind="article" data-lmz-embed-id="123"></div>
<div data-lmz-embed-kind="module" data-lmz-embed-id="45"></div>
<div data-lmz-embed-kind="smartslider" data-lmz-embed-id="16"></div>
<a href="#" data-lmz-page-route="contact">Contact</a>
```

Shared references accept UUID (preferred) or `element_key`. Only `kind=global`,
published, authorised, exactly translated records resolve. Recursive references
are capped and cycles fail closed. Article/module embeds accept Joomla's `*`
language alongside the active tag, as native Joomla content does. Embedded IDs
are validated and rendered through Joomla models/dispatchers; marker text is
never evaluated as PHP or JavaScript. Missing embeds produce an invisible HTML
comment and a `com_lmzpagebuilder` warning log entry.

`data-lmz-page-route` accepts a published logical `page_key`. The renderer
validates the active-language variant and access level, resolves Joomla's real
SEF menu route at request time, and removes the marker. Global elements can
therefore link across pages without hard-coding a domain, installation folder,
language prefix, or translated alias.

Published page/shared CSS is stripped of style-tag breakouts, imports, and
legacy executable constructs, then supplied to Joomla through
`Document::addStyleDeclaration()` rather than echoed as a raw script/tag.
