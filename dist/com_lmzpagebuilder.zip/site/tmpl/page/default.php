<?php

declare(strict_types=1);

defined('_JEXEC') or die;

$pageId  = (int) $this->item->id;
$pageKey = htmlspecialchars((string) $this->item->page_key, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
$language = htmlspecialchars((string) $this->item->language, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
?>
<div
    id="lmz-page-builder"
    class="lmz-page-builder page-<?php echo $pageId; ?><?php echo $this->pageClassSuffix; ?>"
    data-lmz-page-key="<?php echo $pageKey; ?>"
    data-lmz-language="<?php echo $language; ?>"
>
    <?php if ($this->showPageHeading) : ?>
        <header class="lmz-page-header">
            <h1><?php echo htmlspecialchars($this->pageHeading, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); ?></h1>
        </header>
    <?php endif; ?>

    <div class="lmz-page-content">
        <?php // Published HTML is sanitised on write and hardened again by ContentRenderer. ?>
        <?php echo $this->content; ?>
    </div>
</div>
