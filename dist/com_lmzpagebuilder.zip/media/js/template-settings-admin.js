(() => {
  'use strict';

  const root = document.querySelector('[data-lmzpb-template-settings]');
  if (!root) return;

  const form = root.querySelector('[data-lmzpb-settings-form]');
  const dirtyState = root.querySelector('[data-lmzpb-dirty-state]');
  const cleanLabel = dirtyState?.textContent || '';
  const dirtyLabel = document.documentElement.lang.toLowerCase().startsWith('de')
    ? 'Ungespeicherte Änderungen'
    : document.documentElement.lang.toLowerCase().startsWith('pl')
      ? 'Niezapisane zmiany'
      : 'Unsaved changes';

  if (form) {
    const initial = new URLSearchParams(new FormData(form)).toString();
    const updateDirty = () => {
      if (!dirtyState) return;
      const dirty = new URLSearchParams(new FormData(form)).toString() !== initial;
      dirtyState.textContent = dirty ? dirtyLabel : cleanLabel;
      dirtyState.dataset.dirty = dirty ? 'true' : 'false';
    };
    form.addEventListener('input', updateDirty);
    form.addEventListener('change', updateDirty);
  }

  root.querySelectorAll('.lmzpb-colour-field input[type="color"]').forEach(input => {
    const output = input.parentElement?.querySelector('output');
    input.addEventListener('input', () => {
      if (output) output.textContent = input.value.toLowerCase();
    });
  });

  root.querySelectorAll('[data-lmzpb-logo-input]').forEach(input => {
    const image = input.closest('[data-lmzpb-logo-preview], .lmzpb-logo-field')?.querySelector('img')
      || input.parentElement?.querySelector('img');
    input.addEventListener('change', () => {
      if (image && input.value.trim()) image.src = input.value.trim();
    });
  });

  const contactSelect = root.querySelector('[data-lmzpb-contact-select]');
  const contactStatus = root.querySelector('[data-lmzpb-contact-status] p');
  if (contactSelect && contactStatus) {
    const fallbackText = contactStatus.textContent;
    const updateContactStatus = () => {
      const option = contactSelect.selectedOptions[0];
      if (!option || option.value === '0') {
        contactStatus.textContent = fallbackText;
        return;
      }
      const details = [option.dataset.phone, option.dataset.email, option.dataset.address].filter(Boolean);
      contactStatus.textContent = details.length
        ? details.join(' · ')
        : `${option.textContent.trim()} · ${fallbackText}`;
    };
    contactSelect.addEventListener('change', updateContactStatus);
    updateContactStatus();
  }

  const originalSubmit = window.Joomla?.submitbutton;
  if (window.Joomla) {
    window.Joomla.submitbutton = task => {
      if (task === 'templatesettings.save' && form) {
        form.requestSubmit();
        return;
      }
      if (typeof originalSubmit === 'function') originalSubmit(task);
    };
  }
})();
