/**
 * RT Icon Picker
 * ---------------
 * Wiederverwendbarer FontAwesome-Icon-Picker fuer den Joomla-Admin (und das
 * Frontend-Template). Reines Vanilla-JS, kein Framework-Zwang.
 *
 * Einbindung:
 *   - CSS:  media/com_lmzpagebuilder/css/rt-icon-picker.css
 *   - JS:   media/com_lmzpagebuilder/js/rt-icon-picker.js
 *   - FA6/FA5-Pro-CSS von Agent A muss geladen sein, damit die Icons
 *     tatsaechlich gerendert werden (media/com_lmzpagebuilder/fontawesome/css/all.min.css).
 *
 * Auto-Init:
 *   Jedes Element mit dem Attribut  data-rt-icon-picker  wird zum Ausloeser.
 *   data-rt-icon-target="#feld-id"  verweist auf das Input, in das die gewaehlte
 *   Klasse (z.B. "fa-solid fa-phone") geschrieben wird.
 *
 *   <input type="text" id="hero-icon" name="jform[icon]">
 *   <button type="button" data-rt-icon-picker data-rt-icon-target="#hero-icon">Icon</button>
 *
 * Programmatische API:
 *   window.RtIconPicker.attach(inputEl [, options])  -> verdrahtet ein Input,
 *       erzeugt einen kleinen "Icon waehlen"-Knopf + Live-Vorschau daneben.
 *   window.RtIconPicker.open(inputEl)                -> oeffnet den Picker fuer ein Input.
 *   window.RtIconPicker.refresh()                    -> scannt das DOM erneut.
 *
 * Konfiguration (optional, vor dem Laden setzen):
 *   window.RtIconPickerConfig = { metadataUrl: '.../icons.json' };
 *
 * Datenfeld-Vertrag: gespeichert wird der reine FA-Klassenstring, z.B.
 *   "fa-solid fa-phone"  bzw.  "fa-brands fa-github".
 */
(function () {
    'use strict';

    if (window.RtIconPicker && window.RtIconPicker.__ready) {
        return; // Doppel-Init vermeiden.
    }

    // ---------------------------------------------------------------------
    // Pfad-Ermittlung: Metadaten liegen relativ zu diesem Script unter
    // ../fontawesome/metadata/icons.json
    // ---------------------------------------------------------------------
    var SELF_SRC = (function () {
        if (document.currentScript && document.currentScript.src) {
            return document.currentScript.src;
        }
        // Fallback: Script anhand des Dateinamens suchen.
        var scripts = document.getElementsByTagName('script');
        for (var i = scripts.length - 1; i >= 0; i--) {
            if (scripts[i].src && scripts[i].src.indexOf('rt-icon-picker.js') !== -1) {
                return scripts[i].src;
            }
        }
        return '';
    })();

    function defaultMetadataUrl() {
        if (SELF_SRC) {
            // .../media/com_lmzpagebuilder/js/rt-icon-picker.js  ->  .../metadata/icons.json
            var base = SELF_SRC.replace(/[?#].*$/, '').replace(/\/js\/[^/]*$/, '');
            return base + '/fontawesome/metadata/icons.json';
        }
        return 'media/com_lmzpagebuilder/fontawesome/metadata/icons.json';
    }

    var CONFIG = window.RtIconPickerConfig || {};
    var METADATA_URL = CONFIG.metadataUrl || defaultMetadataUrl();

    // Bevorzugte Reihenfolge + Anzeigenamen der FA-Stile.
    var STYLE_ORDER = ['solid', 'regular', 'light', 'thin', 'duotone', 'brands'];
    var STYLE_LABELS = {
        solid: 'Solid',
        regular: 'Regular',
        light: 'Light',
        thin: 'Thin',
        duotone: 'Duotone',
        brands: 'Brands'
    };

    // Wie viele Icons pro Scroll-Batch in den DOM gerendert werden.
    var BATCH_SIZE = 120;

    // ---------------------------------------------------------------------
    // Eingebettete Kern-Liste (~60 Icons) als Notfall-Fallback, falls
    // icons.json fehlt/nicht ladbar ist. Namen sind FA5/FA6-kompatibel
    // gehalten (die mitgelieferte all.min.css ist FA5 Pro).
    // ---------------------------------------------------------------------
    var CORE_FALLBACK = (function () {
        var std = ['solid', 'regular', 'light'];
        var names = [
            'phone', 'phone-volume', 'mobile', 'envelope', 'envelope-open', 'at',
            'map-marker-alt', 'map-pin', 'location-arrow', 'compass', 'globe',
            'bars', 'times', 'plus', 'minus', 'check', 'check-circle', 'circle',
            'arrow-right', 'arrow-left', 'arrow-up', 'arrow-down',
            'chevron-right', 'chevron-left', 'chevron-up', 'chevron-down',
            'angle-right', 'angle-double-right', 'external-link-alt',
            'clock', 'calendar', 'calendar-alt', 'hourglass-half',
            'truck', 'train', 'shipping-fast', 'route', 'road', 'warehouse',
            'cog', 'cogs', 'wrench', 'sliders-h', 'tools',
            'user', 'users', 'user-tie', 'id-card', 'address-book', 'building',
            'search', 'filter', 'sort', 'list', 'th', 'th-large',
            'home', 'star', 'heart', 'bookmark', 'flag',
            'info-circle', 'question-circle', 'exclamation-triangle', 'bell',
            'download', 'upload', 'print', 'file-alt', 'folder', 'paperclip',
            'lock', 'unlock', 'key', 'shield-alt', 'eye', 'eye-slash',
            'euro-sign', 'shopping-cart', 'tag', 'gift', 'chart-line', 'chart-bar',
            'play', 'pause', 'stop', 'volume-up', 'headset', 'comment', 'comments',
            'trash', 'edit', 'copy', 'save', 'sync', 'redo', 'undo',
            'thumbs-up', 'handshake', 'lightbulb', 'bolt', 'fire', 'leaf'
        ];
        var list = [];
        for (var i = 0; i < names.length; i++) {
            list.push({ name: names[i], label: names[i], styles: std.slice(), terms: [] });
        }
        // Ein paar Marken zur Vollstaendigkeit.
        var brands = ['facebook', 'facebook-f', 'instagram', 'linkedin', 'linkedin-in',
            'youtube', 'xing', 'whatsapp', 'x-twitter', 'twitter', 'github'];
        for (var b = 0; b < brands.length; b++) {
            list.push({ name: brands[b], label: brands[b], styles: ['brands'], terms: [] });
        }
        return list;
    })();

    // ---------------------------------------------------------------------
    // State
    // ---------------------------------------------------------------------
    var iconData = null;          // Array<{name,label,styles,terms}>
    var availableStyles = null;   // Array<string> (Union aller Stile)
    var loadPromise = null;       // Promise (Metadaten-Ladevorgang)
    var loadFailed = false;

    // ---------------------------------------------------------------------
    // Metadaten laden + robust parsen
    // ---------------------------------------------------------------------
    function loadIcons() {
        if (loadPromise) {
            return loadPromise;
        }
        loadPromise = fetch(METADATA_URL, { credentials: 'same-origin' })
            .then(function (res) {
                if (!res.ok) {
                    throw new Error('HTTP ' + res.status);
                }
                return res.json();
            })
            .then(function (json) {
                var parsed = parseMetadata(json);
                if (!parsed.length) {
                    throw new Error('Leere Icon-Liste');
                }
                setIconData(parsed);
                return iconData;
            })
            .catch(function (err) {
                // Sanfter Rueckfall auf die eingebettete Kernliste.
                loadFailed = true;
                if (window.console && console.warn) {
                    console.warn('[RtIconPicker] icons.json nicht ladbar (' +
                        (err && err.message) + '), nutze Kern-Fallback.');
                }
                setIconData(CORE_FALLBACK.slice());
                return iconData;
            });
        return loadPromise;
    }

    /**
     * Akzeptiert unterschiedliche Metadaten-Schemata:
     *  - FA-Standard:  { "phone": { label, styles:[...], search:{terms:[...]} }, ... }
     *  - FA6-Variante: { "phone": { label, familyStylesByLicense:{ pro:[{family,style}], free:[...] }, search:{terms} } }
     *  - Array-Form:   [ { name/id, label, styles, terms }, ... ]
     *  - Einfach:      { "phone": ["solid","regular"] }   (Name -> Stile)
     */
    function parseMetadata(json) {
        var out = [];
        if (!json) {
            return out;
        }

        if (Array.isArray(json)) {
            json.forEach(function (entry) {
                if (!entry) { return; }
                var name = entry.name || entry.id || entry.slug;
                if (!name) { return; }
                out.push(normalizeEntry(name, entry));
            });
            return out;
        }

        if (typeof json === 'object') {
            Object.keys(json).forEach(function (name) {
                var entry = json[name];
                if (entry == null) { return; }
                out.push(normalizeEntry(name, entry));
            });
        }
        return out;
    }

    function normalizeEntry(name, entry) {
        var styles = [];
        var terms = [];
        var label = name;

        if (Array.isArray(entry)) {
            // Einfaches Schema: Name -> [stile]
            styles = entry.slice();
        } else if (typeof entry === 'object') {
            label = entry.label || entry.title || name;

            if (Array.isArray(entry.styles)) {
                styles = entry.styles.slice();
            } else if (entry.familyStylesByLicense) {
                // FA6-Schema: aus pro (bevorzugt) bzw. free die Stile ziehen.
                var fsl = entry.familyStylesByLicense;
                var pool = (fsl.pro && fsl.pro.length ? fsl.pro : (fsl.free || []));
                pool.forEach(function (fs) {
                    var st = fs && (fs.style || fs);
                    if (st && styles.indexOf(st) === -1) {
                        styles.push(st);
                    }
                });
            } else if (entry.svg && typeof entry.svg === 'object') {
                styles = Object.keys(entry.svg);
            } else if (Array.isArray(entry.free)) {
                styles = entry.free.slice();
            }

            if (entry.search && Array.isArray(entry.search.terms)) {
                terms = entry.search.terms;
            } else if (Array.isArray(entry.terms)) {
                terms = entry.terms;
            } else if (Array.isArray(entry.aliases && entry.aliases.names)) {
                terms = entry.aliases.names;
            }
        }

        if (!styles.length) {
            styles = ['solid'];
        }
        // Nur bekannte Stile behalten, Reihenfolge normalisieren.
        styles = STYLE_ORDER.filter(function (s) { return styles.indexOf(s) !== -1; });
        if (!styles.length) {
            styles = ['solid'];
        }

        return {
            name: name,
            label: label || name,
            styles: styles,
            // Suchindex vorberechnen (Kleinschreibung).
            search: (name + ' ' + label + ' ' + terms.join(' ')).toLowerCase(),
            terms: terms
        };
    }

    function setIconData(list) {
        iconData = list;
        var seen = {};
        list.forEach(function (it) {
            (it.styles || []).forEach(function (s) { seen[s] = true; });
        });
        availableStyles = STYLE_ORDER.filter(function (s) { return seen[s]; });
        if (!availableStyles.length) {
            availableStyles = ['solid'];
        }
    }

    // ---------------------------------------------------------------------
    // Klassen-Helfer
    // ---------------------------------------------------------------------
    function styleClass(style) {
        return 'fa-' + style;
    }

    function iconClass(style, name) {
        // Basis-Klasse "fa" defensiv voranstellen: die mitgelieferte FA5-CSS
        // haengt die Normalisierung an .fa/.fas/... - so rendert das Glyph
        // auch bei reiner "fa-solid fa-name"-Syntax zuverlaessig.
        return 'fa ' + styleClass(style) + ' fa-' + name;
    }

    // Gespeicherter Wert lt. Vertrag: OHNE Basis-"fa", z.B. "fa-solid fa-phone".
    function storedValue(style, name) {
        return styleClass(style) + ' fa-' + name;
    }

    /**
     * Zerlegt einen vorhandenen Klassenstring in {style, name}.
     * Versteht sowohl neue (fa-solid) als auch alte (fas/far/fal/fat/fad/fab) Prefixe.
     */
    function parseClassString(value) {
        if (!value) { return null; }
        var parts = String(value).trim().split(/\s+/);
        var style = null;
        var name = null;
        var legacy = { fas: 'solid', far: 'regular', fal: 'light', fat: 'thin', fad: 'duotone', fab: 'brands' };
        for (var i = 0; i < parts.length; i++) {
            var p = parts[i];
            if (legacy[p]) {
                style = legacy[p];
            } else if (/^fa-(solid|regular|light|thin|duotone|brands)$/.test(p)) {
                style = p.slice(3);
            } else if (p === 'fa' || p === 'fa-fw' || p === '') {
                // Basis / Modifier ignorieren.
            } else if (p.indexOf('fa-') === 0) {
                name = p.slice(3);
            }
        }
        if (!name) { return null; }
        return { style: style || 'solid', name: name };
    }

    // ---------------------------------------------------------------------
    // DOM-Aufbau des Modals (einmalig, wird wiederverwendet)
    // ---------------------------------------------------------------------
    var ui = null;

    function buildUi() {
        if (ui) { return ui; }

        var root = document.createElement('div');
        root.className = 'rt-iconpicker';
        root.setAttribute('hidden', '');
        root.innerHTML = [
            '<div class="rt-iconpicker__backdrop" data-rt-close></div>',
            '<div class="rt-iconpicker__dialog" role="dialog" aria-modal="true" aria-label="Icon auswählen" tabindex="-1">',
            '  <div class="rt-iconpicker__header">',
            '    <h2 class="rt-iconpicker__title">Icon auswählen</h2>',
            '    <button type="button" class="rt-iconpicker__close" data-rt-close aria-label="Schließen">',
            '      <i class="fa fa-solid fa-times" aria-hidden="true"></i>',
            '    </button>',
            '  </div>',
            '  <div class="rt-iconpicker__toolbar">',
            '    <div class="rt-iconpicker__searchwrap">',
            '      <i class="fa fa-solid fa-search rt-iconpicker__searchicon" aria-hidden="true"></i>',
            '      <input type="search" class="rt-iconpicker__search" placeholder="Icon suchen…" aria-label="Icon suchen" autocomplete="off" spellcheck="false">',
            '    </div>',
            '    <div class="rt-iconpicker__styles" role="group" aria-label="Stil"></div>',
            '  </div>',
            '  <div class="rt-iconpicker__current">',
            '    <span class="rt-iconpicker__currentlabel">Aktuell:</span>',
            '    <span class="rt-iconpicker__preview" aria-live="polite"><em class="rt-iconpicker__none">Kein Icon</em></span>',
            '    <button type="button" class="rt-iconpicker__remove" data-rt-remove hidden>',
            '      <i class="fa fa-solid fa-times" aria-hidden="true"></i> Entfernen',
            '    </button>',
            '  </div>',
            '  <div class="rt-iconpicker__grid" role="listbox" aria-label="Icons" tabindex="0"></div>',
            '  <div class="rt-iconpicker__status" aria-live="polite"></div>',
            '</div>'
        ].join('');

        document.body.appendChild(root);

        ui = {
            root: root,
            dialog: root.querySelector('.rt-iconpicker__dialog'),
            search: root.querySelector('.rt-iconpicker__search'),
            styles: root.querySelector('.rt-iconpicker__styles'),
            grid: root.querySelector('.rt-iconpicker__grid'),
            preview: root.querySelector('.rt-iconpicker__preview'),
            removeBtn: root.querySelector('.rt-iconpicker__remove'),
            status: root.querySelector('.rt-iconpicker__status')
        };

        wireUiEvents();
        return ui;
    }

    // ---------------------------------------------------------------------
    // Laufzeit-State des offenen Pickers
    // ---------------------------------------------------------------------
    var session = {
        input: null,        // Ziel-Input
        onSelect: null,     // optionaler Callback
        style: 'solid',     // aktiver Stil
        query: '',          // Suchbegriff
        filtered: [],       // aktuell gefilterte Liste
        rendered: 0,        // wie viele bereits im DOM
        lastFocus: null,    // Fokus vor dem Oeffnen (Restore)
        activeIndex: -1     // Tastatur-Navigation
    };

    function wireUiEvents() {
        // Schliessen (Backdrop / X)
        ui.root.addEventListener('click', function (ev) {
            if (ev.target.closest('[data-rt-close]')) {
                close();
            }
        });

        // Entfernen
        ui.removeBtn.addEventListener('click', function () {
            applySelection('', '');
            close();
        });

        // Suche
        ui.search.addEventListener('input', function () {
            session.query = ui.search.value.trim().toLowerCase();
            rebuildGrid();
        });

        // ESC schliesst, Enter in Suche waehlt erstes Ergebnis
        ui.root.addEventListener('keydown', function (ev) {
            if (ev.key === 'Escape') {
                ev.preventDefault();
                close();
                return;
            }
            if (ev.target === ui.search && ev.key === 'Enter') {
                ev.preventDefault();
                if (session.filtered.length) {
                    focusCell(0);
                }
            }
        });

        // Grid: Klick-Auswahl (Delegation)
        ui.grid.addEventListener('click', function (ev) {
            var cell = ev.target.closest('[data-rt-icon]');
            if (cell) {
                selectCell(cell);
            }
        });

        // Tastatur-Navigation im Grid
        ui.grid.addEventListener('keydown', onGridKeydown);

        // Lazy-Rendering beim Scrollen
        ui.grid.addEventListener('scroll', function () {
            if (session.rendered >= session.filtered.length) { return; }
            var g = ui.grid;
            if (g.scrollTop + g.clientHeight >= g.scrollHeight - 240) {
                renderBatch();
            }
        });

        // Fokusfalle: Tab am Rand zurueckhalten
        ui.dialog.addEventListener('keydown', trapFocus);
    }

    function onGridKeydown(ev) {
        var cells = ui.grid.querySelectorAll('[data-rt-icon]');
        if (!cells.length) { return; }
        var cols = computeColumns();
        var idx = session.activeIndex;

        switch (ev.key) {
            case 'ArrowRight': idx += 1; break;
            case 'ArrowLeft': idx -= 1; break;
            case 'ArrowDown': idx += cols; break;
            case 'ArrowUp': idx -= cols; break;
            case 'Home': idx = 0; break;
            case 'End': idx = cells.length - 1; break;
            case 'Enter':
            case ' ':
                if (idx >= 0 && cells[idx]) {
                    ev.preventDefault();
                    selectCell(cells[idx]);
                }
                return;
            default:
                return;
        }
        ev.preventDefault();
        // Falls ans Ende der gerenderten Zellen navigiert wird: nachladen.
        while (idx >= cells.length && session.rendered < session.filtered.length) {
            renderBatch();
            cells = ui.grid.querySelectorAll('[data-rt-icon]');
        }
        idx = Math.max(0, Math.min(idx, cells.length - 1));
        focusCell(idx);
    }

    function computeColumns() {
        var cells = ui.grid.querySelectorAll('[data-rt-icon]');
        if (cells.length < 2) { return 1; }
        var top0 = cells[0].offsetTop;
        var cols = 0;
        for (var i = 0; i < cells.length; i++) {
            if (cells[i].offsetTop !== top0) { break; }
            cols++;
        }
        return cols || 1;
    }

    function focusCell(index) {
        var cells = ui.grid.querySelectorAll('[data-rt-icon]');
        if (!cells[index]) { return; }
        session.activeIndex = index;
        cells[index].focus();
    }

    function trapFocus(ev) {
        if (ev.key !== 'Tab') { return; }
        var focusables = ui.dialog.querySelectorAll(
            'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
        );
        var list = Array.prototype.filter.call(focusables, function (el) {
            return !el.hasAttribute('hidden') && el.offsetParent !== null;
        });
        if (!list.length) { return; }
        var first = list[0];
        var last = list[list.length - 1];
        if (ev.shiftKey && document.activeElement === first) {
            ev.preventDefault();
            last.focus();
        } else if (!ev.shiftKey && document.activeElement === last) {
            ev.preventDefault();
            first.focus();
        }
    }

    // ---------------------------------------------------------------------
    // Stil-Umschalter aufbauen
    // ---------------------------------------------------------------------
    function buildStyleToggles() {
        ui.styles.innerHTML = '';
        (availableStyles || ['solid']).forEach(function (style) {
            var btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'rt-iconpicker__style';
            btn.setAttribute('data-style', style);
            btn.setAttribute('aria-pressed', style === session.style ? 'true' : 'false');
            btn.textContent = STYLE_LABELS[style] || style;
            btn.addEventListener('click', function () {
                session.style = style;
                updateStyleToggles();
                rebuildGrid();
            });
            ui.styles.appendChild(btn);
        });
    }

    function updateStyleToggles() {
        var btns = ui.styles.querySelectorAll('.rt-iconpicker__style');
        Array.prototype.forEach.call(btns, function (b) {
            b.setAttribute('aria-pressed', b.getAttribute('data-style') === session.style ? 'true' : 'false');
        });
    }

    // ---------------------------------------------------------------------
    // Grid rendern (mit Filter + Lazy-Batch)
    // ---------------------------------------------------------------------
    function rebuildGrid() {
        var q = session.query;
        var style = session.style;
        session.filtered = (iconData || []).filter(function (it) {
            if (it.styles.indexOf(style) === -1) { return false; }
            if (!q) { return true; }
            return it.search.indexOf(q) !== -1;
        });
        // Namens-Treffer nach vorne (Relevanz).
        if (q) {
            session.filtered.sort(function (a, b) {
                var an = a.name.indexOf(q) === 0 ? 0 : (a.name.indexOf(q) !== -1 ? 1 : 2);
                var bn = b.name.indexOf(q) === 0 ? 0 : (b.name.indexOf(q) !== -1 ? 1 : 2);
                if (an !== bn) { return an - bn; }
                return a.name < b.name ? -1 : (a.name > b.name ? 1 : 0);
            });
        }
        ui.grid.innerHTML = '';
        session.rendered = 0;
        session.activeIndex = -1;
        renderBatch();

        var total = session.filtered.length;
        if (!total) {
            ui.status.textContent = 'Keine Icons gefunden.';
            ui.grid.innerHTML = '<p class="rt-iconpicker__empty">Keine Treffer für „' +
                escapeHtml(session.query) + '“.</p>';
        } else {
            ui.status.textContent = total + ' Icon' + (total === 1 ? '' : 's') +
                (loadFailed ? ' (Kern-Liste – Metadaten nicht geladen)' : '');
        }
    }

    function renderBatch() {
        var frag = document.createDocumentFragment();
        var end = Math.min(session.rendered + BATCH_SIZE, session.filtered.length);
        var current = session.input ? parseClassString(session.input.value) : null;
        for (var i = session.rendered; i < end; i++) {
            var it = session.filtered[i];
            var cell = document.createElement('button');
            cell.type = 'button';
            cell.className = 'rt-iconpicker__cell';
            cell.setAttribute('data-rt-icon', it.name);
            cell.setAttribute('data-style', session.style);
            cell.setAttribute('role', 'option');
            cell.setAttribute('tabindex', '-1');
            cell.setAttribute('title', it.name);
            if (current && current.name === it.name && current.style === session.style) {
                cell.classList.add('is-selected');
                cell.setAttribute('aria-selected', 'true');
            }
            cell.innerHTML = '<i class="' + iconClass(session.style, it.name) +
                '" aria-hidden="true"></i><span class="rt-iconpicker__cellname">' +
                escapeHtml(it.name) + '</span>';
            frag.appendChild(cell);
        }
        ui.grid.appendChild(frag);
        session.rendered = end;
    }

    function selectCell(cell) {
        var name = cell.getAttribute('data-rt-icon');
        var style = cell.getAttribute('data-style') || session.style;
        applySelection(style, name);
        close();
    }

    // ---------------------------------------------------------------------
    // Auswahl anwenden: Wert ins Input schreiben + Events + Vorschau
    // ---------------------------------------------------------------------
    function applySelection(style, name) {
        var value = (style && name) ? storedValue(style, name) : '';
        if (session.input) {
            session.input.value = value;
            // Events fuer Livewire/Alpine/GrapesJS und native Listener.
            dispatch(session.input, 'input');
            dispatch(session.input, 'change');
        }
        updatePreviewFor(session.input, value);
        if (typeof session.onSelect === 'function') {
            try { session.onSelect(value, { style: style, name: name }); } catch (e) { /* still */ }
        }
    }

    function dispatch(el, type) {
        var ev;
        try {
            ev = new Event(type, { bubbles: true });
        } catch (e) {
            ev = document.createEvent('Event');
            ev.initEvent(type, true, true);
        }
        el.dispatchEvent(ev);
    }

    // Vorschau im Modal
    function renderModalPreview(value) {
        var parsed = parseClassString(value);
        if (parsed) {
            ui.preview.innerHTML = '<i class="' + iconClass(parsed.style, parsed.name) +
                '" aria-hidden="true"></i> <code>' + escapeHtml(value) + '</code>';
            ui.removeBtn.hidden = false;
        } else {
            ui.preview.innerHTML = '<em class="rt-iconpicker__none">Kein Icon</em>';
            ui.removeBtn.hidden = true;
        }
    }

    // Externe Live-Vorschau neben dem Input (falls per attach() erzeugt).
    function updatePreviewFor(input, value) {
        renderModalPreview(value);
        if (!input) { return; }
        var host = input.__rtIconPreview;
        if (!host && input.id) {
            host = document.querySelector('[data-rt-icon-preview="#' + cssEscape(input.id) + '"]');
        }
        if (host) {
            var parsed = parseClassString(value);
            host.innerHTML = parsed
                ? '<i class="' + iconClass(parsed.style, parsed.name) + '" aria-hidden="true"></i>'
                : '';
        }
    }

    // ---------------------------------------------------------------------
    // Oeffnen / Schliessen
    // ---------------------------------------------------------------------
    function open(input, options) {
        options = options || {};
        buildUi();

        session.input = input || null;
        session.onSelect = options.onSelect || null;
        session.lastFocus = document.activeElement;
        session.query = '';

        // Vorbelegung anhand des aktuellen Input-Werts.
        var current = input ? parseClassString(input.value) : null;

        ui.root.removeAttribute('hidden');
        document.body.classList.add('rt-iconpicker-open');

        loadIcons().then(function () {
            // Aktiven Stil bestimmen.
            if (current && availableStyles.indexOf(current.style) !== -1) {
                session.style = current.style;
            } else if (availableStyles.indexOf('solid') !== -1) {
                session.style = 'solid';
            } else {
                session.style = availableStyles[0];
            }
            buildStyleToggles();
            ui.search.value = '';
            rebuildGrid();
            renderModalPreview(input ? input.value : '');
            // Fokus in die Suche.
            window.setTimeout(function () { ui.search.focus(); }, 30);
        });
    }

    function close() {
        if (!ui) { return; }
        ui.root.setAttribute('hidden', '');
        document.body.classList.remove('rt-iconpicker-open');
        var restore = session.lastFocus;
        session.input = null;
        session.onSelect = null;
        if (restore && typeof restore.focus === 'function') {
            try { restore.focus(); } catch (e) { /* still */ }
        }
    }

    // ---------------------------------------------------------------------
    // attach(): Input verdrahten + Knopf/Vorschau erzeugen
    // ---------------------------------------------------------------------
    function attach(input, options) {
        if (!input || input.__rtIconAttached) { return; }
        input.__rtIconAttached = true;
        options = options || {};

        // Wrapper fuer Vorschau + Button, direkt hinter dem Input.
        var wrap = document.createElement('span');
        wrap.className = 'rt-iconpicker-field';

        var preview = document.createElement('span');
        preview.className = 'rt-iconpicker-field__preview';
        input.__rtIconPreview = preview;

        var btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'rt-iconpicker-field__btn';
        btn.innerHTML = '<i class="fa fa-solid fa-icons" aria-hidden="true"></i><span>Icon wählen</span>';
        btn.addEventListener('click', function () {
            open(input, options);
        });

        if (input.parentNode) {
            input.parentNode.insertBefore(wrap, input.nextSibling);
            wrap.appendChild(preview);
            wrap.appendChild(btn);
        }

        // Initiale Vorschau + Sync bei manueller Eingabe.
        updatePreviewFor(input, input.value);
        input.addEventListener('input', function () {
            var parsed = parseClassString(input.value);
            preview.innerHTML = parsed
                ? '<i class="' + iconClass(parsed.style, parsed.name) + '" aria-hidden="true"></i>'
                : '';
        });
    }

    // ---------------------------------------------------------------------
    // Trigger-Aufloesung (data-rt-icon-picker + data-rt-icon-target)
    // ---------------------------------------------------------------------
    function resolveTarget(trigger) {
        var sel = trigger.getAttribute('data-rt-icon-target');
        if (sel) {
            var el = document.querySelector(sel);
            if (el) { return el; }
        }
        // Fallback: benachbartes Input.
        var near = trigger.previousElementSibling;
        if (near && near.matches && near.matches('input, textarea')) { return near; }
        return null;
    }

    function openFromTrigger(trigger) {
        var input = resolveTarget(trigger);
        if (!input) {
            if (window.console && console.warn) {
                console.warn('[RtIconPicker] Kein Ziel-Input für Trigger gefunden.', trigger);
            }
            return;
        }
        open(input);
    }

    // Delegation: funktioniert auch fuer dynamisch eingefuegte Trigger.
    document.addEventListener('click', function (ev) {
        var trigger = ev.target.closest('[data-rt-icon-picker]');
        if (trigger) {
            ev.preventDefault();
            openFromTrigger(trigger);
        }
    });
    document.addEventListener('keydown', function (ev) {
        if (ev.key !== 'Enter' && ev.key !== ' ') { return; }
        var trigger = ev.target.closest('[data-rt-icon-picker]');
        // Nur wenn der Trigger selbst kein nativ bedienbares Element ist.
        if (trigger && trigger.getAttribute('data-rt-icon-picker') !== null &&
            !/^(button|a|input)$/i.test(trigger.tagName)) {
            ev.preventDefault();
            openFromTrigger(trigger);
        }
    });

    // Auto-attach fuer Inputs mit data-rt-icon-input (optionale Bequemlichkeit).
    function refresh() {
        var inputs = document.querySelectorAll('[data-rt-icon-input]');
        Array.prototype.forEach.call(inputs, function (inp) { attach(inp); });
    }

    // ---------------------------------------------------------------------
    // kleine Utilities
    // ---------------------------------------------------------------------
    function escapeHtml(str) {
        return String(str == null ? '' : str)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }

    function cssEscape(str) {
        if (window.CSS && CSS.escape) { return CSS.escape(str); }
        return String(str).replace(/[^a-zA-Z0-9_-]/g, '\\$&');
    }

    // ---------------------------------------------------------------------
    // Oeffentliche API
    // ---------------------------------------------------------------------
    window.RtIconPicker = {
        __ready: true,
        open: open,
        close: close,
        attach: attach,
        refresh: refresh,
        load: loadIcons,
        parse: parseClassString,
        get metadataUrl() { return METADATA_URL; }
    };

    // Auto-Init.
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', refresh);
    } else {
        refresh();
    }
})();
