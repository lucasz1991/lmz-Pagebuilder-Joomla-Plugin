(function () {
    'use strict';

    function getJoomlaOptions(key) {
        const direct = window.Joomla?.getOptions?.(key);
        if (direct && typeof direct === 'object') return direct;

        for (const node of document.querySelectorAll('script.joomla-script-options[type="application/json"]')) {
            try {
                const payload = JSON.parse(node.textContent || '{}');
                if (payload && typeof payload[key] === 'object') return payload[key];
            } catch (error) {
                // Ignore an unrelated malformed options node and keep looking.
            }
        }

        return {};
    }

    const escapeText = (value) => String(value ?? '');
    const escapeHtml = (value) => escapeText(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
    const LMZ_BLOCK_CATALOG_VERSION = '2.4.5';

    function siteAssetUrl(rootUrl, path) {
        const joined = `${String(rootUrl || '').replace(/\/+$/, '')}/${String(path).replace(/^\/+/, '')}`;
        try {
            const url = new URL(joined, window.location.origin + '/');
            return url.origin === window.location.origin ? url.pathname + url.search + url.hash : url.href;
        } catch (error) {
            return joined;
        }
    }

    function lmzStandardBlocks(rootUrl) {
        const siteAsset = (path) => siteAssetUrl(rootUrl, path);
        const editorialImage = siteAsset('images/l3/stock/AdobeStock_721131368-web.jpg');
        const serviceImage = siteAsset('images/l3/stock/wagenmeister-dienstleistungen-web.jpg');
        const emergencyImage = siteAsset('images/l3/stock/notfalldienst-24-7-web.jpg');
        const videoPoster = siteAsset('images/l3/start3-first-frame-v2.jpg');
        const heroVideo = siteAsset('images/l3/start3.mp4');
        const category = (name) => `LMZ · ${name}`;
        const block = (id, label, group, content) => ({
            id: `lmz-v2-${id}`,
            definition: {
                label,
                category: category(group),
                content,
                lmzCatalogVersion: LMZ_BLOCK_CATALOG_VERSION,
                attributes: { title: `${label} · Katalog ${LMZ_BLOCK_CATALOG_VERSION}` },
            },
        });

        return [
            block('section', 'Abschnitt', 'Layout', '<section class="py-16" data-lmz-section><div class="mx-auto max-w-7xl px-6"><h2 class="text-3xl font-bold">Neuer Abschnitt</h2><p class="mt-4 max-w-2xl">Inhalte hier einfügen.</p></div></section>'),
            block('container', 'Container', 'Layout', '<div class="mx-auto max-w-7xl px-6 py-8"><p>Inhalt im zentrierten Container</p></div>'),
            block('columns-2', '2 Spalten', 'Layout', '<section class="mx-auto grid max-w-7xl gap-8 px-6 py-12 md:grid-cols-2"><div class="rounded-2xl bg-slate-50 p-8"><h3 class="text-2xl font-bold">Spalte eins</h3><p class="mt-3">Inhalt</p></div><div class="rounded-2xl bg-slate-50 p-8"><h3 class="text-2xl font-bold">Spalte zwei</h3><p class="mt-3">Inhalt</p></div></section>'),
            block('columns-3', '3 Spalten', 'Layout', '<section class="mx-auto grid max-w-7xl gap-6 px-6 py-12 md:grid-cols-3"><article class="rounded-2xl border border-slate-200 p-7"><h3 class="text-xl font-bold">Eins</h3><p class="mt-3">Inhalt</p></article><article class="rounded-2xl border border-slate-200 p-7"><h3 class="text-xl font-bold">Zwei</h3><p class="mt-3">Inhalt</p></article><article class="rounded-2xl border border-slate-200 p-7"><h3 class="text-xl font-bold">Drei</h3><p class="mt-3">Inhalt</p></article></section>'),
            block('card-grid', 'Kachelraster', 'Layout', '<section class="mx-auto grid max-w-7xl gap-5 px-6 py-12 sm:grid-cols-2 lg:grid-cols-3" data-lmz-motion="fade-up" data-lmz-stagger="0.1"><article class="rounded-2xl bg-slate-950 p-8 text-white"><strong>01</strong><h3 class="mt-8 text-2xl font-bold">Erste Kachel</h3></article><article class="rounded-2xl bg-teal-700 p-8 text-white"><strong>02</strong><h3 class="mt-8 text-2xl font-bold">Zweite Kachel</h3></article><article class="rounded-2xl bg-slate-100 p-8"><strong>03</strong><h3 class="mt-8 text-2xl font-bold">Dritte Kachel</h3></article></section>'),
            block('stack', 'Vertikaler Stapel', 'Layout', '<div class="mx-auto flex max-w-4xl flex-col gap-6 px-6 py-12"><article class="rounded-2xl border border-slate-200 p-8">Erster Inhalt</article><article class="rounded-2xl border border-slate-200 p-8">Zweiter Inhalt</article></div>'),
            block('divider', 'Trennlinie', 'Layout', '<hr class="mx-auto my-10 max-w-7xl border-0 border-t border-slate-200">'),
            block('spacer', 'Abstand', 'Layout', '<div class="h-16" aria-hidden="true" data-gjs-name="Abstand"></div>'),

            block('heading-1', 'Überschrift H1', 'Typografie', '<h1 class="text-5xl font-bold leading-tight">Seitentitel</h1>'),
            block('heading-2', 'Überschrift H2', 'Typografie', '<h2 class="text-4xl font-bold leading-tight">Abschnittsüberschrift</h2>'),
            block('paragraph', 'Absatz', 'Typografie', '<p class="max-w-3xl text-lg leading-relaxed text-slate-700">Doppelklicken Sie, um diesen Text zu bearbeiten.</p>'),
            block('richtext', 'Textgruppe', 'Typografie', '<div class="prose max-w-3xl"><h2>Eine klare Überschrift</h2><p>Ein einleitender Absatz mit <strong>Hervorhebung</strong> und einem <a href="#">weiterführenden Link</a>.</p><p>Ein zweiter Absatz strukturiert den Inhalt verständlich.</p></div>'),
            block('quote', 'Zitat', 'Typografie', '<figure class="border-l-4 border-teal-600 py-3 pl-7"><blockquote class="text-2xl font-semibold leading-relaxed">„Ein prägnantes Zitat schafft Vertrauen.“</blockquote><figcaption class="mt-4 text-sm text-slate-600">Name · Funktion</figcaption></figure>'),
            block('list', 'Liste', 'Typografie', '<ul class="space-y-3"><li class="flex gap-3"><span aria-hidden="true">✓</span><span>Erster Vorteil</span></li><li class="flex gap-3"><span aria-hidden="true">✓</span><span>Zweiter Vorteil</span></li><li class="flex gap-3"><span aria-hidden="true">✓</span><span>Dritter Vorteil</span></li></ul>'),
            block('badge', 'Label / Badge', 'Typografie', '<span class="inline-flex rounded-full bg-teal-100 px-3 py-1 text-sm font-bold text-teal-900">Neues Label</span>'),

            block('image', 'Bild', 'Medien', `<img class="h-auto w-full rounded-2xl object-cover" src="${editorialImage}" alt="Beschreibung des Bildes">`),
            block('figure', 'Bild mit Bildtext', 'Medien', `<figure><img class="aspect-video w-full rounded-2xl object-cover" src="${serviceImage}" alt="RailTime Einsatz"><figcaption class="mt-3 text-sm text-slate-600">Bildbeschreibung ergänzen</figcaption></figure>`),
            block('video', 'Video', 'Medien', `<video class="aspect-video w-full rounded-2xl bg-slate-950 object-cover" controls preload="metadata" poster="${videoPoster}"><source src="${heroVideo}" type="video/mp4">Ihr Browser unterstützt dieses Video nicht.</video>`),
            block('audio', 'Audio', 'Medien', '<figure class="rounded-2xl bg-slate-100 p-6"><figcaption class="mb-3 font-bold">Audiotitel</figcaption><audio class="w-full" controls preload="none">Ihr Browser unterstützt Audio nicht.</audio></figure>'),
            block('gallery', '3er-Galerie', 'Medien', `<div class="grid gap-4 md:grid-cols-3" data-lmz-motion="fade-up" data-lmz-stagger="0.08"><img class="aspect-square w-full rounded-2xl object-cover" src="${editorialImage}" alt="Galeriebild eins"><img class="aspect-square w-full rounded-2xl object-cover" src="${serviceImage}" alt="Galeriebild zwei"><img class="aspect-square w-full rounded-2xl object-cover" src="${emergencyImage}" alt="Galeriebild drei"></div>`),

            block('form', 'Formular', 'Formulare', '<form class="mx-auto grid max-w-2xl gap-5 rounded-2xl border border-slate-200 p-8" action="#" method="post"><label class="grid gap-2 font-semibold">Name<input class="rounded-lg border border-slate-300 px-4 py-3 font-normal" name="name" autocomplete="name" required></label><label class="grid gap-2 font-semibold">E-Mail<input class="rounded-lg border border-slate-300 px-4 py-3 font-normal" type="email" name="email" autocomplete="email" required></label><label class="grid gap-2 font-semibold">Nachricht<textarea class="min-h-32 rounded-lg border border-slate-300 px-4 py-3 font-normal" name="message" required></textarea></label><button class="rounded-full bg-slate-950 px-6 py-3 font-bold text-white" type="submit">Absenden</button></form>'),
            block('input', 'Eingabefeld', 'Formulare', '<label class="grid gap-2 font-semibold">Bezeichnung<input class="rounded-lg border border-slate-300 px-4 py-3 font-normal" name="field" placeholder="Eingabe"></label>'),
            block('textarea', 'Textfeld', 'Formulare', '<label class="grid gap-2 font-semibold">Nachricht<textarea class="min-h-32 rounded-lg border border-slate-300 px-4 py-3 font-normal" name="message" placeholder="Ihre Nachricht"></textarea></label>'),
            block('select', 'Auswahlfeld', 'Formulare', '<label class="grid gap-2 font-semibold">Auswahl<select class="rounded-lg border border-slate-300 px-4 py-3 font-normal" name="selection"><option value="">Bitte wählen</option><option value="one">Option eins</option><option value="two">Option zwei</option></select></label>'),
            block('checkbox', 'Checkbox', 'Formulare', '<label class="flex items-start gap-3"><input class="mt-1 h-5 w-5" type="checkbox" name="consent" value="1"><span>Ich stimme der Verarbeitung meiner Angaben zu.</span></label>'),
            block('submit', 'Senden-Button', 'Formulare', '<button class="inline-flex rounded-full bg-teal-700 px-6 py-3 font-bold text-white" type="submit">Formular absenden</button>'),

            block('tabs', 'Tabs', 'Tabs & Accordion', '<section data-lmz-tabs><div class="flex flex-wrap gap-2 border-b border-slate-200" role="tablist" aria-label="Inhaltsbereiche"><button class="border-b-2 border-teal-700 px-4 py-3 font-bold" type="button" role="tab" aria-selected="true">Tab eins</button><button class="px-4 py-3 font-bold text-slate-500" type="button" role="tab" aria-selected="false">Tab zwei</button></div><div class="py-6" role="tabpanel"><h3 class="text-2xl font-bold">Inhalt von Tab eins</h3><p class="mt-3">Tab-Inhalt bearbeiten.</p></div></section>'),
            block('accordion', 'Accordion', 'Tabs & Accordion', '<div class="divide-y divide-slate-200 rounded-2xl border border-slate-200"><details class="p-6" open><summary class="cursor-pointer text-lg font-bold">Erster Bereich</summary><div class="pt-4 text-slate-700">Inhalt des ersten Bereichs.</div></details><details class="p-6"><summary class="cursor-pointer text-lg font-bold">Zweiter Bereich</summary><div class="pt-4 text-slate-700">Inhalt des zweiten Bereichs.</div></details></div>'),

            block('navigation', 'Navigation', 'Navigation', '<nav aria-label="Bereichsnavigation"><ul class="flex flex-wrap items-center gap-6 font-semibold"><li><a href="#">Start</a></li><li><a href="#">Leistungen</a></li><li><a href="#">Kontakt</a></li></ul></nav>'),
            block('breadcrumbs', 'Breadcrumbs', 'Navigation', '<nav aria-label="Brotkrümelnavigation"><ol class="flex flex-wrap items-center gap-2 text-sm text-slate-600"><li><a href="/">Startseite</a></li><li aria-hidden="true">/</li><li aria-current="page">Aktuelle Seite</li></ol></nav>'),
            block('pagination', 'Seitennavigation', 'Navigation', '<nav class="flex items-center justify-between gap-4" aria-label="Seitennavigation"><a class="rounded-full border border-slate-300 px-5 py-2" href="#">Zurück</a><span>Seite 1 von 3</span><a class="rounded-full border border-slate-300 px-5 py-2" href="#">Weiter</a></nav>'),

            block('table', 'Tabelle', 'Tabellen', '<div class="overflow-x-auto"><table class="w-full border-collapse text-left"><thead><tr class="bg-slate-100"><th class="border border-slate-200 p-4">Leistung</th><th class="border border-slate-200 p-4">Umfang</th><th class="border border-slate-200 p-4">Status</th></tr></thead><tbody><tr><td class="border border-slate-200 p-4">Beispiel A</td><td class="border border-slate-200 p-4">Standard</td><td class="border border-slate-200 p-4">Verfügbar</td></tr><tr><td class="border border-slate-200 p-4">Beispiel B</td><td class="border border-slate-200 p-4">Individuell</td><td class="border border-slate-200 p-4">Auf Anfrage</td></tr></tbody></table></div>'),
            block('comparison', 'Vergleichstabelle', 'Tabellen', '<div class="overflow-x-auto"><table class="w-full min-w-2xl text-left"><thead><tr><th class="p-4">Merkmal</th><th class="bg-slate-100 p-4">Basis</th><th class="bg-teal-50 p-4">Plus</th></tr></thead><tbody><tr class="border-t"><th class="p-4">Verfügbarkeit</th><td class="p-4">Geschäftszeiten</td><td class="p-4">24/7</td></tr><tr class="border-t"><th class="p-4">Ansprechpartner</th><td class="p-4">Team</td><td class="p-4">Persönlich</td></tr></tbody></table></div>'),

            block('joomla-article', 'Joomla-Beitrag', 'Joomla-Embeds', '<div class="rounded-2xl border-2 border-dashed border-indigo-300 bg-indigo-50 p-8 text-indigo-950" data-lmz-embed-kind="article" data-lmz-embed-id="" data-gjs-name="Joomla-Beitrag"><strong>Joomla-Beitrag</strong><p class="mt-2 text-sm">Beitrag in den Eigenschaften auswählen.</p></div>'),
            block('joomla-module', 'Joomla-Modul', 'Joomla-Embeds', '<div class="rounded-2xl border-2 border-dashed border-violet-300 bg-violet-50 p-8 text-violet-950" data-lmz-embed-kind="module" data-lmz-embed-id="" data-gjs-name="Joomla-Modul"><strong>Joomla-Modul</strong><p class="mt-2 text-sm">Modul in den Eigenschaften auswählen.</p></div>'),
            block('smartslider', 'Smart Slider 3', 'Joomla-Embeds', '<div class="rounded-2xl border-2 border-dashed border-sky-300 bg-sky-50 p-8 text-sky-950" data-lmz-embed-kind="smartslider" data-lmz-embed-id="" data-gjs-name="Smart Slider 3"><strong>Smart Slider 3</strong><p class="mt-2 text-sm">Slider in den Eigenschaften auswählen. Im Editor wird nur eine sichere Vorschau gezeigt.</p></div>'),

            block('shared-element', 'Globales Element', 'Globale Elemente', '<div class="rounded-2xl border-2 border-dashed border-amber-300 bg-amber-50 p-8 text-amber-950" data-lmz-shared-element="" data-lmz-shared-language="current" data-gjs-name="Globales Element"><strong>Globales Element</strong><p class="mt-2 text-sm">Wiederverwendbares Element in den Eigenschaften auswählen.</p></div>'),

            block('template-editorial', 'Editorial Bild + Text', 'Vorlagen', `<section class="mx-auto grid max-w-7xl items-center gap-12 px-6 py-20 lg:grid-cols-[1.1fr_.9fr]"><figure class="overflow-hidden rounded-3xl"><img class="aspect-[4/3] h-full w-full object-cover" src="${editorialImage}" alt="RailTime"></figure><div data-lmz-motion="fade-up"><p class="text-sm font-bold uppercase tracking-widest text-teal-700">Editorial</p><h2 class="mt-4 text-4xl font-bold">Eine starke Geschichte klar erzählt.</h2><p class="mt-6 text-lg leading-relaxed text-slate-700">Kombinieren Sie Bild, Überschrift, Text und Handlungsaufforderung.</p><a class="mt-8 inline-flex rounded-full bg-slate-950 px-6 py-3 font-bold text-white" href="#">Mehr erfahren</a></div></section>`),
            block('template-contact', 'Kontaktsegment', 'Vorlagen', '<section class="bg-slate-950 py-20 text-white"><div class="mx-auto flex max-w-7xl flex-col justify-between gap-10 px-6 lg:flex-row lg:items-end"><div><p class="text-sm font-bold uppercase tracking-widest text-teal-300">Kontakt</p><h2 class="mt-4 max-w-3xl text-4xl font-bold">Lassen Sie uns über Ihren nächsten Einsatz sprechen.</h2></div><a class="inline-flex rounded-full bg-white px-6 py-3 font-bold text-slate-950" href="kontakt">Kontakt aufnehmen</a></div></section>'),
        ];
    }

    function railTimeBlocks(rootUrl) {
        const siteAsset = (path) => siteAssetUrl(rootUrl, path);
        const serviceImage = siteAsset('images/l3/stock/wagenmeister-dienstleistungen-web.jpg');
        const heroImage = siteAsset('images/l3/railtime-hero.png');

        return [
            {
                id: 'rt-section',
                definition: {
                    label: 'Abschnitt',
                    category: 'RailTime · Layout',
                    content: '<section class="rt-section bg-white py-20"><div class="rt-container mx-auto px-6"><p class="rt-kicker">Abschnitt</p><h2 class="rt-heading">Neue Überschrift</h2><p class="rt-copy mt-5 max-w-2xl">Beschreiben Sie hier den Inhalt dieses Abschnitts.</p></div></section>',
                },
            },
            {
                id: 'rt-split',
                definition: {
                    label: 'Bild + Text',
                    category: 'RailTime · Layout',
                    content: `<section class="rt-section bg-white py-20"><div class="rt-container mx-auto grid items-center gap-12 px-6 lg:grid-cols-2"><figure class="overflow-hidden rounded-2xl"><img class="h-full w-full object-cover" src="${serviceImage}" alt="RailTime Einsatz"></figure><div><p class="rt-kicker">RailTime</p><h2 class="rt-heading">Sicherheit auf der Schiene</h2><p class="rt-copy mt-5">Bearbeiten Sie Bild, Text und Abstände direkt im Editor.</p><a class="rt-button mt-8 inline-flex" href="#">Mehr erfahren</a></div></div></section>`,
                },
            },
            {
                id: 'rt-columns',
                definition: {
                    label: 'Zwei Spalten',
                    category: 'RailTime · Layout',
                    content: '<section class="rt-section bg-slate-50 py-16"><div class="rt-container mx-auto grid gap-6 px-6 md:grid-cols-2"><article class="rounded-2xl bg-white p-8"><p class="rt-kicker">01</p><h3 class="mt-3 text-2xl font-bold">Erste Spalte</h3><p class="mt-4">Inhalt der ersten Spalte.</p></article><article class="rounded-2xl bg-white p-8"><p class="rt-kicker">02</p><h3 class="mt-3 text-2xl font-bold">Zweite Spalte</h3><p class="mt-4">Inhalt der zweiten Spalte.</p></article></div></section>',
                },
            },
            {
                id: 'rt-hero',
                definition: {
                    label: 'Hero',
                    category: 'RailTime · Layout',
                    content: '<section class="relative overflow-hidden bg-slate-950 py-28 text-white"><div class="rt-container relative z-10 mx-auto px-6"><p class="rt-kicker text-teal-300">Deutschlandweit im Einsatz</p><h1 class="mt-4 max-w-4xl text-5xl font-bold leading-tight">Ihr zuverlässiger Partner im Eisenbahnbetrieb.</h1><p class="mt-6 max-w-2xl text-lg text-slate-200">Sicher. Flexibel. Rund um die Uhr erreichbar.</p><a class="mt-9 inline-flex rounded-full bg-white px-6 py-3 font-bold text-slate-950" href="#">Einsatz anfragen</a></div></section>',
                },
            },
            {
                id: 'rt-kpis',
                definition: {
                    label: 'Kennzahlen',
                    category: 'RailTime · Inhalte',
                    content: '<section class="bg-slate-950 py-14 text-white"><div class="rt-container mx-auto grid gap-8 px-6 md:grid-cols-3"><div><strong class="text-4xl">24/7</strong><p class="mt-2 text-slate-300">Notfalldienst</p></div><div><strong class="text-4xl">100%</strong><p class="mt-2 text-slate-300">Einsatzbereitschaft</p></div><div><strong class="text-4xl">DE</strong><p class="mt-2 text-slate-300">Deutschlandweit</p></div></div></section>',
                },
            },
            {
                id: 'rt-cta',
                definition: {
                    label: 'Kontakt CTA',
                    category: 'RailTime · Inhalte',
                    content: '<section class="bg-teal-700 py-16 text-white"><div class="rt-container mx-auto flex flex-col justify-between gap-8 px-6 lg:flex-row lg:items-center"><div><p class="text-sm font-bold uppercase tracking-widest text-teal-100">Bereit für den nächsten Einsatz?</p><h2 class="mt-3 text-4xl font-bold">Sprechen wir über Ihren Bedarf.</h2></div><a class="inline-flex rounded-full bg-white px-6 py-3 font-bold text-teal-800" href="kontakt">Kontakt aufnehmen</a></div></section>',
                },
            },
            {
                id: 'rt-heading',
                definition: { label: 'Überschrift', category: 'RailTime · Basis', content: '<h2 class="rt-heading text-4xl font-bold">Neue Überschrift</h2>' },
            },
            {
                id: 'rt-text',
                definition: { label: 'Text', category: 'RailTime · Basis', content: '<p class="rt-copy leading-relaxed">Bearbeitbarer RailTime-Text. Doppelklicken Sie, um den Inhalt zu ändern.</p>' },
            },
            {
                id: 'rt-button',
                definition: { label: 'Button', category: 'RailTime · Basis', content: '<a class="rt-button inline-flex rounded-full bg-slate-950 px-6 py-3 font-bold text-white" href="#">Mehr erfahren</a>' },
            },
            {
                id: 'rt-image',
                definition: { label: 'Bild', category: 'RailTime · Basis', content: `<img class="h-auto w-full rounded-2xl object-cover" src="${heroImage}" alt="RailTime">` },
            },
            {
                id: 'rt-divider',
                definition: { label: 'Trennlinie', category: 'RailTime · Basis', content: '<hr class="my-10 border-0 border-t border-slate-200">' },
            },
            {
                id: 'rt-spacer',
                definition: { label: 'Abstand', category: 'RailTime · Basis', content: '<div class="h-16" aria-hidden="true"></div>' },
            },
        ];
    }

    function lmzEmbedCatalogBlocks(catalog) {
        if (!catalog || typeof catalog !== 'object') return [];
        const groups = [
            { key: 'articles', kind: 'article', prefix: 'article', category: 'Joomla · Beiträge', hint: 'Joomla-Beitrag' },
            { key: 'modules', kind: 'module', prefix: 'module', category: 'Joomla · Module', hint: 'Joomla-Modul' },
            { key: 'smartsliders', kind: 'smartslider', prefix: 'smartslider', category: 'Joomla · Smart Slider 3', hint: 'Smart Slider 3' },
        ];

        return groups.flatMap((group) => {
            const items = Array.isArray(catalog[group.key]) ? catalog[group.key] : [];
            return items.slice(0, 100).flatMap((item) => {
                const id = Number(item?.id);
                if (!Number.isInteger(id) || id <= 0) return [];
                const title = escapeHtml(item?.title || item?.name || `${group.hint} #${id}`);
                const context = escapeHtml(item?.category_title || item?.position || item?.module || '');
                const contextMarkup = context ? `<small class="mt-2 block opacity-70">${context}</small>` : '';
                return [{
                    id: `lmz-v2-embed-${group.prefix}-${id}`,
                    definition: {
                        label: title,
                        category: group.category,
                        lmzCatalogVersion: LMZ_BLOCK_CATALOG_VERSION,
                        attributes: { title: `${group.hint} #${id}` },
                        content: `<div class="rounded-2xl border-2 border-dashed border-indigo-300 bg-indigo-50 p-8 text-indigo-950" data-lmz-embed-kind="${group.kind}" data-lmz-embed-id="${id}" data-gjs-name="${group.hint}"><strong>${title}</strong>${contextMarkup}</div>`,
                    },
                }];
            });
        });
    }

    function lmzSharedElementBlocks(elements, currentElementId, currentLanguage) {
        if (!Array.isArray(elements)) return [];

        return elements.slice(0, 200).flatMap((element) => {
            const id = Number(element?.id);
            const key = String(element?.element_key || '').trim();
            if (!Number.isInteger(id) || id <= 0 || id === Number(currentElementId) || !/^[a-z0-9][a-z0-9._-]{0,99}$/i.test(key)) return [];
            const title = escapeHtml(element?.title || key);
            const usageCount = Math.max(0, Number(element?.usage_count) || 0);
            const currentVariant = element?.variants?.[currentLanguage] || null;
            const published = Number(element?.state) === 1 && Number(currentVariant?.state) === 1;
            const status = published ? 'Veröffentlicht' : 'Nicht veröffentlicht';

            if (String(element?.kind || '') === 'template') {
                const html = String(currentVariant?.published_html || currentVariant?.draft_html || '').trim();
                const css = String(currentVariant?.published_css || currentVariant?.draft_css || '').trim();
                if (!html) return [];
                const style = css ? `<style>${css.replace(/<\/style/gi, '')}</style>` : '';
                return [{
                    id: `lmz-v2-template-${id}-${String(currentLanguage || 'current').replace(/[^a-z0-9_-]/gi, '-')}`,
                    definition: {
                        label: title,
                        category: 'Vorlagen · Gespeichert',
                        lmzCatalogVersion: LMZ_BLOCK_CATALOG_VERSION,
                        attributes: { title: `${status} · Kopie der Sprachvariante ${currentLanguage || ''}` },
                        content: `${style}${html}`,
                    },
                }];
            }

            if (!currentVariant || Number(currentVariant.state) !== 1 || Number(element?.state) !== 1) return [];

            const previewHtml = String(currentVariant?.published_html || currentVariant?.draft_html || '').trim();
            const preview = previewHtml || `<div class="rounded-2xl border-2 border-dashed border-amber-300 bg-amber-50 p-8 text-amber-950"><strong>${title}</strong><small class="mt-2 block opacity-70">${escapeHtml(status)} · ${usageCount} Einbindungen</small></div>`;

            return [{
                id: `lmz-v2-shared-${id}`,
                definition: {
                    label: title,
                    category: 'Globale Elemente · Gespeichert',
                    lmzCatalogVersion: LMZ_BLOCK_CATALOG_VERSION,
                    attributes: { title: `${status} · ${usageCount} Einbindungen · ${key}` },
                    content: `<div data-lmz-shared-element="${escapeHtml(key)}" data-lmz-shared-language="current" data-gjs-name="Globales Element: ${title}">${preview}</div>`,
                },
            }];
        });
    }

    function lmzBlockCatalog(rootUrl, embedCatalog, sharedElements, currentElementId, currentLanguage) {
        return [
            ...lmzStandardBlocks(rootUrl),
            ...lmzEmbedCatalogBlocks(embedCatalog),
            ...lmzSharedElementBlocks(sharedElements, currentElementId, currentLanguage),
            ...railTimeBlocks(rootUrl),
        ];
    }

    window.LMZPageBuilderBlockCatalog = Object.freeze({
        version: LMZ_BLOCK_CATALOG_VERSION,
        create: lmzBlockCatalog,
    });

    function boot() {
        const root = document.querySelector('[data-lmzpb-editor]');
        const config = getJoomlaOptions('com_lmzpagebuilder.editor');
        if (!root || !config.documentId || !config.csrfToken || !config.leaseToken || !window.LMZBuilder) return;

        const stateNode = root.querySelector('[data-lmzpb-state]');
        const versionNode = root.querySelector('[data-lmzpb-version]');
        const versionStatusNode = root.querySelector('[data-lmzpb-version-status]');
        const onlineVersionNode = root.querySelector('[data-lmzpb-online-version]');
        const draftVersionNode = root.querySelector('[data-lmzpb-draft-version]');
        const loadingNode = root.querySelector('[data-lmzpb-loading]');
        const publishButton = root.querySelector('[data-lmzpb-publish]');
        const toastNode = root.querySelector('[data-lmzpb-toast]');
        const revisionPanel = root.querySelector('[data-lmzpb-revision-panel]');
        const revisionList = root.querySelector('[data-lmzpb-revision-list]');
        const usagePanel = root.querySelector('[data-lmzpb-usage-panel]');
        const usageList = root.querySelector('[data-lmzpb-usage-list]');
        const publishDialog = root.querySelector('[data-lmzpb-publish-dialog]');
        const publishNote = root.querySelector('[data-lmzpb-publish-note]');
        const createRevision = root.querySelector('[data-lmzpb-create-revision]');
        const revisionNote = root.querySelector('[data-lmzpb-revision-note]');
        const rollbackDialog = root.querySelector('[data-lmzpb-rollback-dialog]');
        const rollbackTarget = root.querySelector('[data-lmzpb-rollback-target]');
        const editorStage = root.querySelector('.lmzpb-editor-stage');
        const revisionsButton = root.querySelector('[data-lmzpb-revisions]');
        const discardDraftButton = root.querySelector('[data-lmzpb-discard-draft]');
        const usagesButton = root.querySelector('[data-lmzpb-usages]');
        const backButton = root.querySelector('[data-lmzpb-back]');
        let builder = null;
        let activeSavePromise = Promise.resolve();
        let saveInFlight = 0;
        let toastTimer = null;
        let heartbeatTimer = null;
        let heartbeatRetryTimer = null;
        let heartbeatPromise = null;
        let heartbeatFailures = 0;
        let heartbeatWarning = false;
        let released = false;
        let leaving = false;
        let actionLocked = false;
        let leaseLost = false;
        root.dataset.translationOnly = config.translationOnly ? 'true' : 'false';

        const setState = (text, state) => {
            stateNode.textContent = text;
            stateNode.dataset.state = state || 'ready';
        };

        const formatVersionFingerprint = (fingerprint) => {
            const value = String(fingerprint || '').trim().toLowerCase();
            if (!/^[a-f0-9]{64}$/.test(value)) return config.labels?.versionNone || '—';
            return String(config.labels?.versionLabel || 'Version %s').replace('%s', value.slice(0, 12));
        };

        const applyVersionMeta = (meta) => {
            if (!versionNode || !meta || typeof meta !== 'object') return;
            const status = ['identical', 'newer', 'unpublished'].includes(meta.status)
                ? meta.status
                : 'unpublished';
            const statusLabels = {
                identical: config.labels?.versionStatusIdentical || 'Identical',
                newer: config.labels?.versionStatusNewer || 'Newer draft',
                unpublished: config.labels?.versionStatusUnpublished || 'Unpublished',
            };
            const onlineFingerprint = String(meta.online_fingerprint || '').trim().toLowerCase();
            const draftFingerprint = String(meta.draft_fingerprint || '').trim().toLowerCase();
            versionNode.dataset.versionStatus = status;
            if (versionStatusNode) versionStatusNode.textContent = statusLabels[status];
            if (onlineVersionNode) {
                onlineVersionNode.textContent = formatVersionFingerprint(onlineFingerprint);
                onlineVersionNode.title = onlineFingerprint;
            }
            if (draftVersionNode) {
                draftVersionNode.textContent = formatVersionFingerprint(draftFingerprint);
                draftVersionNode.title = draftFingerprint;
            }
            config.version = meta;
        };

        applyVersionMeta(config.version);

        const toast = (message, state) => {
            window.clearTimeout(toastTimer);
            toastNode.hidden = false;
            toastNode.textContent = message;
            toastNode.dataset.state = state || 'success';
            toastTimer = window.setTimeout(() => { toastNode.hidden = true; }, 5200);
        };

        const setEditorLocked = (locked) => {
            if (!locked && leaseLost) return;
            actionLocked = Boolean(locked);
            root.dataset.actionLocked = actionLocked ? 'true' : 'false';
            editorStage.inert = actionLocked;
            editorStage.toggleAttribute('aria-busy', actionLocked);
            if (revisionPanel) revisionPanel.inert = actionLocked;
            if (usagePanel) usagePanel.inert = actionLocked;
            if (revisionsButton) revisionsButton.disabled = actionLocked;
            if (usagesButton) usagesButton.disabled = actionLocked;
            builder?.setActionLocked?.(actionLocked);

            if (actionLocked && !leaseLost) {
                backButton.setAttribute('aria-disabled', 'true');
            } else if (!leaving || leaseLost) {
                backButton.removeAttribute('aria-disabled');
            }
        };

        const awaitDialog = (dialog, acceptedValue, focusNode) => new Promise((resolve) => {
            if (!dialog || typeof dialog.showModal !== 'function') {
                resolve(false);
                return;
            }

            dialog.returnValue = '';
            dialog.addEventListener('close', () => resolve(dialog.returnValue === acceptedValue), { once: true });
            dialog.showModal();
            window.requestAnimationFrame(() => focusNode?.focus());
        });

        const setRevisionOptIn = (active) => {
            const enabled = active === true;
            if (createRevision) createRevision.checked = enabled;
            if (revisionNote) revisionNote.hidden = !enabled;
            if (publishNote) {
                publishNote.disabled = !enabled;
                if (!enabled) publishNote.value = '';
            }
        };

        const requestPublishOptions = async () => {
            setRevisionOptIn(false);
            const accepted = await awaitDialog(publishDialog, 'publish', createRevision);
            const options = accepted
                ? {
                    note: createRevision?.checked === true ? String(publishNote?.value || '').trim() : '',
                    createRevision: createRevision?.checked === true,
                }
                : null;
            setRevisionOptIn(false);

            return options;
        };

        const confirmRollback = async (revisionId) => {
            if (!rollbackDialog || !rollbackTarget) return false;
            rollbackTarget.textContent = `Version #${revisionId}`;

            return awaitDialog(rollbackDialog, 'rollback', rollbackDialog.querySelector('[value="rollback"]'));
        };

        const request = async (url, options = {}) => {
            const timeoutMs = Math.max(0, Number(options.timeoutMs) || 0);
            const controller = timeoutMs > 0 ? new AbortController() : null;
            const timeoutId = controller
                ? window.setTimeout(() => controller.abort(), timeoutMs)
                : null;
            try {
                const response = await fetch(url, {
                    method: options.method || 'GET',
                    body: options.body || undefined,
                    credentials: 'same-origin',
                    headers: {
                        'X-CSRF-Token': config.csrfToken,
                        'X-LMZ-Editor-Lease': config.leaseToken,
                        Accept: 'application/json',
                        ...(options.headers || {}),
                    },
                    keepalive: options.keepalive === true,
                    signal: controller?.signal,
                });
                let payload = null;

                try {
                    payload = await response.json();
                } catch (error) {
                    if (controller?.signal.aborted) throw error;
                }

                if (!response.ok || !payload?.success) {
                    const error = new Error(payload?.message || `${config.labels?.failed || 'Request failed.'} (${response.status})`);
                    error.status = response.status;
                    error.invalidResponse = payload === null;
                    throw error;
                }

                return payload.data;
            } finally {
                if (timeoutId !== null) window.clearTimeout(timeoutId);
            }
        };

        const stopHeartbeat = () => {
            if (heartbeatTimer) {
                window.clearInterval(heartbeatTimer);
                heartbeatTimer = null;
            }
            if (heartbeatRetryTimer) {
                window.clearTimeout(heartbeatRetryTimer);
                heartbeatRetryTimer = null;
            }
        };

        const touchLease = () => {
            if (released || leaving || actionLocked || heartbeatPromise || !config.endpoints.touch) {
                return heartbeatPromise || Promise.resolve();
            }

            const form = new FormData();
            form.append('id', String(config.documentId));
            heartbeatPromise = request(config.endpoints.touch, { method: 'POST', body: form, timeoutMs: 12000 })
                .then(() => {
                    heartbeatFailures = 0;
                    if (heartbeatRetryTimer) {
                        window.clearTimeout(heartbeatRetryTimer);
                        heartbeatRetryTimer = null;
                    }
                    if (heartbeatWarning && !actionLocked && !leaseLost) {
                        heartbeatWarning = false;
                        setState(config.labels?.ready || 'Ready', 'ready');
                    }
                })
                .catch((error) => {
                    heartbeatFailures += 1;
                    const sessionResponse = error.invalidResponse === true
                        && error.status >= 200
                        && error.status < 400;
                    const permanentFailure = [401, 403, 404, 405, 409, 410, 422, 423].includes(error.status)
                        || sessionResponse;

                    if (permanentFailure || heartbeatFailures >= 3) {
                        leaseLost = true;
                        stopHeartbeat();
                        setEditorLocked(true);
                        const message = sessionResponse
                            ? 'Die Administratorsitzung ist abgelaufen. Öffnen Sie den Editor erneut.'
                            : (permanentFailure && error.message
                                ? error.message
                                : 'Die Editor-Verbindung konnte nicht erneuert werden. Öffnen Sie die Seite erneut.');
                        setState(message, 'error');
                        toast(message, 'error');
                        return;
                    }

                    heartbeatWarning = true;
                    setState('Editor-Verbindung unterbrochen – neuer Versuch…', 'working');
                    if (heartbeatFailures === 1) {
                        toast('Die Editor-Verbindung wird automatisch erneut geprüft.', 'error');
                    }
                    heartbeatRetryTimer = window.setTimeout(() => {
                        heartbeatRetryTimer = null;
                        touchLease();
                    }, 15000);
                })
                .finally(() => {
                    heartbeatPromise = null;
                });

            return heartbeatPromise;
        };

        const startHeartbeat = () => {
            stopHeartbeat();
            if (released || leaving || !config.endpoints.touch) return;
            heartbeatTimer = window.setInterval(touchLease, 240000);
            touchLease();
        };

        const loadProject = async () => {
            const result = await request(config.endpoints.load);
            config.sourceHash = result.document.source_hash;
            config.draftHash = result.document.draft_hash;
            config.publishedTextHash = result.document.published_text_hash || config.publishedTextHash;
            config.layoutDraftHash = result.document.layout_draft_hash || result.document.layoutDraftHash;
            config.layoutPublishedHash = result.document.layout_published_hash || config.layoutPublishedHash;
            config.sourceLanguage = result.document.source_language || config.sourceLanguage;
            config.translationOnly = Boolean(result.document.translation_only);
            root.dataset.translationOnly = config.translationOnly ? 'true' : 'false';
            applyVersionMeta(result.document.version || config.version);
            return result.project;
        };

        const saveProject = ({ project, html, css }) => {
            activeSavePromise = (async () => {
                saveInFlight += 1;
                setState(config.labels?.saving || 'Saving…', 'working');
                try {
                    const form = new FormData();
                    form.append('id', String(config.documentId));
                    form.append('expected_draft_hash', config.draftHash);
                    form.append('expected_layout_hash', config.layoutDraftHash);
                    form.append('data', JSON.stringify(project));
                    form.append('html', html);
                    form.append('css', css);
                    const result = await request(config.endpoints.save, { method: 'POST', body: form });
                    config.draftHash = result.draft_hash;
                    config.publishedTextHash = result.published_text_hash || config.publishedTextHash;
                    config.layoutDraftHash = result.layout_draft_hash || result.layoutDraftHash;
                    config.layoutPublishedHash = result.layout_published_hash || config.layoutPublishedHash;
                    applyVersionMeta(result.version || config.version);
                    setState(config.labels?.saved || 'Saved', 'saved');
                    if (result.html_sanitized) {
                        toast('Der HTML-Inhalt wurde beim Speichern sicher normalisiert.');
                    }
                } catch (error) {
                    setState(error.message, 'error');
                    toast(error.message, 'error');
                    throw error;
                } finally {
                    saveInFlight = Math.max(0, saveInFlight - 1);
                }
            })();

            return activeSavePromise;
        };

        const loadAssets = async () => {
            const result = await request(config.endpoints.assets);
            return result.items || [];
        };

        const loadEmbedCatalog = async () => {
            if (!config.endpoints?.embeds) return {};

            try {
                const url = new URL(config.endpoints.embeds, window.location.href);
                const language = String(config.language || config.canvasLanguage || '').trim();
                if (language && !url.searchParams.has('language')) url.searchParams.set('language', language);
                const result = await request(url.href, { timeoutMs: 12000 });
                if (!result || typeof result !== 'object' || Array.isArray(result)) {
                    throw new Error('Ungültige Antwort des Embed-Katalogs.');
                }

                return ['articles', 'modules', 'smartsliders'].reduce((catalog, key) => {
                    catalog[key] = Array.isArray(result[key])
                        ? result[key].filter((item) => item && typeof item === 'object').slice(0, 100)
                        : [];
                    return catalog;
                }, {});
            } catch (error) {
                console.error(error);
                toast('Joomla-Einbettungen konnten nicht geladen werden: ' + (error?.message || 'Zugriff verweigert'), 'error');
                return {};
            }
        };

        const loadSharedElements = async () => {
            if (!config.endpoints?.elements) return [];

            try {
                const result = await request(config.endpoints.elements, { timeoutMs: 12000 });
                return Array.isArray(result?.items)
                    ? result.items.filter((item) => item && typeof item === 'object').slice(0, 200)
                    : [];
            } catch (error) {
                console.error(error);
                toast('Gespeicherte Elemente konnten nicht geladen werden: ' + (error?.message || 'Zugriff verweigert'), 'error');
                return [];
            }
        };

        const uploadAssets = async ({ files }) => {
            const assets = [];
            for (const file of files) {
                const form = new FormData();
                form.append('file', file);
                assets.push(await request(config.endpoints.upload, { method: 'POST', body: form }));
            }
            return assets;
        };

        const renderRevisions = (items) => {
            revisionList.replaceChildren();
            if (!items.length) {
                const empty = document.createElement('p');
                empty.className = 'text-muted p-3';
                empty.textContent = 'Noch keine Veröffentlichung vorhanden.';
                revisionList.append(empty);
                return;
            }

            items.forEach((item) => {
                const card = document.createElement('article');
                card.className = 'lmzpb-revision';
                const title = document.createElement('strong');
                title.textContent = `${item.operation === 'rollback' ? 'Sicherung vor Rücksetzung' : 'Veröffentlichung'} · #${item.id}`;
                const meta = document.createElement('p');
                const date = new Date(String(item.created).replace(' ', 'T'));
                meta.textContent = `${Number.isNaN(date.getTime()) ? item.created : date.toLocaleString('de-DE')} · ${item.created_by_name || `Benutzer ${item.created_by}`}${item.note ? ` · ${item.note}` : ''}`;
                const button = document.createElement('button');
                button.type = 'button';
                button.className = 'btn btn-sm btn-outline-danger';
                button.textContent = 'Diesen Stand wiederherstellen';
                button.addEventListener('click', () => rollback(item.id, button));
                card.append(title, meta, button);
                revisionList.append(card);
            });
        };

        const openRevisions = async () => {
            if (actionLocked) return;
            if (!revisionPanel || !revisionList || !config.endpoints?.revisions) return;
            if (usagePanel) usagePanel.hidden = true;
            revisionPanel.hidden = false;
            revisionList.textContent = 'Versionen werden geladen…';
            try {
                const result = await request(config.endpoints.revisions);
                renderRevisions(result.items || []);
            } catch (error) {
                revisionList.textContent = error.message;
            }
        };

        const renderUsages = (items) => {
            if (!usageList) return;
            usageList.replaceChildren();
            if (!items.length) {
                const empty = document.createElement('div');
                empty.className = 'lmzpb-empty-state is-compact';
                const title = document.createElement('strong');
                title.textContent = 'Noch nicht eingebunden';
                const copy = document.createElement('p');
                copy.textContent = 'Dieses Element wird aktuell auf keiner Seite und in keinem anderen gespeicherten Element verwendet.';
                empty.append(title, copy);
                usageList.append(empty);
                return;
            }

            items.forEach((item) => {
                const isPage = item.owner_type === 'page_translation';
                const card = document.createElement('article');
                card.className = 'lmzpb-revision lmzpb-usage';
                const type = document.createElement('span');
                type.className = 'lmzpb-element-kind';
                type.textContent = isPage ? 'Seite' : 'Gespeichertes Element';
                const title = document.createElement('strong');
                title.textContent = String(isPage ? item.page_title : item.element_title || `Einbindung #${item.owner_id}`);
                const meta = document.createElement('p');
                const details = [String(item.language || '').toUpperCase(), String(item.context || '')].filter(Boolean);
                meta.textContent = details.join(' · ');
                card.append(type, title, meta);

                const ownerId = Number(isPage ? item.page_id : item.owner_element_id);
                if (Number.isInteger(ownerId) && ownerId > 0) {
                    const link = document.createElement('a');
                    const target = new URL('index.php', window.location.href);
                    target.searchParams.set('option', 'com_lmzpagebuilder');
                    target.searchParams.set('view', isPage ? 'project' : 'element');
                    target.searchParams.set(isPage ? 'page_id' : 'element_id', String(ownerId));
                    target.searchParams.set('language', String(item.language || config.language || ''));
                    target.searchParams.set('tmpl', 'component');
                    link.href = target.href;
                    link.className = 'btn btn-sm btn-outline-primary';
                    link.textContent = 'Einbindung öffnen';
                    link.addEventListener('click', async (event) => {
                        event.preventDefault();
                        await leaveEditor(link.href, link);
                    });
                    card.append(link);
                }
                usageList.append(card);
            });
        };

        const openUsages = async () => {
            if (actionLocked || !usagePanel || !usageList || !config.endpoints?.usages) return;
            if (revisionPanel) revisionPanel.hidden = true;
            usagePanel.hidden = false;
            usageList.textContent = 'Einbindungen werden geladen…';
            try {
                const result = await request(config.endpoints.usages, { timeoutMs: 12000 });
                renderUsages(result.items || []);
            } catch (error) {
                usageList.textContent = error.message;
            }
        };

        const rollback = async (revisionId, button) => {
            if (actionLocked) return;
            if (!await confirmRollback(revisionId)) return;
            button.disabled = true;
            setEditorLocked(true);
            setState('Version wird wiederhergestellt…', 'working');
            try {
                const saved = await builder.save('manual');
                if (saved === false) throw new Error('Der Entwurf konnte vor der Wiederherstellung nicht gespeichert werden.');
                const form = new FormData();
                form.append('revision_id', String(revisionId));
                form.append('expected_source_hash', config.sourceHash);
                form.append('expected_draft_hash', config.draftHash);
                form.append('expected_layout_hash', config.layoutDraftHash);
                const result = await request(config.endpoints.rollback, { method: 'POST', body: form });
                config.sourceHash = result.source_hash;
                config.draftHash = result.draft_hash;
                config.layoutDraftHash = result.layout_draft_hash || result.layoutDraftHash;
                toast('Version wiederhergestellt. Der Editor wird neu geladen.');
                stopHeartbeat();
                window.setTimeout(() => window.location.reload(), 650);
            } catch (error) {
                setEditorLocked(false);
                setState(error.message, 'error');
                toast(error.message, 'error');
                button.disabled = false;
            }
        };

        const publish = async () => {
            if (actionLocked) return;
            publishButton.disabled = true;
            let lockedForPublish = false;
            try {
                const publishOptions = await requestPublishOptions();
                if (publishOptions === null) return;
                setEditorLocked(true);
                lockedForPublish = true;
                const saved = await builder.save('manual');
                if (saved === false) throw new Error('Der Entwurf konnte nicht gespeichert werden.');
                setState(config.labels?.publishing || 'Publishing…', 'working');
                const form = new FormData();
                form.append('id', String(config.documentId));
                form.append('expected_source_hash', config.sourceHash);
                form.append('expected_draft_hash', config.draftHash);
                form.append('expected_layout_hash', config.layoutDraftHash);
                if (publishOptions.createRevision) {
                    form.append('create_revision', '1');
                    form.append('note', publishOptions.note);
                }
                const result = await request(config.endpoints.publish, { method: 'POST', body: form });
                config.sourceHash = result.source_hash;
                config.draftHash = result.draft_hash;
                config.publishedTextHash = result.published_text_hash || config.publishedTextHash;
                config.layoutDraftHash = result.layout_draft_hash || result.layoutDraftHash;
                config.layoutPublishedHash = result.layout_published_hash || config.layoutPublishedHash;
                applyVersionMeta(result.version || config.version);
                setState(config.labels?.published || 'Published', 'saved');
                toast(config.labels?.published || 'Published');
            } catch (error) {
                setState(error.message, 'error');
                toast(error.message, 'error');
            } finally {
                if (lockedForPublish) setEditorLocked(false);
                publishButton.disabled = false;
            }
        };

        const discardDraft = async () => {
            if (!discardDraftButton || actionLocked || !config.endpoints?.discardDraft) return;
            if (!window.confirm('Den Entwurf verwerfen und den zuletzt veröffentlichten Stand wiederherstellen?')) return;
            discardDraftButton.disabled = true;
            setEditorLocked(true);
            try {
                const form = new FormData();
                form.append('id', String(config.documentId));
                const result = await request(config.endpoints.discardDraft, { method: 'POST', body: form });
                config.sourceHash = result.published_hash || config.sourceHash;
                config.draftHash = result.draft_hash || config.draftHash;
                config.layoutDraftHash = result.layout_draft_hash || config.layoutDraftHash;
                config.layoutPublishedHash = result.layout_published_hash || config.layoutPublishedHash;
                applyVersionMeta(result.version || config.version);
                toast(config.labels?.discarded || 'Entwurf verworfen');
                window.setTimeout(() => window.location.reload(), 350);
            } catch (error) {
                setEditorLocked(false);
                discardDraftButton.disabled = false;
                toast(error.message, 'error');
            }
        };

        const releaseBeacon = () => {
            if (released || saveInFlight > 0 || builder?.hasUnsavedChanges?.()) return;
            stopHeartbeat();
            released = true;
            const form = new FormData();
            form.append('id', String(config.documentId));
            form.append('lease_token', config.leaseToken);
            form.append(config.csrfToken, '1');
            navigator.sendBeacon?.(config.endpoints.release, form);
        };

        const leaveEditor = async (href, control) => {
            if (leaving || (actionLocked && !leaseLost)) return;
            leaving = true;

            if (leaseLost) {
                stopHeartbeat();
                released = true;
                window.location.href = href;
                return;
            }

            setEditorLocked(true);
            stopHeartbeat();

            try {
                if (builder) {
                    const saved = await builder.save('manual');
                    if (saved === false) {
                        throw new Error('Der Entwurf konnte vor dem Wechsel nicht gespeichert werden.');
                    }
                }

                const form = new FormData();
                form.append('id', String(config.documentId));
                await request(config.endpoints.release, { method: 'POST', body: form, keepalive: true });
                released = true;
                window.location.href = href;
            } catch (error) {
                leaving = false;
                setEditorLocked(false);
                startHeartbeat();
                setState(error.message, 'error');
                toast(error.message, 'error');
                control?.removeAttribute('aria-disabled');
            }
        };

        const createTranslation = async (button) => {
            const language = String(button.dataset.lmzpbCreateLanguage || '').trim();
            if (!language || !config.endpoints?.createTranslation || actionLocked || leaving) return;

            button.disabled = true;
            setEditorLocked(true);
            setState(`Übersetzung ${language} wird angelegt …`, 'working');

            try {
                if (builder) {
                    const saved = await builder.save('manual');
                    if (saved === false) throw new Error('Der aktuelle Entwurf konnte nicht gespeichert werden.');
                }

                const createForm = new FormData();
                if (config.entityType === 'element') {
                    createForm.append('element_id', String(config.elementId));
                } else {
                    createForm.append('page_id', String(config.pageId));
                }
                createForm.append('language', language);
                await request(config.endpoints.createTranslation, { method: 'POST', body: createForm });

                const releaseForm = new FormData();
                releaseForm.append('id', String(config.documentId));
                await request(config.endpoints.release, { method: 'POST', body: releaseForm, keepalive: true });
                released = true;
                leaving = true;

                const target = new URL(window.location.href);
                target.searchParams.set('language', language);
                window.location.href = target.href;
            } catch (error) {
                setEditorLocked(false);
                button.disabled = false;
                setState(error.message, 'error');
                toast(error.message, 'error');
            }
        };

        const enableTranslationMode = (instance) => {
            if (!config.translationOnly || !instance?.editor) return;
            const editor = instance.editor;
            const allowedAttributes = ['alt', 'title', 'aria-label', 'aria-description', 'placeholder'];
            let initialized = false;

            const lockComponent = (component) => {
                if (!component?.set) return;
                const tag = String(component.get?.('tagName') || component.get?.('type') || '').toLowerCase();
                const attributes = [...allowedAttributes];
                const inputType = String(component.getAttributes?.().type || '').toLowerCase();
                if (tag === 'input' && ['submit', 'button', 'reset'].includes(inputType)) attributes.push('value');
                component.set({
                    draggable: false,
                    droppable: false,
                    removable: false,
                    copyable: false,
                    stylable: false,
                    toolbar: [],
                    traits: attributes.map((name) => ({ type: 'text', name, label: name })),
                }, { silent: true });
                component.components?.().each?.(lockComponent);
            };

            lockComponent(editor.getWrapper?.());
            initialized = true;

            editor.on?.('component:add', (component) => {
                if (!initialized) return;
                component.remove?.({ temporary: true });
                toast(config.labels?.translationStructureBlocked || 'Structure is edited in the source language.', 'error');
            });
            editor.on?.('component:selected', lockComponent);

            const blockDestructiveKeys = (event) => {
                if (event.key !== 'Delete' && event.key !== 'Backspace') return;
                const target = event.target;
                if (target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement || target?.isContentEditable) return;
                event.preventDefault();
                event.stopImmediatePropagation();
                toast(config.labels?.translationStructureBlocked || 'Structure is edited in the source language.', 'error');
            };
            document.addEventListener('keydown', blockDestructiveKeys, true);
            const canvasDocument = editor.Canvas?.getDocument?.();
            canvasDocument?.addEventListener?.('keydown', blockDestructiveKeys, true);
            root.dataset.translationOnly = 'true';
            root.setAttribute('aria-description', config.labels?.translationMode || 'Translation only');
        };

        revisionsButton?.addEventListener('click', openRevisions);
        createRevision?.addEventListener('change', () => setRevisionOptIn(createRevision.checked));
        root.querySelector('[data-lmzpb-revisions-close]')?.addEventListener('click', () => { revisionPanel.hidden = true; });
        usagesButton?.addEventListener('click', openUsages);
        root.querySelector('[data-lmzpb-usages-close]')?.addEventListener('click', () => { usagePanel.hidden = true; });
        publishButton.addEventListener('click', publish);
        discardDraftButton?.addEventListener('click', discardDraft);
        backButton?.addEventListener('click', async (event) => {
            event.preventDefault();
            await leaveEditor(event.currentTarget.href, event.currentTarget);
        });
        root.querySelectorAll('[data-lmzpb-language-link]').forEach((link) => {
            link.addEventListener('click', async (event) => {
                event.preventDefault();
                if (link.matches('[aria-current="page"]')) return;
                await leaveEditor(link.href, link);
            });
        });
        root.querySelector('[data-lmzpb-language-select]')?.addEventListener('change', async (event) => {
            const option = event.target.selectedOptions?.[0];
            if (!option) return;
            if (option.dataset.languageExists !== '1') {
                await createTranslation({ dataset: { lmzpbCreateLanguage: option.dataset.languageCode } });
                return;
            }
            await leaveEditor(option.value, event.target);
        });
        root.querySelectorAll('[data-lmzpb-create-language]').forEach((button) => {
            button.addEventListener('click', () => createTranslation(button));
        });
        document.addEventListener('keydown', (event) => {
            if (event.key === 'Escape' && revisionPanel && !revisionPanel.hidden) revisionPanel.hidden = true;
            if (event.key === 'Escape' && usagePanel && !usagePanel.hidden) usagePanel.hidden = true;
        });
        document.addEventListener('visibilitychange', () => {
            if (document.visibilityState === 'visible') touchLease();
        });
        window.addEventListener('beforeunload', (event) => {
            if (saveInFlight > 0 || builder?.hasUnsavedChanges?.()) {
                event.preventDefault();
                event.returnValue = '';
                return;
            }

            releaseBeacon();
        });

        setState(config.labels?.loading || 'Loading…', 'loading');
        Promise.all([loadEmbedCatalog(), loadSharedElements()]).then(([embedCatalog, sharedElements]) => window.LMZBuilder.create({
            root: '#studio-editor',
            projectId: config.documentId,
            gjsScript: config.assets.grapesJs,
            gjsStyle: config.assets.grapesCss,
            canvasStyles: config.canvasStyles || [],
            canvasScripts: config.canvasScripts || [],
            canvasBaseUrl: config.canvasBaseUrl || config.rootUrl || '/',
            canvasBodyClasses: config.canvasBodyClasses || [],
            canvasLanguage: config.canvasLanguage || '',
            motion: config.motion === undefined ? { enabled: true, preview: true } : config.motion,
            integrations: {
                embedCatalog,
                sharedElements,
                sharedLanguage: config.language || config.canvasLanguage || '',
                currentElementId: config.entityType === 'element' ? Number(config.elementId) || 0 : 0,
            },
            useStudioWebDefaults: false,
            allowFallbackProject: false,
            endpoints: { load: null, save: null, assets: null, upload: null },
            storage: { onLoad: loadProject, onSave: saveProject },
            assets: { onLoad: loadAssets, onUpload: uploadAssets },
            blocks: {
                addDefault: false,
                custom: lmzBlockCatalog(
                    config.rootUrl,
                    embedCatalog,
                    sharedElements,
                    config.entityType === 'element' ? config.elementId : 0,
                    config.language || config.canvasLanguage || ''
                ),
            },
            autosave: { enabled: true, intervalMs: 10000, changesBeforeSave: 20 },
            gjsOptions: {
                deviceManager: {
                    devices: [
                        { id: 'desktop', name: 'Desktop', width: '' },
                        { id: 'tablet', name: 'Tablet', width: '834px', widthMedia: '992px' },
                        { id: 'mobile', name: 'Mobil', width: '393px', widthMedia: '600px' },
                    ],
                },
                parser: { optionsHtml: { allowScripts: false } },
            },
        })).then((instance) => {
            builder = instance;
            enableTranslationMode(instance);
            builder.setActionLocked?.(actionLocked);
            loadingNode.hidden = true;
            publishButton.disabled = false;
            setState(config.labels?.ready || 'Ready', 'ready');
            startHeartbeat();
        }).catch((error) => {
            loadingNode.innerHTML = '';
            const strong = document.createElement('strong');
            strong.textContent = 'Editor konnte nicht geladen werden';
            const detail = document.createElement('small');
            detail.textContent = escapeText(error?.message || config.labels?.failed || 'Unknown error');
            loadingNode.append(strong, detail);
            setState(detail.textContent, 'error');
        });
    }

    document.readyState === 'loading' ? document.addEventListener('DOMContentLoaded', boot) : boot();
})();
