(function (global) {
    'use strict';

    const VERSION = '2.4.5';
    const MOTION_SELECTOR = [
        '[data-lmz-motion]',
        '.sa-motion-up',
        '.sa-motion-left',
        '.sa-motion-right',
        '[data-x-reveal]',
        '[data-x-stagger]',
        '[data-x-scale]',
        '[data-x-parallax]',
        '[data-x-split]',
        '[data-careers-reveal]',
    ].join(',');
    const SAFE_EASES = new Set([
        'none',
        'linear',
        'power1.out',
        'power2.out',
        'power3.out',
        'power4.out',
        'power1.inOut',
        'power2.inOut',
        'power3.inOut',
        'sine.inOut',
        'back.out(1.4)',
    ]);
    const SAFE_STARTS = new Set([
        'top bottom',
        'top 92%',
        'top 90%',
        'top 88%',
        'top 86%',
        'top 80%',
        'top 70%',
        'center bottom',
        'center center',
    ]);
    const SAFE_ENDS = new Set([
        'bottom top',
        'bottom 20%',
        'center top',
        '+=240',
        '+=400',
        '+=620',
        '+=800',
    ]);
    let activeController = null;

    function clamp(value, min, max, fallback) {
        const parsed = Number.parseFloat(value);
        return Number.isFinite(parsed) ? Math.min(max, Math.max(min, parsed)) : fallback;
    }

    function readBoolean(element, name, fallback) {
        if (!element.hasAttribute(name)) return fallback;
        const value = String(element.getAttribute(name) || '').trim().toLowerCase();
        return !['0', 'false', 'off', 'no'].includes(value);
    }

    function readChoice(element, name, allowed, fallback) {
        const value = String(element.getAttribute(name) || '').trim();
        return allowed.has(value) ? value : fallback;
    }

    function readScrub(element, fallback) {
        const value = String(element.getAttribute('data-lmz-scrub') || '').trim().toLowerCase();
        if (!value) return fallback;
        if (['false', 'off', 'no', '0'].includes(value)) return false;
        if (['true', 'on', 'yes'].includes(value)) return 0.6;
        return clamp(value, 0.05, 4, fallback);
    }

    function hasExplicitMotion(element) {
        return String(element.getAttribute('data-lmz-motion') || '').trim() !== '';
    }

    function applyDefinitionOverrides(element, definition) {
        const output = { delay: 0, scale: 0.92, stagger: 0, ...definition };
        if (element.hasAttribute('data-lmz-duration')) {
            output.duration = clamp(element.getAttribute('data-lmz-duration'), 0.1, 5, output.duration);
        }
        if (element.hasAttribute('data-lmz-delay')) {
            output.delay = clamp(element.getAttribute('data-lmz-delay'), 0, 5, output.delay);
        }
        if (element.hasAttribute('data-lmz-distance')) {
            output.distance = clamp(element.getAttribute('data-lmz-distance'), 0, 300, output.distance);
        }
        if (element.hasAttribute('data-lmz-scale')) {
            output.scale = clamp(element.getAttribute('data-lmz-scale'), 0.5, 1.5, output.scale);
        }
        if (element.hasAttribute('data-lmz-stagger')) {
            output.stagger = clamp(element.getAttribute('data-lmz-stagger'), 0, 1, output.stagger);
        }
        if (element.hasAttribute('data-lmz-ease')) {
            output.ease = readChoice(element, 'data-lmz-ease', SAFE_EASES, output.ease);
        }
        if (element.hasAttribute('data-lmz-start')) {
            output.start = readChoice(element, 'data-lmz-start', SAFE_STARTS, output.start);
        }
        if (element.hasAttribute('data-lmz-end')) {
            output.end = readChoice(element, 'data-lmz-end', SAFE_ENDS, output.end);
        }
        if (element.hasAttribute('data-lmz-scrub')) output.scrub = readScrub(element, output.scrub);
        if (element.hasAttribute('data-lmz-reverse')) {
            output.reverse = readBoolean(element, 'data-lmz-reverse', output.reverse);
        }
        if (element.hasAttribute('data-lmz-once')) {
            output.once = readBoolean(element, 'data-lmz-once', output.once);
        }
        return output;
    }

    function getExplicitDefinition(element) {
        if (!hasExplicitMotion(element)) return null;
        const type = String(element.getAttribute('data-lmz-motion') || '').trim().toLowerCase();
        if (![
            'fade-up',
            'fade-down',
            'fade-left',
            'fade-right',
            'scale',
            'reveal',
            'parallax',
            'split-lines',
        ].includes(type)) {
            return { type: 'none' };
        }

        return applyDefinitionOverrides(element, {
            type,
            duration: 0.9,
            delay: 0,
            distance: type === 'split-lines' ? 118 : type === 'parallax' ? 8 : 48,
            scale: 0.92,
            stagger: type === 'split-lines' ? 0.09 : 0,
            ease: 'power3.out',
            start: type === 'split-lines' ? 'top 88%' : 'top 86%',
            end: 'bottom 20%',
            scrub: false,
            reverse: true,
            once: false,
        });
    }

    function getLegacyDefinition(element) {
        let definition;
        if (element.matches('[data-x-split]')) {
            definition = {
                type: 'split-lines', duration: 1.05, distance: 118, stagger: 0.09,
                start: 'top 88%', end: 'bottom 20%', ease: 'power4.out',
                scrub: false, reverse: true, once: true,
            };
        } else if (element.matches('[data-x-stagger]')) {
            definition = {
                type: 'fade-up', duration: 0.95, distance: 60, stagger: 0.1,
                start: 'top 86%', end: 'bottom 20%', ease: 'power3.out',
                scrub: false, reverse: true, once: true,
            };
        } else if (element.matches('[data-x-scale]')) {
            definition = {
                type: 'scale', duration: 1, scale: 1.12, stagger: 0,
                start: 'top bottom', end: 'bottom top', ease: 'none',
                scrub: 0.8, reverse: true, once: false,
            };
        } else if (element.matches('[data-x-parallax]')) {
            definition = {
                type: 'parallax', duration: 1, distance: 8, stagger: 0,
                start: 'top bottom', end: 'bottom top', ease: 'none',
                scrub: 0.7, reverse: true, once: false,
            };
        } else if (element.matches('.sa-motion-left')) {
            definition = {
                type: 'fade-left', duration: 0.9, distance: 42, stagger: 0,
                start: 'top 80%', end: '+=240', ease: 'power3.out',
                scrub: 0.45, reverse: true, once: false,
            };
        } else if (element.matches('.sa-motion-right')) {
            definition = {
                type: 'fade-right', duration: 0.9, distance: 42, stagger: 0,
                start: 'top 80%', end: '+=240', ease: 'power3.out',
                scrub: 0.45, reverse: true, once: false,
            };
        } else if (element.matches('[data-careers-reveal]')) {
            definition = {
                type: 'fade-up', duration: 0.62, distance: 26, stagger: 0,
                start: 'top 86%', end: 'bottom 20%', ease: 'power3.out',
                scrub: false, reverse: true, once: true,
            };
        } else {
            definition = {
                type: 'fade-up', duration: 0.95, distance: 48, stagger: 0,
                start: 'top 86%', end: 'bottom 20%', ease: 'power3.out',
                scrub: false, reverse: true,
                once: element.matches('[data-x-reveal]'),
            };
        }

        return applyDefinitionOverrides(element, definition);
    }

    function query(root, selector) {
        try {
            return root?.querySelector?.(selector) || null;
        } catch (error) {
            return null;
        }
    }

    function queryAll(root, selector) {
        try {
            return Array.from(root?.querySelectorAll?.(selector) || []);
        } catch (error) {
            return [];
        }
    }

    function childElements(element) {
        return element ? Array.from(element.children || []) : [];
    }

    function detectProfiles(root, runtimeDocument) {
        const body = runtimeDocument.body;
        const profiles = new Set();
        if (body?.classList.contains('is-home') || query(root, '.sa-services, .sa-team')) profiles.add('home');
        if (body?.classList.contains('is-careers') || query(root, '[data-rt-careers]')) profiles.add('careers');

        if (body?.classList.contains('is-about')) profiles.add('about');
        else if (body?.classList.contains('is-services')) profiles.add('services');
        else if (body?.classList.contains('is-contact')) profiles.add('contact');
        else if (query(root, '.rt-x')) {
            if (query(root, '.rt-x__buehne')) profiles.add('services');
            else if (query(root, '.rt-x__formular')) profiles.add('contact');
            else if (query(root, '.rt-x__stapel, .rt-x__scheiben')) profiles.add('about');
        }

        if (profiles.has('home') || profiles.has('about') || profiles.has('services')) profiles.add('process');
        return profiles;
    }

    function collectProfileParts(root, profiles) {
        const parts = {};
        if (profiles.has('home')) {
            const services = query(root, '.sa-services');
            const servicesHead = query(services, '.sa-section-head');
            const servicesGrid = query(services, '.sa-services__grid');
            const cards = queryAll(servicesGrid, '.sa-service');
            const team = query(root, '.sa-team');
            const teamVisual = query(team, '.sa-team__visual');
            const teamCopy = query(team, '.sa-team__copy');
            parts.home = {
                services,
                servicesHead,
                headerParts: childElements(servicesHead),
                cards,
                cardFigures: cards.map((card) => query(card, 'figure')).filter(Boolean),
                cardCopy: cards.flatMap((card) => [
                    query(card, ':scope > span'),
                    query(card, ':scope > h3'),
                    query(card, ':scope > .rt-action-arrow'),
                ].filter(Boolean)),
                team,
                teamVisual,
                teamFigures: queryAll(teamVisual, 'figure'),
                teamCopy,
                teamParts: childElements(teamCopy),
                teamSeal: query(teamCopy, '.sa-team__seal'),
            };
        }

        const xRoot = query(root, '.rt-x');
        if (profiles.has('about') && xRoot) {
            const hero = query(xRoot, '.rt-x__hero');
            const heroText = query(hero, '.rt-x__hero-text');
            const heroFigure = query(hero, '.rt-x__hero-figur');
            const facts = query(xRoot, '.rt-x__zahlen');
            const detailSplit = query(xRoot, '.rt-x__split');
            const detailSection = detailSplit?.closest?.('.rt-x__section') || null;
            const detailFigure = query(detailSplit, '.rt-x__bild');
            const detailText = query(detailSplit, '.rt-x__fliess');
            const valuesStack = query(xRoot, '.rt-x__stapel');
            const valuesSection = valuesStack?.closest?.('.rt-x__section') || null;
            const valuesHeader = query(valuesSection, ':scope > header');
            parts.about = {
                root: xRoot,
                hero,
                heroText,
                heroParts: childElements(heroText),
                heroFigure,
                heroImage: query(heroFigure, 'img'),
                facts,
                factItems: childElements(facts),
                detailSection,
                detailFigure,
                detailImage: query(detailFigure, 'img'),
                detailText,
                detailParts: childElements(detailText),
                valuesSection,
                valuesHeaderParts: childElements(valuesHeader),
                values: queryAll(valuesStack, '.rt-x__karte'),
                cta: query(xRoot, '.rt-x__cta'),
            };
        }

        if (profiles.has('services') && xRoot) {
            const hero = query(xRoot, '.rt-x__hero');
            const heroText = query(hero, '.rt-x__hero-text');
            const heroFigure = query(hero, '.rt-x__hero-figur');
            const stage = query(xRoot, '.rt-x__buehne');
            const detailSection = stage?.closest?.('.rt-x__section') || null;
            const detailHeader = query(detailSection, ':scope > header');
            const entries = queryAll(stage, '.rt-x__eintrag');
            const figures = queryAll(stage, '.rt-x__vitrine figure');
            parts.services = {
                root: xRoot,
                hero,
                heroText,
                heroParts: childElements(heroText),
                heroFigure,
                heroImage: query(heroFigure, 'img'),
                facts: query(xRoot, '.rt-x__zahlen'),
                detailSection,
                detailHeaderParts: childElements(detailHeader),
                stage,
                entries,
                fields: entries.map((entry) => query(entry, '.rt-x__feld')).filter(Boolean),
                figures,
                figureImages: figures.map((figure) => query(figure, 'img')).filter(Boolean),
                progress: query(stage, '.rt-x__fortschritt-spur i'),
                cta: query(xRoot, '.rt-x__cta'),
            };
        }

        if (profiles.has('contact') && xRoot) {
            const hero = query(xRoot, '.rt-x__hero');
            const heroText = query(hero, '.rt-x__hero-text');
            const heroFigure = query(hero, '.rt-x__hero-figur');
            const requestSplit = query(xRoot, '.rt-x__split--umgekehrt') || query(xRoot, '.rt-x__split');
            const requestSection = requestSplit?.closest?.('.rt-x__section') || null;
            const contactData = query(requestSplit, '.rt-x__fliess');
            const form = query(requestSplit, '.rt-x__formular');
            parts.contact = {
                root: xRoot,
                hero,
                heroText,
                heroParts: childElements(heroText),
                heroFigure,
                heroImage: query(heroFigure, 'img'),
                requestSection,
                contactData,
                contactParts: childElements(contactData),
                formWrapper: form?.parentElement || null,
                form,
                formParts: childElements(form),
                cta: query(xRoot, '.rt-x__cta'),
            };
        }

        if (profiles.has('careers')) {
            const careersRoot = query(root, '[data-rt-careers]') || query(root, '.rt-careers');
            const hero = query(careersRoot, '.rt-careers-hero');
            const heroCopy = query(hero, '.rt-careers-hero__content, .rt-careers-hero__copy');
            const heroMedia = query(hero, '.rt-careers-hero__media, .rt-careers-hero__visual, figure');
            parts.careers = {
                root: careersRoot,
                hero,
                heroParts: childElements(heroCopy),
                heroMedia,
                heroImage: query(heroMedia, 'img'),
                reveals: queryAll(careersRoot, '[data-careers-reveal]').filter((element) => (
                    !hero?.contains(element) && !element.closest?.('.rt-application')
                )),
            };
        }

        if (profiles.has('process')) {
            let section = null;
            let track = null;
            let variant = 'home';
            if (profiles.has('home')) {
                section = query(root, '.sa-process');
                track = query(section, '.sa-process__steps');
            } else if (profiles.has('about')) {
                variant = 'about';
                track = query(root, '.rt-x__scheiben');
                section = track?.closest?.('.rt-x__section') || null;
            } else if (profiles.has('services')) {
                variant = 'services';
                track = query(root, '.rt-x__spur');
                section = track?.closest?.('.rt-x__section') || null;
            }
            parts.process = {
                variant,
                section,
                track,
                header: query(section, ':scope > header'),
                steps: childElements(track).filter((element) => element.matches('article')),
            };
        }

        return parts;
    }

    function collectHandledElements(parts, isExcluded) {
        const handled = new Set();
        const add = (items) => {
            (Array.isArray(items) ? items : [items]).filter(Boolean).forEach((element) => {
                if (isExcluded(element) || hasExplicitMotion(element) || element.matches('[data-x-split]')) return;
                handled.add(element);
            });
        };

        if (parts.home) {
            add(parts.home.headerParts);
            add(parts.home.cards);
            add(parts.home.cardFigures);
            add(parts.home.cardCopy);
            add(parts.home.teamVisual);
            add(parts.home.teamFigures);
            add(parts.home.teamParts);
        }
        if (parts.about) {
            add(parts.about.heroParts);
            add([parts.about.heroFigure, parts.about.heroImage]);
            add(parts.about.factItems);
            add([parts.about.detailFigure, parts.about.detailImage]);
            add(parts.about.detailText);
            add(parts.about.detailParts);
            add(parts.about.valuesHeaderParts);
            add(parts.about.values);
            add(parts.about.cta);
        }
        if (parts.services) {
            add(parts.services.heroParts);
            add([parts.services.heroFigure, parts.services.heroImage]);
            add(childElements(parts.services.facts));
            add(parts.services.detailHeaderParts);
            add(parts.services.entries);
            add(parts.services.figures);
            add(parts.services.figureImages);
            add(parts.services.cta);
        }
        if (parts.contact) {
            add(parts.contact.heroParts);
            add([parts.contact.heroFigure, parts.contact.heroImage]);
            add(parts.contact.contactData);
            add(parts.contact.contactParts);
            add([parts.contact.formWrapper, parts.contact.form, ...parts.contact.formParts]);
            add(parts.contact.cta);
        }
        if (parts.careers) {
            add(parts.careers.heroParts);
            add([parts.careers.heroMedia, parts.careers.heroImage]);
            add(parts.careers.reveals);
        }
        if (parts.process) {
            add(childElements(parts.process.header));
            add(parts.process.steps);
        }
        return handled;
    }

    function collectEntries(root, handled, isExcluded) {
        return queryAll(root, MOTION_SELECTOR).map((element) => {
            if (isExcluded(element)) return null;
            const explicit = getExplicitDefinition(element);
            if (!explicit && handled.has(element)) return null;
            return { element, definition: explicit || getLegacyDefinition(element) };
        }).filter((entry) => entry && entry.definition.type !== 'none');
    }

    function create(options) {
        const settings = options || {};
        const runtimeWindow = settings.window || global;
        const runtimeDocument = settings.document || runtimeWindow.document;
        const root = settings.root?.querySelectorAll ? settings.root : runtimeDocument.body;
        const gsap = runtimeWindow.gsap;
        const ScrollTrigger = runtimeWindow.ScrollTrigger;
        const SplitText = runtimeWindow.SplitText;
        const reducedMotion = settings.respectReducedMotion !== false
            && runtimeWindow.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
        const excluded = (Array.isArray(settings.excludeElements) ? settings.excludeElements : [])
            .filter((element) => element?.nodeType === 1);
        const isExcluded = (element) => excluded.some((candidate) => (
            candidate === element || candidate.contains?.(element) || element.contains?.(candidate)
        ));
        const profiles = settings.editorMode ? detectProfiles(root, runtimeDocument) : new Set();
        const profileParts = collectProfileParts(root, profiles);
        const handled = collectHandledElements(profileParts, isExcluded);
        const entries = root ? collectEntries(root, handled, isExcluded) : [];
        const pendingMedia = root ? queryAll(root, 'img, video').filter((element) => {
            if (element.tagName === 'IMG') return !element.complete;
            return element.readyState < 1;
        }) : [];
        const animations = [];
        const triggers = [];
        const splits = [];
        const snapshots = new Map();
        const classSnapshots = new Map();
        const restartHandlers = [];
        let context = null;
        let paused = false;
        let destroyed = false;
        let refreshFrame = 0;
        let refreshInnerFrame = 0;
        let restartFrame = 0;
        let destroyFinalizer = null;
        const previousDocumentState = runtimeDocument?.documentElement?.dataset.lmzMotionState;

        const setDocumentState = (state) => {
            if (runtimeDocument?.documentElement) runtimeDocument.documentElement.dataset.lmzMotionState = state;
        };
        const restoreDocumentState = () => {
            if (!runtimeDocument?.documentElement) return;
            if (previousDocumentState === undefined) delete runtimeDocument.documentElement.dataset.lmzMotionState;
            else runtimeDocument.documentElement.dataset.lmzMotionState = previousDocumentState;
        };

        if (!root || !gsap || !ScrollTrigger || reducedMotion || settings.enabled === false) {
            setDocumentState(reducedMotion ? 'reduced' : settings.enabled === false ? 'disabled' : 'unavailable');
            return {
                available: Boolean(gsap && ScrollTrigger),
                reducedMotion: Boolean(reducedMotion),
                state: () => reducedMotion ? 'reduced' : 'disabled',
                pause() {},
                resume() {},
                restart() {},
                refresh() {},
                destroy() {
                    if (destroyed) return;
                    destroyed = true;
                    restoreDocumentState();
                },
            };
        }

        gsap.registerPlugin(ScrollTrigger);
        if (SplitText) gsap.registerPlugin(SplitText);
        gsap.config({ nullTargetWarn: false });

        const snapshot = (targets) => {
            const items = Array.isArray(targets) ? targets : [targets];
            items.filter((element) => element?.nodeType === 1).forEach((element) => {
                if (snapshots.has(element)) return;
                snapshots.set(element, element.getAttribute('style'));
            });
        };
        const snapshotClass = (element) => {
            if (element?.nodeType === 1 && !classSnapshots.has(element)) {
                classSnapshots.set(element, element.getAttribute('class'));
            }
        };
        const addTemporaryClass = (element, ...classNames) => {
            if (!element || isExcluded(element)) return;
            snapshotClass(element);
            element.classList.add(...classNames);
        };
        const restoreSnapshots = () => {
            const styleEntries = Array.from(snapshots.entries());
            const restoreStyle = ([element, value]) => {
                if (!element?.isConnected) return;
                if (value === null) element.removeAttribute('style');
                else element.setAttribute('style', value);
            };
            const settleStyle = ([element, value]) => {
                if (!element?.isConnected) return;
                const current = element.getAttribute('style');
                if (value === null && current === '') element.removeAttribute('style');
                else if (value !== null && (current === null || current === '')) element.setAttribute('style', value);
            };
            styleEntries.forEach(restoreStyle);
            classSnapshots.forEach((value, element) => {
                if (!element?.isConnected) return;
                if (value === null) element.removeAttribute('class');
                else element.setAttribute('class', value);
            });
            snapshots.clear();
            classSnapshots.clear();
            return {
                exact: () => styleEntries.forEach(restoreStyle),
                settle: () => styleEntries.forEach(settleStyle),
            };
        };
        const remember = (animation) => {
            if (!animation) return animation;
            animations.push(animation);
            if (animation.scrollTrigger) triggers.push(animation.scrollTrigger);
            return animation;
        };
        const hasExplicitOwner = (element) => {
            const owner = element?.closest?.('[data-lmz-motion]');
            return Boolean(owner && hasExplicitMotion(owner));
        };
        const canProfileAnimate = (element) => Boolean(
            element && !isExcluded(element) && !hasExplicitOwner(element)
        );
        const availableTargets = (targets) => (Array.isArray(targets) ? targets : [targets])
            .filter(canProfileAnimate)
            .filter((element) => !element.matches('[data-x-split]'));
        const makeScrollTrigger = (element, definition, id) => ({
            id,
            trigger: element,
            start: definition.start,
            end: definition.end,
            scrub: definition.scrub,
            once: definition.once && !definition.scrub,
            toggleActions: definition.scrub
                ? undefined
                : definition.once || definition.reverse === false
                    ? 'play none none none'
                    : 'play none none reverse',
            invalidateOnRefresh: true,
        });
        const addEntryAnimation = (element, definition, index) => {
            if (definition.type === 'split-lines' && SplitText) {
                snapshot(element);
                snapshotClass(element);
                try {
                    const split = SplitText.create(element, {
                        type: 'lines',
                        linesClass: 'rt-x__zeile lmz-editor-split-line',
                        aria: 'auto',
                        autoSplit: false,
                    });
                    splits.push(split);
                    element.classList.add('rt-x__split-host');
                    snapshot(split.lines);
                    remember(gsap.fromTo(split.lines, {
                        yPercent: definition.distance,
                        autoAlpha: 0,
                    }, {
                        yPercent: 0,
                        autoAlpha: 1,
                        duration: definition.duration,
                        delay: definition.delay || 0,
                        ease: definition.ease,
                        stagger: definition.stagger || 0.09,
                        force3D: true,
                        scrollTrigger: makeScrollTrigger(element, definition, `lmz-editor-split-${index}`),
                    }));
                    return;
                } catch (error) {
                    // A plain reveal below remains a safe fallback for malformed
                    // editable markup. SplitText instances are always reverted.
                }
            }

            const targets = definition.stagger > 0 && element.children.length
                ? Array.from(element.children)
                : [element];
            snapshot(targets);
            const commonTo = {
                duration: definition.duration,
                delay: definition.delay || 0,
                ease: definition.ease,
                stagger: definition.stagger || 0,
                force3D: true,
                scrollTrigger: makeScrollTrigger(element, definition, `lmz-editor-motion-${index}`),
            };
            if (definition.type === 'parallax') {
                remember(gsap.fromTo(targets, { yPercent: -definition.distance }, {
                    ...commonTo,
                    yPercent: definition.distance,
                }));
                return;
            }

            const from = { autoAlpha: 0 };
            const to = { ...commonTo, autoAlpha: 1 };
            if (definition.type === 'fade-up' || definition.type === 'split-lines') from.y = definition.distance;
            if (definition.type === 'fade-down') from.y = -definition.distance;
            if (definition.type === 'fade-left') from.x = -definition.distance;
            if (definition.type === 'fade-right') from.x = definition.distance;
            if (definition.type === 'scale') {
                from.scale = definition.scale;
                if (element.matches('[data-x-scale]') && !hasExplicitMotion(element)) {
                    delete from.autoAlpha;
                    delete to.autoAlpha;
                }
            }
            if (definition.type === 'reveal') {
                from.clipPath = 'inset(0 100% 0 0)';
                to.clipPath = 'inset(0 0% 0 0)';
            }
            remember(gsap.fromTo(targets, from, to));
        };

        const addHero = (parts, prefix, direction) => {
            if (!parts?.hero) return;
            const heroParts = availableTargets(parts.heroParts);
            const heroFigure = canProfileAnimate(parts.heroFigure) ? parts.heroFigure : null;
            const heroImage = canProfileAnimate(parts.heroImage) ? parts.heroImage : null;
            const targets = [...heroParts, heroFigure, heroImage].filter(Boolean);
            if (!targets.length) return;
            snapshot(targets);
            const timeline = remember(gsap.timeline({ defaults: { overwrite: 'auto' } }));
            if (heroParts.length) {
                timeline.fromTo(heroParts, { autoAlpha: 0, y: 30 }, {
                    autoAlpha: 1,
                    y: 0,
                    duration: 0.76,
                    ease: 'power3.out',
                    stagger: 0.07,
                }, 0);
            }
            if (heroFigure) {
                timeline.fromTo(heroFigure, {
                    autoAlpha: 0,
                    x: direction === 'right' ? 34 : 0,
                    clipPath: direction === 'bottom' ? 'inset(0 0 100% 0)' : 'inset(0 0 0 100%)',
                }, {
                    autoAlpha: 1,
                    x: 0,
                    clipPath: 'inset(0 0 0% 0)',
                    duration: 0.92,
                    ease: 'power3.inOut',
                }, 0.1);
            }
            if (heroImage) {
                timeline.fromTo(heroImage, { scale: 1.06 }, {
                    scale: 1,
                    duration: 1.08,
                    ease: 'power3.out',
                }, 0.16);
            }
            timeline.data = `${prefix}-hero`;
        };

        const addCta = (cta, id) => {
            if (!canProfileAnimate(cta)) return;
            const textParts = availableTargets(childElements(cta.firstElementChild));
            const image = canProfileAnimate(query(cta, 'img')) ? query(cta, 'img') : null;
            snapshot([cta, ...textParts, image].filter(Boolean));
            const timeline = remember(gsap.timeline({
                scrollTrigger: {
                    id,
                    trigger: cta,
                    start: 'top 84%',
                    toggleActions: 'play none none reverse',
                    invalidateOnRefresh: true,
                },
            }));
            timeline.fromTo(cta, { autoAlpha: 0, y: 42 }, {
                autoAlpha: 1,
                y: 0,
                duration: 0.72,
                ease: 'power3.out',
            }, 0);
            if (textParts.length) {
                timeline.fromTo(textParts, { autoAlpha: 0, y: 22 }, {
                    autoAlpha: 1,
                    y: 0,
                    duration: 0.58,
                    ease: 'power3.out',
                    stagger: 0.06,
                }, 0.14);
            }
            if (image) timeline.fromTo(image, { scale: 1.06 }, { scale: 1, duration: 0.95, ease: 'power2.out' }, 0.08);
        };

        const addHomeProfile = (parts) => {
            if (!parts?.services || !parts.team) return;
            const headerParts = availableTargets(parts.headerParts);
            const cards = availableTargets(parts.cards);
            const figures = availableTargets(parts.cardFigures);
            const cardCopy = availableTargets(parts.cardCopy);
            const teamVisual = canProfileAnimate(parts.teamVisual) ? parts.teamVisual : null;
            const teamFigures = availableTargets(parts.teamFigures);
            const teamParts = availableTargets(parts.teamParts.filter((part) => part !== parts.teamSeal));
            const teamSeal = canProfileAnimate(parts.teamSeal) ? parts.teamSeal : null;
            snapshot([...headerParts, ...cards, ...figures, ...cardCopy, teamVisual, ...teamFigures, ...teamParts, teamSeal].filter(Boolean));

            if (headerParts.length || cards.length) {
                const servicesTimeline = remember(gsap.timeline({
                    scrollTrigger: {
                        id: 'lmz-editor-home-services',
                        trigger: parts.services,
                        start: 'top 86%',
                        end: 'bottom 20%',
                        scrub: 0.65,
                        invalidateOnRefresh: true,
                    },
                }));
                if (headerParts.length) servicesTimeline.fromTo(headerParts,
                    { autoAlpha: 0.08, y: 50 },
                    { autoAlpha: 1, y: 0, duration: 0.82, ease: 'power3.out', stagger: 0.1 }, 0.04);
                if (cards.length) servicesTimeline.fromTo(cards, {
                    autoAlpha: 0.06,
                    y: (index) => 70 + (index % 2 ? 24 : 0),
                    rotationY: (index) => index % 2 ? -3 : 3,
                    scale: 0.94,
                }, {
                    autoAlpha: 1,
                    y: 0,
                    rotationY: 0,
                    scale: 1,
                    duration: 1.4,
                    ease: 'power3.out',
                    stagger: 0.18,
                }, 0.3);
                if (figures.length) servicesTimeline.fromTo(figures,
                    { scale: 1.09, yPercent: -3 },
                    { scale: 1, yPercent: 0, duration: 1.45, ease: 'power2.out', stagger: 0.18 }, 0.34);
                if (cardCopy.length) servicesTimeline.fromTo(cardCopy,
                    { autoAlpha: 0.12, y: 20 },
                    { autoAlpha: 1, y: 0, duration: 0.72, ease: 'power3.out', stagger: 0.05 }, 0.48);
            }

            if (teamVisual || teamParts.length) {
                const teamTimeline = remember(gsap.timeline({
                    scrollTrigger: {
                        id: 'lmz-editor-home-team',
                        trigger: parts.team,
                        start: 'top 88%',
                        end: 'bottom 14%',
                        scrub: 0.68,
                        invalidateOnRefresh: true,
                    },
                }));
                if (teamVisual) teamTimeline.fromTo(teamVisual,
                    { autoAlpha: 0.08, x: -80, scale: 0.95 },
                    { autoAlpha: 1, x: 0, scale: 1, duration: 1.25, ease: 'power3.out' }, 0.05);
                if (teamFigures.length) teamTimeline.fromTo(teamFigures,
                    { xPercent: (index) => index ? 12 : -5, scale: 1.08 },
                    { xPercent: 0, scale: 1, duration: 1.4, ease: 'power2.out', stagger: 0.12 }, 0.1);
                if (teamParts.length) teamTimeline.fromTo(teamParts,
                    { autoAlpha: 0.08, x: 58 },
                    { autoAlpha: 1, x: 0, duration: 0.88, ease: 'power3.out', stagger: 0.1 }, 0.25);
                if (teamSeal) teamTimeline.fromTo(teamSeal,
                    { autoAlpha: 0.08, scale: 0.6, rotation: -14 },
                    { autoAlpha: 1, scale: 1, rotation: 0, duration: 1, ease: 'back.out(1.4)' }, 0.7);
            }
        };

        const addAboutProfile = (parts) => {
            if (!parts) return;
            addHero(parts, 'about', 'right');
            const facts = availableTargets(parts.factItems);
            if (parts.facts && facts.length) {
                snapshot(facts);
                remember(gsap.fromTo(facts, { autoAlpha: 0.1, y: 24 }, {
                    autoAlpha: 1,
                    y: 0,
                    duration: 0.88,
                    ease: 'power3.out',
                    stagger: 0.1,
                    scrollTrigger: {
                        id: 'lmz-editor-about-facts',
                        trigger: parts.facts,
                        start: 'top 92%',
                        end: '+=360',
                        scrub: 0.46,
                        invalidateOnRefresh: true,
                    },
                }));
            }

            const detailFigure = canProfileAnimate(parts.detailFigure) ? parts.detailFigure : null;
            const detailImage = canProfileAnimate(parts.detailImage) ? parts.detailImage : null;
            const detailParts = availableTargets(parts.detailParts);
            if (parts.detailSection && (detailFigure || detailParts.length)) {
                snapshot([detailFigure, detailImage, ...detailParts].filter(Boolean));
                const timeline = remember(gsap.timeline({
                    scrollTrigger: {
                        id: 'lmz-editor-about-detail',
                        trigger: parts.detailSection,
                        start: 'top 88%',
                        end: '+=520',
                        scrub: 0.62,
                        invalidateOnRefresh: true,
                    },
                }));
                if (detailFigure) timeline.fromTo(detailFigure,
                    { autoAlpha: 0.1, x: -52, clipPath: 'inset(0 14% 0 0)' },
                    { autoAlpha: 1, x: 0, clipPath: 'inset(0 0% 0 0)', duration: 1.08, ease: 'power3.out' }, 0);
                if (detailImage) timeline.fromTo(detailImage,
                    { scale: 1.075, yPercent: -3 },
                    { scale: 1, yPercent: 0, duration: 1.22, ease: 'power2.out' }, 0.04);
                if (detailParts.length) timeline.fromTo(detailParts,
                    { autoAlpha: 0.08, x: 46 },
                    { autoAlpha: 1, x: 0, duration: 0.9, ease: 'power3.out', stagger: 0.09 }, 0.16);
            }

            const valueHeaders = availableTargets(parts.valuesHeaderParts);
            const values = availableTargets(parts.values);
            if (parts.valuesSection && (valueHeaders.length || values.length)) {
                snapshot([...valueHeaders, ...values]);
                const timeline = remember(gsap.timeline({
                    scrollTrigger: {
                        id: 'lmz-editor-about-values',
                        trigger: parts.valuesSection,
                        start: 'top 88%',
                        end: '+=520',
                        scrub: 0.62,
                        invalidateOnRefresh: true,
                    },
                }));
                if (valueHeaders.length) timeline.fromTo(valueHeaders,
                    { autoAlpha: 0.08, y: 32 },
                    { autoAlpha: 1, y: 0, duration: 0.88, ease: 'power3.out', stagger: 0.1 }, 0.04);
                if (values.length) timeline.fromTo(values,
                    { autoAlpha: 0.06, x: 54, scale: 0.975 },
                    { autoAlpha: 1, x: 0, scale: 1, duration: 0.92, ease: 'power3.out', stagger: 0.12 }, 0.2);
            }
            addCta(parts.cta, 'lmz-editor-about-cta');
        };

        const addServicesProfile = (parts) => {
            if (!parts) return;
            addHero(parts, 'services', 'bottom');
            const facts = availableTargets(childElements(parts.facts));
            if (parts.facts && facts.length) {
                snapshot(facts);
                remember(gsap.fromTo(facts, { autoAlpha: 0.08, y: 28 }, {
                    autoAlpha: 1,
                    y: 0,
                    duration: 0.72,
                    ease: 'power3.out',
                    stagger: 0.11,
                    scrollTrigger: {
                        id: 'lmz-editor-services-facts',
                        trigger: parts.facts,
                        start: 'top 92%',
                        toggleActions: 'play none none reverse',
                        invalidateOnRefresh: true,
                    },
                }));
            }
            const headerParts = availableTargets(parts.detailHeaderParts);
            if (parts.detailSection && headerParts.length) {
                snapshot(headerParts);
                remember(gsap.fromTo(headerParts, { autoAlpha: 0.08, y: 30 }, {
                    autoAlpha: 1,
                    y: 0,
                    duration: 0.8,
                    ease: 'power3.out',
                    stagger: 0.08,
                    scrollTrigger: {
                        id: 'lmz-editor-services-detail-head',
                        trigger: parts.detailSection,
                        start: 'top 82%',
                        toggleActions: 'play none none reverse',
                        invalidateOnRefresh: true,
                    },
                }));
            }

            const entries = availableTargets(parts.entries);
            const figures = availableTargets(parts.figures);
            const figureImages = availableTargets(parts.figureImages);
            if (parts.stage && entries.length && figures.length) {
                snapshot([...entries, ...figures, ...figureImages, parts.progress].filter(Boolean));
                let currentIndex = -1;
                const renderIndex = (nextIndex, immediate) => {
                    if (destroyed || !figures.length) return;
                    const index = Math.max(0, Math.min(figures.length - 1, nextIndex));
                    if (index === currentIndex && !immediate) return;
                    const direction = currentIndex < 0 || index >= currentIndex ? 1 : -1;
                    currentIndex = index;
                    gsap.killTweensOf([...figures, ...figureImages, ...entries]);
                    figures.forEach((figure, figureIndex) => {
                        const active = figureIndex === index;
                        if (active) {
                            remember(gsap.fromTo(figure, {
                                autoAlpha: immediate ? 1 : 0,
                                xPercent: immediate ? 0 : direction * 8,
                                clipPath: immediate ? 'inset(0 0% 0 0)' : `inset(0 ${direction > 0 ? 18 : 0}% 0 ${direction > 0 ? 0 : 18}%)`,
                            }, {
                                autoAlpha: 1,
                                xPercent: 0,
                                clipPath: 'inset(0 0% 0 0)',
                                duration: immediate ? 0 : 0.55,
                                ease: 'power3.out',
                                overwrite: 'auto',
                            }));
                        } else {
                            remember(gsap.to(figure, {
                                autoAlpha: 0,
                                xPercent: -direction * 5,
                                duration: immediate ? 0 : 0.34,
                                ease: 'power2.out',
                                overwrite: 'auto',
                            }));
                        }
                    });
                    const image = figureImages[index];
                    if (image) remember(gsap.fromTo(image, {
                        scale: immediate ? 1 : 1.085,
                        xPercent: immediate ? 0 : direction * 2.4,
                    }, {
                        scale: 1,
                        xPercent: 0,
                        duration: immediate ? 0 : 0.85,
                        ease: 'power3.out',
                        overwrite: 'auto',
                    }));
                    entries.forEach((entry, entryIndex) => remember(gsap.to(entry, {
                        autoAlpha: entryIndex === index ? 1 : 0.48,
                        x: entryIndex === index ? 0 : 10,
                        duration: immediate ? 0 : 0.36,
                        ease: 'power2.out',
                        overwrite: 'auto',
                    })));
                };
                restartHandlers.push(() => {
                    currentIndex = -1;
                    renderIndex(0, true);
                });
                renderIndex(0, true);
                const stageTimeline = remember(gsap.timeline({
                    scrollTrigger: {
                        id: 'lmz-editor-services-stage',
                        trigger: parts.stage,
                        start: 'top 82%',
                        end: 'bottom 18%',
                        scrub: 0.35,
                        invalidateOnRefresh: true,
                        onUpdate: (self) => {
                            const next = Math.min(entries.length - 1, Math.floor(self.progress * entries.length));
                            renderIndex(next, false);
                        },
                    },
                }));
                if (parts.progress) stageTimeline.fromTo(parts.progress,
                    { scaleX: 0, transformOrigin: 'left center' },
                    { scaleX: 1, transformOrigin: 'left center', duration: 1, ease: 'none' }, 0);
            }
            addCta(parts.cta, 'lmz-editor-services-cta');
        };

        const addContactProfile = (parts) => {
            if (!parts) return;
            addHero(parts, 'contact', 'right');
            const contactParts = availableTargets(parts.contactParts);
            const form = canProfileAnimate(parts.form) ? parts.form : null;
            const formParts = availableTargets(parts.formParts);
            if (parts.requestSection && (contactParts.length || form)) {
                snapshot([...contactParts, form, ...formParts].filter(Boolean));
                const timeline = remember(gsap.timeline({
                    scrollTrigger: {
                        id: 'lmz-editor-contact-request',
                        trigger: parts.requestSection,
                        start: 'top 78%',
                        toggleActions: 'play none none reverse',
                        invalidateOnRefresh: true,
                    },
                }));
                if (contactParts.length) timeline.fromTo(contactParts,
                    { autoAlpha: 0, y: 28 },
                    { autoAlpha: 1, y: 0, duration: 0.64, ease: 'power3.out', stagger: 0.075 }, 0);
                if (form) timeline.fromTo(form,
                    { autoAlpha: 0, y: 38 },
                    { autoAlpha: 1, y: 0, duration: 0.72, ease: 'power3.out' }, 0.18);
                if (formParts.length) timeline.fromTo(formParts,
                    { autoAlpha: 0, y: 18 },
                    { autoAlpha: 1, y: 0, duration: 0.52, ease: 'power3.out', stagger: 0.045 }, 0.32);
            }
            addCta(parts.cta, 'lmz-editor-contact-cta');
        };

        const addCareersProfile = (parts) => {
            if (!parts) return;
            addHero(parts, 'careers', 'right');
            const reveals = availableTargets(parts.reveals);
            snapshot(reveals);
            reveals.forEach((element, index) => remember(gsap.fromTo(element, {
                autoAlpha: 0,
                y: 26,
            }, {
                autoAlpha: 1,
                y: 0,
                duration: 0.62,
                ease: 'power3.out',
                scrollTrigger: {
                    id: `lmz-editor-careers-reveal-${index}`,
                    trigger: element,
                    start: 'top 86%',
                    toggleActions: 'play none none reverse',
                    invalidateOnRefresh: true,
                },
            })));
        };

        const addProcessProfile = (parts) => {
            if (!parts?.section || !parts.header || !parts.track || !parts.steps.length) return;
            addTemporaryClass(parts.section,
                'rt-process-unified',
                parts.variant === 'services' ? 'rt-process-unified--light' : 'rt-process-unified--dark');
            addTemporaryClass(parts.header, 'rt-process-header');
            addTemporaryClass(parts.track, 'rt-process-track');
            parts.steps.forEach((step) => addTemporaryClass(step, 'rt-process-step'));
            const headerParts = availableTargets(childElements(parts.header));
            const steps = availableTargets(parts.steps);
            snapshot([...headerParts, ...steps, parts.section]);
            const timeline = remember(gsap.timeline({
                scrollTrigger: {
                    id: `lmz-editor-process-${parts.variant}`,
                    trigger: parts.section,
                    start: parts.variant === 'home' ? 'top 78%' : 'top 88%',
                    end: parts.variant === 'home' ? '+=460' : '+=540',
                    scrub: parts.variant === 'home' ? 0.5 : 0.64,
                    invalidateOnRefresh: true,
                },
            }));
            timeline.fromTo(parts.section, { '--rt-process-line': 0 }, {
                '--rt-process-line': 1,
                duration: 1.2,
                ease: 'none',
            }, 0);
            if (headerParts.length) timeline.fromTo(headerParts,
                { autoAlpha: 0.08, y: 30 },
                { autoAlpha: 1, y: 0, duration: 0.84, ease: 'power3.out', stagger: 0.09 }, 0.03);
            if (steps.length) timeline.fromTo(steps,
                { autoAlpha: 0.06, y: 38, scale: 0.98 },
                { autoAlpha: 1, y: 0, scale: 1, duration: 0.92, ease: 'power3.out', stagger: 0.11 }, 0.2);
        };

        context = gsap.context(() => {
            entries.forEach(({ element, definition }, index) => addEntryAnimation(element, definition, index));
            if (!settings.editorMode) return;
            addHomeProfile(profileParts.home);
            addAboutProfile(profileParts.about);
            addServicesProfile(profileParts.services);
            addContactProfile(profileParts.contact);
            addCareersProfile(profileParts.careers);
            addProcessProfile(profileParts.process);
        }, root);

        const onLoad = () => ScrollTrigger.refresh();
        const onMediaReady = () => {
            if (!destroyed) ScrollTrigger.refresh();
        };
        runtimeWindow.addEventListener('load', onLoad, { once: true });
        pendingMedia.forEach((element) => {
            element.addEventListener('load', onMediaReady, { once: true });
            element.addEventListener('loadedmetadata', onMediaReady, { once: true });
            element.addEventListener('error', onMediaReady, { once: true });
        });
        refreshFrame = runtimeWindow.requestAnimationFrame(() => {
            if (destroyed) return;
            refreshInnerFrame = runtimeWindow.requestAnimationFrame(() => {
                if (!destroyed) {
                    ScrollTrigger.sort();
                    ScrollTrigger.refresh();
                }
            });
        });
        setDocumentState('playing');

        return {
            available: true,
            reducedMotion: false,
            profiles: Array.from(profiles),
            state() {
                if (destroyed) return 'destroyed';
                return paused ? 'paused' : 'playing';
            },
            pause() {
                if (destroyed || paused) return;
                paused = true;
                triggers.forEach((trigger) => trigger.disable?.(false, false));
                animations.forEach((animation) => animation.pause?.());
                setDocumentState('paused');
            },
            resume() {
                if (destroyed || !paused) return;
                paused = false;
                triggers.forEach((trigger) => trigger.enable?.(false, false));
                animations.filter((animation) => !animation.scrollTrigger).forEach((animation) => animation.resume?.());
                ScrollTrigger.refresh();
                ScrollTrigger.update();
                setDocumentState('playing');
            },
            restart() {
                if (destroyed) return;
                paused = false;
                runtimeWindow.cancelAnimationFrame(restartFrame);
                restartHandlers.forEach((handler) => handler());
                triggers.forEach((trigger) => trigger.disable?.(false, false));
                animations.forEach((animation) => {
                    animation.invalidate?.();
                    animation.pause?.(0);
                });
                ScrollTrigger.refresh();
                restartFrame = runtimeWindow.requestAnimationFrame(() => {
                    if (destroyed) return;
                    triggers.forEach((trigger) => trigger.enable?.(false, false));
                    animations.filter((animation) => !animation.scrollTrigger).forEach((animation) => animation.restart?.());
                    ScrollTrigger.update();
                });
                setDocumentState('playing');
            },
            refresh() {
                if (!destroyed) ScrollTrigger.refresh();
            },
            destroy() {
                if (destroyed) return destroyFinalizer;
                destroyed = true;
                runtimeWindow.removeEventListener('load', onLoad);
                pendingMedia.forEach((element) => {
                    element.removeEventListener('load', onMediaReady);
                    element.removeEventListener('loadedmetadata', onMediaReady);
                    element.removeEventListener('error', onMediaReady);
                });
                runtimeWindow.cancelAnimationFrame(refreshFrame);
                runtimeWindow.cancelAnimationFrame(refreshInnerFrame);
                runtimeWindow.cancelAnimationFrame(restartFrame);
                triggers.forEach((trigger) => trigger.kill?.(true));
                animations.forEach((animation) => animation.kill?.());
                context?.revert?.();
                splits.slice().reverse().forEach((split) => split.revert?.());
                // Flush GSAP's lazy render queue before restoring the exact
                // pre-preview attributes. Otherwise a killed tween can leave
                // an empty style attribute behind in the editable canvas.
                gsap.ticker?.tick?.();
                const styleRestore = restoreSnapshots();
                restoreDocumentState();
                let finalized = false;
                destroyFinalizer = () => {
                    if (finalized) return;
                    finalized = true;
                    styleRestore.exact();
                    styleRestore.settle();
                };
                // CSSPlugin completes part of its style-saver teardown while
                // the destroy call unwinds. Settle empty attributes once more
                // in a microtask. The conditional settle never overwrites a
                // newer controller's non-empty animation state.
                runtimeWindow.queueMicrotask?.(styleRestore.settle);
                return destroyFinalizer;
            },
        };
    }

    global.LMZMotionRuntime = {
        version: VERSION,
        mount(options) {
            const finalizePrevious = activeController?.destroy?.();
            finalizePrevious?.();
            activeController = create(options);
            return activeController;
        },
        destroy() {
            const finalizeActive = activeController?.destroy?.();
            finalizeActive?.();
            activeController = null;
        },
        getActive() {
            return activeController;
        },
    };
})(window);
