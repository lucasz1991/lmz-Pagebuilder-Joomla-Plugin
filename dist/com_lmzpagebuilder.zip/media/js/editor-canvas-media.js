(function () {
    'use strict';

    function prepare(document) {
        document.querySelectorAll('video').forEach((video) => {
            // The editor is an inspection surface. Autoplay belongs to the
            // public intro runtime and is rejected by browsers in an iframe.
            video.removeAttribute('autoplay');
            video.muted = true;
            video.defaultMuted = true;
            video.playsInline = true;
            video.setAttribute('playsinline', '');
            video.setAttribute('controls', '');
            video.preload = 'metadata';
            video.addEventListener('error', () => {
                video.dataset.lmzEditorMediaError = 'true';
                video.setAttribute('aria-label', 'Video konnte im Editor nicht geladen werden');
            }, { once: true });
        });
    }

    function mount() {
        const document = window.document;
        prepare(document);
        new MutationObserver(() => prepare(document)).observe(document.body, { childList: true, subtree: true });
    }

    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', mount, { once: true });
    else mount();
}());
