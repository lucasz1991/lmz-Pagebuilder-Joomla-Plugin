(function () {
    'use strict';

    function getJoomlaOptions(key) {
        const direct = window.Joomla?.getOptions?.(key);
        if (direct && typeof direct === 'object') return direct;

        for (const node of document.querySelectorAll('script.joomla-script-options[type="application/json"]')) {
            try {
                const payload = JSON.parse(node.textContent || '{}');
                if (payload && typeof payload[key] === 'object') return payload[key];
            } catch (error) {
                // Ignore an unrelated malformed options node and keep looking.
            }
        }

        return {};
    }

    function boot() {
        const root = document.querySelector('[data-lmzpb-projects]');
        const config = getJoomlaOptions('com_lmzpagebuilder.projects');
        if (!root || !config.csrfToken) return;

        const notice = root.querySelector('[data-lmzpb-notice]');

        const setSection = (section, updateHash = true) => {
            const target = section === 'elements' ? 'elements' : 'pages';
            root.querySelectorAll('[data-lmzpb-section-tab]').forEach((tab) => {
                const active = tab.dataset.lmzpbSectionTab === target;
                tab.classList.toggle('is-active', active);
                tab.setAttribute('aria-selected', active ? 'true' : 'false');
                tab.tabIndex = active ? 0 : -1;
            });
            root.querySelectorAll('[data-lmzpb-section-panel]').forEach((panel) => {
                panel.hidden = panel.dataset.lmzpbSectionPanel !== target;
            });

            if (updateHash) {
                const nextHash = target === 'elements' ? '#gespeicherte-elemente' : '#seiten';
                if (window.location.hash !== nextHash) history.replaceState(null, '', nextHash);
            }
        };

        const showNotice = (message, state) => {
            notice.hidden = false;
            notice.textContent = message;
            notice.dataset.state = state || 'success';
        };

        const request = async (url, form) => {
            const response = await fetch(url, {
                method: 'POST',
                body: form,
                credentials: 'same-origin',
                headers: { 'X-CSRF-Token': config.csrfToken, Accept: 'application/json' },
            });
            const payload = await response.json().catch(() => null);
            if (!response.ok || !payload?.success) {
                throw new Error(payload?.message || config.labels?.failed || 'Request failed.');
            }
            return payload.data;
        };

        root.querySelectorAll('[data-lmzpb-section-tab]').forEach((tab) => {
            tab.addEventListener('click', () => setSection(tab.dataset.lmzpbSectionTab));
            tab.addEventListener('keydown', (event) => {
                if (!['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) return;
                event.preventDefault();
                const tabs = [...root.querySelectorAll('[data-lmzpb-section-tab]')];
                const current = tabs.indexOf(tab);
                const next = event.key === 'Home'
                    ? 0
                    : event.key === 'End'
                        ? tabs.length - 1
                        : (current + (event.key === 'ArrowRight' ? 1 : -1) + tabs.length) % tabs.length;
                tabs[next]?.focus();
                tabs[next]?.click();
            });
        });

        const initialSection = window.location.hash === '#gespeicherte-elemente' ? 'elements' : 'pages';
        setSection(initialSection, false);
        window.addEventListener('hashchange', () => {
            setSection(window.location.hash === '#gespeicherte-elemente' ? 'elements' : 'pages', false);
        });

        root.querySelector('[data-lmzpb-create-element]')?.addEventListener('submit', async (event) => {
            event.preventDefault();
            const formNode = event.currentTarget;
            const submit = formNode.querySelector('[type="submit"]');
            const title = String(new FormData(formNode).get('title') || '').trim();
            const kind = String(new FormData(formNode).get('kind') || 'global');
            const languages = [...formNode.querySelectorAll('input[name="languages[]"]:checked')]
                .map((input) => input.value)
                .filter(Boolean);

            if (!title) {
                showNotice(config.labels?.titleRequired || 'Bitte einen Titel eingeben.', 'error');
                formNode.querySelector('[name="title"]')?.focus();
                return;
            }
            if (!languages.length) {
                showNotice(config.labels?.languageRequired || 'Bitte mindestens eine aktive Sprache auswählen.', 'error');
                return;
            }

            submit.disabled = true;
            showNotice(config.labels?.working || 'Working…');
            const requestForm = new FormData();
            requestForm.append('payload', JSON.stringify({ title, kind, languages }));
            try {
                const result = await request(config.endpoints.createElement, requestForm);
                const target = new URL('index.php', window.location.href);
                target.searchParams.set('option', 'com_lmzpagebuilder');
                target.searchParams.set('view', 'element');
                target.searchParams.set('element_id', String(result.id));
                target.searchParams.set('language', languages[0]);
                target.searchParams.set('tmpl', 'component');
                window.location.href = target.href;
            } catch (error) {
                showNotice(error.message, 'error');
                submit.disabled = false;
            }
        });

        root.querySelector('[data-lmzpb-import-all]')?.addEventListener('click', async (event) => {
            const button = event.currentTarget;
            button.disabled = true;
            showNotice(config.labels?.working || 'Working…');
            try {
                const result = await request(config.endpoints.importAll, new FormData());
                showNotice(`${config.labels?.imported || 'Import complete.'} ${result.imported} / ${result.refreshed} / ${result.unchanged}`);
                window.setTimeout(() => window.location.reload(), 500);
            } catch (error) {
                showNotice(error.message, 'error');
                button.disabled = false;
            }
        });

        root.querySelectorAll('[data-lmzpb-import-page]').forEach((button) => {
            button.addEventListener('click', async () => {
                button.disabled = true;
                showNotice(config.labels?.working || 'Working…');
                const form = new FormData();
                form.append('page_id', button.dataset.lmzpbImportPage);
                try {
                    await request(config.endpoints.importPage, form);
                    window.location.reload();
                } catch (error) {
                    showNotice(error.message, 'error');
                    button.disabled = false;
                }
            });
        });

        root.querySelectorAll('[data-lmzpb-create-translation]').forEach((button) => {
            button.addEventListener('click', async () => {
                const pageId = button.closest('[data-page-id]')?.dataset.pageId;
                const language = button.dataset.lmzpbCreateTranslation;
                if (!pageId || !language || !config.endpoints?.createTranslation) return;

                button.disabled = true;
                showNotice(config.labels?.working || 'Working…');
                const form = new FormData();
                form.append('page_id', pageId);
                form.append('language', language);
                try {
                    await request(config.endpoints.createTranslation, form);
                    window.location.reload();
                } catch (error) {
                    showNotice(error.message, 'error');
                    button.disabled = false;
                }
            });
        });

        root.querySelectorAll('[data-lmzpb-create-element-translation]').forEach((button) => {
            button.addEventListener('click', async () => {
                const elementId = button.closest('[data-element-id]')?.dataset.elementId;
                const language = button.dataset.lmzpbCreateElementTranslation;
                if (!elementId || !language || !config.endpoints?.createElementTranslation) return;

                button.disabled = true;
                showNotice(config.labels?.working || 'Working…');
                const form = new FormData();
                form.append('element_id', elementId);
                form.append('language', language);
                try {
                    await request(config.endpoints.createElementTranslation, form);
                    const target = new URL('index.php', window.location.href);
                    target.searchParams.set('option', 'com_lmzpagebuilder');
                    target.searchParams.set('view', 'element');
                    target.searchParams.set('element_id', elementId);
                    target.searchParams.set('language', language);
                    target.searchParams.set('tmpl', 'component');
                    window.location.href = target.href;
                } catch (error) {
                    showNotice(error.message, 'error');
                    button.disabled = false;
                }
            });
        });
    }

    document.readyState === 'loading' ? document.addEventListener('DOMContentLoaded', boot) : boot();
})();
