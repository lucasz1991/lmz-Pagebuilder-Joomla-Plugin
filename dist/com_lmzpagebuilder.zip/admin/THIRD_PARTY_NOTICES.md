# Third-party notices

LMZ Page Builder bundles GrapesJS 0.22.14. GrapesJS is distributed under the
BSD 3-Clause license. Copyright (c) 2017, Artur Arseniev.

The bundled GrapesJS JavaScript and CSS are unmodified distribution artifacts
from the WebReach checkout. The surrounding LMZ editor shell was adapted from
LMZ Media's WebReach implementation and does not depend on GrapesJS Studio SDK
or a Studio license key.

GrapesJS project: https://github.com/GrapesJS/grapesjs
