-- Schema marker for the LMZ RailTime Suite 2.4.1 patch release.
SELECT 1;
