-- LMZ Page Builder 2.2.2 adds Joomla 5 editor compatibility, saved-element management, reliable motion previews and update-safe RailTime content migrations.
SELECT 1;
