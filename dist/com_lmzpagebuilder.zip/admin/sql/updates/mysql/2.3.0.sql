CREATE TABLE IF NOT EXISTS `#__lmzpagebuilder_template_settings` (
  `id` tinyint unsigned NOT NULL DEFAULT 1,
  `contact_id` int unsigned NOT NULL DEFAULT 0,
  `data_json` longtext NOT NULL,
  `settings_hash` char(64) NOT NULL,
  `version` int unsigned NOT NULL DEFAULT 1,
  `created` datetime NOT NULL,
  `created_by` int unsigned NOT NULL DEFAULT 0,
  `modified` datetime NOT NULL,
  `modified_by` int unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_lmzpb_template_settings_contact` (`contact_id`),
  KEY `idx_lmzpb_template_settings_modified` (`modified`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__lmzpagebuilder_template_setting_revisions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `settings_id` tinyint unsigned NOT NULL DEFAULT 1,
  `settings_version` int unsigned NOT NULL,
  `operation` varchar(32) NOT NULL DEFAULT 'save',
  `data_json` longtext NOT NULL,
  `snapshot_hash` char(64) NOT NULL,
  `note` varchar(500) NOT NULL DEFAULT '',
  `created` datetime NOT NULL,
  `created_by` int unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_lmzpb_template_revision_version` (`settings_id`, `settings_version`),
  KEY `idx_lmzpb_template_revision_created` (`settings_id`, `created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;
