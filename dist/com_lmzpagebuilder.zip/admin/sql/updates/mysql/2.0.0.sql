-- Additive native multilingual v2 schema. Legacy v1 data was migrated and is
-- intentionally outside this update so a package update never destroys data.
CREATE TABLE IF NOT EXISTS `#__lmzpagebuilder_pages` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `page_key` varchar(191) NOT NULL,
  `title` varchar(255) NOT NULL,
  `state` tinyint NOT NULL DEFAULT 1,
  `ordering` int NOT NULL DEFAULT 0,
  `access` int unsigned NOT NULL DEFAULT 1,
  `created` datetime NOT NULL,
  `created_by` int unsigned NOT NULL DEFAULT 0,
  `modified` datetime NOT NULL,
  `modified_by` int unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_lmzpb_page_key` (`page_key`),
  KEY `idx_lmzpb_page_state_order` (`state`, `ordering`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__lmzpagebuilder_page_translations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `page_id` int unsigned NOT NULL,
  `language` varchar(7) NOT NULL,
  `title` varchar(255) NOT NULL,
  `alias` varchar(191) NOT NULL,
  `browser_title` varchar(255) NOT NULL DEFAULT '',
  `meta_description` text NOT NULL,
  `meta_keywords` text NOT NULL,
  `robots` varchar(64) NOT NULL DEFAULT '',
  `state` tinyint NOT NULL DEFAULT 1,
  `engine` varchar(32) NOT NULL DEFAULT 'grapesjs',
  `schema_version` smallint unsigned NOT NULL DEFAULT 2,
  `draft_project_json` longtext NOT NULL,
  `draft_html` longtext NOT NULL,
  `draft_css` longtext NOT NULL,
  `published_html` longtext NOT NULL,
  `published_css` longtext NOT NULL,
  `draft_hash` char(64) NOT NULL,
  `published_hash` char(64) NOT NULL,
  `checked_out` int unsigned NOT NULL DEFAULT 0,
  `checked_out_time` datetime DEFAULT NULL,
  `checkout_token` char(64) NOT NULL DEFAULT '',
  `created` datetime NOT NULL,
  `created_by` int unsigned NOT NULL DEFAULT 0,
  `modified` datetime NOT NULL,
  `modified_by` int unsigned NOT NULL DEFAULT 0,
  `published` datetime DEFAULT NULL,
  `published_by` int unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_lmzpb_page_language` (`page_id`, `language`),
  UNIQUE KEY `idx_lmzpb_alias_language` (`alias`, `language`),
  KEY `idx_lmzpb_translation_state` (`state`, `language`),
  KEY `idx_lmzpb_translation_modified` (`modified`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__lmzpagebuilder_page_revisions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `translation_id` int unsigned NOT NULL,
  `operation` varchar(32) NOT NULL DEFAULT 'publish',
  `project_json` longtext NOT NULL,
  `html` longtext NOT NULL,
  `css` longtext NOT NULL,
  `snapshot_hash` char(64) NOT NULL,
  `metadata_json` text NOT NULL,
  `note` varchar(500) NOT NULL DEFAULT '',
  `created` datetime NOT NULL,
  `created_by` int unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_lmzpb_revision_translation` (`translation_id`, `id`),
  KEY `idx_lmzpb_revision_created` (`created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__lmzpagebuilder_elements` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL,
  `element_key` varchar(100) NOT NULL,
  `title` varchar(255) NOT NULL,
  `kind` varchar(16) NOT NULL DEFAULT 'global',
  `state` tinyint NOT NULL DEFAULT 1,
  `ordering` int NOT NULL DEFAULT 0,
  `access` int unsigned NOT NULL DEFAULT 1,
  `created` datetime NOT NULL,
  `created_by` int unsigned NOT NULL DEFAULT 0,
  `modified` datetime NOT NULL,
  `modified_by` int unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_lmzpb_element_uuid` (`uuid`),
  UNIQUE KEY `idx_lmzpb_element_key` (`element_key`),
  KEY `idx_lmzpb_element_kind_state` (`kind`, `state`, `ordering`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__lmzpagebuilder_element_translations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `element_id` int unsigned NOT NULL,
  `language` varchar(7) NOT NULL,
  `title` varchar(255) NOT NULL,
  `draft_project_json` longtext NOT NULL,
  `draft_html` longtext NOT NULL,
  `draft_css` longtext NOT NULL,
  `published_html` longtext NOT NULL,
  `published_css` longtext NOT NULL,
  `draft_hash` char(64) NOT NULL,
  `published_hash` char(64) NOT NULL,
  `state` tinyint NOT NULL DEFAULT 1,
  `checked_out` int unsigned NOT NULL DEFAULT 0,
  `checked_out_time` datetime DEFAULT NULL,
  `checkout_token` char(64) NOT NULL DEFAULT '',
  `created` datetime NOT NULL,
  `created_by` int unsigned NOT NULL DEFAULT 0,
  `modified` datetime NOT NULL,
  `modified_by` int unsigned NOT NULL DEFAULT 0,
  `published` datetime DEFAULT NULL,
  `published_by` int unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_lmzpb_element_language` (`element_id`, `language`),
  KEY `idx_lmzpb_element_translation_modified` (`modified`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__lmzpagebuilder_element_usages` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `owner_type` varchar(24) NOT NULL,
  `owner_id` int unsigned NOT NULL,
  `element_id` int unsigned NOT NULL,
  `language` varchar(7) NOT NULL DEFAULT '*',
  `marker_uuid` char(36) NOT NULL,
  `context` varchar(191) NOT NULL DEFAULT '',
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_lmzpb_usage_unique` (`owner_type`, `owner_id`, `element_id`, `context`),
  KEY `idx_lmzpb_usage_element` (`element_id`, `owner_type`),
  KEY `idx_lmzpb_usage_owner` (`owner_type`, `owner_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;

-- Native snapshots live in the unambiguous page-revisions table above.
