-- KI-Assistenz: Audit-/Bestaetigungsspeicher und Gespraechsverlauf.
-- Die Spalten argumente/ergebnis nehmen JSON auf; MariaDB 10.4 bildet JSON
-- ohnehin auf LONGTEXT ab, deshalb wird der portable Typ verwendet.

CREATE TABLE IF NOT EXISTS `#__lmzpagebuilder_assistant_actions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int unsigned NOT NULL DEFAULT 0,
  `bereich` varchar(16) NOT NULL DEFAULT 'admin',
  `werkzeug` varchar(64) NOT NULL,
  `argumente` longtext NOT NULL,
  `status` enum('pending','bestaetigt','ausgefuehrt','abgelehnt','fehler') NOT NULL DEFAULT 'pending',
  `vorschau` longtext DEFAULT NULL,
  `ergebnis` longtext DEFAULT NULL,
  `erstellt` datetime NOT NULL,
  `ausgefuehrt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_lmzpb_assist_action_offen` (`status`, `user_id`),
  KEY `idx_lmzpb_assist_action_user` (`user_id`, `erstellt`),
  KEY `idx_lmzpb_assist_action_erstellt` (`erstellt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__lmzpagebuilder_assistant_messages` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `thread` varchar(64) NOT NULL,
  `user_id` int unsigned NOT NULL DEFAULT 0,
  `bereich` varchar(16) NOT NULL DEFAULT 'admin',
  `rolle` varchar(16) NOT NULL DEFAULT 'user',
  `inhalt` longtext NOT NULL,
  `erstellt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_lmzpb_assist_msg_thread` (`thread`, `id`),
  KEY `idx_lmzpb_assist_msg_user` (`user_id`, `erstellt`),
  KEY `idx_lmzpb_assist_msg_erstellt` (`erstellt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;
