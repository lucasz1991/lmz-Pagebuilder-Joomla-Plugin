CREATE TABLE IF NOT EXISTS `#__lmzpagebuilder_migrations` (
  `migration_key` varchar(191) NOT NULL,
  `package_version` varchar(32) NOT NULL,
  `metadata_json` longtext NOT NULL,
  `applied` datetime NOT NULL,
  PRIMARY KEY (`migration_key`),
  KEY `idx_lmzpb_migration_applied` (`applied`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;
