CREATE TABLE IF NOT EXISTS `#__lmzpagebuilder_page_layouts` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `page_id` int unsigned NOT NULL,
  `source_language` varchar(7) NOT NULL,
  `schema_version` smallint unsigned NOT NULL DEFAULT 1,
  `draft_project_json` longtext NOT NULL,
  `draft_html` longtext NOT NULL,
  `draft_css` longtext NOT NULL,
  `draft_hash` char(64) NOT NULL,
  `draft_signature` char(64) NOT NULL,
  `published_project_json` longtext NOT NULL,
  `published_html` longtext NOT NULL,
  `published_css` longtext NOT NULL,
  `published_hash` char(64) NOT NULL,
  `published_signature` char(64) NOT NULL,
  `created` datetime NOT NULL,
  `created_by` int unsigned NOT NULL DEFAULT 0,
  `modified` datetime NOT NULL,
  `modified_by` int unsigned NOT NULL DEFAULT 0,
  `published` datetime DEFAULT NULL,
  `published_by` int unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_lmzpb_layout_page` (`page_id`),
  KEY `idx_lmzpb_layout_modified` (`modified`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__lmzpagebuilder_page_texts` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `page_id` int unsigned NOT NULL,
  `language` varchar(7) NOT NULL,
  `schema_version` smallint unsigned NOT NULL DEFAULT 1,
  `draft_json` longtext NOT NULL,
  `published_json` longtext NOT NULL,
  `draft_hash` char(64) NOT NULL,
  `published_hash` char(64) NOT NULL,
  `created` datetime NOT NULL,
  `created_by` int unsigned NOT NULL DEFAULT 0,
  `modified` datetime NOT NULL,
  `modified_by` int unsigned NOT NULL DEFAULT 0,
  `published` datetime DEFAULT NULL,
  `published_by` int unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_lmzpb_text_page_language` (`page_id`, `language`),
  KEY `idx_lmzpb_text_modified` (`modified`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;

ALTER TABLE `#__lmzpagebuilder_page_revisions`
  MODIFY `metadata_json` longtext NOT NULL;
