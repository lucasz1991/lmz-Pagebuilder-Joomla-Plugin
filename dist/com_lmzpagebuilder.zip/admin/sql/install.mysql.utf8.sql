CREATE TABLE IF NOT EXISTS `#__lmzpagebuilder_pages` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `page_key` varchar(191) NOT NULL,
  `title` varchar(255) NOT NULL,
  `state` tinyint NOT NULL DEFAULT 1,
  `ordering` int NOT NULL DEFAULT 0,
  `access` int unsigned NOT NULL DEFAULT 1,
  `created` datetime NOT NULL,
  `created_by` int unsigned NOT NULL DEFAULT 0,
  `modified` datetime NOT NULL,
  `modified_by` int unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_lmzpb_page_key` (`page_key`),
  KEY `idx_lmzpb_page_state_order` (`state`, `ordering`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__lmzpagebuilder_page_translations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `page_id` int unsigned NOT NULL,
  `language` varchar(7) NOT NULL,
  `title` varchar(255) NOT NULL,
  `alias` varchar(191) NOT NULL,
  `browser_title` varchar(255) NOT NULL DEFAULT '',
  `meta_description` text NOT NULL,
  `meta_keywords` text NOT NULL,
  `robots` varchar(64) NOT NULL DEFAULT '',
  `state` tinyint NOT NULL DEFAULT 1,
  `engine` varchar(32) NOT NULL DEFAULT 'grapesjs',
  `schema_version` smallint unsigned NOT NULL DEFAULT 2,
  `draft_project_json` longtext NOT NULL,
  `draft_html` longtext NOT NULL,
  `draft_css` longtext NOT NULL,
  `published_html` longtext NOT NULL,
  `published_css` longtext NOT NULL,
  `draft_hash` char(64) NOT NULL,
  `published_hash` char(64) NOT NULL,
  `checked_out` int unsigned NOT NULL DEFAULT 0,
  `checked_out_time` datetime DEFAULT NULL,
  `checkout_token` char(64) NOT NULL DEFAULT '',
  `created` datetime NOT NULL,
  `created_by` int unsigned NOT NULL DEFAULT 0,
  `modified` datetime NOT NULL,
  `modified_by` int unsigned NOT NULL DEFAULT 0,
  `published` datetime DEFAULT NULL,
  `published_by` int unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_lmzpb_page_language` (`page_id`, `language`),
  UNIQUE KEY `idx_lmzpb_alias_language` (`alias`, `language`),
  KEY `idx_lmzpb_translation_state` (`state`, `language`),
  KEY `idx_lmzpb_translation_modified` (`modified`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__lmzpagebuilder_page_revisions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `translation_id` int unsigned NOT NULL,
  `operation` varchar(32) NOT NULL DEFAULT 'publish',
  `project_json` longtext NOT NULL,
  `html` longtext NOT NULL,
  `css` longtext NOT NULL,
  `snapshot_hash` char(64) NOT NULL,
  `metadata_json` longtext NOT NULL,
  `note` varchar(500) NOT NULL DEFAULT '',
  `created` datetime NOT NULL,
  `created_by` int unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_lmzpb_revision_translation` (`translation_id`, `id`),
  KEY `idx_lmzpb_revision_created` (`created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__lmzpagebuilder_migrations` (
  `migration_key` varchar(191) NOT NULL,
  `package_version` varchar(32) NOT NULL,
  `metadata_json` longtext NOT NULL,
  `applied` datetime NOT NULL,
  PRIMARY KEY (`migration_key`),
  KEY `idx_lmzpb_migration_applied` (`applied`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__lmzpagebuilder_page_layouts` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `page_id` int unsigned NOT NULL,
  `source_language` varchar(7) NOT NULL,
  `schema_version` smallint unsigned NOT NULL DEFAULT 1,
  `draft_project_json` longtext NOT NULL,
  `draft_html` longtext NOT NULL,
  `draft_css` longtext NOT NULL,
  `draft_hash` char(64) NOT NULL,
  `draft_signature` char(64) NOT NULL,
  `published_project_json` longtext NOT NULL,
  `published_html` longtext NOT NULL,
  `published_css` longtext NOT NULL,
  `published_hash` char(64) NOT NULL,
  `published_signature` char(64) NOT NULL,
  `created` datetime NOT NULL,
  `created_by` int unsigned NOT NULL DEFAULT 0,
  `modified` datetime NOT NULL,
  `modified_by` int unsigned NOT NULL DEFAULT 0,
  `published` datetime DEFAULT NULL,
  `published_by` int unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_lmzpb_layout_page` (`page_id`),
  KEY `idx_lmzpb_layout_modified` (`modified`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__lmzpagebuilder_page_texts` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `page_id` int unsigned NOT NULL,
  `language` varchar(7) NOT NULL,
  `schema_version` smallint unsigned NOT NULL DEFAULT 1,
  `draft_json` longtext NOT NULL,
  `published_json` longtext NOT NULL,
  `draft_hash` char(64) NOT NULL,
  `published_hash` char(64) NOT NULL,
  `created` datetime NOT NULL,
  `created_by` int unsigned NOT NULL DEFAULT 0,
  `modified` datetime NOT NULL,
  `modified_by` int unsigned NOT NULL DEFAULT 0,
  `published` datetime DEFAULT NULL,
  `published_by` int unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_lmzpb_text_page_language` (`page_id`, `language`),
  KEY `idx_lmzpb_text_modified` (`modified`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__lmzpagebuilder_elements` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL,
  `element_key` varchar(100) NOT NULL,
  `title` varchar(255) NOT NULL,
  `kind` varchar(16) NOT NULL DEFAULT 'global',
  `state` tinyint NOT NULL DEFAULT 1,
  `ordering` int NOT NULL DEFAULT 0,
  `access` int unsigned NOT NULL DEFAULT 1,
  `created` datetime NOT NULL,
  `created_by` int unsigned NOT NULL DEFAULT 0,
  `modified` datetime NOT NULL,
  `modified_by` int unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_lmzpb_element_uuid` (`uuid`),
  UNIQUE KEY `idx_lmzpb_element_key` (`element_key`),
  KEY `idx_lmzpb_element_kind_state` (`kind`, `state`, `ordering`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__lmzpagebuilder_element_translations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `element_id` int unsigned NOT NULL,
  `language` varchar(7) NOT NULL,
  `title` varchar(255) NOT NULL,
  `draft_project_json` longtext NOT NULL,
  `draft_html` longtext NOT NULL,
  `draft_css` longtext NOT NULL,
  `published_html` longtext NOT NULL,
  `published_css` longtext NOT NULL,
  `draft_hash` char(64) NOT NULL,
  `published_hash` char(64) NOT NULL,
  `state` tinyint NOT NULL DEFAULT 1,
  `checked_out` int unsigned NOT NULL DEFAULT 0,
  `checked_out_time` datetime DEFAULT NULL,
  `checkout_token` char(64) NOT NULL DEFAULT '',
  `created` datetime NOT NULL,
  `created_by` int unsigned NOT NULL DEFAULT 0,
  `modified` datetime NOT NULL,
  `modified_by` int unsigned NOT NULL DEFAULT 0,
  `published` datetime DEFAULT NULL,
  `published_by` int unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_lmzpb_element_language` (`element_id`, `language`),
  KEY `idx_lmzpb_element_translation_modified` (`modified`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__lmzpagebuilder_element_usages` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `owner_type` varchar(24) NOT NULL,
  `owner_id` int unsigned NOT NULL,
  `element_id` int unsigned NOT NULL,
  `language` varchar(7) NOT NULL DEFAULT '*',
  `marker_uuid` char(36) NOT NULL,
  `context` varchar(191) NOT NULL DEFAULT '',
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_lmzpb_usage_unique` (`owner_type`, `owner_id`, `element_id`, `context`),
  KEY `idx_lmzpb_usage_element` (`element_id`, `owner_type`),
  KEY `idx_lmzpb_usage_owner` (`owner_type`, `owner_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__lmzpagebuilder_template_settings` (
  `id` tinyint unsigned NOT NULL DEFAULT 1,
  `contact_id` int unsigned NOT NULL DEFAULT 0,
  `data_json` longtext NOT NULL,
  `settings_hash` char(64) NOT NULL,
  `version` int unsigned NOT NULL DEFAULT 1,
  `created` datetime NOT NULL,
  `created_by` int unsigned NOT NULL DEFAULT 0,
  `modified` datetime NOT NULL,
  `modified_by` int unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_lmzpb_template_settings_contact` (`contact_id`),
  KEY `idx_lmzpb_template_settings_modified` (`modified`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__lmzpagebuilder_template_setting_revisions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `settings_id` tinyint unsigned NOT NULL DEFAULT 1,
  `settings_version` int unsigned NOT NULL,
  `operation` varchar(32) NOT NULL DEFAULT 'save',
  `data_json` longtext NOT NULL,
  `snapshot_hash` char(64) NOT NULL,
  `note` varchar(500) NOT NULL DEFAULT '',
  `created` datetime NOT NULL,
  `created_by` int unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_lmzpb_template_revision_version` (`settings_id`, `settings_version`),
  KEY `idx_lmzpb_template_revision_created` (`settings_id`, `created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;

-- KI-Assistenz: Audit-/Bestaetigungsspeicher und Gespraechsverlauf.
-- Die Spalten argumente/ergebnis nehmen JSON auf; MariaDB 10.4 bildet JSON
-- ohnehin auf LONGTEXT ab, deshalb wird der portable Typ verwendet.

CREATE TABLE IF NOT EXISTS `#__lmzpagebuilder_assistant_actions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int unsigned NOT NULL DEFAULT 0,
  `bereich` varchar(16) NOT NULL DEFAULT 'admin',
  `werkzeug` varchar(64) NOT NULL,
  `argumente` longtext NOT NULL,
  `status` enum('pending','bestaetigt','ausgefuehrt','abgelehnt','fehler') NOT NULL DEFAULT 'pending',
  `vorschau` longtext DEFAULT NULL,
  `ergebnis` longtext DEFAULT NULL,
  `erstellt` datetime NOT NULL,
  `ausgefuehrt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_lmzpb_assist_action_offen` (`status`, `user_id`),
  KEY `idx_lmzpb_assist_action_user` (`user_id`, `erstellt`),
  KEY `idx_lmzpb_assist_action_erstellt` (`erstellt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__lmzpagebuilder_assistant_messages` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `thread` varchar(64) NOT NULL,
  `user_id` int unsigned NOT NULL DEFAULT 0,
  `bereich` varchar(16) NOT NULL DEFAULT 'admin',
  `rolle` varchar(16) NOT NULL DEFAULT 'user',
  `inhalt` longtext NOT NULL,
  `erstellt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_lmzpb_assist_msg_thread` (`thread`, `id`),
  KEY `idx_lmzpb_assist_msg_user` (`user_id`, `erstellt`),
  KEY `idx_lmzpb_assist_msg_erstellt` (`erstellt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;
