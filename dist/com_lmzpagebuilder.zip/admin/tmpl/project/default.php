<?php

defined('_JEXEC') or die;

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;

$backUrl = Route::_('index.php?option=com_lmzpagebuilder&view=projects');
$version = is_array($this->item['version'] ?? null) ? $this->item['version'] : [];
$versionStatus = in_array((string) ($version['status'] ?? ''), ['identical', 'newer', 'unpublished'], true)
    ? (string) $version['status']
    : 'unpublished';
$versionStatusLabel = Text::_(match ($versionStatus) {
    'identical' => 'COM_LMZPAGEBUILDER_VERSION_STATUS_IDENTICAL',
    'newer' => 'COM_LMZPAGEBUILDER_VERSION_STATUS_NEWER',
    default => 'COM_LMZPAGEBUILDER_VERSION_STATUS_UNPUBLISHED',
});
$formatVersion = static function (string $fingerprint): string {
    return $fingerprint === ''
        ? Text::_('COM_LMZPAGEBUILDER_VERSION_NONE')
        : Text::sprintf('COM_LMZPAGEBUILDER_VERSION_LABEL', substr($fingerprint, 0, 12));
};
?>

<?php if ($this->error !== null) : ?>
    <main class="lmzpb-editor-error" role="alert">
        <span class="icon-warning" aria-hidden="true"></span>
        <h1><?php echo Text::_('COM_LMZPAGEBUILDER_EDITOR_UNAVAILABLE'); ?></h1>
        <p><?php echo htmlspecialchars($this->error, ENT_QUOTES, 'UTF-8'); ?></p>
        <a class="btn btn-primary" href="<?php echo $backUrl; ?>"><?php echo Text::_('JBACK'); ?></a>
    </main>
<?php else : ?>
    <div class="lmzpb-editor-page" data-lmzpb-editor data-translation-only="<?php echo !empty($this->item['translation_only']) ? 'true' : 'false'; ?>">
        <header class="lmzpb-editor-header">
            <div class="lmzpb-editor-header__identity">
                <a class="lmzpb-icon-button" href="<?php echo $backUrl; ?>" data-lmzpb-back aria-label="<?php echo Text::_('JBACK'); ?>">
                    <span class="icon-arrow-left" aria-hidden="true"></span>
                </a>
                <div>
                    <span class="lmzpb-eyebrow"><?php echo Text::_('COM_LMZPAGEBUILDER_PAGE_EDITOR'); ?> · #<?php echo (int) $this->item['page_id']; ?></span>
                    <h1><?php echo htmlspecialchars((string) $this->item['title'], ENT_QUOTES, 'UTF-8'); ?></h1>
                </div>
                <label class="lmzpb-language-select" title="<?php echo Text::_('COM_LMZPAGEBUILDER_LANGUAGES'); ?>">
                    <span class="visually-hidden"><?php echo Text::_('COM_LMZPAGEBUILDER_LANGUAGES'); ?></span>
                    <select data-lmzpb-language-select>
                    <?php foreach ($this->languageOptions as $language) : ?>
                        <?php $shortCode = strtoupper(strtok((string) $language['code'], '-')); ?>
                        <option value="<?php echo htmlspecialchars((string) ($language['editor_url'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>" data-language-code="<?php echo htmlspecialchars((string) $language['code'], ENT_QUOTES, 'UTF-8'); ?>" data-language-exists="<?php echo !empty($language['exists']) ? '1' : '0'; ?>" <?php echo !empty($language['active']) ? 'selected' : ''; ?>><?php echo htmlspecialchars($shortCode . ' · ' . (string) $language['title'] . (!empty($language['exists']) ? '' : ' · ' . Text::_('COM_LMZPAGEBUILDER_LANGUAGE_NOT_CREATED')), ENT_QUOTES, 'UTF-8'); ?></option>
                    <?php endforeach; ?>
                    </select>
                    <span class="lmzpb-language-count"><?php echo count(array_filter($this->languageOptions, static fn ($language): bool => !empty($language['exists']))); ?>/<?php echo count($this->languageOptions); ?></span>
                </label>
                <span
                    class="lmzpb-editor-mode<?php echo !empty($this->item['translation_only']) ? ' is-translation' : ' is-source'; ?>"
                    data-lmzpb-editor-mode
                    title="<?php echo htmlspecialchars(!empty($this->item['translation_only']) ? Text::sprintf('COM_LMZPAGEBUILDER_TRANSLATION_MODE_HINT', (string) $this->item['source_language']) : Text::_('COM_LMZPAGEBUILDER_SOURCE_MODE_HINT'), ENT_QUOTES, 'UTF-8'); ?>"
                >
                    <span class="icon-<?php echo !empty($this->item['translation_only']) ? 'language' : 'edit'; ?>" aria-hidden="true"></span>
                    <?php echo Text::_(!empty($this->item['translation_only']) ? 'COM_LMZPAGEBUILDER_TRANSLATION_MODE' : 'COM_LMZPAGEBUILDER_SOURCE_MODE'); ?>
                </span>
            </div>
            <div class="lmzpb-editor-header__actions">
                <div class="lmzpb-version-summary lmzpb-editor-version-summary" data-lmzpb-version data-version-status="<?php echo $versionStatus; ?>">
                    <span class="lmzpb-version-summary__status" data-lmzpb-version-status><?php echo $versionStatusLabel; ?></span>
                    <span class="lmzpb-version-summary__line">
                        <strong><?php echo Text::_('COM_LMZPAGEBUILDER_VERSION_ONLINE'); ?>:</strong>
                        <code data-lmzpb-online-version title="<?php echo htmlspecialchars((string) ($version['online_fingerprint'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>"><?php echo $formatVersion((string) ($version['online_fingerprint'] ?? '')); ?></code>
                    </span>
                    <span class="lmzpb-version-summary__line">
                        <strong><?php echo Text::_('COM_LMZPAGEBUILDER_VERSION_DRAFT'); ?>:</strong>
                        <code data-lmzpb-draft-version title="<?php echo htmlspecialchars((string) ($version['draft_fingerprint'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>"><?php echo $formatVersion((string) ($version['draft_fingerprint'] ?? '')); ?></code>
                    </span>
                </div>
                <span class="lmzpb-editor-state" data-lmzpb-state data-state="loading"><?php echo Text::_('COM_LMZPAGEBUILDER_EDITOR_LOADING'); ?></span>
                <button class="btn btn-outline-secondary" type="button" data-lmzpb-revisions>
                    <span class="icon-history" aria-hidden="true"></span><?php echo Text::_('COM_LMZPAGEBUILDER_REVISIONS'); ?>
                </button>
                <button class="btn btn-outline-warning" type="button" data-lmzpb-discard-draft><span class="icon-undo" aria-hidden="true"></span><?php echo Text::_('COM_LMZPAGEBUILDER_DISCARD_DRAFT'); ?></button>
                <a class="btn btn-outline-secondary" href="<?php echo htmlspecialchars($this->frontendUrl, ENT_QUOTES, 'UTF-8'); ?>" target="_blank" rel="noopener">
                    <span class="icon-eye" aria-hidden="true"></span><?php echo Text::_('COM_LMZPAGEBUILDER_LIVE_PREVIEW'); ?>
                </a>
                <button class="btn btn-success" type="button" data-lmzpb-publish disabled>
                    <span class="icon-upload" aria-hidden="true"></span><?php echo Text::_('COM_LMZPAGEBUILDER_PUBLISH'); ?>
                </button>
            </div>
        </header>

        <?php if (!empty($this->item['translation_only'])) : ?>
            <p class="lmzpb-translation-hint" data-lmzpb-translation-hint>
                <span class="icon-info-circle" aria-hidden="true"></span>
                <?php echo Text::sprintf('COM_LMZPAGEBUILDER_TRANSLATION_MODE_HINT', (string) $this->item['source_language']); ?>
            </p>
        <?php endif; ?>

        <main class="lmzpb-editor-stage">
            <div id="studio-editor" data-project="<?php echo (int) $this->item['id']; ?>" aria-label="<?php echo Text::_('COM_LMZPAGEBUILDER_CANVAS'); ?>"></div>
            <div class="lmzpb-editor-loading" data-lmzpb-loading role="status">
                <span class="lmzpb-spinner" aria-hidden="true"></span>
                <strong><?php echo Text::_('COM_LMZPAGEBUILDER_EDITOR_LOADING'); ?></strong>
                <small><?php echo Text::_('COM_LMZPAGEBUILDER_EDITOR_LOADING_DETAIL'); ?></small>
            </div>
        </main>

        <aside class="lmzpb-revisions" data-lmzpb-revision-panel hidden aria-label="<?php echo Text::_('COM_LMZPAGEBUILDER_REVISIONS'); ?>">
            <header>
                <div><span class="lmzpb-eyebrow"><?php echo Text::_('COM_LMZPAGEBUILDER_HISTORY'); ?></span><h2><?php echo Text::_('COM_LMZPAGEBUILDER_REVISIONS'); ?></h2></div>
                <button class="lmzpb-icon-button" type="button" data-lmzpb-revisions-close aria-label="<?php echo Text::_('JCLOSE'); ?>"><span class="icon-times" aria-hidden="true"></span></button>
            </header>
            <div class="lmzpb-revisions__list" data-lmzpb-revision-list></div>
        </aside>

        <dialog class="lmzpb-action-dialog" data-lmzpb-publish-dialog aria-labelledby="lmzpb-publish-dialog-title">
            <form method="dialog">
                <header>
                    <span class="lmzpb-dialog-icon icon-upload" aria-hidden="true"></span>
                    <div>
                        <span class="lmzpb-eyebrow"><?php echo Text::_('COM_LMZPAGEBUILDER_PUBLISH'); ?></span>
                        <h2 id="lmzpb-publish-dialog-title"><?php echo Text::_('COM_LMZPAGEBUILDER_PUBLISH_DIALOG_TITLE'); ?></h2>
                    </div>
                </header>
                <p><?php echo Text::_('COM_LMZPAGEBUILDER_PUBLISH_DIALOG_TEXT'); ?></p>
                <label class="lmzpb-revision-optin" for="lmzpb-create-revision">
                    <input id="lmzpb-create-revision" type="checkbox" value="1" data-lmzpb-create-revision aria-describedby="lmzpb-create-revision-hint">
                    <span>
                        <strong><?php echo Text::_('COM_LMZPAGEBUILDER_CREATE_REVISION'); ?></strong>
                        <small id="lmzpb-create-revision-hint"><?php echo Text::_('COM_LMZPAGEBUILDER_CREATE_REVISION_HINT'); ?></small>
                    </span>
                </label>
                <div class="lmzpb-revision-note" data-lmzpb-revision-note hidden>
                    <label for="lmzpb-publish-note"><?php echo Text::_('COM_LMZPAGEBUILDER_PUBLISH_NOTE_LABEL'); ?></label>
                    <textarea id="lmzpb-publish-note" data-lmzpb-publish-note maxlength="500" rows="3" disabled></textarea>
                </div>
                <footer>
                    <button class="btn btn-outline-secondary" type="submit" value="cancel"><?php echo Text::_('JCANCEL'); ?></button>
                    <button class="btn btn-success" type="submit" value="publish">
                        <span class="icon-upload" aria-hidden="true"></span><?php echo Text::_('COM_LMZPAGEBUILDER_PUBLISH_CONFIRM'); ?>
                    </button>
                </footer>
            </form>
        </dialog>

        <dialog class="lmzpb-action-dialog" data-lmzpb-rollback-dialog aria-labelledby="lmzpb-rollback-dialog-title">
            <form method="dialog">
                <header>
                    <span class="lmzpb-dialog-icon icon-history" aria-hidden="true"></span>
                    <div>
                        <span class="lmzpb-eyebrow"><?php echo Text::_('COM_LMZPAGEBUILDER_REVISIONS'); ?></span>
                        <h2 id="lmzpb-rollback-dialog-title"><?php echo Text::_('COM_LMZPAGEBUILDER_ROLLBACK_DIALOG_TITLE'); ?></h2>
                    </div>
                </header>
                <p><?php echo Text::_('COM_LMZPAGEBUILDER_ROLLBACK_DIALOG_TEXT'); ?></p>
                <strong class="lmzpb-dialog-target" data-lmzpb-rollback-target></strong>
                <footer>
                    <button class="btn btn-outline-secondary" type="submit" value="cancel"><?php echo Text::_('JCANCEL'); ?></button>
                    <button class="btn btn-danger" type="submit" value="rollback">
                        <span class="icon-history" aria-hidden="true"></span><?php echo Text::_('COM_LMZPAGEBUILDER_ROLLBACK_CONFIRM_ACTION'); ?>
                    </button>
                </footer>
            </form>
        </dialog>

        <div class="lmzpb-toast" data-lmzpb-toast hidden role="status"></div>
        <form hidden><?php echo HTMLHelper::_('form.token'); ?></form>
    </div>
<?php endif; ?>
