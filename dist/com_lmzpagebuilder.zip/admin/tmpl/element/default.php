<?php

defined('_JEXEC') or die;

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;

$backUrl = Route::_('index.php?option=com_lmzpagebuilder&view=projects#gespeicherte-elemente');
?>

<?php if ($this->error !== null) : ?>
    <main class="lmzpb-editor-error" role="alert">
        <span class="icon-warning" aria-hidden="true"></span>
        <h1><?php echo Text::_('COM_LMZPAGEBUILDER_EDITOR_UNAVAILABLE'); ?></h1>
        <p><?php echo htmlspecialchars($this->error, ENT_QUOTES, 'UTF-8'); ?></p>
        <a class="btn btn-primary" href="<?php echo $backUrl; ?>"><?php echo Text::_('JBACK'); ?></a>
    </main>
<?php else : ?>
    <div class="lmzpb-editor-page" data-lmzpb-editor data-lmzpb-editor-type="element">
        <header class="lmzpb-editor-header">
            <div class="lmzpb-editor-header__identity">
                <a class="lmzpb-icon-button" href="<?php echo $backUrl; ?>" data-lmzpb-back aria-label="<?php echo Text::_('JBACK'); ?>">
                    <span class="icon-arrow-left" aria-hidden="true"></span>
                </a>
                <div>
                    <span class="lmzpb-eyebrow">
                        <?php echo Text::_('COM_LMZPAGEBUILDER_ELEMENT_EDITOR'); ?>
                        &middot; <?php echo htmlspecialchars((string) $this->element['element_key'], ENT_QUOTES, 'UTF-8'); ?>
                    </span>
                    <h1><?php echo htmlspecialchars((string) $this->item['title'], ENT_QUOTES, 'UTF-8'); ?></h1>
                </div>
                <label class="lmzpb-language-select" title="<?php echo Text::_('COM_LMZPAGEBUILDER_LANGUAGES'); ?>">
                    <span class="visually-hidden"><?php echo Text::_('COM_LMZPAGEBUILDER_LANGUAGES'); ?></span>
                    <select data-lmzpb-language-select>
                    <?php foreach ($this->languageOptions as $language) : ?>
                        <?php $shortCode = strtoupper(strtok((string) $language['code'], '-')); ?>
                        <option value="<?php echo htmlspecialchars((string) ($language['editor_url'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>" data-language-code="<?php echo htmlspecialchars((string) $language['code'], ENT_QUOTES, 'UTF-8'); ?>" data-language-exists="<?php echo !empty($language['exists']) ? '1' : '0'; ?>" <?php echo !empty($language['active']) ? 'selected' : ''; ?>><?php echo htmlspecialchars($shortCode . ' · ' . (string) $language['title'] . (!empty($language['exists']) ? '' : ' · ' . Text::_('COM_LMZPAGEBUILDER_LANGUAGE_NOT_CREATED')), ENT_QUOTES, 'UTF-8'); ?></option>
                    <?php endforeach; ?>
                    </select>
                    <span class="lmzpb-language-count"><?php echo count(array_filter($this->languageOptions, static fn ($language): bool => !empty($language['exists']))); ?>/<?php echo count($this->languageOptions); ?></span>
                </label>
            </div>
            <div class="lmzpb-editor-header__actions">
                <span class="lmzpb-editor-state" data-lmzpb-state data-state="loading"><?php echo Text::_('COM_LMZPAGEBUILDER_EDITOR_LOADING'); ?></span>
                <button class="btn btn-outline-secondary" type="button" data-lmzpb-usages>
                    <span class="icon-link" aria-hidden="true"></span><?php echo Text::_('COM_LMZPAGEBUILDER_USAGES'); ?>
                    <span class="badge bg-secondary ms-1"><?php echo (int) $this->element['usage_count']; ?></span>
                </button>
                <button class="btn btn-success" type="button" data-lmzpb-publish disabled>
                    <span class="icon-upload" aria-hidden="true"></span><?php echo Text::_('COM_LMZPAGEBUILDER_PUBLISH'); ?>
                </button>
            </div>
        </header>

        <main class="lmzpb-editor-stage">
            <div id="studio-editor" data-project="<?php echo (int) $this->item['id']; ?>" aria-label="<?php echo Text::_('COM_LMZPAGEBUILDER_ELEMENT_CANVAS'); ?>"></div>
            <div class="lmzpb-editor-loading" data-lmzpb-loading role="status">
                <span class="lmzpb-spinner" aria-hidden="true"></span>
                <strong><?php echo Text::_('COM_LMZPAGEBUILDER_EDITOR_LOADING'); ?></strong>
                <small><?php echo Text::_('COM_LMZPAGEBUILDER_EDITOR_LOADING_DETAIL'); ?></small>
            </div>
        </main>

        <aside class="lmzpb-revisions" data-lmzpb-usage-panel hidden aria-label="<?php echo Text::_('COM_LMZPAGEBUILDER_USAGES'); ?>">
            <header>
                <div>
                    <span class="lmzpb-eyebrow"><?php echo Text::_('COM_LMZPAGEBUILDER_GLOBAL_ELEMENTS'); ?></span>
                    <h2><?php echo Text::_('COM_LMZPAGEBUILDER_USAGES'); ?></h2>
                </div>
                <button class="lmzpb-icon-button" type="button" data-lmzpb-usages-close aria-label="<?php echo Text::_('JCLOSE'); ?>">
                    <span class="icon-times" aria-hidden="true"></span>
                </button>
            </header>
            <p class="lmzpb-panel-intro"><?php echo Text::_('COM_LMZPAGEBUILDER_USAGES_INTRO'); ?></p>
            <div class="lmzpb-revisions__list" data-lmzpb-usage-list></div>
        </aside>

        <dialog class="lmzpb-action-dialog" data-lmzpb-publish-dialog aria-labelledby="lmzpb-element-publish-dialog-title">
            <form method="dialog">
                <header>
                    <span class="lmzpb-dialog-icon icon-upload" aria-hidden="true"></span>
                    <div>
                        <span class="lmzpb-eyebrow"><?php echo Text::_('COM_LMZPAGEBUILDER_PUBLISH'); ?></span>
                        <h2 id="lmzpb-element-publish-dialog-title"><?php echo Text::_('COM_LMZPAGEBUILDER_ELEMENT_PUBLISH_DIALOG_TITLE'); ?></h2>
                    </div>
                </header>
                <p><?php echo Text::_('COM_LMZPAGEBUILDER_ELEMENT_PUBLISH_DIALOG_TEXT'); ?></p>
                <footer>
                    <button class="btn btn-outline-secondary" type="submit" value="cancel"><?php echo Text::_('JCANCEL'); ?></button>
                    <button class="btn btn-success" type="submit" value="publish">
                        <span class="icon-upload" aria-hidden="true"></span><?php echo Text::_('COM_LMZPAGEBUILDER_PUBLISH_CONFIRM'); ?>
                    </button>
                </footer>
            </form>
        </dialog>

        <div class="lmzpb-toast" data-lmzpb-toast hidden role="status"></div>
        <form hidden><?php echo HTMLHelper::_('form.token'); ?></form>
    </div>
<?php endif; ?>
