<?php

/**
 * Template Settings – overview hub. The editable form has been split into the
 * separate "Kopfzeile / Navigation" (layout=header) and "Fusszeile"
 * (layout=footer) sub-pages. This landing page keeps the global, non-form
 * pieces: the sub-navigation, quick entry cards into the two edit pages, the
 * multilingual GrapesJS shared-element regions and the revision history.
 */

defined('_JEXEC') or die;

use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;

/** @var \LMZ\Component\Lmzpagebuilder\Administrator\View\Templatesettings\HtmlView $this */
$escape = static fn (mixed $value): string => htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
$stateLabel = static fn (string $state): string => match ($state) {
    'published' => Text::_('COM_LMZPAGEBUILDER_TEMPLATE_REGION_PUBLISHED'),
    'draft' => Text::_('COM_LMZPAGEBUILDER_TEMPLATE_REGION_DRAFT'),
    default => Text::_('COM_LMZPAGEBUILDER_TEMPLATE_REGION_MISSING'),
};
?>

<div class="lmzpb-admin lmzpb-template-settings lmzpb-template-settings--overview" data-lmzpb-template-settings>
    <?php require __DIR__ . '/_head.php'; ?>

    <section class="lmzpb-settings-entry" aria-label="<?php echo $escape(Text::_('COM_LMZPAGEBUILDER_TEMPLATE_SETTINGS')); ?>">
        <a class="lmzpb-settings-entry__card" href="<?php echo Route::_('index.php?option=com_lmzpagebuilder&view=templatesettings&layout=header'); ?>">
            <span class="icon-menu" aria-hidden="true"></span>
            <span class="lmzpb-settings-entry__body">
                <strong><?php echo Text::_('COM_LMZPAGEBUILDER_TEMPLATE_SETTINGS_HEADER'); ?></strong>
                <small><?php echo Text::_('COM_LMZPAGEBUILDER_TEMPLATE_SETTINGS_HEADER_DESC'); ?></small>
            </span>
        </a>
        <a class="lmzpb-settings-entry__card" href="<?php echo Route::_('index.php?option=com_lmzpagebuilder&view=templatesettings&layout=footer'); ?>">
            <span class="icon-grid-2" aria-hidden="true"></span>
            <span class="lmzpb-settings-entry__body">
                <strong><?php echo Text::_('COM_LMZPAGEBUILDER_TEMPLATE_SETTINGS_FOOTER'); ?></strong>
                <small><?php echo Text::_('COM_LMZPAGEBUILDER_TEMPLATE_SETTINGS_FOOTER_DESC'); ?></small>
            </span>
        </a>
    </section>

    <section class="lmzpb-template-regions" aria-labelledby="lmzpb-template-regions-title">
        <header>
            <span class="lmzpb-eyebrow">GrapesJS &middot; Shared Elements</span>
            <h2 id="lmzpb-template-regions-title"><?php echo Text::_('COM_LMZPAGEBUILDER_TEMPLATE_REGIONS'); ?></h2>
            <p><?php echo Text::_('COM_LMZPAGEBUILDER_TEMPLATE_REGIONS_DESC'); ?></p>
        </header>

        <div class="lmzpb-template-regions__grid">
            <?php foreach ($this->regions as $regionKey => $region) : ?>
                <article class="lmzpb-template-region-card">
                    <header>
                        <div>
                            <span class="lmzpb-template-region-card__key"><?php echo $escape($region['key']); ?></span>
                            <h3><?php echo $regionKey === 'navigation' ? Text::_('COM_LMZPAGEBUILDER_TEMPLATE_NAVIGATION') : Text::_('COM_LMZPAGEBUILDER_TEMPLATE_FOOTER'); ?></h3>
                        </div>
                        <span class="icon-<?php echo $regionKey === 'navigation' ? 'menu' : 'grid-2'; ?>" aria-hidden="true"></span>
                    </header>

                    <?php if (!empty($region['invalid_kind'])) : ?>
                        <div class="alert alert-danger"><?php echo Text::_('COM_LMZPAGEBUILDER_TEMPLATE_REGION_KEY_CONFLICT'); ?></div>
                    <?php endif; ?>

                    <div class="lmzpb-template-region-card__slots">
                        <?php foreach ($region['slots'] as $slot) : ?>
                            <code><?php echo $escape($slot); ?></code>
                        <?php endforeach; ?>
                    </div>

                    <div class="lmzpb-template-region-card__languages">
                        <?php foreach ($region['languages'] as $language) : ?>
                            <div class="lmzpb-template-language" data-state="<?php echo $escape($language['state']); ?>">
                                <div>
                                    <strong><?php echo $escape($language['title']); ?></strong>
                                    <small><?php echo $escape($language['code']); ?> &middot; <?php echo $escape($stateLabel($language['state'])); ?></small>
                                </div>
                                <?php if ($language['editor_url'] !== '') : ?>
                                    <a class="btn btn-sm btn-outline-primary" href="<?php echo Route::_($language['editor_url']); ?>">
                                        <span class="icon-edit" aria-hidden="true"></span><?php echo Text::_('COM_LMZPAGEBUILDER_TEMPLATE_REGION_EDIT'); ?>
                                    </a>
                                <?php else : ?>
                                    <form action="<?php echo Route::_('index.php?option=com_lmzpagebuilder&task=templatesettings.ensureRegion'); ?>" method="post">
                                        <input type="hidden" name="region" value="<?php echo $escape($regionKey); ?>">
                                        <input type="hidden" name="language" value="<?php echo $escape($language['code']); ?>">
                                        <input type="hidden" name="task" value="templatesettings.ensureRegion">
                                        <?php echo \Joomla\CMS\HTML\HTMLHelper::_('form.token'); ?>
                                        <button class="btn btn-sm btn-outline-primary" type="submit" <?php echo !$this->canEdit || !empty($region['invalid_kind']) ? 'disabled' : ''; ?>>
                                            <span class="icon-plus" aria-hidden="true"></span><?php echo Text::_('COM_LMZPAGEBUILDER_TEMPLATE_REGION_CREATE'); ?>
                                        </button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    </section>

    <?php if ($this->revisions !== []) : ?>
        <section class="lmzpb-template-revisions" aria-labelledby="lmzpb-template-revisions-title">
            <header>
                <h2 id="lmzpb-template-revisions-title"><?php echo Text::_('COM_LMZPAGEBUILDER_TEMPLATE_REVISIONS'); ?></h2>
                <p><?php echo Text::_('COM_LMZPAGEBUILDER_TEMPLATE_REVISIONS_DESC'); ?></p>
            </header>
            <ol>
                <?php foreach ($this->revisions as $revision) : ?>
                    <li>
                        <strong>v<?php echo (int) $revision['settings_version']; ?></strong>
                        <span><?php echo $escape($revision['created']); ?></span>
                        <code><?php echo $escape(substr((string) $revision['snapshot_hash'], 0, 12)); ?></code>
                        <?php if ((string) $revision['note'] !== '') : ?><p><?php echo $escape($revision['note']); ?></p><?php endif; ?>
                    </li>
                <?php endforeach; ?>
            </ol>
        </section>
    <?php endif; ?>
</div>
