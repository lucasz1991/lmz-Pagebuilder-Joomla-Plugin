<?php

/**
 * Renders one Font Awesome icon input wired to the shared icon picker
 * (Agent B, media/com_lmzpagebuilder/js/rt-icon-picker.js).
 *
 * Contract used here (matches the picker's trigger/preview API):
 *   - a normal text input carrying the FA class string (id + name),
 *   - a trigger button with data-rt-icon-picker + data-rt-icon-target="#id"
 *     that opens the picker and writes the chosen class back into the input
 *     (dispatching input/change so the dirty-state watcher reacts),
 *   - a live-preview host with data-rt-icon-preview="#id" the picker fills.
 *
 * Expects in scope before include:
 *   $iconFieldId, $iconFieldName, $iconFieldValue,
 *   $iconFieldLabel, $iconFieldHint, $iconFieldPlaceholder
 */

defined('_JEXEC') or die;

use Joomla\CMS\Language\Text;

$escape = static fn (mixed $value): string => htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
$previewClass = trim((string) ($iconFieldValue ?? ''));
?>
<label class="lmzpb-settings-field lmzpb-icon-field" for="<?php echo $escape($iconFieldId); ?>">
    <span><?php echo $escape($iconFieldLabel); ?></span>
    <span class="lmzpb-icon-field__control">
        <span class="lmzpb-icon-field__preview" data-rt-icon-preview="#<?php echo $escape($iconFieldId); ?>" aria-hidden="true">
            <?php if ($previewClass !== '') : ?><i class="<?php echo $escape($previewClass); ?>"></i><?php endif; ?>
        </span>
        <input
            type="text"
            id="<?php echo $escape($iconFieldId); ?>"
            name="<?php echo $escape($iconFieldName); ?>"
            value="<?php echo $escape($iconFieldValue ?? ''); ?>"
            maxlength="64"
            autocomplete="off"
            spellcheck="false"
            placeholder="<?php echo $escape($iconFieldPlaceholder ?? 'fa-solid fa-star'); ?>"
        >
        <button
            type="button"
            class="btn btn-outline-primary lmzpb-icon-field__btn"
            data-rt-icon-picker
            data-rt-icon-target="#<?php echo $escape($iconFieldId); ?>"
        >
            <span class="icon-list-2" aria-hidden="true"></span><?php echo Text::_('COM_LMZPAGEBUILDER_TEMPLATE_ICON_CHOOSE'); ?>
        </button>
    </span>
    <?php if (!empty($iconFieldHint)) : ?>
        <small><?php echo $escape($iconFieldHint); ?></small>
    <?php endif; ?>
</label>
