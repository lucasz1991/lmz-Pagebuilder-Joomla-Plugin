<?php

/**
 * Template Settings – sub-page "Kopfzeile / Navigation".
 * Holds the shared brand/contact source, the logos and the navigation
 * settings including the hotline icon. Saves only the header section; the
 * footer values stay untouched (server-side merge in TemplateSettingsService).
 */

defined('_JEXEC') or die;

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;

/** @var \LMZ\Component\Lmzpagebuilder\Administrator\View\Templatesettings\HtmlView $this */
$settings = $this->settingsDocument['settings'];
$logos = $settings['logos'];
$navigation = $settings['navigation'];
$disabled = !$this->canEdit || empty($this->settingsDocument['schema_ready']);
$escape = static fn (mixed $value): string => htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
?>

<div class="lmzpb-admin lmzpb-template-settings lmzpb-template-settings--header" data-lmzpb-template-settings>
    <?php require __DIR__ . '/_head.php'; ?>

    <form
        id="adminForm"
        class="lmzpb-template-settings__form"
        action="<?php echo Route::_('index.php?option=com_lmzpagebuilder&task=templatesettings.save'); ?>"
        method="post"
        data-lmzpb-settings-form
    >
        <fieldset class="lmzpb-settings-card lmzpb-settings-card--contact" <?php echo $disabled ? 'disabled' : ''; ?>>
            <legend>
                <span class="icon-address" aria-hidden="true"></span>
                <span><?php echo Text::_('COM_LMZPAGEBUILDER_TEMPLATE_CONTACT_SOURCE'); ?><small><?php echo Text::_('COM_LMZPAGEBUILDER_TEMPLATE_CONTACT_SOURCE_DESC'); ?></small></span>
            </legend>

            <div class="lmzpb-contact-source">
                <label class="lmzpb-settings-field">
                    <span><?php echo Text::_('COM_LMZPAGEBUILDER_TEMPLATE_CONTACT_SELECT'); ?></span>
                    <select name="settings[contact_id]" data-lmzpb-contact-select>
                        <option value="0"><?php echo Text::_('COM_LMZPAGEBUILDER_TEMPLATE_CONTACT_NONE'); ?></option>
                        <?php foreach ($this->contacts as $contact) : ?>
                            <option
                                value="<?php echo (int) $contact['id']; ?>"
                                data-phone="<?php echo $escape($contact['telephone']); ?>"
                                data-email="<?php echo $escape($contact['email']); ?>"
                                data-address="<?php echo $escape($contact['address_complete']); ?>"
                                <?php echo (int) $settings['contact_id'] === (int) $contact['id'] ? 'selected' : ''; ?>
                            ><?php echo $escape($contact['name']); ?> (#<?php echo (int) $contact['id']; ?>)</option>
                        <?php endforeach; ?>
                    </select>
                </label>
                <div class="lmzpb-contact-source__status" data-lmzpb-contact-status aria-live="polite">
                    <span class="icon-info-circle" aria-hidden="true"></span>
                    <p><?php echo Text::_('COM_LMZPAGEBUILDER_TEMPLATE_CONTACT_FALLBACK_INFO'); ?></p>
                </div>
            </div>
        </fieldset>

        <fieldset class="lmzpb-settings-card lmzpb-settings-card--logos" <?php echo $disabled ? 'disabled' : ''; ?>>
            <legend>
                <span class="icon-image" aria-hidden="true"></span>
                <span><?php echo Text::_('COM_LMZPAGEBUILDER_TEMPLATE_LOGOS'); ?><small><?php echo Text::_('COM_LMZPAGEBUILDER_TEMPLATE_LOGOS_DESC'); ?></small></span>
            </legend>

            <div class="lmzpb-logo-grid">
                <?php foreach ([
                    'favicon' => 'COM_LMZPAGEBUILDER_TEMPLATE_FAVICON',
                    'mark' => 'COM_LMZPAGEBUILDER_TEMPLATE_LOGO_MARK',
                    'navigation_wordmark' => 'COM_LMZPAGEBUILDER_TEMPLATE_NAV_WORDMARK',
                    'footer_wordmark' => 'COM_LMZPAGEBUILDER_TEMPLATE_FOOTER_WORDMARK',
                ] as $field => $label) : ?>
                    <label class="lmzpb-logo-field">
                        <span><?php echo Text::_($label); ?></span>
                        <span class="lmzpb-logo-field__preview" data-lmzpb-logo-preview>
                            <img src="<?php echo $escape($logos[$field]); ?>" alt="" loading="lazy">
                        </span>
                        <input
                            type="text"
                            name="settings[logos][<?php echo $field; ?>]"
                            value="<?php echo $escape($logos[$field]); ?>"
                            maxlength="500"
                            required
                            inputmode="url"
                            data-lmzpb-logo-input
                        >
                    </label>
                <?php endforeach; ?>
            </div>

            <label class="lmzpb-settings-field">
                <span><?php echo Text::_('COM_LMZPAGEBUILDER_TEMPLATE_LOGO_ALT'); ?></span>
                <input type="text" name="settings[logos][alt_text]" value="<?php echo $escape($logos['alt_text']); ?>" maxlength="160" required>
                <small><?php echo Text::_('COM_LMZPAGEBUILDER_TEMPLATE_LOGO_ALT_DESC'); ?></small>
            </label>
        </fieldset>

        <fieldset class="lmzpb-settings-card" <?php echo $disabled ? 'disabled' : ''; ?>>
            <legend>
                <span class="icon-menu" aria-hidden="true"></span>
                <span><?php echo Text::_('COM_LMZPAGEBUILDER_TEMPLATE_NAVIGATION'); ?><small><?php echo Text::_('COM_LMZPAGEBUILDER_TEMPLATE_NAVIGATION_DESC'); ?></small></span>
            </legend>

            <div class="lmzpb-settings-grid">
                <label class="lmzpb-settings-field">
                    <span><?php echo Text::_('COM_LMZPAGEBUILDER_TEMPLATE_MENU_TYPE'); ?></span>
                    <select name="settings[navigation][menu_type]" required>
                        <?php foreach ($this->menuTypes as $menuType) : ?>
                            <option value="<?php echo $escape($menuType['value']); ?>" <?php echo $menuType['value'] === $navigation['menu_type'] ? 'selected' : ''; ?>>
                                <?php echo $escape($menuType['text']); ?> (<?php echo $escape($menuType['value']); ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </label>
                <label class="lmzpb-settings-field">
                    <span><?php echo Text::_('COM_LMZPAGEBUILDER_TEMPLATE_HOTLINE'); ?></span>
                    <input type="tel" name="settings[navigation][hotline]" value="<?php echo $escape($navigation['hotline']); ?>" maxlength="40" required>
                </label>
                <?php
                $iconFieldId = 'lmzpb-icon-nav-hotline';
                $iconFieldName = 'settings[navigation][hotline_icon]';
                $iconFieldValue = $navigation['hotline_icon'] ?? '';
                $iconFieldLabel = Text::_('COM_LMZPAGEBUILDER_TEMPLATE_HOTLINE_ICON');
                $iconFieldHint = Text::_('COM_LMZPAGEBUILDER_TEMPLATE_ICON_HINT');
                $iconFieldPlaceholder = 'fa-solid fa-phone';
                require __DIR__ . '/_iconfield.php';
                ?>
                <label class="lmzpb-settings-switch">
                    <input type="hidden" name="settings[navigation][hotline_visible]" value="0">
                    <input type="checkbox" name="settings[navigation][hotline_visible]" value="1" <?php echo $navigation['hotline_visible'] ? 'checked' : ''; ?>>
                    <span><?php echo Text::_('COM_LMZPAGEBUILDER_TEMPLATE_HOTLINE_VISIBLE'); ?></span>
                </label>
                <label class="lmzpb-settings-switch">
                    <input type="hidden" name="settings[navigation][builder_enabled]" value="0">
                    <input type="checkbox" name="settings[navigation][builder_enabled]" value="1" <?php echo $navigation['builder_enabled'] ? 'checked' : ''; ?>>
                    <span><?php echo Text::_('COM_LMZPAGEBUILDER_TEMPLATE_NAV_BUILDER_ENABLED'); ?></span>
                </label>
            </div>

            <div class="lmzpb-colour-grid">
                <?php foreach ([
                    'background' => 'COM_LMZPAGEBUILDER_TEMPLATE_COLOUR_BACKGROUND',
                    'text' => 'COM_LMZPAGEBUILDER_TEMPLATE_COLOUR_TEXT',
                    'accent' => 'COM_LMZPAGEBUILDER_TEMPLATE_COLOUR_ACCENT',
                ] as $field => $label) : ?>
                    <label class="lmzpb-colour-field">
                        <span><?php echo Text::_($label); ?></span>
                        <input type="color" name="settings[navigation][<?php echo $field; ?>]" value="<?php echo $escape($navigation[$field]); ?>">
                        <output><?php echo $escape($navigation[$field]); ?></output>
                    </label>
                <?php endforeach; ?>
            </div>
        </fieldset>

        <section class="lmzpb-settings-savebar" aria-label="<?php echo Text::_('JSAVE'); ?>">
            <label>
                <span><?php echo Text::_('COM_LMZPAGEBUILDER_TEMPLATE_REVISION_NOTE'); ?></span>
                <input type="text" name="revision_note" maxlength="500" placeholder="<?php echo $escape(Text::_('COM_LMZPAGEBUILDER_TEMPLATE_REVISION_NOTE_HINT')); ?>">
            </label>
            <span data-lmzpb-dirty-state aria-live="polite"><?php echo Text::_('COM_LMZPAGEBUILDER_TEMPLATE_SETTINGS_UNCHANGED'); ?></span>
            <button class="btn btn-primary" type="submit" <?php echo $disabled ? 'disabled' : ''; ?>>
                <span class="icon-save" aria-hidden="true"></span><?php echo Text::_('JSAVE'); ?>
            </button>
        </section>

        <input type="hidden" name="section" value="header">
        <input type="hidden" name="expected_hash" value="<?php echo $escape($this->settingsDocument['hash']); ?>">
        <input type="hidden" name="task" value="templatesettings.save">
        <?php echo HTMLHelper::_('form.token'); ?>
    </form>
</div>
