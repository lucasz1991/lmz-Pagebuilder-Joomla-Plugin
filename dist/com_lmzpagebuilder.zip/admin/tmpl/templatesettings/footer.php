<?php

/**
 * Template Settings – sub-page "Fusszeile".
 * Holds the footer company, contact lines (each with its own Font Awesome
 * icon), the footer colour system and the footer builder toggle. Saves only
 * the footer section; navigation, logos and contact source stay untouched
 * (server-side merge in TemplateSettingsService).
 */

defined('_JEXEC') or die;

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;

/** @var \LMZ\Component\Lmzpagebuilder\Administrator\View\Templatesettings\HtmlView $this */
$settings = $this->settingsDocument['settings'];
$footer = $settings['footer'];
$disabled = !$this->canEdit || empty($this->settingsDocument['schema_ready']);
$escape = static fn (mixed $value): string => htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
?>

<div class="lmzpb-admin lmzpb-template-settings lmzpb-template-settings--footer" data-lmzpb-template-settings>
    <?php require __DIR__ . '/_head.php'; ?>

    <form
        id="adminForm"
        class="lmzpb-template-settings__form"
        action="<?php echo Route::_('index.php?option=com_lmzpagebuilder&task=templatesettings.save'); ?>"
        method="post"
        data-lmzpb-settings-form
    >
        <fieldset class="lmzpb-settings-card" <?php echo $disabled ? 'disabled' : ''; ?>>
            <legend>
                <span class="icon-grid-2" aria-hidden="true"></span>
                <span><?php echo Text::_('COM_LMZPAGEBUILDER_TEMPLATE_FOOTER'); ?><small><?php echo Text::_('COM_LMZPAGEBUILDER_TEMPLATE_FOOTER_DESC'); ?></small></span>
            </legend>

            <div class="lmzpb-contact-source__status" role="note">
                <span class="icon-info-circle" aria-hidden="true"></span>
                <p><?php echo Text::_('COM_LMZPAGEBUILDER_TEMPLATE_FOOTER_CONTACT_HINT'); ?></p>
            </div>

            <div class="lmzpb-settings-grid">
                <label class="lmzpb-settings-field">
                    <span><?php echo Text::_('COM_LMZPAGEBUILDER_TEMPLATE_COMPANY'); ?></span>
                    <input type="text" name="settings[footer][company]" value="<?php echo $escape($footer['company']); ?>" maxlength="190" required>
                </label>
                <label class="lmzpb-settings-field">
                    <span><?php echo Text::_('COM_LMZPAGEBUILDER_TEMPLATE_EMAIL'); ?></span>
                    <input type="email" name="settings[footer][email]" value="<?php echo $escape($footer['email']); ?>" maxlength="254" required>
                </label>
                <label class="lmzpb-settings-field lmzpb-settings-field--wide">
                    <span><?php echo Text::_('COM_LMZPAGEBUILDER_TEMPLATE_ADDRESS'); ?></span>
                    <textarea name="settings[footer][address]" rows="3" maxlength="500" required><?php echo $escape($footer['address']); ?></textarea>
                </label>
                <label class="lmzpb-settings-switch">
                    <input type="hidden" name="settings[footer][builder_enabled]" value="0">
                    <input type="checkbox" name="settings[footer][builder_enabled]" value="1" <?php echo $footer['builder_enabled'] ? 'checked' : ''; ?>>
                    <span><?php echo Text::_('COM_LMZPAGEBUILDER_TEMPLATE_FOOTER_BUILDER_ENABLED'); ?></span>
                </label>
            </div>
        </fieldset>

        <fieldset class="lmzpb-settings-card lmzpb-settings-card--icons" <?php echo $disabled ? 'disabled' : ''; ?>>
            <legend>
                <span class="icon-star" aria-hidden="true"></span>
                <span><?php echo Text::_('COM_LMZPAGEBUILDER_TEMPLATE_FOOTER_ICONS'); ?><small><?php echo Text::_('COM_LMZPAGEBUILDER_TEMPLATE_FOOTER_ICONS_DESC'); ?></small></span>
            </legend>

            <div class="lmzpb-settings-grid">
                <?php foreach ([
                    ['id' => 'lmzpb-icon-footer-email', 'name' => 'settings[footer][email_icon]', 'value' => $footer['email_icon'] ?? '', 'label' => 'COM_LMZPAGEBUILDER_TEMPLATE_EMAIL_ICON', 'placeholder' => 'fa-solid fa-envelope'],
                    ['id' => 'lmzpb-icon-footer-address', 'name' => 'settings[footer][address_icon]', 'value' => $footer['address_icon'] ?? '', 'label' => 'COM_LMZPAGEBUILDER_TEMPLATE_ADDRESS_ICON', 'placeholder' => 'fa-solid fa-location-dot'],
                ] as $iconField) : ?>
                    <?php
                    $iconFieldId = $iconField['id'];
                    $iconFieldName = $iconField['name'];
                    $iconFieldValue = $iconField['value'];
                    $iconFieldLabel = Text::_($iconField['label']);
                    $iconFieldHint = Text::_('COM_LMZPAGEBUILDER_TEMPLATE_ICON_HINT');
                    $iconFieldPlaceholder = $iconField['placeholder'];
                    require __DIR__ . '/_iconfield.php';
                    ?>
                <?php endforeach; ?>
            </div>
        </fieldset>

        <fieldset class="lmzpb-settings-card" <?php echo $disabled ? 'disabled' : ''; ?>>
            <legend>
                <span class="icon-palette" aria-hidden="true"></span>
                <span><?php echo Text::_('COM_LMZPAGEBUILDER_TEMPLATE_COLOUR_ACCENT'); ?></span>
            </legend>
            <div class="lmzpb-colour-grid">
                <?php foreach ([
                    'background' => 'COM_LMZPAGEBUILDER_TEMPLATE_COLOUR_BACKGROUND',
                    'text' => 'COM_LMZPAGEBUILDER_TEMPLATE_COLOUR_TEXT',
                    'accent' => 'COM_LMZPAGEBUILDER_TEMPLATE_COLOUR_ACCENT',
                ] as $field => $label) : ?>
                    <label class="lmzpb-colour-field">
                        <span><?php echo Text::_($label); ?></span>
                        <input type="color" name="settings[footer][<?php echo $field; ?>]" value="<?php echo $escape($footer[$field]); ?>">
                        <output><?php echo $escape($footer[$field]); ?></output>
                    </label>
                <?php endforeach; ?>
            </div>
        </fieldset>

        <section class="lmzpb-settings-savebar" aria-label="<?php echo Text::_('JSAVE'); ?>">
            <label>
                <span><?php echo Text::_('COM_LMZPAGEBUILDER_TEMPLATE_REVISION_NOTE'); ?></span>
                <input type="text" name="revision_note" maxlength="500" placeholder="<?php echo $escape(Text::_('COM_LMZPAGEBUILDER_TEMPLATE_REVISION_NOTE_HINT')); ?>">
            </label>
            <span data-lmzpb-dirty-state aria-live="polite"><?php echo Text::_('COM_LMZPAGEBUILDER_TEMPLATE_SETTINGS_UNCHANGED'); ?></span>
            <button class="btn btn-primary" type="submit" <?php echo $disabled ? 'disabled' : ''; ?>>
                <span class="icon-save" aria-hidden="true"></span><?php echo Text::_('JSAVE'); ?>
            </button>
        </section>

        <input type="hidden" name="section" value="footer">
        <input type="hidden" name="expected_hash" value="<?php echo $escape($this->settingsDocument['hash']); ?>">
        <input type="hidden" name="task" value="templatesettings.save">
        <?php echo HTMLHelper::_('form.token'); ?>
    </form>
</div>
