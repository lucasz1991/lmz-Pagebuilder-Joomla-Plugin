<?php

/**
 * Shared header for every Template-Settings sub-page: hero, sub-navigation
 * (real links to the separate Kopfzeile / Fusszeile pages) and the schema
 * warning. Rendered inside the view scope ($this = HtmlView). Underscore
 * prefix keeps it out of Joomla's layout discovery.
 */

defined('_JEXEC') or die;

use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;

/** @var \LMZ\Component\Lmzpagebuilder\Administrator\View\Templatesettings\HtmlView $this */
$escape = static fn (mixed $value): string => htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
$active = $this->activeLayout;

$tabs = [
    'default' => [
        'label' => Text::_('COM_LMZPAGEBUILDER_TEMPLATE_NAV_OVERVIEW'),
        'link' => 'index.php?option=com_lmzpagebuilder&view=templatesettings',
    ],
    'header' => [
        'label' => Text::_('COM_LMZPAGEBUILDER_TEMPLATE_SETTINGS_HEADER'),
        'link' => 'index.php?option=com_lmzpagebuilder&view=templatesettings&layout=header',
    ],
    'footer' => [
        'label' => Text::_('COM_LMZPAGEBUILDER_TEMPLATE_SETTINGS_FOOTER'),
        'link' => 'index.php?option=com_lmzpagebuilder&view=templatesettings&layout=footer',
    ],
];
?>
<section class="lmzpb-template-settings__hero">
    <div>
        <span class="lmzpb-eyebrow">LMZ Page Builder &middot; Template shell</span>
        <h1><?php echo Text::_('COM_LMZPAGEBUILDER_TEMPLATE_SETTINGS_TITLE'); ?></h1>
        <p><?php echo Text::_('COM_LMZPAGEBUILDER_TEMPLATE_SETTINGS_INTRO'); ?></p>
    </div>
    <dl class="lmzpb-template-settings__meta">
        <div>
            <dt><?php echo Text::_('COM_LMZPAGEBUILDER_TEMPLATE_SETTINGS_VERSION'); ?></dt>
            <dd><?php echo (int) $this->settingsDocument['version']; ?></dd>
        </div>
        <div>
            <dt><?php echo Text::_('JGLOBAL_FIELD_MODIFIED_LABEL'); ?></dt>
            <dd><?php echo $this->settingsDocument['modified'] !== '' ? $escape($this->settingsDocument['modified']) : Text::_('COM_LMZPAGEBUILDER_TEMPLATE_SETTINGS_DEFAULTS'); ?></dd>
        </div>
    </dl>
</section>

<nav class="lmzpb-settings-tabs" aria-label="<?php echo $escape(Text::_('COM_LMZPAGEBUILDER_TEMPLATE_SETTINGS')); ?>">
    <?php foreach ($tabs as $key => $tab) : ?>
        <a
            class="lmzpb-settings-tab<?php echo $active === $key ? ' is-active' : ''; ?>"
            href="<?php echo Route::_($tab['link']); ?>"
            <?php echo $active === $key ? 'aria-current="page"' : ''; ?>
        ><?php echo $escape($tab['label']); ?></a>
    <?php endforeach; ?>
</nav>

<?php if (empty($this->settingsDocument['schema_ready'])) : ?>
    <div class="alert alert-warning" role="alert">
        <span class="icon-warning" aria-hidden="true"></span>
        <div>
            <strong><?php echo Text::_('COM_LMZPAGEBUILDER_TEMPLATE_SETTINGS_SCHEMA_MISSING'); ?></strong>
            <p><?php echo Text::_('COM_LMZPAGEBUILDER_TEMPLATE_SETTINGS_SCHEMA_MISSING_DESC'); ?></p>
        </div>
    </div>
<?php endif; ?>
