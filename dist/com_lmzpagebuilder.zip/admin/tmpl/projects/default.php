<?php

defined('_JEXEC') or die;

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;

$documents = array_filter($this->items, static function (array $item): bool {
    return array_filter(
        $item['translations'],
        static fn (array $translation): bool => ($translation['version']['status'] ?? 'unpublished') !== 'identical'
    ) !== [];
});
$published = array_filter($this->items, static function (array $item): bool {
    return array_filter(
        $item['translations'],
        static fn (array $translation): bool => ($translation['version']['status'] ?? 'unpublished') !== 'unpublished'
    ) !== [];
});
$publishedElements = array_filter($this->elements, static function (array $item): bool {
    return (int) $item['state'] === 1
        && array_filter($item['translations'], static fn (array $translation): bool => (int) $translation['state'] === 1) !== [];
});
$formatVersion = static function (string $fingerprint): string {
    return $fingerprint === ''
        ? Text::_('COM_LMZPAGEBUILDER_VERSION_NONE')
        : Text::sprintf('COM_LMZPAGEBUILDER_VERSION_LABEL', substr($fingerprint, 0, 12));
};
?>

<div class="lmzpb-admin" data-lmzpb-projects>
    <section class="lmzpb-hero">
        <div class="lmzpb-hero__copy">
            <span class="lmzpb-eyebrow">LMZ Media &middot; Open-source editor</span>
            <h1><?php echo Text::_('COM_LMZPAGEBUILDER_PROJECTS_TITLE'); ?></h1>
            <p><?php echo Text::_('COM_LMZPAGEBUILDER_PROJECTS_INTRO'); ?></p>
        </div>
    </section>

    <div class="lmzpb-notice" data-lmzpb-notice hidden role="status"></div>

    <nav class="lmzpb-section-tabs" role="tablist" aria-label="<?php echo Text::_('COM_LMZPAGEBUILDER_CONTENT_AREAS'); ?>">
        <button
            id="lmzpb-pages-tab"
            class="lmzpb-section-tab is-active"
            type="button"
            role="tab"
            aria-selected="true"
            aria-controls="lmzpb-pages-panel"
            data-lmzpb-section-tab="pages"
        >
            <span class="icon-grid-2" aria-hidden="true"></span>
            <?php echo Text::_('COM_LMZPAGEBUILDER_PAGES'); ?>
            <span class="lmzpb-section-tab__count"><?php echo count($this->items); ?></span>
        </button>
        <button
            id="lmzpb-elements-tab"
            class="lmzpb-section-tab"
            type="button"
            role="tab"
            aria-selected="false"
            aria-controls="lmzpb-elements-panel"
            data-lmzpb-section-tab="elements"
        >
            <span class="icon-link" aria-hidden="true"></span>
            <?php echo Text::_('COM_LMZPAGEBUILDER_SAVED_ELEMENTS'); ?>
            <span class="lmzpb-section-tab__count"><?php echo count($this->elements); ?></span>
        </button>
    </nav>

    <section
        id="lmzpb-pages-panel"
        class="lmzpb-section-panel"
        role="tabpanel"
        aria-labelledby="lmzpb-pages-tab"
        data-lmzpb-section-panel="pages"
    >
        <section class="lmzpb-stats" aria-label="<?php echo Text::_('COM_LMZPAGEBUILDER_OVERVIEW'); ?>">
            <article><strong><?php echo count($this->items); ?></strong><span><?php echo Text::_('COM_LMZPAGEBUILDER_LIVE_PAGES'); ?></span></article>
            <article><strong><?php echo count($documents); ?></strong><span><?php echo Text::_('COM_LMZPAGEBUILDER_DRAFTS'); ?></span></article>
            <article><strong><?php echo count($published); ?></strong><span><?php echo Text::_('COM_LMZPAGEBUILDER_PUBLISHED_PAGES'); ?></span></article>
            <article><strong><?php echo count($this->languages); ?></strong><span><?php echo Text::_('COM_LMZPAGEBUILDER_LANGUAGES'); ?></span></article>
        </section>

        <div class="table-responsive">
        <table class="table table-striped table-hover align-middle lmzpb-project-list">
            <caption class="visually-hidden"><?php echo Text::_('COM_LMZPAGEBUILDER_LIVE_PAGES'); ?></caption>
            <thead><tr>
                <th scope="col">#</th><th scope="col"><?php echo Text::_('JGLOBAL_TITLE'); ?></th>
                <th scope="col"><?php echo Text::_('COM_LMZPAGEBUILDER_LANGUAGES'); ?></th>
                <th scope="col"><?php echo Text::_('COM_LMZPAGEBUILDER_VERSION_STATUS'); ?></th>
                <th scope="col" class="text-end"><?php echo Text::_('JGLOBAL_ACTIONS'); ?></th>
            </tr></thead>
            <tbody>
            <?php foreach ($this->items as $item) : ?>
                <?php
                $hasDocument = $item['translations'] !== [];
                $primaryLanguage = (string) $item['language'];
                $versionLanguage = strtoupper(strtok($primaryLanguage, '-'));
                $version = is_array($item['version'] ?? null) ? $item['version'] : [];
                $versionStatus = in_array((string) ($version['status'] ?? ''), ['identical', 'newer', 'unpublished'], true)
                    ? (string) $version['status']
                    : 'unpublished';
                $versionStatusLabel = Text::_(match ($versionStatus) {
                    'identical' => 'COM_LMZPAGEBUILDER_VERSION_STATUS_IDENTICAL',
                    'newer' => 'COM_LMZPAGEBUILDER_VERSION_STATUS_NEWER',
                    default => 'COM_LMZPAGEBUILDER_VERSION_STATUS_UNPUBLISHED',
                });
                $editorUrl = Route::_('index.php?option=com_lmzpagebuilder&view=project&page_id=' . (int) $item['id'] . '&language=' . rawurlencode($primaryLanguage) . '&tmpl=component');
                ?>
                <tr data-page-id="<?php echo (int) $item['id']; ?>">
                    <th scope="row">#<?php echo (int) $item['id']; ?></th>
                    <td><strong><?php echo htmlspecialchars((string) $item['title'], ENT_QUOTES, 'UTF-8'); ?></strong><div class="small text-muted"><?php echo htmlspecialchars((string) $item['page_key'], ENT_QUOTES, 'UTF-8'); ?></div></td>
                    <td>
                        <div class="lmzpb-project-card__languages" aria-label="<?php echo Text::_('COM_LMZPAGEBUILDER_LANGUAGES'); ?>">
                            <?php foreach ($item['available_languages'] as $language) : ?>
                                <?php
                                $languageCode = (string) $language['code'];
                                $translation = $item['variants'][$languageCode] ?? null;
                                $languageParts = explode('-', $languageCode, 2);
                                $code = strtoupper($languageParts[0]);
                                $translationEditorUrl = $translation === null ? '' : Route::_('index.php?option=com_lmzpagebuilder&view=project&page_id=' . (int) $item['id'] . '&language=' . rawurlencode($languageCode) . '&tmpl=component');
                                ?>
                                <?php if ($translation !== null) : ?>
                                    <a class="lmzpb-language" href="<?php echo $translationEditorUrl; ?>" title="<?php echo htmlspecialchars((string) $translation['title'], ENT_QUOTES, 'UTF-8'); ?>">
                                        <?php echo htmlspecialchars($code, ENT_QUOTES, 'UTF-8'); ?>
                                    </a>
                                <?php else : ?>
                                    <button
                                        class="lmzpb-language is-missing"
                                        type="button"
                                        title="<?php echo Text::sprintf('COM_LMZPAGEBUILDER_CREATE_TRANSLATION', (string) ($language['native_title'] ?: $language['title'])); ?>"
                                        data-lmzpb-create-translation="<?php echo htmlspecialchars($languageCode, ENT_QUOTES, 'UTF-8'); ?>"
                                    >+<?php echo htmlspecialchars($code, ENT_QUOTES, 'UTF-8'); ?></button>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </div>
                    </td>
                    <td>
                        <div class="lmzpb-version-summary" data-version-status="<?php echo $versionStatus; ?>">
                            <span class="lmzpb-version-summary__status">
                                <?php echo $versionStatusLabel; ?>
                                <small><?php echo htmlspecialchars($versionLanguage, ENT_QUOTES, 'UTF-8'); ?></small>
                            </span>
                            <span class="lmzpb-version-summary__line">
                                <strong><?php echo Text::_('COM_LMZPAGEBUILDER_VERSION_ONLINE'); ?>:</strong>
                                <code title="<?php echo htmlspecialchars((string) ($version['online_fingerprint'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>"><?php echo $formatVersion((string) ($version['online_fingerprint'] ?? '')); ?></code>
                            </span>
                            <span class="lmzpb-version-summary__line">
                                <strong><?php echo Text::_('COM_LMZPAGEBUILDER_VERSION_DRAFT'); ?>:</strong>
                                <code title="<?php echo htmlspecialchars((string) ($version['draft_fingerprint'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>"><?php echo $formatVersion((string) ($version['draft_fingerprint'] ?? '')); ?></code>
                            </span>
                        </div>
                    </td>
                    <td class="text-end">
                        <?php if ($hasDocument) : ?>
                            <a class="btn btn-primary" href="<?php echo $editorUrl; ?>"><?php echo Text::_('COM_LMZPAGEBUILDER_OPEN_EDITOR'); ?></a>
                        <?php endif; ?>
                        <?php if ((string) $item['frontend_url'] !== '') : ?>
                            <a class="btn btn-outline-secondary" href="<?php echo htmlspecialchars((string) $item['frontend_url'], ENT_QUOTES, 'UTF-8'); ?>" target="_blank" rel="noopener">
                                <?php echo Text::_('COM_LMZPAGEBUILDER_PREVIEW'); ?>
                            </a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        </div>
    </section>

    <section
        id="lmzpb-elements-panel"
        class="lmzpb-section-panel"
        role="tabpanel"
        aria-labelledby="lmzpb-elements-tab"
        data-lmzpb-section-panel="elements"
        hidden
    >
        <div class="lmzpb-elements-layout">
            <aside class="lmzpb-element-create">
                <span class="lmzpb-eyebrow"><?php echo Text::_('COM_LMZPAGEBUILDER_NEW_ELEMENT'); ?></span>
                <h2><?php echo Text::_('COM_LMZPAGEBUILDER_CREATE_SAVED_ELEMENT'); ?></h2>
                <p><?php echo Text::_('COM_LMZPAGEBUILDER_CREATE_ELEMENT_INTRO'); ?></p>
                <form data-lmzpb-create-element>
                    <label>
                        <span><?php echo Text::_('JGLOBAL_TITLE'); ?></span>
                        <input name="title" type="text" maxlength="255" required autocomplete="off">
                    </label>
                    <label>
                        <span><?php echo Text::_('COM_LMZPAGEBUILDER_ELEMENT_KIND'); ?></span>
                        <select name="kind">
                            <option value="global"><?php echo Text::_('COM_LMZPAGEBUILDER_GLOBAL_ELEMENT'); ?></option>
                            <option value="template"><?php echo Text::_('COM_LMZPAGEBUILDER_ELEMENT_TEMPLATE'); ?></option>
                        </select>
                    </label>
                    <fieldset>
                        <legend><?php echo Text::_('COM_LMZPAGEBUILDER_LANGUAGE_VARIANTS'); ?></legend>
                        <div class="lmzpb-language-checks">
                            <?php foreach ($this->languages as $language) : ?>
                                <?php $languageCode = (string) $language['code']; ?>
                                <label>
                                    <input type="checkbox" name="languages[]" value="<?php echo htmlspecialchars($languageCode, ENT_QUOTES, 'UTF-8'); ?>" checked>
                                    <span><?php echo htmlspecialchars((string) ($language['native_title'] ?: $language['title']), ENT_QUOTES, 'UTF-8'); ?></span>
                                    <small><?php echo htmlspecialchars($languageCode, ENT_QUOTES, 'UTF-8'); ?></small>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    </fieldset>
                    <button class="btn btn-primary" type="submit">
                        <span class="icon-plus" aria-hidden="true"></span><?php echo Text::_('COM_LMZPAGEBUILDER_CREATE_ELEMENT'); ?>
                    </button>
                </form>
            </aside>

            <div>
                <section class="lmzpb-stats lmzpb-element-stats" aria-label="<?php echo Text::_('COM_LMZPAGEBUILDER_SAVED_ELEMENTS'); ?>">
                    <article><strong><?php echo count($this->elements); ?></strong><span><?php echo Text::_('COM_LMZPAGEBUILDER_SAVED_ELEMENTS'); ?></span></article>
                    <article><strong><?php echo count($publishedElements); ?></strong><span><?php echo Text::_('COM_LMZPAGEBUILDER_PUBLISHED_ELEMENTS'); ?></span></article>
                    <article><strong><?php echo array_sum(array_column($this->elements, 'usage_count')); ?></strong><span><?php echo Text::_('COM_LMZPAGEBUILDER_USAGES'); ?></span></article>
                </section>

                <?php if ($this->elements === []) : ?>
                    <div class="lmzpb-empty-state">
                        <span class="icon-link" aria-hidden="true"></span>
                        <h2><?php echo Text::_('COM_LMZPAGEBUILDER_NO_ELEMENTS'); ?></h2>
                        <p><?php echo Text::_('COM_LMZPAGEBUILDER_NO_ELEMENTS_INTRO'); ?></p>
                    </div>
                <?php else : ?>
                    <section class="lmzpb-project-grid lmzpb-element-grid">
                        <?php foreach ($this->elements as $element) : ?>
                            <?php
                            $primaryLanguage = (string) array_key_first($element['variants']);
                            $editorUrl = $primaryLanguage === '' ? '' : Route::_('index.php?option=com_lmzpagebuilder&view=element&element_id=' . (int) $element['id'] . '&language=' . rawurlencode($primaryLanguage) . '&tmpl=component');
                            ?>
                            <article class="lmzpb-project-card lmzpb-element-card" data-element-id="<?php echo (int) $element['id']; ?>">
                                <header>
                                    <div class="lmzpb-project-card__id"><?php echo htmlspecialchars((string) $element['element_key'], ENT_QUOTES, 'UTF-8'); ?></div>
                                    <div class="lmzpb-project-card__languages" aria-label="<?php echo Text::_('COM_LMZPAGEBUILDER_LANGUAGES'); ?>">
                                        <?php foreach ($element['available_languages'] as $language) : ?>
                                            <?php
                                            $languageCode = (string) $language['code'];
                                            $translation = $element['variants'][$languageCode] ?? null;
                                            $shortCode = strtoupper(strtok($languageCode, '-'));
                                            $translationEditorUrl = $translation === null ? '' : Route::_('index.php?option=com_lmzpagebuilder&view=element&element_id=' . (int) $element['id'] . '&language=' . rawurlencode($languageCode) . '&tmpl=component');
                                            ?>
                                            <?php if ($translation !== null) : ?>
                                                <a class="lmzpb-language" href="<?php echo $translationEditorUrl; ?>" title="<?php echo htmlspecialchars((string) $translation['title'], ENT_QUOTES, 'UTF-8'); ?>">
                                                    <?php echo htmlspecialchars($shortCode, ENT_QUOTES, 'UTF-8'); ?>
                                                </a>
                                            <?php else : ?>
                                                <button
                                                    class="lmzpb-language is-missing"
                                                    type="button"
                                                    title="<?php echo Text::sprintf('COM_LMZPAGEBUILDER_CREATE_TRANSLATION', (string) ($language['native_title'] ?: $language['title'])); ?>"
                                                    data-lmzpb-create-element-translation="<?php echo htmlspecialchars($languageCode, ENT_QUOTES, 'UTF-8'); ?>"
                                                >+<?php echo htmlspecialchars($shortCode, ENT_QUOTES, 'UTF-8'); ?></button>
                                            <?php endif; ?>
                                        <?php endforeach; ?>
                                    </div>
                                </header>
                                <div class="lmzpb-project-card__body">
                                    <span class="lmzpb-element-kind"><?php echo (string) $element['kind'] === 'template' ? Text::_('COM_LMZPAGEBUILDER_ELEMENT_TEMPLATE') : Text::_('COM_LMZPAGEBUILDER_GLOBAL_ELEMENT'); ?></span>
                                    <h2><?php echo htmlspecialchars((string) $element['title'], ENT_QUOTES, 'UTF-8'); ?></h2>
                                    <div class="lmzpb-project-card__meta">
                                        <span class="<?php echo (int) $element['state'] === 1 ? 'is-live' : 'is-offline'; ?>">
                                            <?php echo (int) $element['state'] === 1 ? Text::_('JPUBLISHED') : Text::_('JUNPUBLISHED'); ?>
                                        </span>
                                        <span><?php echo Text::sprintf('COM_LMZPAGEBUILDER_USAGE_COUNT', (int) $element['usage_count']); ?></span>
                                    </div>
                                </div>
                                <footer>
                                    <?php if ($editorUrl !== '') : ?>
                                        <a class="btn btn-primary" href="<?php echo $editorUrl; ?>"><?php echo Text::_('COM_LMZPAGEBUILDER_OPEN_ELEMENT_EDITOR'); ?></a>
                                    <?php endif; ?>
                                </footer>
                            </article>
                        <?php endforeach; ?>
                    </section>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <form hidden><?php echo HTMLHelper::_('form.token'); ?></form>
</div>
