<?php

namespace LMZ\Component\Lmzpagebuilder\Administrator\Controller;

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Log\Log;
use Joomla\CMS\MVC\Controller\BaseController;
use Joomla\CMS\Session\Session;
use Joomla\Database\DatabaseInterface;
use LMZ\Component\Lmzpagebuilder\Administrator\Service\AssetService;
use LMZ\Component\Lmzpagebuilder\Administrator\Service\EmbedCatalogService;
use LMZ\Component\Lmzpagebuilder\Administrator\Service\PageBuilderService;
use LMZ\Component\Lmzpagebuilder\Administrator\Service\SharedElementService;
use Throwable;

final class ProjectController extends BaseController
{
    public function pages(): void
    {
        $this->runJson(function (): array {
            $this->assertToken();

            return ['items' => $this->service()->listPages()];
        });
    }

    public function languages(): void
    {
        $this->runJson(function (): array {
            $this->assertToken();

            return ['items' => $this->service()->listLanguages()];
        });
    }

    public function createPage(): void
    {
        $this->runJson(function (): array {
            $this->assertToken();

            return $this->service()->createPage($this->payload());
        });
    }

    public function updatePage(): void
    {
        $this->runJson(function (): array {
            $this->assertToken();

            return $this->service()->updatePage($this->input->post->getInt('page_id'), $this->payload());
        });
    }

    public function createTranslation(): void
    {
        $this->runJson(function (): array {
            $this->assertToken();

            return $this->service()->createTranslation(
                $this->input->post->getInt('page_id'),
                $this->input->post->getString('language', ''),
                $this->payload()
            );
        });
    }

    public function updateTranslation(): void
    {
        $this->runJson(function (): array {
            $this->assertToken();

            return $this->service()->updateTranslationMetadata(
                $this->input->post->getInt('translation_id'),
                $this->payload()
            );
        });
    }

    public function load(): void
    {
        $this->runJson(function (): array {
            $this->assertToken();
            $id = $this->input->getInt('id');

            return $this->service()->loadForEditor($id, $this->leaseToken());
        });
    }

    public function save(): void
    {
        $this->runJson(function (): array {
            $this->assertToken();

            return $this->service()->saveDraft(
                $this->input->post->getInt('id'),
                strtolower($this->input->post->getString('expected_draft_hash', '')),
                strtolower($this->input->post->getString('expected_layout_hash', '')),
                (string) $this->input->post->get('data', '', 'raw'),
                (string) $this->input->post->get('html', '', 'raw'),
                (string) $this->input->post->get('css', '', 'raw'),
                $this->leaseToken()
            );
        });
    }

    public function publish(): void
    {
        $this->runJson(function (): array {
            $this->assertToken();

            return $this->service()->publish(
                $this->input->post->getInt('id'),
                strtolower($this->input->post->getString('expected_source_hash', '')),
                strtolower($this->input->post->getString('expected_draft_hash', '')),
                strtolower($this->input->post->getString('expected_layout_hash', '')),
                $this->leaseToken(),
                $this->input->post->getString('note', ''),
                $this->input->post->getBool('create_revision', false)
            );
        });
    }

    public function discardDraft(): void
    {
        $this->runJson(function (): array {
            $this->assertToken();

            return $this->service()->discardDraft(
                $this->input->post->getInt('id'),
                $this->leaseToken()
            );
        });
    }

    public function importNativePage(): void
    {
        $this->runJson(function (): array {
            $this->assertToken();

            return $this->service()->importNativePage($this->payload());
        });
    }

    public function elements(): void
    {
        $this->runJson(function (): array {
            $this->assertToken();

            return ['items' => $this->elementsService()->listElements($this->input->getCmd('kind', ''))];
        });
    }

    public function createElement(): void
    {
        $this->runJson(function (): array {
            $this->assertToken();

            return $this->elementsService()->createElement($this->payload());
        });
    }

    public function updateElement(): void
    {
        $this->runJson(function (): array {
            $this->assertToken();

            return $this->elementsService()->updateElement(
                $this->input->post->getInt('element_id'),
                $this->payload()
            );
        });
    }

    public function createElementTranslation(): void
    {
        $this->runJson(function (): array {
            $this->assertToken();

            return $this->elementsService()->createTranslation(
                $this->input->post->getInt('element_id'),
                $this->input->post->getString('language', ''),
                $this->payload()
            );
        });
    }

    public function acquireElement(): void
    {
        $this->runJson(function (): array {
            $this->assertToken();

            return $this->elementsService()->acquire(
                $this->input->post->getInt('element_id'),
                $this->input->post->getString('language', '')
            );
        });
    }

    public function loadElement(): void
    {
        $this->runJson(function (): array {
            $this->assertToken();

            return $this->elementsService()->loadForEditor($this->input->getInt('id'), $this->leaseToken());
        });
    }

    public function saveElement(): void
    {
        $this->runJson(function (): array {
            $this->assertToken();

            return $this->elementsService()->saveDraft(
                $this->input->post->getInt('id'),
                strtolower($this->input->post->getString('expected_draft_hash', '')),
                (string) $this->input->post->get('data', '', 'raw'),
                (string) $this->input->post->get('html', '', 'raw'),
                (string) $this->input->post->get('css', '', 'raw'),
                $this->leaseToken()
            );
        });
    }

    public function publishElement(): void
    {
        $this->runJson(function (): array {
            $this->assertToken();

            return $this->elementsService()->publish(
                $this->input->post->getInt('id'),
                strtolower($this->input->post->getString('expected_published_hash', $this->input->post->getString('expected_source_hash', ''))),
                strtolower($this->input->post->getString('expected_draft_hash', '')),
                $this->leaseToken()
            );
        });
    }

    public function touchElement(): void
    {
        $this->runJson(function (): array {
            $this->assertToken();

            return $this->elementsService()->touch($this->input->post->getInt('id'), $this->leaseToken());
        });
    }

    public function releaseElement(): void
    {
        $this->runJson(function (): array {
            $this->assertToken();
            $this->elementsService()->release($this->input->post->getInt('id'), $this->leaseToken());

            return ['released' => true];
        });
    }

    public function elementUsages(): void
    {
        $this->runJson(function (): array {
            $this->assertToken();

            return ['items' => $this->elementsService()->usages($this->input->getInt('element_id'))];
        });
    }

    public function deleteElement(): void
    {
        $this->runJson(function (): array {
            $this->assertToken();
            $elementId = $this->input->post->getInt('element_id');
            $this->elementsService()->deleteElement($elementId);

            return ['deleted' => true, 'element_id' => $elementId];
        });
    }

    public function embeds(): void
    {
        $this->runJson(function (): array {
            $this->assertToken();

            return $this->embedService()->catalog(
                $this->input->getString('language', ''),
                $this->input->getString('search', ''),
                $this->input->getInt('limit', 100)
            );
        });
    }

    public function embedArticles(): void
    {
        $this->runJson(function (): array {
            $this->assertToken();

            return ['items' => $this->embedService()->articles(
                $this->input->getString('language', ''),
                $this->input->getString('search', ''),
                $this->input->getInt('limit', 100)
            )];
        });
    }

    public function embedModules(): void
    {
        $this->runJson(function (): array {
            $this->assertToken();

            return ['items' => $this->embedService()->modules(
                $this->input->getString('language', ''),
                $this->input->getString('search', ''),
                $this->input->getInt('limit', 100)
            )];
        });
    }

    public function embedSmartSliders(): void
    {
        $this->runJson(function (): array {
            $this->assertToken();

            return ['items' => $this->embedService()->smartSliders(
                $this->input->getString('search', ''),
                $this->input->getInt('limit', 100)
            )];
        });
    }

    public function revisions(): void
    {
        $this->runJson(function (): array {
            $this->assertToken();

            return ['items' => $this->service()->revisions($this->input->getInt('id'), $this->leaseToken())];
        });
    }

    public function rollback(): void
    {
        $this->runJson(function (): array {
            $this->assertToken();

            return $this->service()->rollback(
                $this->input->post->getInt('revision_id'),
                strtolower($this->input->post->getString('expected_source_hash', '')),
                strtolower($this->input->post->getString('expected_draft_hash', '')),
                strtolower($this->input->post->getString('expected_layout_hash', '')),
                $this->leaseToken()
            );
        });
    }

    public function touch(): void
    {
        $this->runJson(function (): array {
            $this->assertToken();

            return $this->service()->touch(
                $this->input->post->getInt('id'),
                $this->leaseToken()
            );
        });
    }

    public function release(): void
    {
        $this->runJson(function (): array {
            $this->assertToken();
            $this->service()->release($this->input->post->getInt('id'), $this->leaseToken());

            return ['released' => true];
        });
    }

    public function assets(): void
    {
        $this->runJson(function (): array {
            $this->assertToken();
            $this->assertMediaPermission('core.manage');

            return ['items' => (new AssetService())->listImages()];
        });
    }

    public function upload(): void
    {
        $this->runJson(function (): array {
            $this->assertToken();
            $this->assertMediaPermission('core.create');
            $file = $this->input->files->get('file', null, 'raw');

            if (!is_array($file)) {
                throw new \RuntimeException('An image file is required.', 422);
            }

            return (new AssetService())->upload($file);
        });
    }

    private function service(): PageBuilderService
    {
        return new PageBuilderService(
            Factory::getContainer()->get(DatabaseInterface::class),
            $this->app->getIdentity()
        );
    }

    private function elementsService(): SharedElementService
    {
        return new SharedElementService(
            Factory::getContainer()->get(DatabaseInterface::class),
            $this->app->getIdentity()
        );
    }

    private function embedService(): EmbedCatalogService
    {
        return new EmbedCatalogService(
            Factory::getContainer()->get(DatabaseInterface::class),
            $this->app->getIdentity()
        );
    }

    /** @return array<string, mixed> */
    private function payload(): array
    {
        $raw = (string) $this->input->post->get('payload', '', 'raw');
        if ($raw === '') {
            return [];
        }

        $decoded = json_decode($raw, true);
        if (!is_array($decoded)) {
            throw new \RuntimeException('The request payload must be a JSON object.', 422);
        }

        return $decoded;
    }

    private function assertToken(): void
    {
        if (!Session::checkToken('request')) {
            throw new \RuntimeException('Invalid or expired CSRF token.', 403);
        }
    }

    private function leaseToken(): string
    {
        $header = $this->input->server->getString('HTTP_X_LMZ_EDITOR_LEASE', '');

        return strtolower($header !== '' ? $header : $this->input->getString('lease_token', ''));
    }

    private function assertMediaPermission(string $action): void
    {
        $identity = $this->app->getIdentity();

        if (!$identity->authorise('core.admin', 'com_media') && !$identity->authorise($action, 'com_media')) {
            throw new \RuntimeException('Joomla media permission is required.', 403);
        }
    }

    /** @param callable(): array<string, mixed> $callback */
    private function runJson(callable $callback): void
    {
        try {
            $payload = ['success' => true, 'data' => $callback()];
            $status = 200;
        } catch (Throwable $error) {
            Log::addLogger(
                ['text_file' => 'com_lmzpagebuilder.php'],
                Log::ALL,
                ['com_lmzpagebuilder']
            );
            Log::add(
                sprintf(
                    '%s: %s in %s:%d',
                    $error::class,
                    $error->getMessage(),
                    $error->getFile(),
                    $error->getLine()
                ),
                Log::ERROR,
                'com_lmzpagebuilder'
            );
            $code = (int) $error->getCode();
            $status = $code >= 400 && $code <= 599 ? $code : 500;
            $payload = [
                'success' => false,
                'message' => $status === 500 ? 'The LMZ Page Builder request failed.' : $error->getMessage(),
                'code' => $status,
            ];
        }

        http_response_code($status);
        $this->app->setHeader('Content-Type', 'application/json; charset=utf-8', true);
        $this->app->setHeader('Cache-Control', 'no-store, no-cache, must-revalidate', true);
        echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        $this->app->close();
    }
}
