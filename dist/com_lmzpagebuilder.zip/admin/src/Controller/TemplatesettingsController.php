<?php

declare(strict_types=1);

namespace LMZ\Component\Lmzpagebuilder\Administrator\Controller;

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Controller\BaseController;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Session\Session;
use Joomla\Database\DatabaseInterface;
use LMZ\Component\Lmzpagebuilder\Administrator\Service\TemplateSettingsService;
use Throwable;

final class TemplatesettingsController extends BaseController
{
    public function save(): void
    {
        $this->assertPostToken();
        $section = $this->input->post->getCmd('section', '');
        $layout = in_array($section, ['header', 'footer'], true) ? $section : '';
        $redirect = Route::_(
            'index.php?option=com_lmzpagebuilder&view=templatesettings'
            . ($layout !== '' ? '&layout=' . $layout : ''),
            false
        );

        try {
            $settings = $this->input->post->get('settings', [], 'array');
            if (!is_array($settings)) {
                $settings = [];
            }

            $this->service()->save(
                $settings,
                strtolower($this->input->post->getString('expected_hash', '')),
                $this->input->post->getString('revision_note', ''),
                $section
            );
            $this->setRedirect($redirect, Text::_('COM_LMZPAGEBUILDER_TEMPLATE_SETTINGS_SAVED'), 'success');
        } catch (Throwable $error) {
            $this->setRedirect($redirect, $error->getMessage(), 'error');
        }
    }

    public function ensureRegion(): void
    {
        $this->assertPostToken();
        $redirect = Route::_('index.php?option=com_lmzpagebuilder&view=templatesettings', false);

        try {
            $region = $this->input->post->getCmd('region', '');
            $language = $this->input->post->getString('language', '');
            $result = $this->service()->ensureRegion($region, $language);
            $editorUrl = Route::_((string) $result['editor_url']);
            $this->setRedirect($editorUrl, Text::_('COM_LMZPAGEBUILDER_TEMPLATE_REGION_READY'), 'success');
        } catch (Throwable $error) {
            $this->setRedirect($redirect, $error->getMessage(), 'error');
        }
    }

    private function service(): TemplateSettingsService
    {
        return new TemplateSettingsService(
            Factory::getContainer()->get(DatabaseInterface::class),
            $this->app->getIdentity()
        );
    }

    private function assertPostToken(): void
    {
        if (strtoupper((string) $this->input->getMethod()) !== 'POST' || !Session::checkToken()) {
            throw new \RuntimeException(Text::_('JINVALID_TOKEN'), 403);
        }
    }
}
