<?php

declare(strict_types=1);

namespace LMZ\Component\Lmzpagebuilder\Administrator\View\Templatesettings;

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use Joomla\CMS\Toolbar\ToolbarHelper;
use Joomla\Database\DatabaseInterface;
use LMZ\Component\Lmzpagebuilder\Administrator\Service\TemplateSettingsService;

final class HtmlView extends BaseHtmlView
{
    /** @var array<string, mixed> */
    public array $settingsDocument = [];

    /** @var array<string, array<string, mixed>> */
    public array $regions = [];

    /** @var array<int, array<string, mixed>> */
    public array $revisions = [];

    /** @var array<int, array<string, string>> */
    public array $menuTypes = [];

    /** @var array<int, array<string, mixed>> */
    public array $contacts = [];

    public bool $canEdit = false;

    /** Active sub-page: 'default' (overview), 'header' or 'footer'. */
    public string $activeLayout = 'default';

    public function display($tpl = null): void
    {
        $app = Factory::getApplication();
        $identity = $app->getIdentity();
        if (!$identity->authorise('core.admin', 'com_lmzpagebuilder')
            && !$identity->authorise('core.manage', 'com_lmzpagebuilder')) {
            throw new \RuntimeException(Text::_('JERROR_ALERTNOAUTHOR'), 403);
        }

        $db = Factory::getContainer()->get(DatabaseInterface::class);
        $service = new TemplateSettingsService($db, $identity);
        $this->settingsDocument = $service->load();
        $this->regions = $service->regionStatus();
        $this->revisions = $service->revisions();
        $this->canEdit = $identity->authorise('core.admin', 'com_lmzpagebuilder')
            || $identity->authorise('lmzpagebuilder.settings', 'com_lmzpagebuilder')
            || $identity->authorise('core.edit', 'com_lmzpagebuilder');

        $query = $db->getQuery(true)
            ->select($db->quoteName(['menutype', 'title']))
            ->from($db->quoteName('#__menu_types'))
            ->order($db->quoteName('title') . ' ASC');
        foreach ($db->setQuery($query)->loadAssocList() ?: [] as $menuType) {
            $this->menuTypes[] = [
                'value' => (string) $menuType['menutype'],
                'text' => (string) $menuType['title'],
            ];
        }

        $contactQuery = $db->getQuery(true)
            ->select($db->quoteName([
                'c.id', 'c.name', 'c.telephone', 'c.email_to', 'c.address',
                'c.suburb', 'c.state', 'c.postcode', 'c.country',
            ]))
            ->from($db->quoteName('#__contact_details', 'c'))
            ->innerJoin($db->quoteName('#__categories', 'cat') . ' ON ' . $db->quoteName('cat.id') . ' = ' . $db->quoteName('c.catid'))
            ->where($db->quoteName('c.published') . ' = 1')
            ->where($db->quoteName('cat.published') . ' = 1')
            ->where($db->quoteName('c.access') . ' = 1')
            ->where($db->quoteName('cat.access') . ' = 1')
            ->order($db->quoteName('c.name') . ' ASC');
        foreach ($db->setQuery($contactQuery)->loadAssocList() ?: [] as $contact) {
            $this->contacts[] = [
                'id' => (int) $contact['id'],
                'name' => (string) $contact['name'],
                'telephone' => (string) $contact['telephone'],
                'email' => (string) $contact['email_to'],
                'address_complete' => trim(implode(' ', array_filter([
                    (string) $contact['address'],
                    (string) $contact['postcode'],
                    (string) $contact['suburb'],
                    (string) $contact['state'],
                    (string) $contact['country'],
                ]))),
            ];
        }

        $layout = $this->getLayout();
        $this->activeLayout = in_array($layout, ['header', 'footer'], true) ? $layout : 'default';
        $isEditor = $this->activeLayout !== 'default';

        $document = $app->getDocument();
        $document->getWebAssetManager()
            ->useStyle('com_lmzpagebuilder.admin')
            ->useStyle('com_lmzpagebuilder.template-settings')
            ->useScript('com_lmzpagebuilder.template-settings');

        // The header and footer sub-pages expose Font Awesome icon fields via the
        // shared icon picker (Agent B) rendered with self-hosted Font Awesome 6
        // (Agent A). The relative loader silently skips files that have not been
        // deployed yet, so the pages keep working before those assets land.
        if ($isEditor) {
            HTMLHelper::_('stylesheet', 'com_lmzpagebuilder/fontawesome/css/all.min.css', ['relative' => true, 'version' => 'auto']);
            HTMLHelper::_('stylesheet', 'com_lmzpagebuilder/css/rt-icon-picker.css', ['relative' => true, 'version' => 'auto']);
            HTMLHelper::_('script', 'com_lmzpagebuilder/js/rt-icon-picker.js', ['relative' => true, 'version' => 'auto'], ['defer' => true]);
        }

        $title = match ($this->activeLayout) {
            'header' => Text::_('COM_LMZPAGEBUILDER_TEMPLATE_SETTINGS_HEADER'),
            'footer' => Text::_('COM_LMZPAGEBUILDER_TEMPLATE_SETTINGS_FOOTER'),
            default => Text::_('COM_LMZPAGEBUILDER_TEMPLATE_SETTINGS'),
        };
        ToolbarHelper::title($title, 'cog');
        if ($isEditor && $this->canEdit && !empty($this->settingsDocument['schema_ready'])) {
            ToolbarHelper::custom(
                'templatesettings.save',
                'save',
                'save',
                Text::_('JSAVE'),
                false
            );
        }
        ToolbarHelper::preferences('com_lmzpagebuilder');

        parent::display($tpl);
    }
}
