<?php

namespace LMZ\Component\Lmzpagebuilder\Administrator\View\Project;

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use Joomla\CMS\Session\Session;
use Joomla\CMS\Uri\Uri;
use Joomla\Database\DatabaseInterface;
use LMZ\Component\Lmzpagebuilder\Administrator\Service\PageBuilderService;

final class HtmlView extends BaseHtmlView
{
    /** @var array<string, mixed> */
    public array $item = [];
    /** @var array<int, array<string, mixed>> */
    public array $languageOptions = [];
    public string $frontendUrl = '';
    public ?string $error = null;

    public function display($tpl = null): void
    {
        $app = Factory::getApplication();
        $pageId = $app->getInput()->getInt('page_id');
        $requestedLanguage = $app->getInput()->getString('language', '');
        $service = new PageBuilderService(
            Factory::getContainer()->get(DatabaseInterface::class),
            $app->getIdentity()
        );

        try {
            $this->item = $service->acquireByPage($pageId, $requestedLanguage);
            $availableLanguages = $service->listLanguages();
            foreach ($service->listPages() as $page) {
                if ((int) $page['id'] === $pageId) {
                    $variants = is_array($page['variants'] ?? null) ? $page['variants'] : [];
                    $currentLanguage = (string) $this->item['language'];
                    $this->frontendUrl = (string) ($variants[$currentLanguage]['frontend_url'] ?? $page['frontend_url'] ?? '');

                    foreach ($availableLanguages as $language) {
                        $code = (string) $language['code'];
                        $variant = is_array($variants[$code] ?? null) ? $variants[$code] : null;
                        $this->languageOptions[] = [
                            'code' => $code,
                            'title' => (string) ($language['native_title'] ?: $language['title']),
                            'active' => $code === $currentLanguage,
                            'exists' => $variant !== null,
                            'editor_url' => $variant === null ? '' : 'index.php?option=com_lmzpagebuilder&view=project&page_id=' . $pageId
                                . '&language=' . rawurlencode($code) . '&tmpl=component',
                        ];
                    }
                    break;
                }
            }
        } catch (\Throwable $error) {
            if ($this->item !== []) {
                try {
                    $service->release(
                        (int) $this->item['id'],
                        (string) $this->item['checkout_token']
                    );
                } catch (\Throwable $releaseError) {
                    // Preserve the original editor error. A database-level release
                    // failure remains recoverable through the configured timeout.
                }
            }

            $this->item = [];
            $this->error = $error->getMessage();
        }

        $root = rtrim(Uri::root(), '/');
        $media = $root . '/media/com_lmzpagebuilder';
        $templateCss = [
            'tailwind.min.css',
            'design-system.css',
            'layout-polish.css',
            'logo-3d.css',
            'layout.css',
            'motion-stability.css',
            'brand-lockup.css',
            'mobile-navigation.css',
            'joomla-integration.css',
            'rt-motion.css',
            'rt-footer.css',
            'rt-language.css',
            'rt-germany-map.css',
            'home-first-segment.css',
            'rt-system.css',
            'rt-about.css',
            'rt-services.css',
            'rt-contact.css',
            'rt-careers.css',
            'rt-process.css',
            'signal-atlas.css',
            'signal-atlas-tune.css',
        ];
        $canvasStyles = array_map(
            static fn (string $file): string => $root . '/templates/lmz_builder/l3/css/' . $file,
            $templateCss
        );
        $canvasScripts = [
            $root . '/templates/lmz_builder/l3/js/vendor/gsap.min.js?v=2.4.5-20260804',
            $root . '/templates/lmz_builder/l3/js/vendor/ScrollTrigger.min.js?v=2.4.5-20260804',
            $root . '/templates/lmz_builder/l3/js/vendor/SplitText.min.js?v=2.4.5-20260804',
            $media . '/js/lmz-motion-runtime.js?v=2.4.5-20260804',
            $media . '/js/editor-canvas-media.js?v=2.4.5-20260806',
        ];

        $document = $app->getDocument();
        $document->getWebAssetManager()
            ->useStyle('com_lmzpagebuilder.admin')
            ->useStyle('com_lmzpagebuilder.grapesjs')
            ->useStyle('com_lmzpagebuilder.builder')
            ->useScript('com_lmzpagebuilder.grapesjs')
            ->useScript('com_lmzpagebuilder.builder')
            ->useScript('com_lmzpagebuilder.editor');

        if ($this->item !== []) {
            $canvasBodyClasses = $this->canvasBodyClasses(
                (string) $this->item['page_key'],
                (string) $this->item['draft_html']
            );
            $document->addScriptOptions('com_lmzpagebuilder.editor', [
                'entityType' => 'page',
                'documentId' => (int) $this->item['id'],
                'pageId' => (int) $this->item['page_id'],
                'title' => (string) $this->item['title'],
                'sourceHash' => (string) $this->item['published_hash'],
                'draftHash' => (string) $this->item['draft_hash'],
                'publishedTextHash' => (string) $this->item['published_text_hash'],
                'layoutDraftHash' => (string) $this->item['layout_draft_hash'],
                'layoutPublishedHash' => (string) $this->item['layout_published_hash'],
                'version' => $this->item['version'],
                'sourceLanguage' => (string) $this->item['source_language'],
                'translationOnly' => (bool) $this->item['translation_only'],
                'leaseToken' => (string) $this->item['checkout_token'],
                'csrfToken' => Session::getFormToken(),
                'rootUrl' => $root,
                'canvasBaseUrl' => $root . '/',
                'assets' => [
                    'grapesJs' => $media . '/js/grapesjs.js',
                    'grapesCss' => $media . '/css/grapesjs.css',
                ],
                'canvasStyles' => $canvasStyles,
                'canvasScripts' => $canvasScripts,
                'canvasBodyClasses' => $canvasBodyClasses,
                'language' => (string) $this->item['language'],
                'canvasLanguage' => (string) $this->item['language'],
                'motion' => [
                    'enabled' => true,
                    'preview' => true,
                    'debounceMs' => 140,
                    'respectReducedMotion' => true,
                ],
                'frontendUrl' => $this->frontendUrl,
                'endpoints' => [
                    'load' => 'index.php?option=com_lmzpagebuilder&task=project.load&format=json&id=' . (int) $this->item['id'],
                    'save' => 'index.php?option=com_lmzpagebuilder&task=project.save&format=json',
                    'publish' => 'index.php?option=com_lmzpagebuilder&task=project.publish&format=json',
                    'discardDraft' => 'index.php?option=com_lmzpagebuilder&task=project.discardDraft&format=json',
                    'revisions' => 'index.php?option=com_lmzpagebuilder&task=project.revisions&format=json&id=' . (int) $this->item['id'],
                    'rollback' => 'index.php?option=com_lmzpagebuilder&task=project.rollback&format=json',
                    'touch' => 'index.php?option=com_lmzpagebuilder&task=project.touch&format=json',
                    'release' => 'index.php?option=com_lmzpagebuilder&task=project.release&format=json',
                    'assets' => 'index.php?option=com_lmzpagebuilder&task=project.assets&format=json',
                    'upload' => 'index.php?option=com_lmzpagebuilder&task=project.upload&format=json',
                    'embeds' => 'index.php?option=com_lmzpagebuilder&task=project.embeds&format=json',
                    'elements' => 'index.php?option=com_lmzpagebuilder&task=project.elements&format=json',
                    'createTranslation' => 'index.php?option=com_lmzpagebuilder&task=project.createTranslation&format=json',
                ],
                'labels' => [
                    'loading' => Text::_('COM_LMZPAGEBUILDER_EDITOR_LOADING'),
                    'ready' => Text::_('COM_LMZPAGEBUILDER_EDITOR_READY'),
                    'saving' => Text::_('COM_LMZPAGEBUILDER_EDITOR_SAVING'),
                    'saved' => Text::_('COM_LMZPAGEBUILDER_EDITOR_SAVED'),
                    'publishing' => Text::_('COM_LMZPAGEBUILDER_EDITOR_PUBLISHING'),
                    'published' => Text::_('COM_LMZPAGEBUILDER_EDITOR_PUBLISHED'),
                    'discarded' => Text::_('COM_LMZPAGEBUILDER_DRAFT_DISCARDED'),
                    'failed' => Text::_('COM_LMZPAGEBUILDER_REQUEST_FAILED'),
                    'rollbackConfirm' => Text::_('COM_LMZPAGEBUILDER_ROLLBACK_CONFIRM'),
                    'publishNote' => Text::_('COM_LMZPAGEBUILDER_PUBLISH_NOTE_PROMPT'),
                    'sourceMode' => Text::_('COM_LMZPAGEBUILDER_SOURCE_MODE'),
                    'translationMode' => Text::_('COM_LMZPAGEBUILDER_TRANSLATION_MODE'),
                    'translationStructureBlocked' => Text::_('COM_LMZPAGEBUILDER_TRANSLATION_STRUCTURE_BLOCKED'),
                    'versionLabel' => Text::_('COM_LMZPAGEBUILDER_VERSION_LABEL'),
                    'versionNone' => Text::_('COM_LMZPAGEBUILDER_VERSION_NONE'),
                    'versionStatusIdentical' => Text::_('COM_LMZPAGEBUILDER_VERSION_STATUS_IDENTICAL'),
                    'versionStatusNewer' => Text::_('COM_LMZPAGEBUILDER_VERSION_STATUS_NEWER'),
                    'versionStatusUnpublished' => Text::_('COM_LMZPAGEBUILDER_VERSION_STATUS_UNPUBLISHED'),
                ],
            ]);
        }

        parent::display($tpl);
    }

    /** @return array<int, string> */
    private function canvasBodyClasses(string $pageKey, string $html): array
    {
        $classes = ['rt-shell', 'theme-3', 'rt-l3-page', 'antialiased', 'lmzpb-editor-canvas'];
        $type = match ($pageKey) {
            'home' => 'is-home',
            'about' => 'is-about',
            'services' => 'is-services',
            'contact' => 'is-contact',
            'careers' => 'is-careers',
            'legal', 'privacy' => 'is-legal',
            default => null,
        };

        if ($type === null) {
            $type = match (true) {
                str_contains($html, 'sa-main') => 'is-home',
                str_contains($html, 'rt-careers') => 'is-careers',
                str_contains($html, 'rt-x__buehne') => 'is-services',
                str_contains($html, 'rt-x__formular') => 'is-contact',
                str_contains($html, 'rt-x__recht') => 'is-legal',
                str_contains($html, 'rt-x__stapel') => 'is-about',
                default => 'is-subpage',
            };
        }

        if ($type !== 'is-home') {
            $classes[] = 'is-subpage';
        }
        $classes[] = $type;

        return $classes;
    }
}
