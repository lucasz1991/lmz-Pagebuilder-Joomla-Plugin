<?php

namespace LMZ\Component\Lmzpagebuilder\Administrator\View\Element;

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use Joomla\CMS\Session\Session;
use Joomla\CMS\Uri\Uri;
use Joomla\Database\DatabaseInterface;
use LMZ\Component\Lmzpagebuilder\Administrator\Service\SharedElementService;

final class HtmlView extends BaseHtmlView
{
    /** @var array<string, mixed> */
    public array $item = [];

    /** @var array<string, mixed> */
    public array $element = [];

    /** @var array<int, array<string, mixed>> */
    public array $languageOptions = [];

    public ?string $error = null;

    public function display($tpl = null): void
    {
        $app = Factory::getApplication();
        $elementId = $app->getInput()->getInt('element_id');
        $requestedLanguage = trim($app->getInput()->getString('language', ''));
        $service = new SharedElementService(
            Factory::getContainer()->get(DatabaseInterface::class),
            $app->getIdentity()
        );

        try {
            foreach ($service->listElements() as $element) {
                if ((int) $element['id'] === $elementId) {
                    $this->element = $element;
                    break;
                }
            }

            if ($this->element === []) {
                throw new \RuntimeException('Das gespeicherte Element wurde nicht gefunden.', 404);
            }

            $variants = is_array($this->element['variants'] ?? null) ? $this->element['variants'] : [];
            if ($requestedLanguage === '' || !isset($variants[$requestedLanguage])) {
                $requestedLanguage = (string) array_key_first($variants);
            }
            if ($requestedLanguage === '') {
                throw new \RuntimeException('Das gespeicherte Element besitzt noch keine Sprachvariante.', 404);
            }

            $this->item = $service->acquire($elementId, $requestedLanguage);
            $currentLanguage = (string) $this->item['language'];
            foreach ($this->element['available_languages'] as $language) {
                $code = (string) $language['code'];
                $variant = is_array($variants[$code] ?? null) ? $variants[$code] : null;
                $this->languageOptions[] = [
                    'code' => $code,
                    'title' => (string) ($language['native_title'] ?: $language['title']),
                    'active' => $code === $currentLanguage,
                    'exists' => $variant !== null,
                    'editor_url' => $variant === null ? '' : 'index.php?option=com_lmzpagebuilder&view=element&element_id=' . $elementId
                        . '&language=' . rawurlencode($code) . '&tmpl=component',
                ];
            }
        } catch (\Throwable $error) {
            if ($this->item !== []) {
                try {
                    $service->release(
                        (int) $this->item['id'],
                        (string) $this->item['checkout_token']
                    );
                } catch (\Throwable $releaseError) {
                    // Preserve the original editor error. The configured lease
                    // timeout remains the safe recovery path for release errors.
                }
            }

            $this->item = [];
            $this->error = $error->getMessage();
        }

        $root = rtrim(Uri::root(), '/');
        $media = $root . '/media/com_lmzpagebuilder';
        $templateCss = [
            'tailwind.min.css',
            'design-system.css',
            'layout-polish.css',
            'logo-3d.css',
            'layout.css',
            'motion-stability.css',
            'brand-lockup.css',
            'mobile-navigation.css',
            'joomla-integration.css',
            'rt-motion.css',
            'rt-footer.css',
            'rt-language.css',
            'rt-germany-map.css',
            'home-first-segment.css',
            'rt-system.css',
            'rt-about.css',
            'rt-services.css',
            'rt-contact.css',
            'rt-careers.css',
            'rt-process.css',
            'signal-atlas.css',
            'signal-atlas-tune.css',
        ];
        $canvasStyles = array_map(
            static fn (string $file): string => $root . '/templates/lmz_builder/l3/css/' . $file,
            $templateCss
        );
        $canvasScripts = [
            $root . '/templates/lmz_builder/l3/js/vendor/gsap.min.js?v=2.4.5-20260804',
            $root . '/templates/lmz_builder/l3/js/vendor/ScrollTrigger.min.js?v=2.4.5-20260804',
            $root . '/templates/lmz_builder/l3/js/vendor/SplitText.min.js?v=2.4.5-20260804',
            $media . '/js/lmz-motion-runtime.js?v=2.4.5-20260804',
            $media . '/js/editor-canvas-media.js?v=2.4.5-20260806',
        ];

        $document = $app->getDocument();
        $document->getWebAssetManager()
            ->useStyle('com_lmzpagebuilder.admin')
            ->useStyle('com_lmzpagebuilder.grapesjs')
            ->useStyle('com_lmzpagebuilder.builder')
            ->useScript('com_lmzpagebuilder.grapesjs')
            ->useScript('com_lmzpagebuilder.builder')
            ->useScript('com_lmzpagebuilder.editor');

        if ($this->item !== []) {
            $document->addScriptOptions('com_lmzpagebuilder.editor', [
                'entityType' => 'element',
                'documentId' => (int) $this->item['id'],
                'elementId' => (int) $this->item['element_id'],
                'title' => (string) $this->item['title'],
                'sourceHash' => (string) $this->item['published_hash'],
                'draftHash' => (string) $this->item['draft_hash'],
                'leaseToken' => (string) $this->item['checkout_token'],
                'csrfToken' => Session::getFormToken(),
                'rootUrl' => $root,
                'canvasBaseUrl' => $root . '/',
                'assets' => [
                    'grapesJs' => $media . '/js/grapesjs.js',
                    'grapesCss' => $media . '/css/grapesjs.css',
                ],
                'canvasStyles' => $canvasStyles,
                'canvasScripts' => $canvasScripts,
                'canvasBodyClasses' => ['rt-shell', 'theme-3', 'rt-l3-page', 'antialiased', 'lmzpb-editor-canvas', 'lmzpb-shared-element-canvas'],
                'language' => (string) $this->item['language'],
                'canvasLanguage' => (string) $this->item['language'],
                'motion' => [
                    'enabled' => true,
                    'preview' => true,
                    'debounceMs' => 140,
                    'respectReducedMotion' => true,
                ],
                'endpoints' => [
                    'load' => 'index.php?option=com_lmzpagebuilder&task=project.loadElement&format=json&id=' . (int) $this->item['id'],
                    'save' => 'index.php?option=com_lmzpagebuilder&task=project.saveElement&format=json',
                    'publish' => 'index.php?option=com_lmzpagebuilder&task=project.publishElement&format=json',
                    'touch' => 'index.php?option=com_lmzpagebuilder&task=project.touchElement&format=json',
                    'release' => 'index.php?option=com_lmzpagebuilder&task=project.releaseElement&format=json',
                    'usages' => 'index.php?option=com_lmzpagebuilder&task=project.elementUsages&format=json&element_id=' . (int) $this->item['element_id'],
                    'assets' => 'index.php?option=com_lmzpagebuilder&task=project.assets&format=json',
                    'upload' => 'index.php?option=com_lmzpagebuilder&task=project.upload&format=json',
                    'embeds' => 'index.php?option=com_lmzpagebuilder&task=project.embeds&format=json',
                    'elements' => 'index.php?option=com_lmzpagebuilder&task=project.elements&format=json',
                    'createTranslation' => 'index.php?option=com_lmzpagebuilder&task=project.createElementTranslation&format=json',
                ],
                'labels' => [
                    'loading' => Text::_('COM_LMZPAGEBUILDER_EDITOR_LOADING'),
                    'ready' => Text::_('COM_LMZPAGEBUILDER_EDITOR_READY'),
                    'saving' => Text::_('COM_LMZPAGEBUILDER_EDITOR_SAVING'),
                    'saved' => Text::_('COM_LMZPAGEBUILDER_EDITOR_SAVED'),
                    'publishing' => Text::_('COM_LMZPAGEBUILDER_ELEMENT_PUBLISHING'),
                    'published' => Text::_('COM_LMZPAGEBUILDER_ELEMENT_PUBLISHED'),
                    'failed' => Text::_('COM_LMZPAGEBUILDER_REQUEST_FAILED'),
                    'publishNote' => Text::_('COM_LMZPAGEBUILDER_PUBLISH_NOTE_PROMPT'),
                ],
            ]);
        }

        parent::display($tpl);
    }
}
