<?php

namespace LMZ\Component\Lmzpagebuilder\Administrator\View\Projects;

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use Joomla\CMS\Session\Session;
use Joomla\CMS\Toolbar\ToolbarHelper;
use Joomla\Database\DatabaseInterface;
use LMZ\Component\Lmzpagebuilder\Administrator\Service\PageBuilderService;
use LMZ\Component\Lmzpagebuilder\Administrator\Service\SharedElementService;

final class HtmlView extends BaseHtmlView
{
    /** @var array<int, array<string, mixed>> */
    public array $items = [];

    /** @var array<int, array<string, mixed>> */
    public array $elements = [];

    /** @var array<int, array<string, mixed>> */
    public array $languages = [];

    public function display($tpl = null): void
    {
        $app = Factory::getApplication();
        $service = new PageBuilderService(
            Factory::getContainer()->get(DatabaseInterface::class),
            $app->getIdentity()
        );
        $this->items = $service->listPages();
        $this->languages = $service->listLanguages();
        $this->elements = (new SharedElementService(
            Factory::getContainer()->get(DatabaseInterface::class),
            $app->getIdentity()
        ))->listElements();
        $document = $app->getDocument();
        $document->getWebAssetManager()
            ->useStyle('com_lmzpagebuilder.admin')
            ->useScript('com_lmzpagebuilder.projects');
        $document->addScriptOptions('com_lmzpagebuilder.projects', [
            'csrfToken' => Session::getFormToken(),
            'endpoints' => [
                'release' => 'index.php?option=com_lmzpagebuilder&task=project.release&format=json',
                'languages' => 'index.php?option=com_lmzpagebuilder&task=project.languages&format=json',
                'createTranslation' => 'index.php?option=com_lmzpagebuilder&task=project.createTranslation&format=json',
                'createElement' => 'index.php?option=com_lmzpagebuilder&task=project.createElement&format=json',
                'createElementTranslation' => 'index.php?option=com_lmzpagebuilder&task=project.createElementTranslation&format=json',
            ],
            'labels' => [
                'working' => Text::_('COM_LMZPAGEBUILDER_WORKING'),
                'failed' => Text::_('COM_LMZPAGEBUILDER_REQUEST_FAILED'),
                'imported' => Text::_('COM_LMZPAGEBUILDER_IMPORT_COMPLETE'),
                'titleRequired' => Text::_('COM_LMZPAGEBUILDER_TITLE_REQUIRED'),
                'languageRequired' => Text::_('COM_LMZPAGEBUILDER_LANGUAGE_REQUIRED'),
            ],
        ]);

        ToolbarHelper::title(Text::_('COM_LMZPAGEBUILDER'), 'grid-2');
        ToolbarHelper::preferences('com_lmzpagebuilder');
        parent::display($tpl);
    }
}
