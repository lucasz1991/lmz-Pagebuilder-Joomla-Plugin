<?php

/**
 * @package     LMZ.Component
 * @subpackage  com_lmzpagebuilder
 *
 * @copyright   (C) 2026 LMZ Media. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

declare(strict_types=1);

namespace LMZ\Component\Lmzpagebuilder\Administrator\Service\Ai;

defined('_JEXEC') or die;

use RuntimeException;
use Throwable;

/**
 * Fehler der OpenRouter-Anbindung. Die Meldung ist immer einer der stabilen
 * Fehlerschluessel aus OpenRouterClient::FEHLER_* - sie wird nie ungefiltert
 * an die Oberflaeche gereicht, damit keine Schluessel oder Upstream-Details
 * nach aussen gelangen.
 */
final class OpenRouterException extends RuntimeException
{
    /** HTTP-Status der Upstream-Antwort, sofern vorhanden. */
    private int $httpStatus;

    public function __construct(string $schluessel, int $httpStatus = 0, ?Throwable $previous = null)
    {
        parent::__construct($schluessel, 0, $previous);

        $this->httpStatus = $httpStatus;
    }

    public function schluessel(): string
    {
        return $this->getMessage();
    }

    public function httpStatus(): int
    {
        return $this->httpStatus;
    }
}
