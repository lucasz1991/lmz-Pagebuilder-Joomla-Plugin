<?php

/**
 * @package     LMZ.Component
 * @subpackage  com_lmzpagebuilder
 *
 * @copyright   (C) 2026 LMZ Media. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

declare(strict_types=1);

namespace LMZ\Component\Lmzpagebuilder\Administrator\Service\Ai;

defined('_JEXEC') or die;

use Joomla\CMS\Component\ComponentHelper;
use Throwable;

/**
 * Liest die Assistenz-Konfiguration aus den Komponenteneinstellungen und
 * liefert geprüfte Werte mit sicheren Vorgaben.
 *
 * Zwei Zugänge auf dieselben Daten:
 *  - static laden(): array   – der Schnittstellenvertrag der KI-Steuerung
 *    (feste deutsche Schlüssel, von Controllern und Werkzeugen genutzt).
 *  - die Instanzmethoden     – feingranularer Zugriff für Dienste, die nur
 *    einen einzelnen Wert brauchen.
 *
 * Zum API-Schlüssel: Joomla legt Komponenten-Params unverschlüsselt in
 * #__extensions ab. Wer den Schlüssel nicht in der Datenbank haben möchte,
 * definiert stattdessen die Konstante LMZ_OPENROUTER_KEY (oder
 * LMZ_OPENROUTER_API_KEY) in configuration.php oder setzt die gleichnamige
 * Umgebungsvariable. Beide haben Vorrang vor dem gespeicherten Wert.
 */
final class AssistantSettings
{
    /** Namen von Konstante und Umgebungsvariable für den API-Schlüssel, in dieser Reihenfolge. */
    public const KEY_KONSTANTEN = ['LMZ_OPENROUTER_KEY', 'LMZ_OPENROUTER_API_KEY'];

    /** Nur diese Hosts dürfen als Endpunkt dienen. */
    public const ERLAUBTE_HOSTS = ['openrouter.ai'];

    public const STANDARD_BASIS_URL = 'https://openrouter.ai/api/v1';

    public const STANDARD_MODELL = 'openai/gpt-4o-mini';

    public const STANDARD_PROMPT_ADMIN = 'Du bist die Redaktionsassistenz des LMZ Page Builders der RT Rail Time GmbH. '
        . 'Du hilfst beim Anlegen, Ändern und Übersetzen von Seiten. Antworte kurz, sachlich und auf Deutsch. '
        . 'Ändernde Schritte schlägst du zuerst als Vorschau vor; ausgeführt werden sie erst nach ausdrücklicher '
        . 'Bestätigung durch die Redaktion. Erfinde keine Inhalte, Zahlen oder Kontaktdaten.';

    public const STANDARD_PROMPT_SITE = 'Du bist der Website-Assistent der RT Rail Time GmbH. '
        . 'Du beantwortest Besucherfragen zu Leistungen, Standorten und Kontaktwegen ausschliesslich auf Basis der '
        . 'veröffentlichten Website-Inhalte. Antworte kurz, freundlich und in der Sprache der Frage. '
        . 'Wenn du etwas nicht weisst, verweise auf das Kontaktformular. Du gibst keine Preise oder Zusagen ab.';

    /** @var array<string, mixed> */
    private array $params;

    /** @var array<string, mixed>|null */
    private static ?array $zwischenspeicher = null;

    /** @param array<string, mixed>|null $params */
    public function __construct(?array $params = null)
    {
        $this->params = $params ?? self::paramsLesen();
    }

    /* --- Schnittstellenvertrag ------------------------------------------ */

    /**
     * Die Einstellungen der Assistenz als festes Array.
     *
     * @param  bool  $neuLaden  Zwischenspeicher umgehen (nach dem Speichern der Konfiguration).
     *
     * @return array<string, mixed>
     */
    public static function laden(bool $neuLaden = false): array
    {
        if (!$neuLaden && self::$zwischenspeicher !== null) {
            return self::$zwischenspeicher;
        }

        $e = new self();

        return self::$zwischenspeicher = [
            // Der OpenRouter-Hauptschalter deckelt beide Oberflächen.
            'aktiv_admin' => $e->adminAssistentAktiv(),
            'aktiv_site'  => $e->websiteChatbotAktiv(),

            'api_key'   => $e->apiSchluessel(),
            'basis_url' => $e->basisUrl(),

            'modell_admin' => $e->modell('admin'),
            'modell_site'  => $e->modell('site'),

            'system_prompt_admin' => $e->systemAnweisung('admin') ?: self::STANDARD_PROMPT_ADMIN,
            'system_prompt_site'  => $e->systemAnweisung('site') ?: self::STANDARD_PROMPT_SITE,

            'rate_limit' => $e->anfragenProMinute(),
            'max_tokens' => $e->maximaleToken(),

            'schreiben_bestaetigen' => $e->aenderungBestaetigen(),

            // Zusatzangaben für den OpenRouterClient (Header und Endpunktprüfung).
            'referer'        => $e->referer(),
            'titel'          => $e->titel() ?: 'RT Rail Time GmbH',
            'erlaubte_hosts' => self::ERLAUBTE_HOSTS,
        ];
    }

    /** Zwischenspeicher verwerfen (Tests, Konfigurationsspeicherung). */
    public static function zuruecksetzen(): void
    {
        self::$zwischenspeicher = null;
    }

    /**
     * Ist die Assistenz für den Bereich betriebsbereit (aktiv und Schlüssel vorhanden)?
     *
     * @param  string  $bereich  'admin' oder 'site'
     */
    public static function betriebsbereit(string $bereich): bool
    {
        $e = self::laden();

        return (bool) ($bereich === 'site' ? $e['aktiv_site'] : $e['aktiv_admin']);
    }

    /* --- Verbindung ----------------------------------------------------- */

    public function openRouterAktiv(): bool
    {
        return (int) ($this->params['openrouter_enabled'] ?? 0) === 1;
    }

    /**
     * Der API-Schlüssel. Reihenfolge: Konstante, Umgebungsvariable,
     * Komponenteneinstellung.
     */
    public function apiSchluessel(): string
    {
        foreach (self::KEY_KONSTANTEN as $name) {
            if (\defined($name)) {
                $ausKonstante = self::alsText(\constant($name));

                if ($ausKonstante !== '') {
                    return $ausKonstante;
                }
            }
        }

        foreach (self::KEY_KONSTANTEN as $name) {
            $ausUmgebung = self::alsText(getenv($name));

            if ($ausUmgebung !== '') {
                return $ausUmgebung;
            }
        }

        return self::alsText($this->params['openrouter_api_key'] ?? '');
    }

    /**
     * Die Basis-URL der API. Nur Hosts aus ERLAUBTE_HOSTS werden akzeptiert;
     * bei allem anderen greift die Vorgabe. So kann eine versehentlich oder
     * böswillig gesetzte Basis-URL den Schlüssel nicht abfliessen lassen.
     */
    public function basisUrl(): string
    {
        $basis = self::alsText($this->params['openrouter_base_url'] ?? '');

        if ($basis === '' || !$this->hostErlaubt($basis)) {
            $basis = self::STANDARD_BASIS_URL;
        }

        return rtrim($basis, '/');
    }

    /** Der vollständige Chat-Endpunkt. */
    public function chatEndpunkt(): string
    {
        return $this->basisUrl() . '/chat/completions';
    }

    public function hostErlaubt(string $url): bool
    {
        $teile = parse_url($url);

        if (
            !\is_array($teile)
            || ($teile['scheme'] ?? '') !== 'https'
            || !isset($teile['host'])
            || isset($teile['user'])
            || isset($teile['pass'])
            || isset($teile['fragment'])
        ) {
            return false;
        }

        return \in_array(strtolower($teile['host']), self::ERLAUBTE_HOSTS, true);
    }

    public function referer(): string
    {
        return self::alsText($this->params['openrouter_site_url'] ?? '');
    }

    public function titel(): string
    {
        return self::alsText($this->params['openrouter_site_title'] ?? '');
    }

    /* --- Oberflächen ---------------------------------------------------- */

    public function adminAssistentAktiv(): bool
    {
        return $this->openRouterAktiv()
            && $this->apiSchluessel() !== ''
            && (int) ($this->params['assistant_admin_enabled'] ?? 1) === 1;
    }

    /** Der öffentliche Chatbot ist bewusst standardmäßig aus. */
    public function websiteChatbotAktiv(): bool
    {
        return $this->openRouterAktiv()
            && $this->apiSchluessel() !== ''
            && (int) ($this->params['assistant_site_enabled'] ?? 0) === 1;
    }

    /** @param string $bereich 'admin' oder 'site' */
    public function modell(string $bereich = 'admin'): string
    {
        $bereich = $bereich === 'site' ? 'site' : 'admin';

        $spezifisch = self::alsText($this->params['assistant_model_' . $bereich] ?? '');

        if ($spezifisch !== '') {
            return $spezifisch;
        }

        if ($bereich === 'site') {
            $vomAdmin = self::alsText($this->params['assistant_model_admin'] ?? '');

            if ($vomAdmin !== '') {
                return $vomAdmin;
            }
        }

        $standard = self::alsText($this->params['openrouter_model'] ?? '');

        return $standard !== '' ? $standard : self::STANDARD_MODELL;
    }

    /** @param string $bereich 'admin' oder 'site' */
    public function systemAnweisung(string $bereich = 'admin'): string
    {
        $bereich = $bereich === 'site' ? 'site' : 'admin';

        return trim((string) ($this->params['assistant_system_prompt_' . $bereich] ?? ''));
    }

    /* --- Schutzgrenzen -------------------------------------------------- */

    public function anfragenProMinute(): int
    {
        return max(1, min(600, (int) ($this->params['assistant_rate_limit'] ?? 30)));
    }

    public function maximaleToken(): int
    {
        return max(128, min(32000, (int) ($this->params['assistant_max_tokens'] ?? 2000)));
    }

    /**
     * Schreibende Aktionen brauchen eine Bestätigung. Bewusst als "nur wenn
     * ausdrücklich abgeschaltet" formuliert: fehlt der Wert, wird bestätigt.
     */
    public function aenderungBestaetigen(): bool
    {
        return (int) ($this->params['assistant_write_requires_confirm'] ?? 1) === 1;
    }

    /**
     * Kurzfassung für Oberflächen und Diagnose. Enthält bewusst NIE den
     * Schlüssel selbst, nur ob einer vorhanden ist und woher er stammt.
     *
     * @return array<string, mixed>
     */
    public function diagnose(): array
    {
        $quelle = 'keiner';

        foreach (self::KEY_KONSTANTEN as $name) {
            if (\defined($name) && self::alsText(\constant($name)) !== '') {
                $quelle = 'Konstante';
                break;
            }

            if (self::alsText(getenv($name)) !== '') {
                $quelle = 'Umgebungsvariable';
                break;
            }
        }

        if ($quelle === 'keiner' && self::alsText($this->params['openrouter_api_key'] ?? '') !== '') {
            $quelle = 'Komponenteneinstellung';
        }

        return [
            'openrouter_aktiv'      => $this->openRouterAktiv(),
            'schluessel_vorhanden'  => $this->apiSchluessel() !== '',
            'schluessel_quelle'     => $quelle,
            'endpunkt'              => $this->chatEndpunkt(),
            'modell_admin'          => $this->modell('admin'),
            'modell_site'           => $this->modell('site'),
            'admin_assistent'       => $this->adminAssistentAktiv(),
            'website_chatbot'       => $this->websiteChatbotAktiv(),
            'anfragen_pro_minute'   => $this->anfragenProMinute(),
            'maximale_token'        => $this->maximaleToken(),
            'aenderung_bestaetigen' => $this->aenderungBestaetigen(),
        ];
    }

    /* --- Hilfen --------------------------------------------------------- */

    /** @return array<string, mixed> */
    private static function paramsLesen(): array
    {
        try {
            return ComponentHelper::getParams('com_lmzpagebuilder')->toArray();
        } catch (Throwable) {
            // Ohne geladene Joomla-Anwendung greifen ausschliesslich die Vorgaben.
            return [];
        }
    }

    /**
     * Text säubern. Steuerzeichen fliegen raus - ein Schlüssel mit
     * Zeilenumbruch würde sonst den HTTP-Header zerlegen.
     */
    private static function alsText(mixed $wert): string
    {
        if (!\is_scalar($wert)) {
            return '';
        }

        return trim(preg_replace('/[\x00-\x1F\x7F]/u', '', (string) $wert) ?? '');
    }
}
