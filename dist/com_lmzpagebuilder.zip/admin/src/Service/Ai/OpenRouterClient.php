<?php

/**
 * @package     LMZ.Component
 * @subpackage  com_lmzpagebuilder
 *
 * @copyright   (C) 2026 LMZ Media. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

declare(strict_types=1);

namespace LMZ\Component\Lmzpagebuilder\Administrator\Service\Ai;

defined('_JEXEC') or die;

use Joomla\CMS\Http\Http;
use Joomla\CMS\Http\HttpFactory;
use Throwable;

/**
 * Schmale OpenRouter-Anbindung nach dem Vorbild der RailTime-App
 * (App/app/Services/Ai/OpenRouterChatClient).
 *
 * Grundsaetze:
 *  - Der Endpunkt wird gegen eine Whitelist geprueft (nur https, nur erlaubte
 *    Hosts, keine Zugangsdaten in der URL) - sonst 'endpoint_not_allowed'.
 *  - Es wird niemals umgeleitet gefolgt; sonst koennte ein manipulierter
 *    Basis-URL den Authorization-Header an einen fremden Host tragen.
 *  - chat() wirft nichts nach aussen, sondern liefert immer das im
 *    Schnittstellenvertrag festgelegte Array mit einem stabilen Fehlerschluessel.
 */
final class OpenRouterClient
{
    public const FEHLER_NICHT_KONFIGURIERT = 'nicht_konfiguriert';
    public const FEHLER_ENDPUNKT           = 'endpoint_not_allowed';
    public const FEHLER_TRANSPORT          = 'transportfehler';
    public const FEHLER_ZEITUEBERSCHREITUNG = 'zeitueberschreitung';
    public const FEHLER_HTTP               = 'http_fehler';
    public const FEHLER_JSON               = 'ungueltiges_json';
    public const FEHLER_ZU_GROSS           = 'antwort_zu_gross';
    public const FEHLER_LEER               = 'leere_antwort';
    public const FEHLER_UPSTREAM           = 'upstream_fehler';

    /** Sekunden bis zum Abbruch einer Anfrage. */
    private const STANDARD_TIMEOUT = 45;

    private const MIN_TIMEOUT = 5;

    private const MAX_TIMEOUT = 120;

    /** Obergrenze fuer den Antwortkoerper (4 MB) - schuetzt den Speicher. */
    private const MAX_ANTWORT_BYTES = 4194304;

    /** Obergrenze fuer die Argumente eines einzelnen Werkzeugaufrufs. */
    private const MAX_ARGUMENT_BYTES = 20000;

    /** @var array<string, mixed> */
    private array $einstellungen;

    private ?Http $http;

    /**
     * @param  array<string, mixed>|null  $einstellungen  Standard: AssistantSettings::laden()
     * @param  Http|null                  $http           Nur fuer Tests uebergeben.
     */
    public function __construct(?array $einstellungen = null, ?Http $http = null)
    {
        $this->einstellungen = $einstellungen ?? AssistantSettings::laden();
        $this->http          = $http;
    }

    /**
     * Ist die Anbindung grundsaetzlich benutzbar (Schluessel, Modell, erlaubter Endpunkt)?
     */
    public function istKonfiguriert(): bool
    {
        if ($this->apiSchluessel() === '') {
            return false;
        }

        try {
            $this->validierterEndpunkt();
        } catch (OpenRouterException) {
            return false;
        }

        return true;
    }

    /**
     * Eine Chat-Vervollstaendigung anfordern.
     *
     * @param  array<int, array<string, mixed>>  $nachrichten  Rollen/Inhalte im OpenAI-Format.
     * @param  array<string, mixed>              $optionen     modell, max_tokens, temperatur,
     *                                                         werkzeuge (tools), werkzeug_wahl
     *                                                         (tool_choice), timeout, bereich.
     *
     * @return array{inhalt: string, werkzeugaufrufe: array<int, array<string, mixed>>, roh: array<string, mixed>, fehler: string|null}
     */
    public function chat(array $nachrichten, array $optionen = []): array
    {
        try {
            return $this->anfrageSenden($nachrichten, $optionen);
        } catch (OpenRouterException $e) {
            return $this->fehlerAntwort($e->schluessel());
        } catch (Throwable) {
            return $this->fehlerAntwort(self::FEHLER_TRANSPORT);
        }
    }

    /**
     * @param  array<int, array<string, mixed>>  $nachrichten
     * @param  array<string, mixed>              $optionen
     *
     * @return array{inhalt: string, werkzeugaufrufe: array<int, array<string, mixed>>, roh: array<string, mixed>, fehler: string|null}
     */
    private function anfrageSenden(array $nachrichten, array $optionen): array
    {
        $endpunkt   = $this->validierterEndpunkt();
        $schluessel = $this->apiSchluessel();
        $modell     = $this->modell($optionen);

        if ($schluessel === '' || $modell === '' || $nachrichten === []) {
            throw new OpenRouterException(self::FEHLER_NICHT_KONFIGURIERT);
        }

        $nutzlast = [
            'model'    => $modell,
            'messages' => array_values($nachrichten),
            'stream'   => false,
            'max_tokens' => $this->maxTokens($optionen),
        ];

        $temperatur = $optionen['temperatur'] ?? $optionen['temperature'] ?? null;

        if (is_numeric($temperatur)) {
            $nutzlast['temperature'] = max(0.0, min(2.0, (float) $temperatur));
        }

        $werkzeuge = $optionen['werkzeuge'] ?? $optionen['tools'] ?? [];

        if (\is_array($werkzeuge) && $werkzeuge !== []) {
            $nutzlast['tools']                = array_values($werkzeuge);
            $nutzlast['tool_choice']          = $optionen['werkzeug_wahl'] ?? $optionen['tool_choice'] ?? 'auto';
            $nutzlast['parallel_tool_calls']  = false;
        }

        $json = json_encode($nutzlast, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);

        if ($json === false) {
            throw new OpenRouterException(self::FEHLER_JSON);
        }

        $timeout = $this->timeout($optionen);

        try {
            $antwort = $this->http($timeout)->post($endpunkt, $json, $this->header($schluessel), $timeout);
        } catch (Throwable $e) {
            $meldung = strtolower($e->getMessage());

            if (str_contains($meldung, 'timed out') || str_contains($meldung, 'timeout')) {
                throw new OpenRouterException(self::FEHLER_ZEITUEBERSCHREITUNG, 0, $e);
            }

            throw new OpenRouterException(self::FEHLER_TRANSPORT, 0, $e);
        }

        $status = (int) $antwort->getStatusCode();
        $koerper = (string) $antwort->getBody();

        if (\strlen($koerper) > self::MAX_ANTWORT_BYTES) {
            throw new OpenRouterException(self::FEHLER_ZU_GROSS, $status);
        }

        if ($status < 200 || $status >= 300) {
            throw new OpenRouterException(self::FEHLER_HTTP, $status);
        }

        $roh = json_decode($koerper, true);

        if (!\is_array($roh)) {
            throw new OpenRouterException(self::FEHLER_JSON, $status);
        }

        if (isset($roh['error'])) {
            throw new OpenRouterException(self::FEHLER_UPSTREAM, $status);
        }

        $meldung = $roh['choices'][0]['message'] ?? null;

        if (!\is_array($meldung)) {
            throw new OpenRouterException(self::FEHLER_LEER, $status);
        }

        $inhalt          = \is_string($meldung['content'] ?? null) ? trim($meldung['content']) : '';
        $werkzeugaufrufe = $this->werkzeugaufrufe($meldung['tool_calls'] ?? []);

        if ($inhalt === '' && $werkzeugaufrufe === []) {
            throw new OpenRouterException(self::FEHLER_LEER, $status);
        }

        return [
            'inhalt'          => $inhalt,
            'werkzeugaufrufe' => $werkzeugaufrufe,
            'roh'             => $roh,
            'fehler'          => null,
        ];
    }

    /**
     * Endpunktpruefung wie im App-Vorbild: nur https, nur freigegebene Hosts,
     * keine Benutzerdaten und kein Fragment in der URL.
     *
     * @throws OpenRouterException 'endpoint_not_allowed'
     */
    public function validierterEndpunkt(): string
    {
        $basis = trim((string) ($this->einstellungen['basis_url'] ?? ''));

        if ($basis === '') {
            $basis = AssistantSettings::STANDARD_BASIS_URL;
        }

        $endpunkt = rtrim($basis, '/') . '/chat/completions';
        $teile    = parse_url($endpunkt);

        if (!\is_array($teile)) {
            throw new OpenRouterException(self::FEHLER_ENDPUNKT);
        }

        $hosts = $this->einstellungen['erlaubte_hosts'] ?? AssistantSettings::ERLAUBTE_HOSTS;
        $hosts = \is_array($hosts) && $hosts !== [] ? array_map('strtolower', $hosts) : AssistantSettings::ERLAUBTE_HOSTS;

        $host = strtolower((string) ($teile['host'] ?? ''));

        if (
            ($teile['scheme'] ?? null) !== 'https'
            || $host === ''
            || !\in_array($host, $hosts, true)
            || isset($teile['user'])
            || isset($teile['pass'])
            || isset($teile['port'])
            || isset($teile['fragment'])
            || isset($teile['query'])
        ) {
            throw new OpenRouterException(self::FEHLER_ENDPUNKT);
        }

        return $endpunkt;
    }

    /** @return array<string, string> */
    private function header(string $schluessel): array
    {
        $header = [
            'Authorization' => 'Bearer ' . $schluessel,
            'Content-Type'  => 'application/json',
            'Accept'        => 'application/json',
            'User-Agent'    => 'LMZ-PageBuilder-Assistant/1.0',
        ];

        $referer = trim((string) ($this->einstellungen['referer'] ?? ''));

        if ($referer !== '' && \in_array(parse_url($referer, PHP_URL_SCHEME), ['http', 'https'], true)) {
            $header['HTTP-Referer'] = $referer;
        }

        $titel = trim((string) ($this->einstellungen['titel'] ?? ''));

        if ($titel !== '') {
            $header['X-Title'] = mb_substr($titel, 0, 255);
        }

        return $header;
    }

    private function http(int $timeout): Http
    {
        if ($this->http instanceof Http) {
            return $this->http;
        }

        return $this->http = HttpFactory::getHttp([
            'follow_location' => false,
            'timeout'         => $timeout,
            'userAgent'       => 'LMZ-PageBuilder-Assistant/1.0',
        ]);
    }

    private function apiSchluessel(): string
    {
        return trim((string) ($this->einstellungen['api_key'] ?? ''));
    }

    /** @param array<string, mixed> $optionen */
    private function modell(array $optionen): string
    {
        $modell = trim((string) ($optionen['modell'] ?? $optionen['model'] ?? ''));

        if ($modell !== '') {
            return $modell;
        }

        $bereich = ($optionen['bereich'] ?? 'admin') === 'site' ? 'modell_site' : 'modell_admin';

        return trim((string) ($this->einstellungen[$bereich] ?? ''));
    }

    /** @param array<string, mixed> $optionen */
    private function maxTokens(array $optionen): int
    {
        $grenze = (int) ($this->einstellungen['max_tokens'] ?? 2000);
        $grenze = max(128, min(32000, $grenze));

        $wunsch = $optionen['max_tokens'] ?? null;

        if (is_numeric($wunsch)) {
            $grenze = min($grenze, max(128, (int) $wunsch));
        }

        return $grenze;
    }

    /** @param array<string, mixed> $optionen */
    private function timeout(array $optionen): int
    {
        $wert = $optionen['timeout'] ?? null;

        if (!is_numeric($wert)) {
            return self::STANDARD_TIMEOUT;
        }

        return max(self::MIN_TIMEOUT, min(self::MAX_TIMEOUT, (int) $wert));
    }

    /**
     * Werkzeugaufrufe der Antwort auf eine strenge, erwartbare Form bringen.
     * Ausgefuehrt wird spaeter ausschliesslich ueber die BuilderToolRegistry -
     * hier findet nur die Formpruefung statt.
     *
     * @return array<int, array{id: string, type: string, function: array{name: string, arguments: string}}>
     */
    private function werkzeugaufrufe(mixed $aufrufe): array
    {
        if (!\is_array($aufrufe)) {
            return [];
        }

        $ergebnis = [];

        foreach (array_slice($aufrufe, 0, 4) as $aufruf) {
            if (!\is_array($aufruf) || !\is_array($aufruf['function'] ?? null)) {
                continue;
            }

            $id        = trim((string) ($aufruf['id'] ?? ''));
            $name      = trim((string) ($aufruf['function']['name'] ?? ''));
            $argumente = (string) ($aufruf['function']['arguments'] ?? '');

            if (
                $id === ''
                || mb_strlen($id) > 255
                || preg_match('/[\x00-\x20\x7F]/', $id) === 1
                || preg_match('/^[A-Za-z0-9_.:-]{1,120}$/', $name) !== 1
                || \strlen($argumente) > self::MAX_ARGUMENT_BYTES
            ) {
                continue;
            }

            $ergebnis[] = [
                'id'       => $id,
                'type'     => 'function',
                'function' => [
                    'name'      => $name,
                    'arguments' => $argumente,
                ],
            ];
        }

        return $ergebnis;
    }

    /**
     * @return array{inhalt: string, werkzeugaufrufe: array<int, array<string, mixed>>, roh: array<string, mixed>, fehler: string}
     */
    private function fehlerAntwort(string $schluessel): array
    {
        return [
            'inhalt'          => '',
            'werkzeugaufrufe' => [],
            'roh'             => [],
            'fehler'          => $schluessel,
        ];
    }
}
