<?php

namespace LMZ\Component\Lmzpagebuilder\Administrator\Service;

defined('_JEXEC') or die;

use DOMDocument;
use DOMElement;
use DOMNode;
use RuntimeException;

final class HtmlSanitizer
{
    private const BLOCKED_ELEMENTS = [
        'script', 'iframe', 'frame', 'frameset', 'object', 'embed', 'applet',
        'base', 'meta', 'link', 'portal', 'xmp', 'plaintext',
        // Keep passive SVG artwork, but remove elements that can load or execute
        // nested active content.
        'foreignobject', 'animate', 'animatemotion', 'animatetransform', 'set', 'discard',
    ];

    private const URL_ATTRIBUTES = [
        'action', 'background', 'cite', 'data', 'formaction', 'href', 'longdesc',
        'poster', 'src', 'usemap', 'xlink:href',
    ];

    public function sanitizeHtml(string $html): string
    {
        if (strpos($html, "\0") !== false) {
            throw new RuntimeException('HTML contains an invalid null byte.', 422);
        }

        $dom = new DOMDocument('1.0', 'UTF-8');
        $previousErrors = libxml_use_internal_errors(true);
        $loaded = $dom->loadHTML(
            '<!DOCTYPE html><html><head><meta charset="utf-8"></head><body>' . $html . '</body></html>',
            LIBXML_HTML_NODEFDTD | LIBXML_NOERROR | LIBXML_NOWARNING | LIBXML_NONET | LIBXML_COMPACT
        );
        libxml_clear_errors();
        libxml_use_internal_errors($previousErrors);

        if (!$loaded) {
            throw new RuntimeException('HTML could not be parsed safely.', 422);
        }

        $body = $dom->getElementsByTagName('body')->item(0);
        if (!$body instanceof DOMElement) {
            throw new RuntimeException('HTML body could not be parsed safely.', 422);
        }

        $this->sanitizeChildren($body);
        $safe = '';

        foreach ($this->childNodes($body) as $child) {
            $encoded = $dom->saveHTML($child);
            if (is_string($encoded)) {
                $safe .= $encoded;
            }
        }

        return trim($safe);
    }

    public function sanitizeCss(string $css, bool $inline = false): string
    {
        if (strpos($css, "\0") !== false) {
            throw new RuntimeException('CSS contains an invalid null byte.', 422);
        }

        if (preg_match('~</?\s*(?:style|script)\b~i', $css)) {
            throw new RuntimeException('CSS contains an unsafe markup boundary.', 422);
        }

        $inspection = preg_replace('~/\*.*?\*/~s', '', $css) ?? $css;
        $inspection = $this->decodeCssEscapes($inspection);
        $compact = strtolower(preg_replace('/[\x00-\x20\x7f]+/u', '', $inspection) ?? '');

        if (preg_match('~@(?:import|charset|namespace)\b|expression\(|(?:^|[;{])behavior:|-moz-binding:|javascript:|vbscript:|data:text/html|data:application/(?:xhtml\+xml|xml)~i', $compact)) {
            throw new RuntimeException('CSS contains an unsafe executable construct.', 422);
        }

        if ($inline && strpbrk($css, '{}') !== false) {
            throw new RuntimeException('Inline CSS must not contain a rule block.', 422);
        }

        $css = preg_replace_callback(
            '~url\s*\(\s*((?:"[^"]*"|\'[^\']*\'|[^)]*))\s*\)~iu',
            function (array $match): string {
                $url = trim($match[1]);
                if (($url[0] ?? '') === '"' || ($url[0] ?? '') === "'") {
                    $url = substr($url, 1, -1);
                }

                if (!$this->isSafeUrl($url, 'css')) {
                    throw new RuntimeException('CSS contains an unsafe URL.', 422);
                }

                return $match[0];
            },
            $css
        );

        if (!is_string($css)) {
            throw new RuntimeException('CSS could not be sanitized.', 422);
        }

        return trim($css);
    }

    private function sanitizeChildren(DOMNode $parent): void
    {
        foreach ($this->childNodes($parent) as $child) {
            if (!$child instanceof DOMElement) {
                continue;
            }

            $tag = strtolower($child->tagName);
            if (in_array($tag, self::BLOCKED_ELEMENTS, true)) {
                $parent->removeChild($child);
                continue;
            }

            $this->sanitizeElement($child);
            $this->sanitizeChildren($child);
        }
    }

    private function sanitizeElement(DOMElement $element): void
    {
        $names = [];
        foreach ($element->attributes as $attribute) {
            $names[] = $attribute->nodeName;
        }

        foreach ($names as $name) {
            $normalized = strtolower($name);
            $value = $element->getAttribute($name);

            if (preg_match('/^on[\pL\pN:_-]*$/iu', $normalized)
                || in_array($normalized, ['srcdoc', 'nonce'], true)) {
                $element->removeAttribute($name);
                continue;
            }

            if ($normalized === 'style') {
                $safeStyle = $this->sanitizeCss($value, true);
                if ($safeStyle === '') {
                    $element->removeAttribute($name);
                } else {
                    $element->setAttribute('style', $safeStyle);
                }
                continue;
            }

            if ($normalized === 'srcset') {
                if (!$this->isSafeSrcset($value)) {
                    $element->removeAttribute($name);
                }
                continue;
            }

            if (in_array($normalized, self::URL_ATTRIBUTES, true)
                && !$this->isSafeUrl($value, $normalized)) {
                $element->removeAttribute($name);
            }
        }

        if (strtolower($element->tagName) === 'style') {
            $safeCss = $this->sanitizeCss($element->textContent);
            while ($element->firstChild) {
                $element->removeChild($element->firstChild);
            }
            $element->appendChild($element->ownerDocument->createTextNode($safeCss));
        }

        if (strtolower($element->tagName) === 'a'
            && strtolower($element->getAttribute('target')) === '_blank') {
            $rel = preg_split('/\s+/', strtolower(trim($element->getAttribute('rel')))) ?: [];
            $rel = array_values(array_unique(array_filter([...$rel, 'noopener', 'noreferrer'])));
            $element->setAttribute('rel', implode(' ', $rel));
        }

        if (strtolower($element->tagName) === 'video' && $element->hasAttribute('data-hero-video')) {
            // GrapesJS' generic video component serializes native playback
            // controls and allowfullscreen even when the source hero markup
            // deliberately omits them. The RailTime intro is an automated,
            // muted presentation whose playback is owned by home-intro.js.
            foreach (['controls', 'controlslist', 'allowfullscreen', 'autoplay', 'loop'] as $attribute) {
                $element->removeAttribute($attribute);
            }
        }
    }

    private function isSafeSrcset(string $value): bool
    {
        $decoded = $this->decodeUrlForInspection($value);
        if (str_contains($decoded, 'data:')) {
            return false;
        }

        return !preg_match('~(?:javascript|vbscript|file|blob):~i', $decoded);
    }

    private function isSafeUrl(string $value, string $attribute): bool
    {
        $decoded = $this->decodeUrlForInspection($value);
        if ($decoded === '' || str_starts_with($decoded, '#')) {
            return true;
        }

        if (str_starts_with($decoded, 'data:')) {
            return in_array($attribute, ['src', 'poster', 'css'], true)
                && preg_match('~^data:image/(?:png|jpe?g|gif|webp);base64,~i', $decoded) === 1;
        }

        if (!preg_match('~^([a-z][a-z0-9+.-]*):~i', $decoded, $match)) {
            return true;
        }

        return in_array(strtolower($match[1]), ['http', 'https', 'mailto', 'tel', 'sms', 'ftp'], true);
    }

    private function decodeUrlForInspection(string $value): string
    {
        $decoded = html_entity_decode(trim($value), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        for ($pass = 0; $pass < 2; $pass++) {
            $next = rawurldecode($decoded);
            if ($next === $decoded) {
                break;
            }
            $decoded = $next;
        }

        return strtolower(preg_replace('/[\x00-\x20\x7f]+/u', '', $decoded) ?? '');
    }

    private function decodeCssEscapes(string $css): string
    {
        return preg_replace_callback(
            '/\\\\(?:([0-9a-f]{1,6})\s?|(.))/isu',
            static function (array $match): string {
                if (!empty($match[1])) {
                    $codepoint = hexdec($match[1]);

                    return $codepoint > 0 && $codepoint <= 0x10ffff ? mb_chr($codepoint, 'UTF-8') : '';
                }

                return (string) ($match[2] ?? '');
            },
            $css
        ) ?? $css;
    }

    /** @return array<int, DOMNode> */
    private function childNodes(DOMNode $parent): array
    {
        $children = [];
        foreach ($parent->childNodes as $child) {
            $children[] = $child;
        }

        return $children;
    }
}
