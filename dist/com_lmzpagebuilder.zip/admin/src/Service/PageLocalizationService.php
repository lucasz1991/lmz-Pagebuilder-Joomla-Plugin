<?php

namespace LMZ\Component\Lmzpagebuilder\Administrator\Service;

defined('_JEXEC') or die;

use DOMDocument;
use DOMElement;
use DOMNode;
use DOMText;
use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Factory;
use Joomla\Database\DatabaseInterface;
use RuntimeException;
use stdClass;
use Throwable;

/**
 * Owns the v2.4 shared-layout/localized-value persistence contract.
 *
 * The public migration/rematerialisation entry points intentionally contain no
 * ACL checks: Joomla's package postflight calls them without an administrator
 * session. They are not exposed by a controller. Interactive authorization and
 * editor leases remain PageBuilderService's responsibility.
 */
final class PageLocalizationService
{
    private const DICTIONARY_VERSION = 1;
    private const SCHEMA_VERSION = 1;
    private const MARKER_ATTRIBUTE = 'data-lmz-i18n';
    private const TRANSLATABLE_ATTRIBUTES = [
        'alt', 'title', 'aria-label', 'aria-description', 'placeholder',
    ];

    public function __construct(
        private DatabaseInterface $db,
        private ?object $identity = null,
        private ?HtmlSanitizer $sanitizer = null
    ) {
        $this->sanitizer ??= new HtmlSanitizer();
    }

    /**
     * Returns a stable content fingerprint for one localized page state.
     *
     * This is deliberately not a sequential version number. It identifies the
     * exact language dictionary and shared layout that form the page state.
     */
    public static function versionFingerprint(string $textHash, string $layoutHash): string
    {
        $textHash = strtolower(trim($textHash));
        $layoutHash = strtolower(trim($layoutHash));

        if (!preg_match('/^[a-f0-9]{64}$/', $textHash)
            || !preg_match('/^[a-f0-9]{64}$/', $layoutHash)) {
            return '';
        }

        return hash('sha256', "lmzpb-page-version-v1\0" . $textHash . "\0" . $layoutHash);
    }

    /**
     * @return array{status: string, online_fingerprint: string, draft_fingerprint: string}
     */
    public static function versionMeta(
        string $draftTextHash,
        string $publishedTextHash,
        string $draftLayoutHash,
        string $publishedLayoutHash,
        bool $published
    ): array {
        $draftTextHash = strtolower(trim($draftTextHash));
        $publishedTextHash = strtolower(trim($publishedTextHash));
        $draftLayoutHash = strtolower(trim($draftLayoutHash));
        $publishedLayoutHash = strtolower(trim($publishedLayoutHash));
        $draftFingerprint = self::versionFingerprint($draftTextHash, $draftLayoutHash);
        $onlineFingerprint = $published
            ? self::versionFingerprint($publishedTextHash, $publishedLayoutHash)
            : '';
        $identical = $published
            && $draftFingerprint !== ''
            && $onlineFingerprint !== ''
            && hash_equals($draftTextHash, $publishedTextHash)
            && hash_equals($draftLayoutHash, $publishedLayoutHash);

        return [
            'status' => !$published ? 'unpublished' : ($identical ? 'identical' : 'newer'),
            'online_fingerprint' => $onlineFingerprint,
            'draft_fingerprint' => $draftFingerprint,
        ];
    }

    /**
     * Idempotently migrates all legacy page variants, or one selected page.
     * A pre-migration revision is stored once per language before cache fields
     * are converted to derived renders.
     *
     * @return array{migrated: int, skipped: int, pages: array<int, int>}
     */
    public function migrateAllExistingPages(?int $onlyPageId = null): array
    {
        $query = $this->db->getQuery(true)
            ->select($this->db->quoteName('id'))
            ->from($this->db->quoteName('#__lmzpagebuilder_pages'))
            ->order($this->db->quoteName('id') . ' ASC');
        if ($onlyPageId !== null) {
            if ($onlyPageId <= 0) {
                throw new RuntimeException('A valid page ID is required for localization migration.', 422);
            }
            $query->where($this->db->quoteName('id') . ' = ' . $onlyPageId);
        }

        $pageIds = array_map('intval', $this->db->setQuery($query)->loadColumn() ?: []);
        $result = ['migrated' => 0, 'skipped' => 0, 'pages' => []];

        foreach ($pageIds as $pageId) {
            if ($this->layout($pageId) !== null) {
                $result['skipped']++;
                continue;
            }

            $this->db->transactionStart();
            try {
                // Recheck under the transaction so repeated postflight calls or
                // concurrent installers cannot create a second master row.
                if ($this->layout($pageId, true) !== null) {
                    $this->db->transactionCommit();
                    $result['skipped']++;
                    continue;
                }

                $translations = $this->translations($pageId, true);
                if ($translations === []) {
                    $this->db->transactionCommit();
                    $result['skipped']++;
                    continue;
                }

                $source = $this->selectSourceTranslation($translations);
                foreach ($translations as $translation) {
                    $this->addPreMigrationRevision($translation);
                }

                $pageKey = (string) ($source['page_key'] ?? ('page-' . $pageId));
                $draftSource = $this->annotateMasterHtml(
                    $this->sanitizer->sanitizeHtml((string) $source['draft_html']),
                    $pageKey
                );
                $publishedSource = $this->annotateMasterHtml(
                    $this->sanitizer->sanitizeHtml((string) $source['published_html']),
                    $pageKey,
                    $draftSource['keys']
                );
                $draftCss = $this->sanitizer->sanitizeCss((string) $source['draft_css']);
                $publishedCss = $this->sanitizer->sanitizeCss((string) $source['published_css']);
                $draftProject = $this->projectWithContent(
                    (string) $source['draft_project_json'],
                    $pageId,
                    (string) $source['language'],
                    (string) $source['title'],
                    $draftSource['html'],
                    $draftCss
                );
                $publishedProject = $this->projectWithContent(
                    (string) $source['draft_project_json'],
                    $pageId,
                    (string) $source['language'],
                    (string) $source['title'],
                    $publishedSource['html'],
                    $publishedCss
                );
                $now = $this->now();
                $layout = new stdClass();
                $layout->page_id = $pageId;
                $layout->source_language = (string) $source['language'];
                $layout->schema_version = self::SCHEMA_VERSION;
                $layout->draft_project_json = $draftProject;
                $layout->draft_html = $draftSource['html'];
                $layout->draft_css = $draftCss;
                $layout->draft_hash = $this->layoutHash($draftProject, $draftSource['html'], $draftCss);
                $layout->draft_signature = $draftSource['signature'];
                $layout->published_project_json = $publishedProject;
                $layout->published_html = $publishedSource['html'];
                $layout->published_css = $publishedCss;
                $layout->published_hash = $this->layoutHash($publishedProject, $publishedSource['html'], $publishedCss);
                $layout->published_signature = $publishedSource['signature'];
                $layout->created = $now;
                $layout->created_by = $this->actorId();
                $layout->modified = $now;
                $layout->modified_by = $this->actorId();
                $layout->published = trim($publishedSource['html']) !== '' || $publishedCss !== '' ? $now : null;
                $layout->published_by = $this->actorId();
                $this->db->insertObject('#__lmzpagebuilder_page_layouts', $layout, 'id');

                foreach ($translations as $translation) {
                    $draftDictionary = (int) $translation['id'] === (int) $source['id']
                        ? $draftSource['dictionary']
                        : $this->mapLegacyVariant($draftSource['html'], (string) $translation['draft_html']);
                    $publishedDictionary = (int) $translation['id'] === (int) $source['id']
                        ? $publishedSource['dictionary']
                        : $this->mapLegacyVariant($publishedSource['html'], (string) $translation['published_html']);
                    $this->insertTextRow(
                        $pageId,
                        (string) $translation['language'],
                        $draftDictionary,
                        $publishedDictionary,
                        $now,
                        (string) ($translation['published'] ?? '') !== ''
                    );
                }

                $this->materializePage($pageId);
                $this->db->transactionCommit();
                $result['migrated']++;
                $result['pages'][] = $pageId;
            } catch (Throwable $error) {
                $this->safeRollback();
                throw $error;
            }
        }

        return $result;
    }

    /**
     * Creates an empty shared layout for a newly-created logical page.
     */
    public function initializeEmptyPage(int $pageId, string $sourceLanguage, string $title): void
    {
        if ($this->layout($pageId, true) !== null) {
            return;
        }

        $now = $this->now();
        $empty = $this->emptyDictionary();
        $project = $this->projectWithContent('', $pageId, $sourceLanguage, $title, '', '');
        $layout = new stdClass();
        $layout->page_id = $pageId;
        $layout->source_language = $sourceLanguage;
        $layout->schema_version = self::SCHEMA_VERSION;
        $layout->draft_project_json = $project;
        $layout->draft_html = '';
        $layout->draft_css = '';
        $layout->draft_hash = $this->layoutHash($project, '', '');
        $layout->draft_signature = $this->structuralSignature('');
        $layout->published_project_json = $project;
        $layout->published_html = '';
        $layout->published_css = '';
        $layout->published_hash = $this->layoutHash($project, '', '');
        $layout->published_signature = $this->structuralSignature('');
        $layout->created = $now;
        $layout->created_by = $this->actorId();
        $layout->modified = $now;
        $layout->modified_by = $this->actorId();
        $layout->published = null;
        $layout->published_by = 0;
        $this->db->insertObject('#__lmzpagebuilder_page_layouts', $layout, 'id');

        foreach ($this->translations($pageId, true) as $translation) {
            $this->insertTextRow($pageId, (string) $translation['language'], $empty, $empty, $now, false);
        }
        $this->materializePage($pageId);
    }

    /**
     * Lazily creates only a text dictionary for a newly-added language.
     */
    public function initializeTranslation(int $pageId, string $language): void
    {
        $this->requireLayout($pageId, true);
        $this->ensureTextRow($pageId, $language, $this->now());
        $this->materializePage($pageId, $language);
    }

    /**
     * Builds the localized draft project returned by the editor load endpoint.
     *
     * @param array<string, mixed> $translation
     * @return array<string, mixed>
     */
    public function editorState(array $translation): array
    {
        $pageId = (int) $translation['page_id'];
        $language = (string) $translation['language'];
        $layout = $this->requireLayout($pageId);
        $text = $this->text($pageId, $language) ?? $this->ensureTextRow($pageId, $language, $this->now());
        $sourceText = $this->text($pageId, (string) $layout['source_language'])
            ?? $this->ensureTextRow($pageId, (string) $layout['source_language'], $this->now());
        $html = $this->renderLocalizedHtml(
            (string) $layout['draft_html'],
            $this->decodeDictionary((string) $text['draft_json']),
            $this->decodeDictionary((string) $sourceText['draft_json'])
        );
        $projectJson = $this->projectWithContent(
            (string) $layout['draft_project_json'],
            $pageId,
            $language,
            (string) $translation['title'],
            $html,
            (string) $layout['draft_css']
        );
        $project = json_decode($projectJson, true);
        if (!is_array($project)) {
            throw new RuntimeException('The localized builder project is invalid.', 500);
        }

        return [
            'project' => $project,
            'html' => $html,
            'css' => (string) $layout['draft_css'],
            'draft_hash' => (string) $text['draft_hash'],
            'published_text_hash' => (string) $text['published_hash'],
            'layout_draft_hash' => (string) $layout['draft_hash'],
            'layout_published_hash' => (string) $layout['published_hash'],
            'source_language' => (string) $layout['source_language'],
            'translation_only' => $language !== (string) $layout['source_language'],
        ];
    }

    /**
     * Saves either the full source layout or language-only values. The caller
     * owns the surrounding transaction and editor lease.
     *
     * @param array<string, mixed> $translation
     * @return array<string, mixed>
     */
    public function saveDraft(
        array $translation,
        string $expectedTextHash,
        string $expectedLayoutHash,
        string $projectJson,
        string $html,
        string $css
    ): array {
        $pageId = (int) $translation['page_id'];
        $language = (string) $translation['language'];
        $layout = $this->requireLayout($pageId, true);
        $text = $this->requireText($pageId, $language, true);
        $this->assertCurrentHash((string) $text['draft_hash'], $expectedTextHash, 'The language draft changed in another editor.');
        $this->assertCurrentHash((string) $layout['draft_hash'], $expectedLayoutHash, 'The shared page layout changed in another editor.');
        $safeHtml = $this->sanitizer->sanitizeHtml($html);
        $safeCss = $this->sanitizer->sanitizeCss($css);
        $source = $language === (string) $layout['source_language'];
        $now = $this->now();

        if ($source) {
            $pageKey = (string) ($translation['page_key'] ?? ('page-' . $pageId));
            $safeHtml = $this->preserveStableMarkers((string) $layout['draft_html'], $safeHtml);
            $annotated = $this->annotateMasterHtml($safeHtml, $pageKey, [], $this->reservedTextKeys($pageId));
            $masterProject = $this->projectWithContent(
                $projectJson,
                $pageId,
                $language,
                (string) $translation['title'],
                $annotated['html'],
                $safeCss
            );
            $nextLayoutHash = $this->layoutHash($masterProject, $annotated['html'], $safeCss);
            $update = new stdClass();
            $update->id = (int) $layout['id'];
            $update->draft_project_json = $masterProject;
            $update->draft_html = $annotated['html'];
            $update->draft_css = $safeCss;
            $update->draft_hash = $nextLayoutHash;
            $update->draft_signature = $annotated['signature'];
            $update->modified = $now;
            $update->modified_by = $this->actorId();
            $this->db->updateObject('#__lmzpagebuilder_page_layouts', $update, 'id', true);
            $nextTextHash = $this->updateDraftDictionary((int) $text['id'], $annotated['dictionary'], $now);
            $this->materializePage($pageId);
        } else {
            if (!hash_equals((string) $layout['draft_css'], $safeCss)) {
                throw new RuntimeException('CSS is owned by the source language and cannot be changed in translation mode.', 422);
            }
            if (!hash_equals((string) $layout['draft_signature'], $this->structuralSignature($safeHtml))) {
                throw new RuntimeException('Translation mode accepts text and accessibility values only; the page structure changed.', 409);
            }
            $dictionary = $this->dictionaryForMaster($safeHtml, (string) $layout['draft_html']);
            $nextTextHash = $this->updateDraftDictionary((int) $text['id'], $dictionary, $now);
            $nextLayoutHash = (string) $layout['draft_hash'];
            $this->materializePage($pageId, $language);
        }

        return [
            'draft_hash' => $nextTextHash,
            'published_text_hash' => (string) $text['published_hash'],
            'layout_draft_hash' => $nextLayoutHash,
            'layout_published_hash' => (string) $layout['published_hash'],
            'translation_only' => !$source,
            'html_sanitized' => !hash_equals(hash('sha256', $html), hash('sha256', $safeHtml)),
        ];
    }

    /**
     * Publishes source structure for all languages, or one language dictionary.
     * $beforePublishedChange receives each legacy translation before its cache
     * is changed and is used by PageBuilderService to write revisions.
     *
     * @param array<string, mixed> $translation
     * @param callable(array<string, mixed>): void $beforePublishedChange
     * @return array<string, mixed>
     */
    public function publish(
        array $translation,
        string $expectedPublishedHash,
        string $expectedDraftHash,
        string $expectedLayoutHash,
        callable $beforePublishedChange
    ): array {
        $pageId = (int) $translation['page_id'];
        $language = (string) $translation['language'];
        $layout = $this->requireLayout($pageId, true);
        $text = $this->requireText($pageId, $language, true);
        $this->assertCurrentHash((string) $translation['published_hash'], $expectedPublishedHash, 'The published language render changed.');
        $this->assertCurrentHash((string) $text['draft_hash'], $expectedDraftHash, 'The language draft changed before publishing.');
        $this->assertCurrentHash((string) $layout['draft_hash'], $expectedLayoutHash, 'The shared page layout changed before publishing.');
        $source = $language === (string) $layout['source_language'];
        $now = $this->now();

        if ($source) {
            foreach ($this->translations($pageId, true) as $candidate) {
                if ((int) $candidate['state'] === 1) {
                    $candidate['revision_project_json'] = (string) $layout['published_project_json'];
                    $beforePublishedChange($candidate);
                }
            }
            $layoutUpdate = new stdClass();
            $layoutUpdate->id = (int) $layout['id'];
            $layoutUpdate->published_project_json = (string) $layout['draft_project_json'];
            $layoutUpdate->published_html = (string) $layout['draft_html'];
            $layoutUpdate->published_css = (string) $layout['draft_css'];
            $layoutUpdate->published_hash = (string) $layout['draft_hash'];
            $layoutUpdate->published_signature = (string) $layout['draft_signature'];
            $layoutUpdate->published = $now;
            $layoutUpdate->published_by = $this->actorId();
            $layoutUpdate->modified = $now;
            $layoutUpdate->modified_by = $this->actorId();
            $this->db->updateObject('#__lmzpagebuilder_page_layouts', $layoutUpdate, 'id', true);
            $publishedTextHash = $this->publishTextRow((int) $text['id'], $now);
            $this->materializePage($pageId);
        } else {
            $translation['revision_project_json'] = (string) $layout['published_project_json'];
            $beforePublishedChange($translation);
            $publishedTextHash = $this->publishTextRow((int) $text['id'], $now);
            $this->materializePage($pageId, $language);
        }

        $translationUpdate = new stdClass();
        $translationUpdate->id = (int) $translation['id'];
        $translationUpdate->state = 1;
        $translationUpdate->published = $now;
        $translationUpdate->published_by = $this->actorId();
        $translationUpdate->modified = $now;
        $translationUpdate->modified_by = $this->actorId();
        $this->db->updateObject('#__lmzpagebuilder_page_translations', $translationUpdate, 'id', true);
        $fresh = $this->translation((int) $translation['id']);

        return [
            'source_hash' => (string) $fresh['published_hash'],
            'published_hash' => (string) $fresh['published_hash'],
            'published_text_hash' => $publishedTextHash,
            'draft_hash' => (string) $text['draft_hash'],
            'layout_draft_hash' => (string) $layout['draft_hash'],
            'layout_published_hash' => $source ? (string) $layout['draft_hash'] : (string) $layout['published_hash'],
            'translation_only' => !$source,
            'modified' => $now,
        ];
    }

    /**
     * Drops an unpublished draft back to the last published state without
     * creating a revision. The published payload remains untouched.
     *
     * @param array<string, mixed> $translation
     * @return array{draft_hash: string, published_text_hash: string, layout_draft_hash: string, layout_published_hash: string, translation_only: bool}
     */
    public function discardDraft(array $translation): array
    {
        $pageId = (int) $translation['page_id'];
        $language = (string) $translation['language'];
        $layout = $this->requireLayout($pageId, true);
        $text = $this->requireText($pageId, $language, true);
        $source = $language === (string) $layout['source_language'];
        $now = $this->now();

        if ($source) {
            $update = new stdClass();
            $update->id = (int) $layout['id'];
            $update->draft_project_json = (string) $layout['published_project_json'];
            $update->draft_html = (string) $layout['published_html'];
            $update->draft_css = (string) $layout['published_css'];
            $update->draft_hash = (string) $layout['published_hash'];
            $update->draft_signature = (string) $layout['published_signature'];
            $update->modified = $now;
            $update->modified_by = $this->actorId();
            $this->db->updateObject('#__lmzpagebuilder_page_layouts', $update, 'id', true);

            foreach ($this->translations($pageId, true) as $candidate) {
                $candidateText = $this->requireText($pageId, (string) $candidate['language'], true);
                $this->replaceTextRow(
                    (int) $candidateText['id'],
                    $this->decodeDictionary((string) $candidateText['published_json']),
                    $this->decodeDictionary((string) $candidateText['published_json']),
                    $now
                );
            }
            $this->materializePage($pageId);
        } else {
            $published = $this->decodeDictionary((string) $text['published_json']);
            $draftHash = $this->replaceTextRow((int) $text['id'], $published, $published, $now);
            $this->materializePage($pageId, $language);

            return [
                'draft_hash' => $draftHash,
                'published_text_hash' => (string) $text['published_hash'],
                'layout_draft_hash' => (string) $layout['draft_hash'],
                'layout_published_hash' => (string) $layout['published_hash'],
                'translation_only' => true,
            ];
        }

        return [
            'draft_hash' => (string) $text['published_hash'],
            'published_text_hash' => (string) $text['published_hash'],
            'layout_draft_hash' => (string) $layout['published_hash'],
            'layout_published_hash' => (string) $layout['published_hash'],
            'translation_only' => false,
        ];
    }

    /**
     * Restores a revision without reintroducing per-language structure.
     *
     * @param array<string, mixed> $translation
     * @param array<string, mixed> $revision
     * @param callable(array<string, mixed>): void $beforePublishedChange
     * @return array<string, mixed>
     */
    public function rollback(
        array $translation,
        array $revision,
        string $expectedPublishedHash,
        string $expectedDraftHash,
        string $expectedLayoutHash,
        callable $beforePublishedChange
    ): array {
        $pageId = (int) $translation['page_id'];
        $language = (string) $translation['language'];
        $layout = $this->requireLayout($pageId, true);
        $text = $this->requireText($pageId, $language, true);
        $this->assertCurrentHash((string) $translation['published_hash'], $expectedPublishedHash, 'The published language render changed before rollback.');
        $this->assertCurrentHash((string) $text['draft_hash'], $expectedDraftHash, 'The language draft changed before rollback.');
        $this->assertCurrentHash((string) $layout['draft_hash'], $expectedLayoutHash, 'The shared page layout changed before rollback.');
        $source = $language === (string) $layout['source_language'];
        $safeHtml = $this->sanitizer->sanitizeHtml((string) $revision['html']);
        $safeCss = $this->sanitizer->sanitizeCss((string) $revision['css']);
        $now = $this->now();

        if ($source) {
            foreach ($this->translations($pageId, true) as $candidate) {
                if ((int) $candidate['state'] === 1) {
                    $candidate['revision_project_json'] = (string) $layout['published_project_json'];
                    $beforePublishedChange($candidate);
                }
            }
            $annotated = $this->annotateMasterHtml(
                $safeHtml,
                (string) ($translation['page_key'] ?? ('page-' . $pageId)),
                [],
                $this->reservedTextKeys($pageId)
            );
            $project = $this->projectWithContent(
                (string) $revision['project_json'],
                $pageId,
                $language,
                (string) $translation['title'],
                $annotated['html'],
                $safeCss
            );
            $nextLayoutHash = $this->layoutHash($project, $annotated['html'], $safeCss);
            $layoutUpdate = new stdClass();
            $layoutUpdate->id = (int) $layout['id'];
            $layoutUpdate->draft_project_json = $project;
            $layoutUpdate->draft_html = $annotated['html'];
            $layoutUpdate->draft_css = $safeCss;
            $layoutUpdate->draft_hash = $nextLayoutHash;
            $layoutUpdate->draft_signature = $annotated['signature'];
            $layoutUpdate->published_project_json = $project;
            $layoutUpdate->published_html = $annotated['html'];
            $layoutUpdate->published_css = $safeCss;
            $layoutUpdate->published_hash = $nextLayoutHash;
            $layoutUpdate->published_signature = $annotated['signature'];
            $layoutUpdate->modified = $now;
            $layoutUpdate->modified_by = $this->actorId();
            $layoutUpdate->published = $now;
            $layoutUpdate->published_by = $this->actorId();
            $this->db->updateObject('#__lmzpagebuilder_page_layouts', $layoutUpdate, 'id', true);
            $nextTextHash = $this->replaceTextRow((int) $text['id'], $annotated['dictionary'], $annotated['dictionary'], $now);
            $this->materializePage($pageId);
        } else {
            if (!hash_equals((string) $layout['draft_signature'], $this->structuralSignature($safeHtml))
                || !hash_equals((string) $layout['draft_css'], $safeCss)) {
                throw new RuntimeException('This legacy revision has a different structure and cannot be restored in translation mode.', 409);
            }
            $translation['revision_project_json'] = (string) $layout['published_project_json'];
            $beforePublishedChange($translation);
            $dictionary = $this->dictionaryForMaster($safeHtml, (string) $layout['draft_html']);
            $nextTextHash = $this->replaceTextRow((int) $text['id'], $dictionary, $dictionary, $now);
            $nextLayoutHash = (string) $layout['draft_hash'];
            $this->materializePage($pageId, $language);
        }

        $fresh = $this->translation((int) $translation['id']);

        return [
            'source_hash' => (string) $fresh['published_hash'],
            'published_hash' => (string) $fresh['published_hash'],
            'draft_hash' => $nextTextHash,
            'layout_draft_hash' => $nextLayoutHash,
            'translation_only' => !$source,
        ];
    }

    /**
     * Rebuilds all legacy cache columns from layout + dictionaries. This is an
     * installer/internal API and deliberately has no ACL dependency.
     *
     * @return array{page_id: int, translations: int}
     */
    public function rematerializePage(int $pageId): array
    {
        if ($pageId <= 0) {
            throw new RuntimeException('A valid page ID is required for rematerialisation.', 422);
        }

        $this->db->transactionStart();
        try {
            $count = $this->materializePage($pageId);
            $this->db->transactionCommit();
        } catch (Throwable $error) {
            $this->safeRollback();
            throw $error;
        }

        return ['page_id' => $pageId, 'translations' => $count];
    }

    /**
     * Re-applies the current sanitizer contract to one stored shared layout.
     * This is an installer/CLI repair hook, not an interactive write path.
     * It preserves draft and published states independently and never creates
     * an editor revision.
     *
     * @return array{page_id: int, changed: bool, translations: int}
     */
    public function resanitizePage(int $pageId): array
    {
        if ($pageId <= 0) {
            throw new RuntimeException('A valid page ID is required for re-sanitization.', 422);
        }

        $this->db->transactionStart();
        try {
            $layout = $this->requireLayout($pageId, true);
            $translations = $this->translations($pageId, true);
            $source = null;
            foreach ($translations as $translation) {
                if ((string) $translation['language'] === (string) $layout['source_language']) {
                    $source = $translation;
                    break;
                }
            }
            if (!is_array($source)) {
                throw new RuntimeException('The shared layout has no source-language translation.', 409);
            }

            $draftHtml = $this->sanitizer->sanitizeHtml((string) $layout['draft_html']);
            $publishedHtml = $this->sanitizer->sanitizeHtml((string) $layout['published_html']);
            $draftCss = $this->sanitizer->sanitizeCss((string) $layout['draft_css']);
            $publishedCss = $this->sanitizer->sanitizeCss((string) $layout['published_css']);
            $draftProject = $this->projectWithContent(
                (string) $layout['draft_project_json'],
                $pageId,
                (string) $layout['source_language'],
                (string) $source['title'],
                $draftHtml,
                $draftCss
            );
            $publishedProject = $this->projectWithContent(
                (string) $layout['published_project_json'],
                $pageId,
                (string) $layout['source_language'],
                (string) $source['title'],
                $publishedHtml,
                $publishedCss
            );
            $draftHash = $this->layoutHash($draftProject, $draftHtml, $draftCss);
            $publishedHash = $this->layoutHash($publishedProject, $publishedHtml, $publishedCss);
            $draftSignature = $this->structuralSignature($draftHtml);
            $publishedSignature = $this->structuralSignature($publishedHtml);
            $changed = !hash_equals((string) $layout['draft_hash'], $draftHash)
                || !hash_equals((string) $layout['published_hash'], $publishedHash)
                || !hash_equals((string) $layout['draft_signature'], $draftSignature)
                || !hash_equals((string) $layout['published_signature'], $publishedSignature)
                || !hash_equals((string) $layout['draft_html'], $draftHtml)
                || !hash_equals((string) $layout['published_html'], $publishedHtml)
                || !hash_equals((string) $layout['draft_project_json'], $draftProject)
                || !hash_equals((string) $layout['published_project_json'], $publishedProject);
            $count = count($translations);

            if ($changed) {
                $now = $this->now();
                $update = new stdClass();
                $update->id = (int) $layout['id'];
                $update->draft_project_json = $draftProject;
                $update->draft_html = $draftHtml;
                $update->draft_css = $draftCss;
                $update->draft_hash = $draftHash;
                $update->draft_signature = $draftSignature;
                $update->published_project_json = $publishedProject;
                $update->published_html = $publishedHtml;
                $update->published_css = $publishedCss;
                $update->published_hash = $publishedHash;
                $update->published_signature = $publishedSignature;
                $update->modified = $now;
                $update->modified_by = $this->actorId();
                $update->published = trim($publishedHtml) !== '' || $publishedCss !== '' ? $now : null;
                $update->published_by = $this->actorId();
                $this->db->updateObject('#__lmzpagebuilder_page_layouts', $update, 'id', true);
                $count = $this->materializePage($pageId);
            }

            $this->db->transactionCommit();
        } catch (Throwable $error) {
            $this->safeRollback();
            throw $error;
        }

        return ['page_id' => $pageId, 'changed' => $changed, 'translations' => $count];
    }

    /**
     * Adds/preserves stable markers and extracts the source dictionary.
     * Existing valid unique keys survive DOM moves. New/duplicate/invalid keys
     * receive deterministic collision-safe replacements.
     *
     * @param array<string, string> $preferredKeys structural-path => key
     * @param array<int, string> $reservedKeys historic keys which a new node
     *        must not accidentally reuse after an older node was deleted
     * @return array{html: string, dictionary: array<string, mixed>, signature: string, keys: array<string, string>}
     */
    public function annotateMasterHtml(
        string $html,
        string $pageKey,
        array $preferredKeys = [],
        array $reservedKeys = []
    ): array
    {
        [$dom, $body] = $this->parseFragment($html);
        $used = [];
        $reserved = array_fill_keys(array_filter(array_map('strval', $reservedKeys), fn (string $key): bool => $this->validMarker($key)), true);
        $keys = [];

        foreach ($this->elementMap($body) as $path => $element) {
            if (!$this->hasTranslatableValue($element)) {
                continue;
            }
            $candidate = trim($element->getAttribute(self::MARKER_ATTRIBUTE));
            if (!$this->validMarker($candidate) || isset($used[$candidate])) {
                $preferred = (string) ($preferredKeys[$path] ?? '');
                $candidate = $this->validMarker($preferred) && !isset($used[$preferred])
                    ? $preferred
                    : $this->newMarker($pageKey, $path, strtolower($element->tagName), $used + $reserved);
                $element->setAttribute(self::MARKER_ATTRIBUTE, $candidate);
            }
            $used[$candidate] = true;
            $keys[$path] = $candidate;
        }

        $annotated = $this->serializeBody($dom, $body);

        return [
            'html' => $annotated,
            'dictionary' => $this->extractDictionary($annotated),
            'signature' => $this->structuralSignature($annotated),
            'keys' => $keys,
        ];
    }

    /** @return array{version: int, values: array<string, mixed>} */
    public function extractDictionary(string $html): array
    {
        [, $body] = $this->parseFragment($html);
        $dictionary = $this->emptyDictionary();
        $seen = [];

        foreach ($this->elementMap($body) as $element) {
            $key = trim($element->getAttribute(self::MARKER_ATTRIBUTE));
            if ($key === '') {
                continue;
            }
            if (!$this->validMarker($key) || isset($seen[$key])) {
                throw new RuntimeException('The page contains an invalid or duplicate data-lmz-i18n key.', 422);
            }
            $seen[$key] = true;
            $entry = ['text' => [], 'attributes' => []];
            foreach ($this->directTextNodes($element) as $index => $node) {
                $entry['text'][(string) $index] = $node->nodeValue ?? '';
            }
            foreach ($this->allowedAttributes($element) as $attribute) {
                if ($element->hasAttribute($attribute)) {
                    $entry['attributes'][$attribute] = $element->getAttribute($attribute);
                }
            }
            if ($entry['text'] !== [] || $entry['attributes'] !== []) {
                $dictionary['values'][$key] = $entry;
            }
        }

        return $this->normalizeDictionary($dictionary);
    }

    /**
     * Applies only text and explicitly allowed attributes. Missing target
     * values fall back to the source dictionary and finally the master HTML.
     *
     * @param array<string, mixed> $dictionary
     * @param array<string, mixed> $fallback
     */
    public function renderLocalizedHtml(string $masterHtml, array $dictionary, array $fallback = []): string
    {
        [$dom, $body] = $this->parseFragment($masterHtml);
        $dictionary = $this->normalizeDictionary($dictionary);
        $fallback = $this->normalizeDictionary($fallback === [] ? $this->emptyDictionary() : $fallback);

        foreach ($this->elementMap($body) as $element) {
            $key = trim($element->getAttribute(self::MARKER_ATTRIBUTE));
            if ($key === '') {
                continue;
            }
            $target = is_array($dictionary['values'][$key] ?? null) ? $dictionary['values'][$key] : [];
            $source = is_array($fallback['values'][$key] ?? null) ? $fallback['values'][$key] : [];
            foreach ($this->directTextNodes($element) as $index => $node) {
                $index = (string) $index;
                if (array_key_exists($index, $target['text'] ?? [])) {
                    $node->nodeValue = (string) $target['text'][$index];
                } elseif (array_key_exists($index, $source['text'] ?? [])) {
                    $node->nodeValue = (string) $source['text'][$index];
                }
            }
            foreach ($this->allowedAttributes($element) as $attribute) {
                if (array_key_exists($attribute, $target['attributes'] ?? [])) {
                    $element->setAttribute($attribute, (string) $target['attributes'][$attribute]);
                } elseif (array_key_exists($attribute, $source['attributes'] ?? [])) {
                    $element->setAttribute($attribute, (string) $source['attributes'][$attribute]);
                }
            }
        }

        return $this->serializeBody($dom, $body);
    }

    public function structuralSignature(string $html): string
    {
        [, $body] = $this->parseFragment($html);

        return hash('sha256', $this->structureOf($body));
    }

    /**
     * Repairs marker-only edits/removals when the surrounding DOM is otherwise
     * unchanged. Structural moves retain their marker naturally on the moved
     * element and are not path-remapped here.
     */
    public function preserveStableMarkers(string $storedMasterHtml, string $candidateHtml): string
    {
        [$storedDom, $storedBody] = $this->parseFragment($storedMasterHtml);
        [$candidateDom, $candidateBody] = $this->parseFragment($candidateHtml);
        if (!hash_equals(
            hash('sha256', $this->structureOf($storedBody, true)),
            hash('sha256', $this->structureOf($candidateBody, true))
        )) {
            return $candidateHtml;
        }
        $storedMap = $this->elementMap($storedBody);
        $candidateMap = $this->elementMap($candidateBody);
        foreach ($storedMap as $path => $stored) {
            $key = trim($stored->getAttribute(self::MARKER_ATTRIBUTE));
            $candidate = $candidateMap[$path] ?? null;
            if ($this->validMarker($key) && $candidate instanceof DOMElement
                && strtolower($candidate->tagName) === strtolower($stored->tagName)) {
                $candidate->setAttribute(self::MARKER_ATTRIBUTE, $key);
            }
        }

        return $this->serializeBody($candidateDom, $candidateBody);
    }

    /** @param array<string, mixed> $dictionary @return array{version: int, values: array<string, mixed>} */
    public function normalizeDictionary(array $dictionary): array
    {
        $normalized = $this->emptyDictionary();
        $values = is_array($dictionary['values'] ?? null) ? $dictionary['values'] : [];

        foreach ($values as $key => $entry) {
            $key = (string) $key;
            if (!$this->validMarker($key) || !is_array($entry)) {
                continue;
            }
            $text = [];
            foreach (is_array($entry['text'] ?? null) ? $entry['text'] : [] as $index => $value) {
                if (preg_match('/^(?:0|[1-9][0-9]*)$/', (string) $index)) {
                    $text[(string) $index] = $this->cleanValue((string) $value);
                }
            }
            uksort($text, static fn (string $left, string $right): int => (int) $left <=> (int) $right);
            $attributes = [];
            foreach (is_array($entry['attributes'] ?? null) ? $entry['attributes'] : [] as $name => $value) {
                $name = strtolower((string) $name);
                if (in_array($name, [...self::TRANSLATABLE_ATTRIBUTES, 'value'], true)) {
                    $attributes[$name] = $this->cleanValue((string) $value);
                }
            }
            ksort($attributes);
            if ($text !== [] || $attributes !== []) {
                $normalized['values'][$key] = ['text' => $text, 'attributes' => $attributes];
            }
        }
        ksort($normalized['values']);

        return $normalized;
    }

    // ---------------------------------------------------------------------
    // Database/materialisation helpers

    /** @return array<string, mixed>|null */
    private function layout(int $pageId, bool $forUpdate = false): ?array
    {
        $query = $this->db->getQuery(true)
            ->select('*')
            ->from($this->db->quoteName('#__lmzpagebuilder_page_layouts'))
            ->where($this->db->quoteName('page_id') . ' = ' . $pageId);
        $row = $this->db->setQuery((string) $query . ($forUpdate ? ' FOR UPDATE' : ''))->loadAssoc();

        return $row ?: null;
    }

    /** @return array<string, mixed> */
    private function requireLayout(int $pageId, bool $forUpdate = false): array
    {
        $layout = $this->layout($pageId, $forUpdate);
        if ($layout === null) {
            throw new RuntimeException('The page has not been migrated to the shared localization layout.', 409);
        }

        return $layout;
    }

    /** @return array<string, mixed>|null */
    private function text(int $pageId, string $language, bool $forUpdate = false): ?array
    {
        $query = $this->db->getQuery(true)
            ->select('*')
            ->from($this->db->quoteName('#__lmzpagebuilder_page_texts'))
            ->where($this->db->quoteName('page_id') . ' = ' . $pageId)
            ->where($this->db->quoteName('language') . ' = ' . $this->db->quote($language));
        $row = $this->db->setQuery((string) $query . ($forUpdate ? ' FOR UPDATE' : ''))->loadAssoc();

        return $row ?: null;
    }

    /** @return array<string, mixed> */
    private function requireText(int $pageId, string $language, bool $forUpdate = false): array
    {
        $text = $this->text($pageId, $language, $forUpdate);
        if ($text === null) {
            throw new RuntimeException('The language value dictionary is missing.', 409);
        }

        return $text;
    }

    /** @return array<int, string> */
    private function reservedTextKeys(int $pageId): array
    {
        $query = $this->db->getQuery(true)
            ->select($this->db->quoteName(['draft_json', 'published_json']))
            ->from($this->db->quoteName('#__lmzpagebuilder_page_texts'))
            ->where($this->db->quoteName('page_id') . ' = ' . $pageId);
        $keys = [];
        foreach ($this->db->setQuery($query)->loadAssocList() ?: [] as $row) {
            foreach (['draft_json', 'published_json'] as $field) {
                $dictionary = $this->decodeDictionary((string) $row[$field]);
                foreach (array_keys($dictionary['values']) as $key) {
                    $keys[(string) $key] = true;
                }
            }
        }

        return array_keys($keys);
    }

    /** @return array<string, mixed> */
    private function ensureTextRow(int $pageId, string $language, string $now): array
    {
        $existing = $this->text($pageId, $language, true);
        if ($existing !== null) {
            return $existing;
        }
        $empty = $this->emptyDictionary();
        $this->insertTextRow($pageId, $language, $empty, $empty, $now, false);

        return $this->requireText($pageId, $language, true);
    }

    /** @return array<int, array<string, mixed>> */
    private function translations(int $pageId, bool $forUpdate = false): array
    {
        $query = $this->db->getQuery(true)
            ->select('t.*')
            ->select($this->db->quoteName('p.page_key'))
            ->from($this->db->quoteName('#__lmzpagebuilder_page_translations', 't'))
            ->innerJoin($this->db->quoteName('#__lmzpagebuilder_pages', 'p') . ' ON p.id = t.page_id')
            ->where($this->db->quoteName('t.page_id') . ' = ' . $pageId)
            ->order($this->db->quoteName('t.id') . ' ASC');

        return $this->db->setQuery((string) $query . ($forUpdate ? ' FOR UPDATE' : ''))->loadAssocList() ?: [];
    }

    /** @return array<string, mixed> */
    private function translation(int $translationId): array
    {
        $query = $this->db->getQuery(true)
            ->select('*')
            ->from($this->db->quoteName('#__lmzpagebuilder_page_translations'))
            ->where($this->db->quoteName('id') . ' = ' . $translationId);
        $row = $this->db->setQuery($query)->loadAssoc();
        if (!$row) {
            throw new RuntimeException('Builder translation not found after localization update.', 500);
        }

        return $row;
    }

    /** @param array<int, array<string, mixed>> $translations @return array<string, mixed> */
    private function selectSourceTranslation(array $translations): array
    {
        $default = '';
        try {
            $configured = str_replace('_', '-', (string) ComponentHelper::getParams('com_languages')->get('site', ''));
            if (preg_match('/^([a-z]{2,3})-([a-z]{2})$/i', $configured, $matches)) {
                $default = strtolower($matches[1]) . '-' . strtoupper($matches[2]);
            }
            if ($default === '') {
                $default = (new LanguageService($this->db))->defaultCode();
            }
        } catch (Throwable $ignored) {
            // A valid first variant is the documented migration fallback.
        }
        foreach ($translations as $translation) {
            if ((string) $translation['language'] === $default) {
                return $translation;
            }
        }

        return $translations[0];
    }

    /**
     * @param array<string, mixed> $draft
     * @param array<string, mixed> $published
     */
    private function insertTextRow(
        int $pageId,
        string $language,
        array $draft,
        array $published,
        string $now,
        bool $isPublished
    ): void {
        if ($this->text($pageId, $language) !== null) {
            return;
        }
        $draftJson = $this->encodeDictionary($draft);
        $publishedJson = $this->encodeDictionary($published);
        $row = new stdClass();
        $row->page_id = $pageId;
        $row->language = $language;
        $row->schema_version = self::SCHEMA_VERSION;
        $row->draft_json = $draftJson;
        $row->published_json = $publishedJson;
        $row->draft_hash = hash('sha256', $draftJson);
        $row->published_hash = hash('sha256', $publishedJson);
        $row->created = $now;
        $row->created_by = $this->actorId();
        $row->modified = $now;
        $row->modified_by = $this->actorId();
        $row->published = $isPublished ? $now : null;
        $row->published_by = $isPublished ? $this->actorId() : 0;
        $this->db->insertObject('#__lmzpagebuilder_page_texts', $row, 'id');
    }

    private function updateDraftDictionary(int $textId, array $dictionary, string $now): string
    {
        $json = $this->encodeDictionary($dictionary);
        $hash = hash('sha256', $json);
        $update = new stdClass();
        $update->id = $textId;
        $update->draft_json = $json;
        $update->draft_hash = $hash;
        $update->modified = $now;
        $update->modified_by = $this->actorId();
        $this->db->updateObject('#__lmzpagebuilder_page_texts', $update, 'id', true);

        return $hash;
    }

    private function publishTextRow(int $textId, string $now): string
    {
        $query = $this->db->getQuery(true)
            ->select('*')
            ->from($this->db->quoteName('#__lmzpagebuilder_page_texts'))
            ->where($this->db->quoteName('id') . ' = ' . $textId);
        $text = $this->db->setQuery((string) $query . ' FOR UPDATE')->loadAssoc();
        if (!$text) {
            throw new RuntimeException('Language value dictionary not found for publish.', 409);
        }
        $update = new stdClass();
        $update->id = $textId;
        $update->published_json = (string) $text['draft_json'];
        $update->published_hash = (string) $text['draft_hash'];
        $update->published = $now;
        $update->published_by = $this->actorId();
        $update->modified = $now;
        $update->modified_by = $this->actorId();
        $this->db->updateObject('#__lmzpagebuilder_page_texts', $update, 'id', true);

        return (string) $text['draft_hash'];
    }

    private function replaceTextRow(int $textId, array $draft, array $published, string $now): string
    {
        $draftJson = $this->encodeDictionary($draft);
        $publishedJson = $this->encodeDictionary($published);
        $update = new stdClass();
        $update->id = $textId;
        $update->draft_json = $draftJson;
        $update->published_json = $publishedJson;
        $update->draft_hash = hash('sha256', $draftJson);
        $update->published_hash = hash('sha256', $publishedJson);
        $update->modified = $now;
        $update->modified_by = $this->actorId();
        $update->published = $now;
        $update->published_by = $this->actorId();
        $this->db->updateObject('#__lmzpagebuilder_page_texts', $update, 'id', true);

        return $update->draft_hash;
    }

    private function materializePage(int $pageId, ?string $onlyLanguage = null): int
    {
        $layout = $this->requireLayout($pageId);
        $translations = $this->translations($pageId);
        $sourceText = $this->text($pageId, (string) $layout['source_language'])
            ?? $this->ensureTextRow($pageId, (string) $layout['source_language'], $this->now());
        $sourceDraft = $this->decodeDictionary((string) $sourceText['draft_json']);
        $sourcePublished = $this->decodeDictionary((string) $sourceText['published_json']);
        $count = 0;

        foreach ($translations as $translation) {
            $language = (string) $translation['language'];
            if ($onlyLanguage !== null && $language !== $onlyLanguage) {
                continue;
            }
            $text = $this->text($pageId, $language) ?? $this->ensureTextRow($pageId, $language, $this->now());
            $draftDictionary = $this->decodeDictionary((string) $text['draft_json']);
            $publishedDictionary = $this->decodeDictionary((string) $text['published_json']);
            $draftHtml = $this->renderLocalizedHtml((string) $layout['draft_html'], $draftDictionary, $sourceDraft);
            $publishedHtml = $this->renderLocalizedHtml((string) $layout['published_html'], $publishedDictionary, $sourcePublished);
            $draftProject = $this->projectWithContent(
                (string) $layout['draft_project_json'],
                $pageId,
                $language,
                (string) $translation['title'],
                $draftHtml,
                (string) $layout['draft_css']
            );
            $update = new stdClass();
            $update->id = (int) $translation['id'];
            $update->schema_version = 3;
            $update->draft_project_json = $draftProject;
            $update->draft_html = $draftHtml;
            $update->draft_css = (string) $layout['draft_css'];
            $update->published_html = $publishedHtml;
            $update->published_css = (string) $layout['published_css'];
            // Legacy hashes describe the derived cache. Concurrency hashes for
            // dictionaries live in page_texts and are returned by editorState.
            $update->draft_hash = (string) $text['draft_hash'];
            $update->published_hash = hash('sha256', $publishedHtml . "\0" . (string) $layout['published_css']);
            $this->db->updateObject('#__lmzpagebuilder_page_translations', $update, 'id', true);
            $count++;
        }

        return $count;
    }

    /** @param array<string, mixed> $translation */
    private function addPreMigrationRevision(array $translation): void
    {
        $query = $this->db->getQuery(true)
            ->select('COUNT(*)')
            ->from($this->db->quoteName('#__lmzpagebuilder_page_revisions'))
            ->where($this->db->quoteName('translation_id') . ' = ' . (int) $translation['id'])
            ->where($this->db->quoteName('operation') . ' = ' . $this->db->quote('pre_migration'));
        if ((int) $this->db->setQuery($query)->loadResult() > 0) {
            return;
        }
        $html = $this->sanitizer->sanitizeHtml((string) $translation['published_html']);
        $css = $this->sanitizer->sanitizeCss((string) $translation['published_css']);
        $revision = new stdClass();
        $revision->translation_id = (int) $translation['id'];
        $revision->operation = 'pre_migration';
        $revision->project_json = (string) $translation['draft_project_json'];
        $revision->html = $html;
        $revision->css = $css;
        $revision->snapshot_hash = hash(
            'sha256',
            (string) $translation['draft_project_json'] . "\0"
            . (string) $translation['draft_html'] . "\0"
            . (string) $translation['draft_css'] . "\0"
            . $html . "\0" . $css
        );
        $revision->metadata_json = json_encode([
            'migration' => 'shared-layout-v1',
            'title' => (string) $translation['title'],
            'alias' => (string) $translation['alias'],
            'browser_title' => (string) $translation['browser_title'],
            'meta_description' => (string) $translation['meta_description'],
            'meta_keywords' => (string) $translation['meta_keywords'],
            'robots' => (string) $translation['robots'],
            'language' => (string) $translation['language'],
            'legacy_draft_project_json' => (string) $translation['draft_project_json'],
            'legacy_draft_html' => (string) $translation['draft_html'],
            'legacy_draft_css' => (string) $translation['draft_css'],
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
        $revision->note = 'Automatic backup before LMZ Page Builder 2.4 localization migration';
        $revision->created = $this->now();
        $revision->created_by = $this->actorId();
        $this->db->insertObject('#__lmzpagebuilder_page_revisions', $revision, 'id');
    }

    // ---------------------------------------------------------------------
    // DOM/dictionary helpers

    /** @return array{0: DOMDocument, 1: DOMElement} */
    private function parseFragment(string $html): array
    {
        if (str_contains($html, "\0")) {
            throw new RuntimeException('Localized HTML contains an invalid null byte.', 422);
        }
        $dom = new DOMDocument('1.0', 'UTF-8');
        $previous = libxml_use_internal_errors(true);
        $loaded = $dom->loadHTML(
            '<!DOCTYPE html><html><head><meta charset="utf-8"></head><body>' . $html . '</body></html>',
            LIBXML_HTML_NODEFDTD | LIBXML_NOERROR | LIBXML_NOWARNING | LIBXML_NONET | LIBXML_COMPACT
        );
        libxml_clear_errors();
        libxml_use_internal_errors($previous);
        $body = $dom->getElementsByTagName('body')->item(0);
        if (!$loaded || !$body instanceof DOMElement) {
            throw new RuntimeException('Localized HTML could not be parsed.', 422);
        }

        return [$dom, $body];
    }

    /** @return array<string, DOMElement> */
    private function elementMap(DOMElement $body): array
    {
        $map = [];
        $walk = function (DOMNode $parent, string $prefix) use (&$walk, &$map): void {
            $position = 0;
            foreach ($parent->childNodes as $child) {
                if (!$child instanceof DOMElement) {
                    continue;
                }
                $path = $prefix === '' ? (string) $position : $prefix . '.' . $position;
                $map[$path] = $child;
                $walk($child, $path);
                $position++;
            }
        };
        $walk($body, '');

        return $map;
    }

    /** @return array<int, DOMText> */
    private function directTextNodes(DOMElement $element): array
    {
        $nodes = [];
        foreach ($element->childNodes as $child) {
            if ($child instanceof DOMText && trim($child->nodeValue ?? '') !== '') {
                $nodes[] = $child;
            }
        }

        return $nodes;
    }

    /** @return array<int, string> */
    private function allowedAttributes(DOMElement $element): array
    {
        $attributes = self::TRANSLATABLE_ATTRIBUTES;
        if (strtolower($element->tagName) === 'input'
            && in_array(strtolower($element->getAttribute('type')), ['submit', 'button', 'reset'], true)) {
            $attributes[] = 'value';
        }

        return $attributes;
    }

    private function hasTranslatableValue(DOMElement $element): bool
    {
        if ($this->directTextNodes($element) !== []) {
            return true;
        }
        foreach ($this->allowedAttributes($element) as $attribute) {
            if ($element->hasAttribute($attribute)) {
                return true;
            }
        }

        return false;
    }

    private function serializeBody(DOMDocument $dom, DOMElement $body): string
    {
        $html = '';
        foreach (iterator_to_array($body->childNodes) as $child) {
            $serialized = $dom->saveHTML($child);
            if (is_string($serialized)) {
                $html .= $serialized;
            }
        }

        return trim($html);
    }

    private function structureOf(DOMNode $node, bool $ignoreMarkers = false): string
    {
        $result = '';
        foreach ($node->childNodes as $child) {
            if ($child instanceof DOMElement) {
                $attributes = [];
                foreach ($child->attributes as $attribute) {
                    $name = strtolower($attribute->nodeName);
                    if (in_array($name, $this->allowedAttributes($child), true)) {
                        continue;
                    }
                    if ($ignoreMarkers && $name === self::MARKER_ATTRIBUTE) {
                        continue;
                    }
                    $attributes[$name] = $attribute->nodeValue ?? '';
                }
                ksort($attributes);
                $result .= '<' . strtolower($child->tagName) . ' ' . json_encode($attributes, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . '>';
                $result .= $this->structureOf($child, $ignoreMarkers);
                $result .= '</' . strtolower($child->tagName) . '>';
            } elseif ($child->nodeType === XML_COMMENT_NODE) {
                $result .= '#comment:' . hash('sha256', (string) $child->nodeValue);
            }
        }

        return $result;
    }

    /** @param array<string, bool> $used */
    private function newMarker(string $pageKey, string $path, string $tag, array $used): string
    {
        $prefix = strtolower(preg_replace('/[^a-z0-9._-]+/i', '-', trim($pageKey)) ?? 'page');
        $prefix = trim($prefix, '-.') ?: 'page';
        $base = substr($prefix . '.' . $tag . '.' . str_replace('.', '-', $path), 0, 150)
            . '.' . substr(hash('sha256', $prefix . '|' . $path . '|' . $tag), 0, 8);
        $candidate = $base;
        $suffix = 2;
        while (isset($used[$candidate])) {
            $candidate = substr($base, 0, 180) . '-' . $suffix++;
        }

        return $candidate;
    }

    private function validMarker(string $key): bool
    {
        return $key !== '' && strlen($key) <= 191 && preg_match('/^[a-z0-9][a-z0-9._:-]*$/i', $key) === 1;
    }

    /** @return array{version: int, values: array<string, mixed>} */
    private function dictionaryForMaster(string $localizedHtml, string $masterHtml): array
    {
        [, $masterBody] = $this->parseFragment($masterHtml);
        [, $candidateBody] = $this->parseFragment($localizedHtml);
        $masterByKey = [];
        $candidateByKey = [];
        foreach ($this->elementMap($masterBody) as $element) {
            $key = trim($element->getAttribute(self::MARKER_ATTRIBUTE));
            if ($key !== '') {
                $masterByKey[$key] = $element;
            }
        }
        foreach ($this->elementMap($candidateBody) as $element) {
            $key = trim($element->getAttribute(self::MARKER_ATTRIBUTE));
            if ($key !== '') {
                $candidateByKey[$key] = $element;
            }
        }

        $dictionary = $this->emptyDictionary();
        foreach ($masterByKey as $key => $master) {
            $candidate = $candidateByKey[$key] ?? null;
            if (!$candidate instanceof DOMElement || strtolower($candidate->tagName) !== strtolower($master->tagName)) {
                throw new RuntimeException('Translation mode cannot change or remove data-lmz-i18n markers.', 409);
            }
            $entry = ['text' => [], 'attributes' => []];
            $masterNodes = $this->directTextNodes($master);
            $candidateNodes = $this->directTextNodes($candidate);
            foreach ($masterNodes as $index => $ignored) {
                // An absent candidate node represents an intentional empty
                // translation, not a request to fall back to the source.
                $entry['text'][(string) $index] = isset($candidateNodes[$index])
                    ? (string) ($candidateNodes[$index]->nodeValue ?? '')
                    : '';
            }
            foreach ($this->allowedAttributes($master) as $attribute) {
                if ($candidate->hasAttribute($attribute)) {
                    $entry['attributes'][$attribute] = $candidate->getAttribute($attribute);
                } elseif ($master->hasAttribute($attribute)) {
                    $entry['attributes'][$attribute] = '';
                }
            }
            if ($entry['text'] !== [] || $entry['attributes'] !== []) {
                $dictionary['values'][$key] = $entry;
            }
        }

        return $this->normalizeDictionary($dictionary);
    }

    /** @return array{version: int, values: array<string, mixed>} */
    private function mapLegacyVariant(string $masterHtml, string $variantHtml): array
    {
        [, $masterBody] = $this->parseFragment($masterHtml);
        [, $variantBody] = $this->parseFragment($this->sanitizer->sanitizeHtml($variantHtml));
        $masterMap = $this->elementMap($masterBody);
        $variantMap = $this->elementMap($variantBody);
        $dictionary = $this->emptyDictionary();

        foreach ($masterMap as $path => $master) {
            $key = trim($master->getAttribute(self::MARKER_ATTRIBUTE));
            $variant = $variantMap[$path] ?? null;
            if ($key === '' || !$variant instanceof DOMElement
                || strtolower($variant->tagName) !== strtolower($master->tagName)) {
                continue;
            }
            $entry = ['text' => [], 'attributes' => []];
            $sourceNodes = $this->directTextNodes($master);
            $variantNodes = $this->directTextNodes($variant);
            if (count($sourceNodes) === count($variantNodes)) {
                foreach ($variantNodes as $index => $node) {
                    $entry['text'][(string) $index] = $node->nodeValue ?? '';
                }
            }
            foreach ($this->allowedAttributes($master) as $attribute) {
                if ($master->hasAttribute($attribute) && $variant->hasAttribute($attribute)) {
                    $entry['attributes'][$attribute] = $variant->getAttribute($attribute);
                }
            }
            if ($entry['text'] !== [] || $entry['attributes'] !== []) {
                $dictionary['values'][$key] = $entry;
            }
        }

        return $this->normalizeDictionary($dictionary);
    }

    private function projectWithContent(
        string $projectJson,
        int $pageId,
        string $language,
        string $title,
        string $html,
        string $css
    ): string {
        $newProject = trim($projectJson) === '';
        $project = json_decode($projectJson, true);
        if (!is_array($project)) {
            if (!$newProject) {
                throw new RuntimeException('The stored builder project JSON is invalid; localization stopped without changing it.', 422);
            }
            $project = [];
        }
        if (!$newProject && (!isset($project['pages']) || !is_array($project['pages']) || !is_array($project['pages'][0] ?? null))) {
            throw new RuntimeException('The stored builder project has no valid GrapesJS page; localization stopped without changing it.', 422);
        }
        $project['assets'] = is_array($project['assets'] ?? null) ? $project['assets'] : [];
        $project['styles'] = is_array($project['styles'] ?? null) ? $project['styles'] : [];
        $component = $css !== '' ? '<style>' . str_ireplace('</style', '', $css) . '</style>' . $html : $html;
        $page = is_array($project['pages'][0] ?? null) ? $project['pages'][0] : [];
        $page['id'] = (string) ($page['id'] ?? ('lmz-page-' . $pageId));
        $page['name'] = $title;
        $page['component'] = $component;
        $project['pages'] = [$page];
        $project['custom'] = is_array($project['custom'] ?? null) ? $project['custom'] : [];
        $project['custom']['engine'] = 'lmz-grapesjs';
        $project['custom']['schemaVersion'] = 3;
        $project['custom']['source'] = ['pageId' => $pageId, 'language' => $language];

        return json_encode($project, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
    }

    /** @return array{version: int, values: array<string, mixed>} */
    private function emptyDictionary(): array
    {
        return ['version' => self::DICTIONARY_VERSION, 'values' => []];
    }

    private function encodeDictionary(array $dictionary): string
    {
        return json_encode(
            $this->normalizeDictionary($dictionary),
            JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR
        );
    }

    /** @return array{version: int, values: array<string, mixed>} */
    private function decodeDictionary(string $json): array
    {
        $decoded = json_decode($json, true);

        return $this->normalizeDictionary(is_array($decoded) ? $decoded : $this->emptyDictionary());
    }

    private function layoutHash(string $projectJson, string $html, string $css): string
    {
        return hash('sha256', $projectJson . "\0" . $html . "\0" . $css);
    }

    private function assertCurrentHash(string $stored, string $expected, string $message): void
    {
        if (!preg_match('/^[a-f0-9]{64}$/', strtolower($expected)) || !hash_equals($stored, strtolower($expected))) {
            throw new RuntimeException($message . ' Reload before continuing.', 409);
        }
    }

    private function cleanValue(string $value): string
    {
        if (str_contains($value, "\0")) {
            throw new RuntimeException('A localized value contains an invalid null byte.', 422);
        }

        return mb_substr($value, 0, 20000);
    }

    private function actorId(): int
    {
        return max(0, (int) ($this->identity->id ?? 0));
    }

    private function now(): string
    {
        return Factory::getDate()->toSql();
    }

    private function safeRollback(): void
    {
        try {
            $this->db->transactionRollback();
        } catch (Throwable $ignored) {
            // Preserve the original failure.
        }
    }
}
