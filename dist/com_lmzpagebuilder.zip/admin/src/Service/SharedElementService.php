<?php

namespace LMZ\Component\Lmzpagebuilder\Administrator\Service;

defined('_JEXEC') or die;

use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Factory;
use Joomla\CMS\Filter\OutputFilter;
use Joomla\Database\DatabaseInterface;
use RuntimeException;
use stdClass;
use Throwable;

final class SharedElementService
{
    private DatabaseInterface $db;
    private object $identity;
    private HtmlSanitizer $sanitizer;
    private LanguageService $languages;
    private int $maxPayloadBytes;
    private int $checkoutMinutes;

    public function __construct(DatabaseInterface $db, object $identity)
    {
        $this->db = $db;
        $this->identity = $identity;
        $this->sanitizer = new HtmlSanitizer();
        $this->languages = new LanguageService($db);
        $params = ComponentHelper::getParams('com_lmzpagebuilder');
        $this->maxPayloadBytes = max(2, min(32, (int) $params->get('max_payload_mb', 12))) * 1024 * 1024;
        $this->checkoutMinutes = max(10, min(480, (int) $params->get('checkout_minutes', 60)));
    }

    /** @return array<int, array<string, mixed>> */
    public function listElements(string $kind = ''): array
    {
        $this->assertManage();
        $query = $this->db->getQuery(true)
            ->select('e.*')
            ->select('COUNT(DISTINCT u.id) AS usage_count')
            ->from($this->db->quoteName('#__lmzpagebuilder_elements', 'e'))
            ->leftJoin($this->db->quoteName('#__lmzpagebuilder_element_usages', 'u') . ' ON ' . $this->db->quoteName('u.element_id') . ' = ' . $this->db->quoteName('e.id'))
            ->group(implode(', ', array_map([$this->db, 'quoteName'], [
                'e.id', 'e.uuid', 'e.element_key', 'e.title', 'e.kind', 'e.state', 'e.access',
                'e.ordering', 'e.created', 'e.created_by', 'e.modified', 'e.modified_by',
            ])))
            ->order($this->db->quoteName('e.kind') . ' ASC, ' . $this->db->quoteName('e.ordering') . ' ASC, ' . $this->db->quoteName('e.id') . ' ASC');

        if ($kind !== '') {
            $query->where($this->db->quoteName('e.kind') . ' = ' . $this->db->quote($this->validateKind($kind)));
        }

        $elements = $this->db->setQuery($query)->loadAssocList() ?: [];
        $translationQuery = $this->db->getQuery(true)
            ->select('*')
            ->from($this->db->quoteName('#__lmzpagebuilder_element_translations'))
            ->order($this->db->quoteName('language') . ' ASC');
        $byElement = [];

        foreach ($this->db->setQuery($translationQuery)->loadAssocList() ?: [] as $translation) {
            $translation = $this->normalizeTranslation($translation);
            $byElement[(int) $translation['element_id']][(string) $translation['language']] = $translation;
        }

        foreach ($elements as &$element) {
            $element['id'] = (int) $element['id'];
            $element['state'] = (int) $element['state'];
            $element['access'] = (int) $element['access'];
            $element['ordering'] = (int) $element['ordering'];
            $element['usage_count'] = (int) $element['usage_count'];
            $element['variants'] = $byElement[(int) $element['id']] ?? [];
            $element['translations'] = array_values($element['variants']);
            $element['available_languages'] = $this->languages->listAvailable();
        }
        unset($element);

        return $elements;
    }

    /** @param array<string, mixed> $data */
    public function createElement(array $data): array
    {
        $this->assertAction('core.create');
        $title = $this->cleanTitle((string) ($data['title'] ?? ''));
        $kind = $this->validateKind((string) ($data['kind'] ?? 'global'));
        $key = $this->uniqueKey((string) ($data['element_key'] ?? $title));
        $languages = $data['languages'] ?? [$this->languages->defaultCode()];

        if (!is_array($languages) || $languages === []) {
            $languages = [$this->languages->defaultCode()];
        }

        $languageCodes = [];
        foreach ($languages as $language) {
            $languageCodes[] = $this->languages->assertAvailable((string) $language);
        }
        $languageCodes = array_values(array_unique($languageCodes));
        $this->db->transactionStart();

        try {
            $now = Factory::getDate()->toSql();
            $element = new stdClass();
            $element->uuid = $this->uuid();
            $element->element_key = $key;
            $element->title = $title;
            $element->kind = $kind;
            $element->state = isset($data['state']) ? (int) ((bool) $data['state']) : 1;
            $element->access = max(1, (int) ($data['access'] ?? 1));
            $element->ordering = (int) ($data['ordering'] ?? 0);
            $element->created = $now;
            $element->created_by = (int) $this->identity->id;
            $element->modified = $now;
            $element->modified_by = (int) $this->identity->id;
            $this->db->insertObject('#__lmzpagebuilder_elements', $element, 'id');

            foreach ($languageCodes as $language) {
                $this->insertEmptyTranslation((int) $element->id, $language, $title, $now);
            }

            $this->db->transactionCommit();
        } catch (Throwable $error) {
            $this->safeRollback();
            throw $error;
        }

        return $this->loadElement((int) $element->id);
    }

    /** @param array<string, mixed> $data */
    public function updateElement(int $elementId, array $data): array
    {
        $this->assertAction('core.edit');
        $element = $this->loadElement($elementId);
        $update = new stdClass();
        $update->id = $elementId;
        $update->title = array_key_exists('title', $data) ? $this->cleanTitle((string) $data['title']) : (string) $element['title'];
        $update->kind = array_key_exists('kind', $data) ? $this->validateKind((string) $data['kind']) : (string) $element['kind'];
        $update->state = array_key_exists('state', $data) ? (int) ((bool) $data['state']) : (int) $element['state'];
        $update->access = array_key_exists('access', $data) ? max(1, (int) $data['access']) : (int) $element['access'];
        $update->ordering = array_key_exists('ordering', $data) ? (int) $data['ordering'] : (int) $element['ordering'];
        $update->modified = Factory::getDate()->toSql();
        $update->modified_by = (int) $this->identity->id;
        $this->db->updateObject('#__lmzpagebuilder_elements', $update, 'id', true);

        return $this->loadElement($elementId);
    }

    /** @param array<string, mixed> $data */
    public function createTranslation(int $elementId, string $language, array $data = []): array
    {
        $this->assertAction('core.create');
        $element = $this->loadElement($elementId);
        $language = $this->languages->assertAvailable($language);
        $existing = $this->findTranslation($elementId, $language);

        if ($existing !== null) {
            return $this->normalizeTranslation($existing);
        }

        $title = $this->cleanTitle((string) ($data['title'] ?? $element['title']));
        $this->insertEmptyTranslation($elementId, $language, $title, Factory::getDate()->toSql());

        return $this->normalizeTranslation($this->loadTranslation((int) $this->db->insertid()));
    }

    /** @return array<string, mixed> */
    public function acquire(int $elementId, string $language): array
    {
        $this->assertAction('core.edit');
        $language = $this->languages->assertAvailable($language);
        $translation = $this->findTranslation($elementId, $language);

        if ($translation === null) {
            throw new RuntimeException('No shared-element translation exists for the selected language.', 404);
        }

        $this->db->transactionStart();
        try {
            $translation = $this->loadTranslation((int) $translation['id'], true);
            $this->assertCheckout($translation);
            $now = Factory::getDate()->toSql();
            $token = bin2hex(random_bytes(32));
            $update = new stdClass();
            $update->id = (int) $translation['id'];
            $update->checked_out = (int) $this->identity->id;
            $update->checked_out_time = $now;
            $update->checkout_token = $token;
            $this->db->updateObject('#__lmzpagebuilder_element_translations', $update, 'id', true);
            $translation['checked_out'] = (int) $this->identity->id;
            $translation['checked_out_time'] = $now;
            $translation['checkout_token'] = $token;
            $this->db->transactionCommit();
        } catch (Throwable $error) {
            $this->safeRollback();
            throw $error;
        }

        return $this->editorDocument($translation);
    }

    /** @return array<string, mixed> */
    public function loadForEditor(int $translationId, string $leaseToken): array
    {
        $this->assertManage();
        $translation = $this->loadTranslation($translationId);
        $this->assertLease($translation, $leaseToken);
        $project = json_decode((string) $translation['draft_project_json'], true);

        if (!is_array($project) || !isset($project['pages'])) {
            throw new RuntimeException('The stored shared-element project is invalid.', 500);
        }

        return ['project' => $project, 'document' => $this->documentMeta($translation)];
    }

    /** @return array<string, mixed> */
    public function saveDraft(
        int $translationId,
        string $expectedDraftHash,
        string $projectJson,
        string $html,
        string $css,
        string $leaseToken
    ): array {
        $this->assertAction('lmzpagebuilder.save', 'core.edit');
        $this->assertHash($expectedDraftHash, 'expected_draft_hash');
        $this->assertPayloadSize($projectJson, $html, $css);
        $decoded = json_decode($projectJson, true);
        if (!is_array($decoded) || !isset($decoded['pages']) || !is_array($decoded['pages'])) {
            throw new RuntimeException('The GrapesJS project JSON must contain a pages list.', 422);
        }

        $safeHtml = $this->sanitizer->sanitizeHtml($html);
        $safeCss = $this->sanitizer->sanitizeCss($css);
        $this->db->transactionStart();

        try {
            $translation = $this->loadTranslation($translationId, true);
            $this->assertLease($translation, $leaseToken);
            if (!hash_equals((string) $translation['draft_hash'], strtolower($expectedDraftHash))) {
                throw new RuntimeException('The shared-element draft changed in another editor.', 409);
            }

            $references = $this->referencesFromHtml($safeHtml);
            if ((string) $translation['kind'] === 'global') {
                $this->assertNoCycle((int) $translation['element_id'], $references);
            }
            $project = $this->projectJson(
                (int) $translation['element_id'],
                (string) $translation['language'],
                (string) $translation['title'],
                $safeHtml,
                $safeCss
            );
            $hash = $this->draftHash($project, $safeHtml, $safeCss);
            $now = Factory::getDate()->toSql();
            $update = new stdClass();
            $update->id = $translationId;
            $update->draft_project_json = $project;
            $update->draft_html = $safeHtml;
            $update->draft_css = $safeCss;
            $update->draft_hash = $hash;
            $update->checked_out = (int) $this->identity->id;
            $update->checked_out_time = $now;
            $update->modified = $now;
            $update->modified_by = (int) $this->identity->id;
            $this->db->updateObject('#__lmzpagebuilder_element_translations', $update, 'id', true);
            $this->replaceUsages('element_translation', $translationId, (string) $translation['language'], $references);
            $this->db->transactionCommit();
        } catch (Throwable $error) {
            $this->safeRollback();
            throw $error;
        }

        return ['draft_hash' => $hash, 'modified' => $now];
    }

    /** @return array<string, mixed> */
    public function publish(
        int $translationId,
        string $expectedPublishedHash,
        string $expectedDraftHash,
        string $leaseToken
    ): array {
        $this->assertAction('lmzpagebuilder.publish', 'core.edit.state');
        $this->assertHash($expectedPublishedHash, 'expected_published_hash');
        $this->assertHash($expectedDraftHash, 'expected_draft_hash');
        $this->db->transactionStart();

        try {
            $translation = $this->loadTranslation($translationId, true);
            $this->assertLease($translation, $leaseToken);
            if (!hash_equals((string) $translation['published_hash'], strtolower($expectedPublishedHash))) {
                throw new RuntimeException('The published shared element changed.', 409);
            }
            if (!hash_equals((string) $translation['draft_hash'], strtolower($expectedDraftHash))) {
                throw new RuntimeException('The shared-element draft is stale.', 409);
            }

            $html = $this->sanitizer->sanitizeHtml((string) $translation['draft_html']);
            $css = $this->sanitizer->sanitizeCss((string) $translation['draft_css']);
            $this->assertTemplateRegionSlots($translation, $html);
            $references = $this->referencesFromHtml($html);
            if ((string) $translation['kind'] === 'global') {
                $this->assertNoCycle((int) $translation['element_id'], $references);
            }
            $hash = $this->publishedHash($html, $css);
            $now = Factory::getDate()->toSql();
            $update = new stdClass();
            $update->id = $translationId;
            $update->published_html = $html;
            $update->published_css = $css;
            $update->published_hash = $hash;
            $update->state = 1;
            $update->published = $now;
            $update->published_by = (int) $this->identity->id;
            $update->checked_out_time = $now;
            $update->modified = $now;
            $update->modified_by = (int) $this->identity->id;
            $this->db->updateObject('#__lmzpagebuilder_element_translations', $update, 'id', true);
            $this->replaceUsages('element_translation', $translationId, (string) $translation['language'], $references);
            $this->db->transactionCommit();
        } catch (Throwable $error) {
            $this->safeRollback();
            throw $error;
        }

        $this->clearCache();

        return ['published_hash' => $hash, 'source_hash' => $hash, 'draft_hash' => (string) $translation['draft_hash'], 'modified' => $now];
    }

    /** @return array{checked_out_time: string} */
    public function touch(int $translationId, string $leaseToken): array
    {
        $this->assertAction('core.edit');
        $translation = $this->loadTranslation($translationId);
        $this->assertLease($translation, $leaseToken);
        $now = Factory::getDate()->toSql();
        $update = new stdClass();
        $update->id = $translationId;
        $update->checked_out_time = $now;
        $this->db->updateObject('#__lmzpagebuilder_element_translations', $update, 'id', true);

        return ['checked_out_time' => $now];
    }

    public function release(int $translationId, string $leaseToken): void
    {
        $this->assertManage();
        $this->db->transactionStart();
        try {
            $translation = $this->loadTranslation($translationId, true);
            $this->assertLease($translation, $leaseToken);
            $update = new stdClass();
            $update->id = $translationId;
            $update->checked_out = 0;
            $update->checked_out_time = null;
            $update->checkout_token = '';
            $this->db->updateObject('#__lmzpagebuilder_element_translations', $update, 'id', true);
            $this->db->transactionCommit();
        } catch (Throwable $error) {
            $this->safeRollback();
            throw $error;
        }

        $this->clearCache();
    }

    /** @return array<int, array<string, mixed>> */
    public function usages(int $elementId): array
    {
        $this->assertManage();
        $this->loadElement($elementId);
        $query = $this->db->getQuery(true)
            ->select('u.*')
            ->select($this->db->quoteName('pt.page_id', 'page_id'))
            ->select($this->db->quoteName('pt.title', 'page_title'))
            ->select($this->db->quoteName('et.element_id', 'owner_element_id'))
            ->select($this->db->quoteName('et.title', 'element_title'))
            ->from($this->db->quoteName('#__lmzpagebuilder_element_usages', 'u'))
            ->leftJoin($this->db->quoteName('#__lmzpagebuilder_page_translations', 'pt') . " ON u.owner_type = 'page_translation' AND pt.id = u.owner_id")
            ->leftJoin($this->db->quoteName('#__lmzpagebuilder_element_translations', 'et') . " ON u.owner_type = 'element_translation' AND et.id = u.owner_id")
            ->where($this->db->quoteName('u.element_id') . ' = ' . $elementId)
            ->order($this->db->quoteName('u.owner_type') . ' ASC, ' . $this->db->quoteName('u.owner_id') . ' ASC');

        return $this->db->setQuery($query)->loadAssocList() ?: [];
    }

    public function deleteElement(int $elementId): void
    {
        $this->assertAction('core.delete');
        $this->loadElement($elementId);
        $usageQuery = $this->db->getQuery(true)
            ->select('COUNT(*)')
            ->from($this->db->quoteName('#__lmzpagebuilder_element_usages'))
            ->where($this->db->quoteName('element_id') . ' = ' . $elementId);
        if ((int) $this->db->setQuery($usageQuery)->loadResult() > 0) {
            throw new RuntimeException('The shared element is still embedded and cannot be deleted.', 409);
        }

        $translationIdsQuery = $this->db->getQuery(true)
            ->select($this->db->quoteName('id'))
            ->from($this->db->quoteName('#__lmzpagebuilder_element_translations'))
            ->where($this->db->quoteName('element_id') . ' = ' . $elementId);
        $translationIds = array_map('intval', $this->db->setQuery($translationIdsQuery)->loadColumn() ?: []);
        $this->db->transactionStart();
        try {
            if ($translationIds !== []) {
                $deleteUsages = $this->db->getQuery(true)
                    ->delete($this->db->quoteName('#__lmzpagebuilder_element_usages'))
                    ->where($this->db->quoteName('owner_type') . ' = ' . $this->db->quote('element_translation'))
                    ->where($this->db->quoteName('owner_id') . ' IN (' . implode(',', $translationIds) . ')');
                $this->db->setQuery($deleteUsages)->execute();
            }
            $deleteTranslations = $this->db->getQuery(true)
                ->delete($this->db->quoteName('#__lmzpagebuilder_element_translations'))
                ->where($this->db->quoteName('element_id') . ' = ' . $elementId);
            $this->db->setQuery($deleteTranslations)->execute();
            $deleteElement = $this->db->getQuery(true)
                ->delete($this->db->quoteName('#__lmzpagebuilder_elements'))
                ->where($this->db->quoteName('id') . ' = ' . $elementId);
            $this->db->setQuery($deleteElement)->execute();
            $this->db->transactionCommit();
        } catch (Throwable $error) {
            $this->safeRollback();
            throw $error;
        }

        $this->clearCache();
    }

    /**
     * Synchronises exact shared-element references in a page draft. UUID and
     * element_key are accepted. Unknown references are rejected, never silently
     * ignored.
     */
    public function syncPageUsages(int $translationId, string $language, string $html): void
    {
        $this->assertManage();
        $this->replaceUsages('page_translation', $translationId, $language, $this->referencesFromHtml($html));
    }

    /**
     * Resolve a published global element for a precise language. There is no
     * language fallback: missing translations fail visibly.
     *
     * @return array<string, mixed>
     */
    public function published(string $uuidOrKey, string $language): array
    {
        $language = $this->languages->assertAvailable($language);
        $element = $this->findByReference($uuidOrKey);
        if ($element === null || (string) $element['kind'] !== 'global' || (int) $element['state'] !== 1) {
            throw new RuntimeException('Published global element not found.', 404);
        }

        $translation = $this->findTranslation((int) $element['id'], $language);
        if ($translation === null || (int) $translation['state'] !== 1) {
            throw new RuntimeException('The global element has no published translation for ' . $language . '.', 404);
        }

        return [
            'id' => (int) $element['id'],
            'uuid' => (string) $element['uuid'],
            'element_key' => (string) $element['element_key'],
            'language' => $language,
            'html' => (string) $translation['published_html'],
            'css' => (string) $translation['published_css'],
            'published_hash' => (string) $translation['published_hash'],
        ];
    }

    /** @return array<string, mixed> */
    private function loadElement(int $elementId): array
    {
        if ($elementId <= 0) {
            throw new RuntimeException('A valid shared-element ID is required.', 422);
        }
        $query = $this->db->getQuery(true)
            ->select('*')
            ->from($this->db->quoteName('#__lmzpagebuilder_elements'))
            ->where($this->db->quoteName('id') . ' = ' . $elementId);
        $row = $this->db->setQuery($query)->loadAssoc();
        if (!$row) {
            throw new RuntimeException('Shared element not found.', 404);
        }

        return $row;
    }

    /** @return array<string, mixed>|null */
    private function findByReference(string $uuidOrKey): ?array
    {
        $reference = trim($uuidOrKey);
        $isUuid = preg_match('/^[a-f0-9]{8}-[a-f0-9]{4}-[1-5][a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/i', $reference) === 1;
        if (!$isUuid && !preg_match('/^[a-z0-9][a-z0-9._-]{0,99}$/i', $reference)) {
            throw new RuntimeException('Invalid shared-element reference.', 422);
        }

        $query = $this->db->getQuery(true)
            ->select('*')
            ->from($this->db->quoteName('#__lmzpagebuilder_elements'));
        $query->where(
            $this->db->quoteName($isUuid ? 'uuid' : 'element_key') . ' = ' . $this->db->quote($reference)
        );
        $row = $this->db->setQuery($query)->loadAssoc();

        return $row ?: null;
    }

    /** @return array<string, mixed>|null */
    private function findTranslation(int $elementId, string $language): ?array
    {
        $query = $this->db->getQuery(true)
            ->select('t.*')
            ->select($this->db->quoteName('e.kind'))
            ->select($this->db->quoteName('e.uuid'))
            ->select($this->db->quoteName('e.element_key'))
            ->from($this->db->quoteName('#__lmzpagebuilder_element_translations', 't'))
            ->innerJoin($this->db->quoteName('#__lmzpagebuilder_elements', 'e') . ' ON ' . $this->db->quoteName('e.id') . ' = ' . $this->db->quoteName('t.element_id'))
            ->where($this->db->quoteName('t.element_id') . ' = ' . $elementId)
            ->where($this->db->quoteName('t.language') . ' = ' . $this->db->quote($language));
        $row = $this->db->setQuery($query)->loadAssoc();

        return $row ?: null;
    }

    /** @return array<string, mixed> */
    private function loadTranslation(int $translationId, bool $forUpdate = false): array
    {
        $query = $this->db->getQuery(true)
            ->select('t.*')
            ->select($this->db->quoteName('e.kind'))
            ->select($this->db->quoteName('e.uuid'))
            ->select($this->db->quoteName('e.element_key'))
            ->from($this->db->quoteName('#__lmzpagebuilder_element_translations', 't'))
            ->innerJoin($this->db->quoteName('#__lmzpagebuilder_elements', 'e') . ' ON ' . $this->db->quoteName('e.id') . ' = ' . $this->db->quoteName('t.element_id'))
            ->where($this->db->quoteName('t.id') . ' = ' . max(0, $translationId));
        $sql = (string) $query . ($forUpdate ? ' FOR UPDATE' : '');
        $row = $this->db->setQuery($sql)->loadAssoc();
        if (!$row) {
            throw new RuntimeException('Shared-element translation not found.', 404);
        }

        return $row;
    }

    private function insertEmptyTranslation(int $elementId, string $language, string $title, string $now): void
    {
        $project = $this->projectJson($elementId, $language, $title, '', '');
        $translation = new stdClass();
        $translation->element_id = $elementId;
        $translation->language = $language;
        $translation->title = $title;
        $translation->draft_project_json = $project;
        $translation->draft_html = '';
        $translation->draft_css = '';
        $translation->published_html = '';
        $translation->published_css = '';
        $translation->draft_hash = $this->draftHash($project, '', '');
        $translation->published_hash = $this->publishedHash('', '');
        $translation->state = 0;
        $translation->checked_out = 0;
        $translation->checked_out_time = null;
        $translation->checkout_token = '';
        $translation->created = $now;
        $translation->created_by = (int) $this->identity->id;
        $translation->modified = $now;
        $translation->modified_by = (int) $this->identity->id;
        $translation->published = null;
        $translation->published_by = 0;
        $this->db->insertObject('#__lmzpagebuilder_element_translations', $translation, 'id');
    }

    /** @return array<int, array<string, mixed>> */
    private function referencesFromHtml(string $html): array
    {
        preg_match_all(
            '~\bdata-lmz-shared-element\s*=\s*(["\'])([a-z0-9][a-z0-9._-]{0,99}|[a-f0-9-]{36})\1~i',
            $html,
            $matches,
            PREG_SET_ORDER
        );
        $references = [];
        foreach ($matches as $index => $match) {
            $element = $this->findByReference((string) $match[2]);
            if ($element === null || (string) $element['kind'] !== 'global') {
                throw new RuntimeException('Unknown global element reference: ' . (string) $match[2], 422);
            }
            $references[] = [
                'element_id' => (int) $element['id'],
                'uuid' => (string) $element['uuid'],
                'context' => 'marker-' . ($index + 1),
            ];
        }

        return $references;
    }

    /** @param array<int, array<string, mixed>> $references */
    private function replaceUsages(string $ownerType, int $ownerId, string $language, array $references): void
    {
        if (!in_array($ownerType, ['page_translation', 'element_translation'], true)) {
            throw new RuntimeException('Unsupported shared-element usage owner.', 500);
        }
        $delete = $this->db->getQuery(true)
            ->delete($this->db->quoteName('#__lmzpagebuilder_element_usages'))
            ->where($this->db->quoteName('owner_type') . ' = ' . $this->db->quote($ownerType))
            ->where($this->db->quoteName('owner_id') . ' = ' . $ownerId);
        $this->db->setQuery($delete)->execute();
        $now = Factory::getDate()->toSql();

        foreach ($references as $reference) {
            $usage = new stdClass();
            $usage->owner_type = $ownerType;
            $usage->owner_id = $ownerId;
            $usage->element_id = (int) $reference['element_id'];
            $usage->language = $language;
            $usage->marker_uuid = (string) $reference['uuid'];
            $usage->context = (string) $reference['context'];
            $usage->created = $now;
            $this->db->insertObject('#__lmzpagebuilder_element_usages', $usage, 'id');
        }
    }

    /** @param array<int, array<string, mixed>> $proposed */
    private function assertNoCycle(int $ownerElementId, array $proposed): void
    {
        $query = $this->db->getQuery(true)
            ->select($this->db->quoteName('et.element_id', 'owner_element_id'))
            ->select($this->db->quoteName('u.element_id', 'dependency_element_id'))
            ->from($this->db->quoteName('#__lmzpagebuilder_element_usages', 'u'))
            ->innerJoin($this->db->quoteName('#__lmzpagebuilder_element_translations', 'et') . ' ON ' . $this->db->quoteName('et.id') . ' = ' . $this->db->quoteName('u.owner_id'))
            ->where($this->db->quoteName('u.owner_type') . ' = ' . $this->db->quote('element_translation'));
        $graph = [];
        foreach ($this->db->setQuery($query)->loadAssocList() ?: [] as $edge) {
            $owner = (int) $edge['owner_element_id'];
            if ($owner === $ownerElementId) {
                continue;
            }
            $graph[$owner][] = (int) $edge['dependency_element_id'];
        }
        $graph[$ownerElementId] = array_values(array_unique(array_map(
            static fn (array $reference): int => (int) $reference['element_id'],
            $proposed
        )));

        $visiting = [];
        $visited = [];
        $walk = function (int $node) use (&$walk, &$graph, &$visiting, &$visited): void {
            if (isset($visiting[$node])) {
                throw new RuntimeException('Shared elements cannot reference themselves directly or indirectly.', 422);
            }
            if (isset($visited[$node])) {
                return;
            }
            $visiting[$node] = true;
            foreach ($graph[$node] ?? [] as $dependency) {
                $walk((int) $dependency);
            }
            unset($visiting[$node]);
            $visited[$node] = true;
        };
        $walk($ownerElementId);
    }

    private function projectJson(int $elementId, string $language, string $title, string $html, string $css): string
    {
        $component = $css !== '' ? '<style>' . $css . '</style>' . $html : $html;
        return (string) json_encode([
            'assets' => [],
            'styles' => [],
            'pages' => [[
                'id' => 'lmz-element-' . $elementId . '-' . strtolower(str_replace('-', '_', $language)),
                'name' => $title,
                'component' => $component,
            ]],
            'custom' => [
                'engine' => 'lmz-grapesjs',
                'schemaVersion' => 2,
                'source' => ['elementId' => $elementId, 'language' => $language],
            ],
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
    }

    /** @return array<string, mixed> */
    private function editorDocument(array $translation): array
    {
        $translation = $this->normalizeTranslation($translation);
        $translation['document_id'] = (int) $translation['id'];
        $translation['translation_id'] = (int) $translation['id'];
        $translation['project_json'] = (string) $translation['draft_project_json'];
        $translation['source_hash'] = (string) $translation['published_hash'];

        return $translation;
    }

    /** @return array<string, mixed> */
    private function documentMeta(array $translation): array
    {
        return [
            'id' => (int) $translation['id'],
            'translation_id' => (int) $translation['id'],
            'element_id' => (int) $translation['element_id'],
            'language' => (string) $translation['language'],
            'title' => (string) $translation['title'],
            'source_hash' => (string) $translation['published_hash'],
            'published_hash' => (string) $translation['published_hash'],
            'draft_hash' => (string) $translation['draft_hash'],
            'modified' => (string) $translation['modified'],
        ];
    }

    /** @return array<string, mixed> */
    private function normalizeTranslation(array $translation): array
    {
        foreach (['id', 'element_id', 'state', 'checked_out', 'created_by', 'modified_by', 'published_by'] as $field) {
            if (isset($translation[$field])) {
                $translation[$field] = (int) $translation[$field];
            }
        }
        $translation['document_id'] = (int) $translation['id'];
        $translation['source_hash'] = (string) $translation['published_hash'];

        return $translation;
    }

    private function validateKind(string $kind): string
    {
        $kind = strtolower(trim($kind));
        if (!in_array($kind, ['global', 'template'], true)) {
            throw new RuntimeException('Shared-element kind must be global or template.', 422);
        }

        return $kind;
    }

    /**
     * Reserved template elements may change layout freely, but their dynamic
     * Joomla runtime slots are an exact, immutable contract. Incomplete or
     * duplicate slot sets are rejected before publication.
     *
     * @param array<string, mixed> $translation
     */
    private function assertTemplateRegionSlots(array $translation, string $html): void
    {
        if ((string) ($translation['kind'] ?? '') !== 'template') {
            return;
        }

        $contracts = [
            'template-navigation' => ['brand', 'toggle', 'menu', 'languages', 'hotline'],
            'template-footer' => ['brand', 'services', 'company', 'contact', 'legal'],
        ];
        $key = (string) ($translation['element_key'] ?? '');
        if (!isset($contracts[$key])) {
            return;
        }

        preg_match_all(
            '~\bdata-lmz-template-slot\s*=\s*(["\'])([^"\']*)\1~i',
            $html,
            $matches
        );
        $slots = array_map(static fn (string $slot): string => strtolower(trim($slot)), $matches[2] ?? []);
        $expected = $contracts[$key];
        sort($slots, SORT_STRING);
        sort($expected, SORT_STRING);

        if ($slots !== $expected) {
            throw new RuntimeException(
                'The template region must contain every reserved runtime slot exactly once: '
                . implode(', ', $contracts[$key]) . '.',
                422
            );
        }
    }

    private function cleanTitle(string $title): string
    {
        $title = trim(preg_replace('/\s+/u', ' ', strip_tags($title)) ?? '');
        if ($title === '') {
            throw new RuntimeException('A shared-element title is required.', 422);
        }

        return mb_substr($title, 0, 255);
    }

    private function uniqueKey(string $candidate): string
    {
        $base = mb_substr(OutputFilter::stringURLSafe($candidate) ?: 'element', 0, 90);
        $key = $base;
        $suffix = 2;
        do {
            $query = $this->db->getQuery(true)
                ->select('COUNT(*)')
                ->from($this->db->quoteName('#__lmzpagebuilder_elements'))
                ->where($this->db->quoteName('element_key') . ' = ' . $this->db->quote($key));
            $exists = (int) $this->db->setQuery($query)->loadResult() > 0;
            if ($exists) {
                $key = mb_substr($base, 0, 90 - strlen((string) $suffix) - 1) . '-' . $suffix++;
            }
        } while ($exists);

        return $key;
    }

    private function uuid(): string
    {
        $bytes = random_bytes(16);
        $bytes[6] = chr((ord($bytes[6]) & 0x0f) | 0x40);
        $bytes[8] = chr((ord($bytes[8]) & 0x3f) | 0x80);
        $hex = bin2hex($bytes);

        return substr($hex, 0, 8) . '-' . substr($hex, 8, 4) . '-' . substr($hex, 12, 4)
            . '-' . substr($hex, 16, 4) . '-' . substr($hex, 20, 12);
    }

    private function draftHash(string $project, string $html, string $css): string
    {
        return hash('sha256', $project . "\0" . $html . "\0" . $css);
    }

    private function publishedHash(string $html, string $css): string
    {
        return hash('sha256', $html . "\0" . $css);
    }

    private function assertPayloadSize(string ...$values): void
    {
        if (array_sum(array_map('strlen', $values)) > $this->maxPayloadBytes) {
            throw new RuntimeException('The builder payload exceeds the configured size limit.', 413);
        }
    }

    private function assertHash(string $hash, string $field): void
    {
        if (!preg_match('/^[a-f0-9]{64}$/', strtolower($hash))) {
            throw new RuntimeException($field . ' must be a SHA-256 hash.', 428);
        }
    }

    /** @param array<string, mixed> $translation */
    private function assertCheckout(array $translation): void
    {
        $owner = (int) ($translation['checked_out'] ?? 0);
        $timestamp = strtotime((string) ($translation['checked_out_time'] ?? '') . ' UTC');
        $stale = $timestamp === false || $timestamp < time() - ($this->checkoutMinutes * 60);
        if ($owner === 0 || $owner === (int) $this->identity->id || $stale) {
            return;
        }

        throw new RuntimeException('The shared-element translation is checked out by another user.', 423);
    }

    /** @param array<string, mixed> $translation */
    private function assertLease(array $translation, string $token): void
    {
        if (!preg_match('/^[a-f0-9]{64}$/', strtolower($token))) {
            throw new RuntimeException('A valid shared-element editor lease is required.', 409);
        }
        if ((int) $translation['checked_out'] !== (int) $this->identity->id
            || !hash_equals(strtolower((string) $translation['checkout_token']), strtolower($token))) {
            throw new RuntimeException('A newer editor session owns this shared element.', 409);
        }
    }

    private function assertManage(): void
    {
        if ((int) ($this->identity->id ?? 0) <= 0
            || (!$this->identity->authorise('core.admin', 'com_lmzpagebuilder')
                && !$this->identity->authorise('core.manage', 'com_lmzpagebuilder'))) {
            throw new RuntimeException('LMZ Page Builder management permission is required.', 403);
        }
    }

    private function assertAction(string $action, ?string $fallback = null): void
    {
        $this->assertManage();
        if (!$this->identity->authorise('core.admin', 'com_lmzpagebuilder')
            && !$this->identity->authorise($action, 'com_lmzpagebuilder')
            && ($fallback === null || !$this->identity->authorise($fallback, 'com_lmzpagebuilder'))) {
            throw new RuntimeException('Permission denied for action ' . $action . '.', 403);
        }
    }

    private function safeRollback(): void
    {
        try {
            $this->db->transactionRollback();
        } catch (Throwable $ignored) {
            // Preserve original error.
        }
    }

    private function clearCache(): void
    {
        try {
            Factory::getCache('com_lmzpagebuilder')->clean();
        } catch (Throwable $ignored) {
            // Persisted content remains authoritative if cache cleanup fails.
        }
    }
}
