<?php

namespace LMZ\Component\Lmzpagebuilder\Administrator\Service;

defined('_JEXEC') or die;

use Joomla\CMS\Component\ComponentHelper;
use Joomla\Database\DatabaseInterface;

final class LanguageService
{
    public function __construct(private DatabaseInterface $db)
    {
    }

    /**
     * Returns Joomla content languages which are both published and backed by
     * an enabled site language extension. No language code is hard-coded.
     *
     * @return array<int, array<string, mixed>>
     */
    public function listAvailable(): array
    {
        $languages = [];
        $query = $this->db->getQuery(true)
            ->select($this->db->quoteName([
                'lang_code', 'title', 'title_native', 'sef', 'image', 'published', 'ordering',
            ]))
            ->from($this->db->quoteName('#__languages'))
            ->where($this->db->quoteName('published') . ' = 1')
            ->order($this->db->quoteName('ordering') . ' ASC');

        foreach ($this->db->setQuery($query)->loadAssocList() ?: [] as $row) {
            $code = $this->normalize((string) $row['lang_code']);
            if ($code === null) {
                continue;
            }

            $languages[$code] = [
                'code' => $code,
                'title' => (string) $row['title'],
                'native_title' => (string) $row['title_native'],
                'sef' => (string) $row['sef'],
                'image' => (string) $row['image'],
                'published' => true,
                'installed' => false,
                'ordering' => (int) $row['ordering'],
            ];
        }

        $installedQuery = $this->db->getQuery(true)
            ->select($this->db->quoteName(['element', 'name', 'enabled']))
            ->from($this->db->quoteName('#__extensions'))
            ->where($this->db->quoteName('type') . ' = ' . $this->db->quote('language'))
            ->where($this->db->quoteName('client_id') . ' = 0')
            ->where($this->db->quoteName('enabled') . ' = 1');

        foreach ($this->db->setQuery($installedQuery)->loadAssocList() ?: [] as $row) {
            $code = $this->normalize((string) $row['element']);
            if ($code === null) {
                continue;
            }

            if (isset($languages[$code])) {
                $languages[$code]['installed'] = true;
            }
        }

        $languages = array_filter(
            $languages,
            static fn (array $language): bool => $language['published'] && $language['installed']
        );

        $default = $this->normalize((string) ComponentHelper::getParams('com_languages')->get('site', ''));
        foreach ($languages as &$language) {
            $language['default'] = $default !== null && $language['code'] === $default;
        }
        unset($language);

        uasort($languages, static function (array $left, array $right): int {
            return [$left['ordering'], $left['native_title'], $left['code']]
                <=> [$right['ordering'], $right['native_title'], $right['code']];
        });

        return array_values($languages);
    }

    public function assertAvailable(string $language): string
    {
        $normalized = $this->normalize($language);
        if ($normalized === null) {
            throw new \RuntimeException('A valid Joomla language tag is required.', 422);
        }

        foreach ($this->listAvailable() as $item) {
            if ($item['code'] === $normalized) {
                return $normalized;
            }
        }

        throw new \RuntimeException('The selected language is not installed or published for the site.', 422);
    }

    public function defaultCode(): string
    {
        $languages = $this->listAvailable();
        foreach ($languages as $language) {
            if ($language['default']) {
                return (string) $language['code'];
            }
        }

        if ($languages !== []) {
            return (string) $languages[0]['code'];
        }

        throw new \RuntimeException('No usable site language is installed.', 500);
    }

    private function normalize(string $language): ?string
    {
        $language = str_replace('_', '-', trim($language));
        if (!preg_match('/^([a-z]{2,3})-([a-z]{2})$/i', $language, $matches)) {
            return null;
        }

        return strtolower($matches[1]) . '-' . strtoupper($matches[2]);
    }
}
