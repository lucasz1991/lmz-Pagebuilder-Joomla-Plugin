<?php

namespace LMZ\Component\Lmzpagebuilder\Administrator\Service;

defined('_JEXEC') or die;

use Joomla\CMS\Filesystem\Folder;
use Joomla\CMS\Uri\Uri;
use RuntimeException;

final class AssetService
{
    private const MAX_UPLOAD_BYTES = 8 * 1024 * 1024;
    private const MIME_EXTENSIONS = [
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
        'image/webp' => 'webp',
        'image/gif' => 'gif',
    ];

    /** @return array<int, array<string, mixed>> */
    public function listImages(): array
    {
        $assets = [];

        foreach (['images/lmz-pagebuilder', 'images/l3'] as $relativeRoot) {
            $absoluteRoot = JPATH_ROOT . '/' . $relativeRoot;

            if (!is_dir($absoluteRoot)) {
                continue;
            }

            $iterator = new \RecursiveIteratorIterator(
                new \RecursiveDirectoryIterator($absoluteRoot, \FilesystemIterator::SKIP_DOTS),
                \RecursiveIteratorIterator::LEAVES_ONLY
            );

            foreach ($iterator as $file) {
                if (!$file->isFile() || $file->isLink()) {
                    continue;
                }

                $extension = strtolower($file->getExtension());
                if (!in_array($extension, ['jpg', 'jpeg', 'png', 'webp', 'gif', 'svg'], true)) {
                    continue;
                }

                $absolute = str_replace('\\', '/', $file->getPathname());
                $root = str_replace('\\', '/', JPATH_ROOT) . '/';
                $relative = ltrim(substr($absolute, strlen($root)), '/');
                $assets[] = [
                    'src' => rtrim(Uri::root(), '/') . '/' . $relative,
                    'name' => $file->getBasename(),
                    'size' => $file->getSize(),
                ];

                if (count($assets) >= 750) {
                    break 2;
                }
            }
        }

        return $assets;
    }

    /** @param array<string, mixed> $upload */
    public function upload(array $upload): array
    {
        $error = (int) ($upload['error'] ?? UPLOAD_ERR_NO_FILE);
        $temporary = (string) ($upload['tmp_name'] ?? '');
        $size = (int) ($upload['size'] ?? 0);

        if ($error !== UPLOAD_ERR_OK || $temporary === '' || !is_uploaded_file($temporary)) {
            throw new RuntimeException('No valid uploaded image was received.', 422);
        }
        if ($size <= 0 || $size > self::MAX_UPLOAD_BYTES) {
            throw new RuntimeException('Images may be at most 8 MB.', 413);
        }

        $finfo = new \finfo(FILEINFO_MIME_TYPE);
        $mime = (string) $finfo->file($temporary);
        $extension = self::MIME_EXTENSIONS[$mime] ?? null;

        if ($extension === null) {
            throw new RuntimeException('Only JPEG, PNG, WebP and GIF images are allowed.', 422);
        }

        $targetDirectory = JPATH_ROOT . '/images/lmz-pagebuilder';
        if (!is_dir($targetDirectory) && !Folder::create($targetDirectory)) {
            throw new RuntimeException('The LMZ media directory could not be created.', 500);
        }

        $originalBase = pathinfo((string) ($upload['name'] ?? 'image'), PATHINFO_FILENAME);
        $safeBase = trim(preg_replace('/[^a-z0-9]+/i', '-', $originalBase) ?? '', '-');
        $safeBase = strtolower(substr($safeBase !== '' ? $safeBase : 'image', 0, 60));
        $filename = $safeBase . '-' . bin2hex(random_bytes(6)) . '.' . $extension;
        $target = $targetDirectory . '/' . $filename;

        if (!move_uploaded_file($temporary, $target)) {
            throw new RuntimeException('The uploaded image could not be stored.', 500);
        }

        @chmod($target, 0644);
        $url = rtrim(Uri::root(), '/') . '/images/lmz-pagebuilder/' . rawurlencode($filename);

        return ['src' => $url, 'url' => $url, 'name' => $filename, 'size' => filesize($target) ?: $size];
    }
}
