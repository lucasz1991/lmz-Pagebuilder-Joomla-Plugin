<?php

declare(strict_types=1);

namespace LMZ\Component\Lmzpagebuilder\Administrator\Service;

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\Database\DatabaseInterface;
use Joomla\Database\ParameterType;
use RuntimeException;
use stdClass;
use Throwable;

/**
 * Stores the template shell configuration independently from the Joomla
 * template-style params. A content hash provides optimistic concurrency and
 * every accepted save receives an immutable revision row.
 */
final class TemplateSettingsService
{
    private const SETTINGS_ID = 1;

    /** @var array<string, array{key:string,title:string,slots:array<int,string>}> */
    private const REGIONS = [
        'navigation' => [
            'key' => 'template-navigation',
            'title' => 'Navigation',
            'slots' => ['brand', 'toggle', 'menu', 'languages', 'hotline'],
        ],
        'footer' => [
            'key' => 'template-footer',
            'title' => 'Footer',
            'slots' => ['brand', 'services', 'company', 'contact', 'legal'],
        ],
    ];

    public function __construct(
        private DatabaseInterface $db,
        private object $identity
    ) {
    }

    /** @return array<string, mixed> */
    public static function defaults(): array
    {
        return [
            'contact_id' => 0,
            'logos' => [
                'favicon' => '/images/l3/logo/rt-logo.svg',
                'mark' => '/images/l3/logo/rt-logo.svg',
                'navigation_wordmark' => '/images/l3/logo-txt-darkbg.png',
                'footer_wordmark' => '/images/l3/logo-txt-darkbg.png',
                'alt_text' => 'RT Rail Time GmbH',
            ],
            'navigation' => [
                'menu_type' => 'mainmenu',
                'hotline' => '04171 546803',
                'hotline_visible' => true,
                'hotline_icon' => '',
                'background' => '#090c11',
                'text' => '#ffffff',
                'accent' => '#e4002b',
                'builder_enabled' => false,
            ],
            'footer' => [
                'company' => 'RT Rail Time GmbH',
                'email' => 'info@rail-time.de',
                'address' => "Borsteler Weg 29–31\n21423 Winsen (Luhe)",
                'email_icon' => '',
                'address_icon' => '',
                'background' => '#090c11',
                'text' => '#ffffff',
                'accent' => '#e4002b',
                'builder_enabled' => false,
            ],
        ];
    }

    /** @return array<string, mixed> */
    public function load(): array
    {
        $this->assertManage();
        $defaults = self::defaults();
        $result = [
            'settings' => $defaults,
            'hash' => $this->hash($defaults),
            'version' => 0,
            'modified' => '',
            'schema_ready' => $this->settingsSchemaAvailable(),
        ];

        if (!$result['schema_ready']) {
            return $result;
        }

        $query = $this->db->getQuery(true)
            ->select('*')
            ->from($this->db->quoteName('#__lmzpagebuilder_template_settings'))
            ->where($this->db->quoteName('id') . ' = ' . self::SETTINGS_ID);
        $row = $this->db->setQuery($query)->loadAssoc();

        if (!$row) {
            return $result;
        }

        $decoded = json_decode((string) $row['data_json'], true);
        if (is_array($decoded)) {
            $decoded['contact_id'] = (int) ($row['contact_id'] ?? $decoded['contact_id'] ?? 0);
        }
        try {
            $settings = is_array($decoded) ? $this->normalise($decoded, false) : $defaults;
        } catch (Throwable $invalidSettings) {
            $settings = $defaults;
            $result['data_invalid'] = true;
        }
        $canonicalHash = $this->hash($settings);

        $result['settings'] = $settings;
        $result['hash'] = preg_match('/^[a-f0-9]{64}$/', (string) $row['settings_hash'])
            ? (string) $row['settings_hash']
            : $canonicalHash;
        $result['version'] = (int) $row['version'];
        $result['modified'] = (string) $row['modified'];

        return $result;
    }

    /**
     * @param array<string, mixed> $input
     * @return array<string, mixed>
     */
    public function save(array $input, string $expectedHash, string $note = '', string $section = ''): array
    {
        $this->assertAction('lmzpagebuilder.settings', 'core.edit');
        if (!preg_match('/^[a-f0-9]{64}$/', strtolower($expectedHash))) {
            throw new RuntimeException('A valid settings version hash is required.', 428);
        }
        if (!$this->settingsSchemaAvailable()) {
            throw new RuntimeException('The template-settings database update has not been installed yet.', 503);
        }

        // Partial saves from the split "Kopfzeile / Navigation" and "Fusszeile"
        // pages only submit their own section. Merge the submitted fields onto
        // the currently stored settings so the untouched section is preserved
        // instead of being reset to defaults by normalise().
        $input = $this->mergeSection($input, strtolower(trim($section)));

        $settings = $this->normalise($input, true);
        $json = $this->canonicalJson($settings);
        $hash = hash('sha256', $json);
        $note = mb_substr(trim(preg_replace('/\s+/u', ' ', strip_tags($note)) ?? ''), 0, 500);
        $now = Factory::getDate()->toSql();
        $userId = (int) ($this->identity->id ?? 0);

        $this->db->transactionStart();
        try {
            $sql = (string) $this->db->getQuery(true)
                ->select('*')
                ->from($this->db->quoteName('#__lmzpagebuilder_template_settings'))
                ->where($this->db->quoteName('id') . ' = ' . self::SETTINGS_ID)
                . ' FOR UPDATE';
            $current = $this->db->setQuery($sql)->loadAssoc();

            if ($current) {
                if (!hash_equals(strtolower((string) $current['settings_hash']), strtolower($expectedHash))) {
                    throw new RuntimeException('The template settings were changed in another session. Reload before saving.', 409);
                }

                $version = (int) $current['version'] + 1;
                $update = new stdClass();
                $update->id = self::SETTINGS_ID;
                $update->contact_id = (int) $settings['contact_id'];
                $update->data_json = $json;
                $update->settings_hash = $hash;
                $update->version = $version;
                $update->modified = $now;
                $update->modified_by = $userId;
                $this->db->updateObject('#__lmzpagebuilder_template_settings', $update, 'id', true);
            } else {
                $defaultHash = $this->hash(self::defaults());
                if (!hash_equals($defaultHash, strtolower($expectedHash))) {
                    throw new RuntimeException('The template settings were initialised by another session. Reload before saving.', 409);
                }

                $version = 1;
                $insert = new stdClass();
                $insert->id = self::SETTINGS_ID;
                $insert->contact_id = (int) $settings['contact_id'];
                $insert->data_json = $json;
                $insert->settings_hash = $hash;
                $insert->version = $version;
                $insert->created = $now;
                $insert->created_by = $userId;
                $insert->modified = $now;
                $insert->modified_by = $userId;
                $this->db->insertObject('#__lmzpagebuilder_template_settings', $insert, 'id');
            }

            $revision = new stdClass();
            $revision->settings_id = self::SETTINGS_ID;
            $revision->settings_version = $version;
            $revision->operation = 'save';
            $revision->data_json = $json;
            $revision->snapshot_hash = $hash;
            $revision->note = $note;
            $revision->created = $now;
            $revision->created_by = $userId;
            $this->db->insertObject('#__lmzpagebuilder_template_setting_revisions', $revision, 'id');
            $this->db->transactionCommit();
        } catch (Throwable $error) {
            $this->safeRollback();
            throw $error;
        }

        try {
            Factory::getCache('com_lmzpagebuilder')->clean();
        } catch (Throwable $ignored) {
            // The persisted row is authoritative if cache cleanup is unavailable.
        }

        return [
            'settings' => $settings,
            'hash' => $hash,
            'version' => $version,
            'modified' => $now,
            'schema_ready' => true,
        ];
    }

    /** @return array<int, array<string, mixed>> */
    public function revisions(int $limit = 8): array
    {
        $this->assertManage();
        if (!$this->settingsSchemaAvailable()) {
            return [];
        }

        $query = $this->db->getQuery(true)
            ->select($this->db->quoteName(['id', 'settings_version', 'operation', 'snapshot_hash', 'note', 'created', 'created_by']))
            ->from($this->db->quoteName('#__lmzpagebuilder_template_setting_revisions'))
            ->where($this->db->quoteName('settings_id') . ' = ' . self::SETTINGS_ID)
            ->order($this->db->quoteName('id') . ' DESC');

        return $this->db->setQuery($query, 0, max(1, min(25, $limit)))->loadAssocList() ?: [];
    }

    /** @return array<string, array<string, mixed>> */
    public function regionStatus(): array
    {
        $this->assertManage();
        $languages = (new LanguageService($this->db))->listAvailable();
        $result = [];

        foreach (self::REGIONS as $region => $definition) {
            $result[$region] = [
                'key' => $definition['key'],
                'title' => $definition['title'],
                'slots' => $definition['slots'],
                'element_id' => 0,
                'languages' => [],
            ];
        }

        if (!$this->elementsSchemaAvailable()) {
            foreach ($result as &$region) {
                foreach ($languages as $language) {
                    $region['languages'][] = $this->languageStatus($language, null, 0);
                }
            }
            unset($region);

            return $result;
        }

        $keys = array_column(self::REGIONS, 'key');
        $query = $this->db->getQuery(true)
            ->select($this->db->quoteName(['id', 'element_key', 'kind', 'state']))
            ->from($this->db->quoteName('#__lmzpagebuilder_elements'))
            ->whereIn($this->db->quoteName('element_key'), $keys, ParameterType::STRING);
        $elements = [];
        foreach ($this->db->setQuery($query)->loadAssocList() ?: [] as $element) {
            $elements[(string) $element['element_key']] = $element;
        }

        foreach (self::REGIONS as $region => $definition) {
            $element = $elements[$definition['key']] ?? null;
            $elementId = is_array($element) ? (int) $element['id'] : 0;
            $translations = [];
            if ($elementId > 0) {
                $translationQuery = $this->db->getQuery(true)
                    ->select($this->db->quoteName(['id', 'language', 'state', 'draft_hash', 'published_hash', 'modified']))
                    ->from($this->db->quoteName('#__lmzpagebuilder_element_translations'))
                    ->where($this->db->quoteName('element_id') . ' = ' . $elementId);
                foreach ($this->db->setQuery($translationQuery)->loadAssocList() ?: [] as $translation) {
                    $translations[(string) $translation['language']] = $translation;
                }
            }

            $result[$region]['element_id'] = $elementId;
            $result[$region]['invalid_kind'] = is_array($element) && (string) $element['kind'] !== 'template';
            foreach ($languages as $language) {
                $code = (string) $language['code'];
                $result[$region]['languages'][] = $this->languageStatus(
                    $language,
                    $translations[$code] ?? null,
                    $elementId
                );
            }
        }

        return $result;
    }

    /** @return array<string, mixed> */
    public function ensureRegion(string $region, string $language): array
    {
        $this->assertAction('lmzpagebuilder.settings', 'core.create');
        if (!isset(self::REGIONS[$region])) {
            throw new RuntimeException('Unknown template region.', 422);
        }
        if (!$this->elementsSchemaAvailable()) {
            throw new RuntimeException('The shared-element database schema is unavailable.', 503);
        }

        $language = (new LanguageService($this->db))->assertAvailable($language);
        $definition = self::REGIONS[$region];
        $this->db->transactionStart();

        try {
            $elementQuery = $this->db->getQuery(true)
                ->select('*')
                ->from($this->db->quoteName('#__lmzpagebuilder_elements'))
                ->where($this->db->quoteName('element_key') . ' = ' . $this->db->quote($definition['key']));
            $element = $this->db->setQuery((string) $elementQuery . ' FOR UPDATE')->loadAssoc();
            $now = Factory::getDate()->toSql();
            $userId = (int) ($this->identity->id ?? 0);

            if ($element && (string) $element['kind'] !== 'template') {
                throw new RuntimeException('The reserved template-region key is already used by a non-template element.', 409);
            }

            if (!$element) {
                $record = new stdClass();
                $record->uuid = $this->uuid();
                $record->element_key = $definition['key'];
                $record->title = $definition['title'];
                $record->kind = 'template';
                $record->state = 1;
                $record->ordering = $region === 'navigation' ? -20 : -10;
                $record->access = 1;
                $record->created = $now;
                $record->created_by = $userId;
                $record->modified = $now;
                $record->modified_by = $userId;
                $this->db->insertObject('#__lmzpagebuilder_elements', $record, 'id');
                $elementId = (int) $record->id;
            } else {
                $elementId = (int) $element['id'];
            }

            $translationQuery = $this->db->getQuery(true)
                ->select('*')
                ->from($this->db->quoteName('#__lmzpagebuilder_element_translations'))
                ->where($this->db->quoteName('element_id') . ' = ' . $elementId)
                ->where($this->db->quoteName('language') . ' = ' . $this->db->quote($language));
            $translation = $this->db->setQuery((string) $translationQuery . ' FOR UPDATE')->loadAssoc();

            if (!$translation) {
                $title = $this->regionTitle($region, $language);
                $html = $this->regionHtml($region, $language);
                $css = $this->regionCss($region);
                $project = $this->regionProject($elementId, $language, $title, $html, $css);
                $record = new stdClass();
                $record->element_id = $elementId;
                $record->language = $language;
                $record->title = $title;
                $record->draft_project_json = $project;
                $record->draft_html = $html;
                $record->draft_css = $css;
                $record->published_html = '';
                $record->published_css = '';
                $record->draft_hash = hash('sha256', $project . "\0" . $html . "\0" . $css);
                $record->published_hash = hash('sha256', "\0");
                $record->state = 0;
                $record->checked_out = 0;
                $record->checked_out_time = null;
                $record->checkout_token = '';
                $record->created = $now;
                $record->created_by = $userId;
                $record->modified = $now;
                $record->modified_by = $userId;
                $record->published = null;
                $record->published_by = 0;
                $this->db->insertObject('#__lmzpagebuilder_element_translations', $record, 'id');
                $translationId = (int) $record->id;
            } else {
                $translationId = (int) $translation['id'];
            }

            $this->db->transactionCommit();
        } catch (Throwable $error) {
            $this->safeRollback();
            throw $error;
        }

        return [
            'region' => $region,
            'element_id' => $elementId,
            'translation_id' => $translationId,
            'language' => $language,
            'editor_url' => 'index.php?option=com_lmzpagebuilder&view=element&element_id=' . $elementId
                . '&language=' . rawurlencode($language) . '&tmpl=component',
        ];
    }

    /** @param array<string, mixed> $input */
    private function normalise(array $input, bool $validateMenu): array
    {
        $defaults = self::defaults();
        $logos = is_array($input['logos'] ?? null) ? $input['logos'] : [];
        $navigation = is_array($input['navigation'] ?? null) ? $input['navigation'] : [];
        $footer = is_array($input['footer'] ?? null) ? $input['footer'] : [];

        $contactId = max(0, (int) ($input['contact_id'] ?? 0));
        if ($contactId > 0 && $validateMenu) {
            $contactQuery = $this->db->getQuery(true)
                ->select('COUNT(*)')
                ->from($this->db->quoteName('#__contact_details', 'c'))
                ->innerJoin($this->db->quoteName('#__categories', 'cat') . ' ON ' . $this->db->quoteName('cat.id') . ' = ' . $this->db->quoteName('c.catid'))
                ->where($this->db->quoteName('c.id') . ' = ' . $contactId)
                ->where($this->db->quoteName('c.published') . ' = 1')
                ->where($this->db->quoteName('cat.published') . ' = 1')
                ->where($this->db->quoteName('c.access') . ' = 1')
                ->where($this->db->quoteName('cat.access') . ' = 1');
            if ((int) $this->db->setQuery($contactQuery)->loadResult() < 1) {
                throw new RuntimeException('The selected Joomla contact is not published or publicly accessible.', 422);
            }
        }

        $menuType = $this->plain((string) ($navigation['menu_type'] ?? $defaults['navigation']['menu_type']), 48);
        if (!preg_match('/^[a-z0-9][a-z0-9_-]{0,47}$/i', $menuType)) {
            throw new RuntimeException('The Joomla menu type is invalid.', 422);
        }
        if ($validateMenu) {
            $query = $this->db->getQuery(true)
                ->select('COUNT(*)')
                ->from($this->db->quoteName('#__menu_types'))
                ->where($this->db->quoteName('menutype') . ' = ' . $this->db->quote($menuType));
            if ((int) $this->db->setQuery($query)->loadResult() < 1) {
                throw new RuntimeException('The selected Joomla menu no longer exists.', 422);
            }
        }

        $email = mb_strtolower(trim((string) ($footer['email'] ?? $defaults['footer']['email'])));
        if (!filter_var($email, FILTER_VALIDATE_EMAIL) || mb_strlen($email) > 254) {
            throw new RuntimeException('A valid footer email address is required.', 422);
        }

        return [
            'contact_id' => $contactId,
            'logos' => [
                'favicon' => $this->assetUrl((string) ($logos['favicon'] ?? $defaults['logos']['favicon'])),
                'mark' => $this->assetUrl((string) ($logos['mark'] ?? $defaults['logos']['mark'])),
                'navigation_wordmark' => $this->assetUrl((string) ($logos['navigation_wordmark'] ?? $defaults['logos']['navigation_wordmark'])),
                'footer_wordmark' => $this->assetUrl((string) ($logos['footer_wordmark'] ?? $defaults['logos']['footer_wordmark'])),
                'alt_text' => $this->plain((string) ($logos['alt_text'] ?? $defaults['logos']['alt_text']), 160),
            ],
            'navigation' => [
                'menu_type' => $menuType,
                'hotline' => $this->phone((string) ($navigation['hotline'] ?? $defaults['navigation']['hotline'])),
                'hotline_visible' => $this->boolean($navigation['hotline_visible'] ?? false),
                'hotline_icon' => $this->icon($navigation['hotline_icon'] ?? ''),
                'background' => $this->colour((string) ($navigation['background'] ?? $defaults['navigation']['background'])),
                'text' => $this->colour((string) ($navigation['text'] ?? $defaults['navigation']['text'])),
                'accent' => $this->colour((string) ($navigation['accent'] ?? $defaults['navigation']['accent'])),
                'builder_enabled' => $this->boolean($navigation['builder_enabled'] ?? false),
            ],
            'footer' => [
                'company' => $this->plain((string) ($footer['company'] ?? $defaults['footer']['company']), 190),
                'email' => $email,
                'address' => $this->multiline((string) ($footer['address'] ?? $defaults['footer']['address']), 500),
                'email_icon' => $this->icon($footer['email_icon'] ?? ''),
                'address_icon' => $this->icon($footer['address_icon'] ?? ''),
                'background' => $this->colour((string) ($footer['background'] ?? $defaults['footer']['background'])),
                'text' => $this->colour((string) ($footer['text'] ?? $defaults['footer']['text'])),
                'accent' => $this->colour((string) ($footer['accent'] ?? $defaults['footer']['accent'])),
                'builder_enabled' => $this->boolean($footer['builder_enabled'] ?? false),
            ],
        ];
    }

    /**
     * Merge a partial section payload onto the currently stored settings so the
     * untouched section keeps its persisted values. An empty section keeps the
     * legacy behaviour of accepting a full settings payload unchanged.
     *
     * @param array<string, mixed> $input
     * @return array<string, mixed>
     */
    private function mergeSection(array $input, string $section): array
    {
        if ($section !== 'header' && $section !== 'footer') {
            return $input;
        }

        $current = $this->load()['settings'];

        if ($section === 'header') {
            $current['contact_id'] = $input['contact_id'] ?? $current['contact_id'];
            if (isset($input['logos']) && is_array($input['logos'])) {
                $current['logos'] = $input['logos'];
            }
            if (isset($input['navigation']) && is_array($input['navigation'])) {
                $current['navigation'] = $input['navigation'];
            }

            return $current;
        }

        if (isset($input['footer']) && is_array($input['footer'])) {
            $current['footer'] = $input['footer'];
        }

        return $current;
    }

    /**
     * Sanitises a Font Awesome class string (e.g. "fa-solid fa-phone").
     * Icons are optional decoration, so an empty or unusable value collapses to
     * an empty string instead of throwing – keeping backward compatibility with
     * saved settings that predate the icon fields.
     */
    private function icon(mixed $value): string
    {
        $value = is_scalar($value)
            ? strtolower(trim(preg_replace('/\s+/u', ' ', strip_tags((string) $value)) ?? ''))
            : '';
        if ($value === '') {
            return '';
        }
        $value = trim(preg_replace('/\s+/', ' ', (string) preg_replace('/[^a-z0-9 -]/', '', $value)) ?? '');

        return mb_substr($value, 0, 64);
    }

    private function settingsSchemaAvailable(): bool
    {
        return $this->hasTable('#__lmzpagebuilder_template_settings')
            && $this->hasTable('#__lmzpagebuilder_template_setting_revisions');
    }

    private function elementsSchemaAvailable(): bool
    {
        return $this->hasTable('#__lmzpagebuilder_elements')
            && $this->hasTable('#__lmzpagebuilder_element_translations');
    }

    private function hasTable(string $table): bool
    {
        try {
            return in_array($this->db->replacePrefix($table), $this->db->getTableList(), true);
        } catch (Throwable $ignored) {
            return false;
        }
    }

    /** @param array<string, mixed> $language @param array<string, mixed>|null $translation */
    private function languageStatus(array $language, ?array $translation, int $elementId): array
    {
        $code = (string) $language['code'];
        $state = 'missing';
        if ($translation !== null) {
            $state = (int) $translation['state'] === 1 && !hash_equals(hash('sha256', "\0"), (string) $translation['published_hash'])
                ? 'published'
                : 'draft';
        }

        return [
            'code' => $code,
            'title' => (string) ($language['native_title'] ?: $language['title']),
            'state' => $state,
            'translation_id' => (int) ($translation['id'] ?? 0),
            'modified' => (string) ($translation['modified'] ?? ''),
            'editor_url' => $translation === null || $elementId < 1 ? ''
                : 'index.php?option=com_lmzpagebuilder&view=element&element_id=' . $elementId
                    . '&language=' . rawurlencode($code) . '&tmpl=component',
        ];
    }

    private function regionTitle(string $region, string $language): string
    {
        $prefix = strtolower(strtok($language, '-'));
        $titles = [
            'navigation' => ['de' => 'Navigation', 'en' => 'Navigation', 'pl' => 'Nawigacja'],
            'footer' => ['de' => 'Footer', 'en' => 'Footer', 'pl' => 'Stopka'],
        ];

        return $titles[$region][$prefix] ?? self::REGIONS[$region]['title'];
    }

    private function regionHtml(string $region, string $language): string
    {
        $prefix = strtolower(strtok($language, '-'));
        $labels = [
            'de' => [
                'brand' => 'Logo', 'toggle' => 'Mobiles Menü', 'menu' => 'Hauptmenü',
                'languages' => 'Sprachen', 'hotline' => 'Hotline', 'services' => 'Leistungen',
                'company' => 'Unternehmen', 'contact' => 'Kontakt', 'legal' => 'Rechtliches',
            ],
            'pl' => [
                'brand' => 'Logo', 'toggle' => 'Menu mobilne', 'menu' => 'Menu główne',
                'languages' => 'Języki', 'hotline' => 'Infolinia', 'services' => 'Usługi',
                'company' => 'Firma', 'contact' => 'Kontakt', 'legal' => 'Informacje prawne',
            ],
            'en' => [
                'brand' => 'Logo', 'toggle' => 'Mobile menu', 'menu' => 'Main menu',
                'languages' => 'Languages', 'hotline' => 'Hotline', 'services' => 'Services',
                'company' => 'Company', 'contact' => 'Contact', 'legal' => 'Legal',
            ],
        ];
        $labels = $labels[$prefix] ?? $labels['en'];
        $slots = self::REGIONS[$region]['slots'];
        $html = '<div class="lmz-template-region lmz-template-region--' . $region . '" data-lmz-template-region="' . $region . '">';
        foreach ($slots as $slot) {
            $html .= '<div class="lmz-template-region__slot" data-lmz-template-slot="' . $slot . '">'
                . '<span>' . htmlspecialchars($labels[$slot], ENT_QUOTES, 'UTF-8') . '</span></div>';
        }

        return $html . '</div>';
    }

    private function regionCss(string $region): string
    {
        return '.lmz-template-region--' . $region . '{display:contents}'
            . '.lmzpb-editor-canvas .lmz-template-region--' . $region . '{display:grid;gap:12px;padding:24px}'
            . '.lmzpb-editor-canvas .lmz-template-region__slot{min-height:64px;display:grid;place-items:center;padding:12px;border:1px dashed #e4002b;background:#111923;color:#fff;font:700 12px/1.3 Manrope,sans-serif}';
    }

    private function regionProject(int $elementId, string $language, string $title, string $html, string $css): string
    {
        return (string) json_encode([
            'assets' => [],
            'styles' => [],
            'pages' => [[
                'id' => 'lmz-element-' . $elementId . '-' . strtolower(str_replace('-', '_', $language)),
                'name' => $title,
                'component' => '<style>' . $css . '</style>' . $html,
            ]],
            'custom' => [
                'engine' => 'lmz-grapesjs',
                'schemaVersion' => 2,
                'source' => ['elementId' => $elementId, 'language' => $language, 'templateRegion' => true],
            ],
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
    }

    private function assetUrl(string $value): string
    {
        $value = trim(html_entity_decode($value, ENT_QUOTES | ENT_HTML5, 'UTF-8'));
        if ($value === '' || mb_strlen($value) > 500 || str_contains($value, "\0") || preg_match('/[<>"\']/', $value)) {
            throw new RuntimeException('A valid logo or favicon path is required.', 422);
        }
        if (str_starts_with($value, '//')) {
            throw new RuntimeException('Protocol-relative asset URLs are not supported.', 422);
        }
        if (preg_match('/^[a-z][a-z0-9+.-]*:/i', $value) && !preg_match('~^https?://~i', $value)) {
            throw new RuntimeException('Only local, HTTP, or HTTPS asset URLs are supported.', 422);
        }
        if (preg_match('~^https?://~i', $value) && !filter_var($value, FILTER_VALIDATE_URL)) {
            throw new RuntimeException('The remote asset URL is invalid.', 422);
        }
        if (!preg_match('~^https?://~i', $value) && !str_starts_with($value, '/')) {
            $value = '/' . ltrim($value, '/');
        }

        return $value;
    }

    private function phone(string $value): string
    {
        $value = trim(preg_replace('/\s+/u', ' ', strip_tags($value)) ?? '');
        if ($value === '' || mb_strlen($value) > 40 || !preg_match('/^\+?[0-9][0-9 ()\/.-]{4,39}$/', $value)) {
            throw new RuntimeException('A valid hotline number is required.', 422);
        }

        return $value;
    }

    private function colour(string $value): string
    {
        $value = strtolower(trim($value));
        if (preg_match('/^#([a-f0-9]{3})$/', $value, $match)) {
            return '#' . $match[1][0] . $match[1][0] . $match[1][1] . $match[1][1] . $match[1][2] . $match[1][2];
        }
        if (!preg_match('/^#[a-f0-9]{6}$/', $value)) {
            throw new RuntimeException('Colours must use a three- or six-digit hexadecimal value.', 422);
        }

        return $value;
    }

    private function plain(string $value, int $length): string
    {
        $value = trim(preg_replace('/\s+/u', ' ', strip_tags($value)) ?? '');
        if ($value === '') {
            throw new RuntimeException('A required template setting is empty.', 422);
        }

        return mb_substr($value, 0, $length);
    }

    private function multiline(string $value, int $length): string
    {
        $value = str_replace(["\r\n", "\r"], "\n", strip_tags($value));
        $lines = array_map(static fn (string $line): string => trim(preg_replace('/\s+/u', ' ', $line) ?? ''), explode("\n", $value));
        $value = trim(implode("\n", array_filter($lines, static fn (string $line): bool => $line !== '')));
        if ($value === '') {
            throw new RuntimeException('A footer address is required.', 422);
        }

        return mb_substr($value, 0, $length);
    }

    private function boolean(mixed $value): bool
    {
        return in_array($value, [true, 1, '1', 'true', 'on', 'yes'], true);
    }

    /** @param array<string, mixed> $data */
    private function hash(array $data): string
    {
        return hash('sha256', $this->canonicalJson($data));
    }

    /** @param array<string, mixed> $data */
    private function canonicalJson(array $data): string
    {
        $sort = function (array $value) use (&$sort): array {
            if (!array_is_list($value)) {
                ksort($value, SORT_STRING);
            }
            foreach ($value as $key => $item) {
                if (is_array($item)) {
                    $value[$key] = $sort($item);
                }
            }

            return $value;
        };

        return (string) json_encode($sort($data), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
    }

    private function uuid(): string
    {
        $bytes = random_bytes(16);
        $bytes[6] = chr((ord($bytes[6]) & 0x0f) | 0x40);
        $bytes[8] = chr((ord($bytes[8]) & 0x3f) | 0x80);
        $hex = bin2hex($bytes);

        return substr($hex, 0, 8) . '-' . substr($hex, 8, 4) . '-' . substr($hex, 12, 4)
            . '-' . substr($hex, 16, 4) . '-' . substr($hex, 20, 12);
    }

    private function assertManage(): void
    {
        if ((int) ($this->identity->id ?? 0) <= 0
            || (!$this->identity->authorise('core.admin', 'com_lmzpagebuilder')
                && !$this->identity->authorise('core.manage', 'com_lmzpagebuilder'))) {
            throw new RuntimeException('LMZ Page Builder management permission is required.', 403);
        }
    }

    private function assertAction(string $action, ?string $fallback = null): void
    {
        $this->assertManage();
        if (!$this->identity->authorise('core.admin', 'com_lmzpagebuilder')
            && !$this->identity->authorise($action, 'com_lmzpagebuilder')
            && ($fallback === null || !$this->identity->authorise($fallback, 'com_lmzpagebuilder'))) {
            throw new RuntimeException('Permission denied for action ' . $action . '.', 403);
        }
    }

    private function safeRollback(): void
    {
        try {
            $this->db->transactionRollback();
        } catch (Throwable $ignored) {
            // Preserve the original failure.
        }
    }
}
