<?php

namespace LMZ\Component\Lmzpagebuilder\Administrator\Service;

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\Database\DatabaseInterface;
use RuntimeException;

final class EmbedCatalogService
{
    private DatabaseInterface $db;
    private object $identity;
    private LanguageService $languages;

    public function __construct(DatabaseInterface $db, object $identity)
    {
        $this->db = $db;
        $this->identity = $identity;
        $this->languages = new LanguageService($db);
    }

    /** @return array<int, array<string, mixed>> */
    public function articles(string $language, string $search = '', int $limit = 100): array
    {
        $this->assertManage();
        $language = $this->languages->assertAvailable($language);
        $levels = $this->viewLevels();
        $now = Factory::getDate()->toSql();
        $query = $this->db->getQuery(true)
            ->select([
                $this->db->quoteName('c.id'),
                $this->db->quoteName('c.title'),
                $this->db->quoteName('c.alias'),
                $this->db->quoteName('c.language'),
                $this->db->quoteName('c.catid'),
                $this->db->quoteName('cat.title', 'category_title'),
                $this->db->quoteName('c.modified'),
            ])
            ->from($this->db->quoteName('#__content', 'c'))
            ->leftJoin($this->db->quoteName('#__categories', 'cat') . ' ON ' . $this->db->quoteName('cat.id') . ' = ' . $this->db->quoteName('c.catid'))
            ->where($this->db->quoteName('c.state') . ' = 1')
            ->where($this->db->quoteName('c.access') . ' IN (' . implode(',', $levels) . ')')
            ->where('(' . $this->db->quoteName('cat.id') . ' IS NULL OR ('
                . $this->db->quoteName('cat.published') . ' = 1 AND '
                . $this->db->quoteName('cat.access') . ' IN (' . implode(',', $levels) . ')))')
            ->where('(' . $this->db->quoteName('c.language') . ' = ' . $this->db->quote($language)
                . ' OR ' . $this->db->quoteName('c.language') . ' = ' . $this->db->quote('*') . ')')
            ->where('(' . $this->db->quoteName('c.publish_up') . ' IS NULL OR ' . $this->db->quoteName('c.publish_up') . ' <= ' . $this->db->quote($now) . ')')
            ->where('(' . $this->db->quoteName('c.publish_down') . ' IS NULL OR ' . $this->db->quoteName('c.publish_down') . ' >= ' . $this->db->quote($now) . ')')
            ->order($this->db->quoteName('c.title') . ' ASC');
        $this->applySearch($query, $search, ['c.title', 'c.alias']);
        $rows = $this->db->setQuery($query, 0, $this->limit($limit))->loadAssocList() ?: [];

        foreach ($rows as &$row) {
            $row['id'] = (int) $row['id'];
            $row['catid'] = (int) $row['catid'];
            $row['kind'] = 'article';
            $row['marker'] = '<div data-lmz-embed-kind="article" data-lmz-embed-id="' . $row['id'] . '"></div>';
        }
        unset($row);

        return $rows;
    }

    /** @return array<int, array<string, mixed>> */
    public function modules(string $language, string $search = '', int $limit = 100): array
    {
        $this->assertManage();
        $language = $this->languages->assertAvailable($language);
        $levels = $this->viewLevels();
        $now = Factory::getDate()->toSql();
        $query = $this->db->getQuery(true)
            ->select($this->db->quoteName([
                'm.id', 'm.title', 'm.module', 'm.position', 'm.showtitle', 'm.language', 'm.ordering',
            ]))
            ->from($this->db->quoteName('#__modules', 'm'))
            ->innerJoin($this->db->quoteName('#__extensions', 'e')
                . ' ON ' . $this->db->quoteName('e.element') . ' = ' . $this->db->quoteName('m.module')
                . ' AND ' . $this->db->quoteName('e.type') . ' = ' . $this->db->quote('module')
                . ' AND ' . $this->db->quoteName('e.client_id') . ' = 0')
            ->where($this->db->quoteName('m.client_id') . ' = 0')
            ->where($this->db->quoteName('m.published') . ' = 1')
            ->where($this->db->quoteName('e.enabled') . ' = 1')
            ->where($this->db->quoteName('m.access') . ' IN (' . implode(',', $levels) . ')')
            ->where('(' . $this->db->quoteName('m.language') . ' = ' . $this->db->quote($language)
                . ' OR ' . $this->db->quoteName('m.language') . ' = ' . $this->db->quote('*') . ')')
            ->where('(' . $this->db->quoteName('m.publish_up') . ' IS NULL OR ' . $this->db->quoteName('m.publish_up') . ' <= ' . $this->db->quote($now) . ')')
            ->where('(' . $this->db->quoteName('m.publish_down') . ' IS NULL OR ' . $this->db->quoteName('m.publish_down') . ' >= ' . $this->db->quote($now) . ')')
            ->order($this->db->quoteName('m.position') . ' ASC, ' . $this->db->quoteName('m.ordering') . ' ASC');
        $this->applySearch($query, $search, ['m.title', 'm.module', 'm.position']);
        $rows = $this->db->setQuery($query, 0, $this->limit($limit))->loadAssocList() ?: [];

        foreach ($rows as &$row) {
            $row['id'] = (int) $row['id'];
            $row['ordering'] = (int) $row['ordering'];
            $row['showtitle'] = (int) $row['showtitle'];
            $row['kind'] = 'module';
            $row['marker'] = '<div data-lmz-embed-kind="module" data-lmz-embed-id="' . $row['id'] . '"></div>';
        }
        unset($row);

        return $rows;
    }

    /** @return array<int, array<string, mixed>> */
    public function smartSliders(string $search = '', int $limit = 100): array
    {
        $this->assertManage();
        $table = '#__nextend2_smartslider3_sliders';
        if (!$this->tableExists($table)) {
            return [];
        }

        $physicalTable = $this->db->replacePrefix($table);
        $columns = array_change_key_case($this->db->getTableColumns($physicalTable, false), CASE_LOWER);
        if (!isset($columns['id']) || !isset($columns['title'])) {
            return [];
        }

        $optional = ['alias', 'type', 'thumbnail', 'thumbnailimage', 'slider_status', 'status', 'published', 'modified', 'time'];
        $select = [$this->db->quoteName('id'), $this->db->quoteName('title')];
        foreach ($optional as $column) {
            if (isset($columns[$column])) {
                $select[] = $this->db->quoteName($column);
            }
        }

        $query = $this->db->getQuery(true)
            ->select($select)
            ->from($this->db->quoteName($table))
            ->order($this->db->quoteName('title') . ' ASC');
        if (isset($columns['slider_status'])) {
            $query->where($this->db->quoteName('slider_status') . ' = ' . $this->db->quote('published'));
        } elseif (isset($columns['published'])) {
            $query->where($this->db->quoteName('published') . ' = 1');
        } elseif (isset($columns['status'])) {
            $query->where($this->db->quoteName('status') . ' IN (1, ' . $this->db->quote('published') . ')');
        }
        $this->applySearch($query, $search, array_values(array_filter(['title', isset($columns['alias']) ? 'alias' : null])));
        $rows = $this->db->setQuery($query, 0, $this->limit($limit))->loadAssocList() ?: [];

        foreach ($rows as &$row) {
            $row['id'] = (int) $row['id'];
            $row['kind'] = 'smartslider';
            $row['marker'] = '<div data-lmz-embed-kind="smartslider" data-lmz-embed-id="' . $row['id'] . '"></div>';
        }
        unset($row);

        return $rows;
    }

    /** @return array<string, mixed> */
    public function catalog(string $language, string $search = '', int $limit = 100): array
    {
        return [
            'articles' => $this->articles($language, $search, $limit),
            'modules' => $this->modules($language, $search, $limit),
            'smartsliders' => $this->smartSliders($search, $limit),
        ];
    }

    /** @return array<int, int> */
    private function viewLevels(): array
    {
        $levels = method_exists($this->identity, 'getAuthorisedViewLevels')
            ? array_map('intval', $this->identity->getAuthorisedViewLevels()) : [1];

        return array_values(array_unique(array_filter($levels, static fn (int $level): bool => $level > 0))) ?: [1];
    }

    /** @param array<int, string> $columns */
    private function applySearch(object $query, string $search, array $columns): void
    {
        $search = trim($search);
        if ($search === '' || $columns === []) {
            return;
        }

        $needle = $this->db->quote('%' . $this->db->escape(mb_substr($search, 0, 100), true) . '%', false);
        $conditions = [];
        foreach ($columns as $column) {
            $conditions[] = $this->db->quoteName($column) . ' LIKE ' . $needle;
        }
        $query->where('(' . implode(' OR ', $conditions) . ')');
    }

    private function tableExists(string $table): bool
    {
        $expected = strtolower($this->db->replacePrefix($table));

        return in_array($expected, array_map('strtolower', $this->db->getTableList()), true);
    }

    private function limit(int $limit): int
    {
        return max(1, min(250, $limit));
    }

    private function assertManage(): void
    {
        if ((int) ($this->identity->id ?? 0) <= 0
            || (!$this->identity->authorise('core.admin', 'com_lmzpagebuilder')
                && !$this->identity->authorise('core.manage', 'com_lmzpagebuilder'))) {
            throw new RuntimeException('LMZ Page Builder management permission is required.', 403);
        }
    }
}
