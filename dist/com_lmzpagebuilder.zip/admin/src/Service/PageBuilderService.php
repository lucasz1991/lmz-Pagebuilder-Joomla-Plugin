<?php

namespace LMZ\Component\Lmzpagebuilder\Administrator\Service;

defined('_JEXEC') or die;

use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Factory;
use Joomla\CMS\Filter\OutputFilter;
use Joomla\CMS\Uri\Uri;
use Joomla\Database\DatabaseInterface;
use RuntimeException;
use stdClass;
use Throwable;

/**
 * Native v2 page repository and publishing service.
 *
 * The translation row is the editor document. Draft and published payloads are
 * intentionally independent; no frontend source is consulted during editing or
 * publishing. The completed one-time migration is not part of the runtime.
 */
final class PageBuilderService
{
    private DatabaseInterface $db;
    private object $identity;
    private HtmlSanitizer $sanitizer;
    private LanguageService $languages;
    private PageLocalizationService $localization;
    private int $maxPayloadBytes;
    private int $revisionLimit;
    private int $checkoutMinutes;

    public function __construct(DatabaseInterface $db, object $identity)
    {
        $this->db = $db;
        $this->identity = $identity;
        $this->sanitizer = new HtmlSanitizer();
        $this->languages = new LanguageService($db);
        $this->localization = new PageLocalizationService($db, $identity, $this->sanitizer);
        $params = ComponentHelper::getParams('com_lmzpagebuilder');
        $this->maxPayloadBytes = max(2, min(32, (int) $params->get('max_payload_mb', 12))) * 1024 * 1024;
        $this->revisionLimit = max(5, min(100, (int) $params->get('revision_limit', 25)));
        $this->checkoutMinutes = max(10, min(480, (int) $params->get('checkout_minutes', 60)));
    }

    /**
     * Installer-only, idempotent localization migration. This method has no
     * ACL dependency because Joomla package postflight has no administrator
     * identity. It is deliberately not exposed by ProjectController.
     *
     * @return array{migrated: int, skipped: int, pages: array<int, int>}
     */
    public function migrateAllExistingPages(?int $pageId = null): array
    {
        return $this->localization->migrateAllExistingPages($pageId);
    }

    /** @return array{page_id: int, translations: int} */
    public function rematerializePage(int $pageId): array
    {
        return $this->localization->rematerializePage($pageId);
    }

    /** @return array<int, array<string, mixed>> */
    public function listLanguages(): array
    {
        $this->assertManage();

        return $this->languages->listAvailable();
    }

    /**
     * One result row represents one logical page. Its translations/variants
     * contain the language-specific editor documents.
     *
     * @return array<int, array<string, mixed>>
     */
    public function listPages(): array
    {
        $this->assertManage();
        $pageQuery = $this->db->getQuery(true)
            ->select('p.*')
            ->from($this->db->quoteName('#__lmzpagebuilder_pages', 'p'))
            ->order($this->db->quoteName('p.ordering') . ' ASC, ' . $this->db->quoteName('p.id') . ' ASC');
        $pages = $this->db->setQuery($pageQuery)->loadAssocList() ?: [];
        $translationQuery = $this->db->getQuery(true)
            ->select('t.*')
            ->from($this->db->quoteName('#__lmzpagebuilder_page_translations', 't'))
            ->order($this->db->quoteName('t.language') . ' ASC, ' . $this->db->quoteName('t.id') . ' ASC');
        $translations = $this->db->setQuery($translationQuery)->loadAssocList() ?: [];
        $layoutQuery = $this->db->getQuery(true)
            ->select($this->db->quoteName(['page_id', 'draft_hash', 'published_hash']))
            ->from($this->db->quoteName('#__lmzpagebuilder_page_layouts'));
        $layoutVersions = [];
        foreach ($this->db->setQuery($layoutQuery)->loadAssocList() ?: [] as $layout) {
            $layoutVersions[(int) $layout['page_id']] = $layout;
        }
        $textQuery = $this->db->getQuery(true)
            ->select($this->db->quoteName(['page_id', 'language', 'draft_hash', 'published_hash']))
            ->from($this->db->quoteName('#__lmzpagebuilder_page_texts'));
        $textVersions = [];
        foreach ($this->db->setQuery($textQuery)->loadAssocList() ?: [] as $text) {
            $textVersions[(int) $text['page_id']][(string) $text['language']] = $text;
        }
        $byPage = [];

        foreach ($translations as $translation) {
            $translation = $this->normalizeTranslation($translation);
            $byPage[(int) $translation['page_id']][] = $translation;
        }

        $availableLanguages = $this->languages->listAvailable();
        $defaultLanguage = $this->languages->defaultCode();
        $menuMap = $this->menuMap();

        foreach ($pages as &$page) {
            $pageId = (int) $page['id'];
            $variants = [];

            foreach ($byPage[$pageId] ?? [] as $translation) {
                $language = (string) $translation['language'];
                $textVersion = $textVersions[$pageId][$language] ?? [];
                $layoutVersion = $layoutVersions[$pageId] ?? [];
                $isPublished = (int) $page['state'] === 1
                    && (int) $translation['state'] === 1
                    && (bool) $translation['has_published_content'];
                $translation['version'] = PageLocalizationService::versionMeta(
                    (string) ($textVersion['draft_hash'] ?? ''),
                    (string) ($textVersion['published_hash'] ?? ''),
                    (string) ($layoutVersion['draft_hash'] ?? ''),
                    (string) ($layoutVersion['published_hash'] ?? ''),
                    $isPublished
                );
                $translation['frontend_url'] = $menuMap[$pageId][$language]
                    ?? rtrim(Uri::root(), '/') . '/index.php?option=com_lmzpagebuilder&view=page&id=' . $pageId
                    . '&lang=' . rawurlencode($language);
                $variants[$language] = $translation;
            }

            $primary = $variants[$defaultLanguage] ?? ($variants !== [] ? reset($variants) : null);
            $page['id'] = $pageId;
            $page['state'] = (int) $page['state'];
            $page['ordering'] = (int) $page['ordering'];
            $page['access'] = (int) $page['access'];
            $page['translations'] = array_values($variants);
            $page['variants'] = $variants;
            $page['available_languages'] = $availableLanguages;
            // Compatibility fields used by the v1 list while its template is
            // being upgraded to language badges on one logical card.
            $page['document_id'] = (int) ($primary['id'] ?? 0);
            $page['language'] = (string) ($primary['language'] ?? $defaultLanguage);
            $page['version'] = $primary['version'] ?? PageLocalizationService::versionMeta('', '', '', '', false);
            $page['published'] = (int) (($page['version']['status'] ?? 'unpublished') !== 'unpublished');
            $page['draft_hash'] = (string) ($primary['draft_hash'] ?? '');
            $page['source_hash'] = (string) ($primary['published_hash'] ?? '');
            $page['source_is_current'] = ($page['version']['status'] ?? '') === 'identical';
            $page['frontend_url'] = (string) ($primary['frontend_url'] ?? '');
        }
        unset($page);

        return $pages;
    }

    /** @param array<string, mixed> $data */
    public function createPage(array $data): array
    {
        $this->assertAction('core.create');
        $title = $this->cleanTitle((string) ($data['title'] ?? ''));
        $pageKey = $this->uniquePageKey((string) ($data['page_key'] ?? $title));
        $requestedLanguages = $data['languages'] ?? [$this->languages->defaultCode()];

        if (!is_array($requestedLanguages) || $requestedLanguages === []) {
            $requestedLanguages = [$this->languages->defaultCode()];
        }

        $languageCodes = [];
        foreach ($requestedLanguages as $language) {
            $languageCodes[] = $this->languages->assertAvailable((string) $language);
        }
        $languageCodes = array_values(array_unique($languageCodes));
        $this->db->transactionStart();

        try {
            $now = Factory::getDate()->toSql();
            $page = new stdClass();
            $page->page_key = $pageKey;
            $page->title = $title;
            $page->state = isset($data['state']) ? (int) ((bool) $data['state']) : 1;
            $page->ordering = (int) ($data['ordering'] ?? 0);
            $page->access = max(1, (int) ($data['access'] ?? 1));
            $page->created = $now;
            $page->created_by = (int) $this->identity->id;
            $page->modified = $now;
            $page->modified_by = (int) $this->identity->id;
            $this->db->insertObject('#__lmzpagebuilder_pages', $page, 'id');

            foreach ($languageCodes as $language) {
                $this->insertEmptyTranslation((int) $page->id, $language, $title, '', $now);
            }

            $sourceLanguage = in_array($defaultLanguage = $this->languages->defaultCode(), $languageCodes, true)
                ? $defaultLanguage
                : $languageCodes[0];
            $this->localization->initializeEmptyPage((int) $page->id, $sourceLanguage, $title);

            $this->db->transactionCommit();
        } catch (Throwable $error) {
            $this->safeRollback();
            throw $error;
        }

        return $this->loadPage((int) $page->id);
    }

    /** @param array<string, mixed> $data */
    public function updatePage(int $pageId, array $data): array
    {
        $this->assertAction('core.edit');
        $page = $this->loadPage($pageId);
        $update = new stdClass();
        $update->id = $pageId;
        $update->title = array_key_exists('title', $data) ? $this->cleanTitle((string) $data['title']) : (string) $page['title'];
        $update->state = array_key_exists('state', $data) ? (int) ((bool) $data['state']) : (int) $page['state'];
        $update->ordering = array_key_exists('ordering', $data) ? (int) $data['ordering'] : (int) $page['ordering'];
        $update->access = array_key_exists('access', $data) ? max(1, (int) $data['access']) : (int) $page['access'];
        $update->modified = Factory::getDate()->toSql();
        $update->modified_by = (int) $this->identity->id;
        $this->db->updateObject('#__lmzpagebuilder_pages', $update, 'id', true);

        return $this->loadPage($pageId);
    }

    /** @param array<string, mixed> $data */
    public function createTranslation(int $pageId, string $language, array $data = []): array
    {
        $this->assertAction('core.create');
        $page = $this->loadPage($pageId);
        $language = $this->languages->assertAvailable($language);
        $existing = $this->findTranslation($pageId, $language);

        if ($existing !== null) {
            return $this->normalizeTranslation($existing);
        }

        $title = $this->cleanTitle((string) ($data['title'] ?? $page['title']));
        $now = Factory::getDate()->toSql();
        $this->db->transactionStart();

        try {
            $this->insertEmptyTranslation($pageId, $language, $title, (string) ($data['alias'] ?? ''), $now);
            $translationId = (int) $this->db->insertid();
            $this->localization->initializeTranslation($pageId, $language);
            $this->db->transactionCommit();
        } catch (Throwable $error) {
            $this->safeRollback();
            throw $error;
        }

        return $this->normalizeTranslation($this->loadTranslation($translationId));
    }

    /** @param array<string, mixed> $data */
    public function updateTranslationMetadata(int $translationId, array $data): array
    {
        $this->assertAction('core.edit');
        $translation = $this->loadTranslation($translationId);
        $update = new stdClass();
        $update->id = $translationId;
        $update->title = array_key_exists('title', $data)
            ? $this->cleanTitle((string) $data['title']) : (string) $translation['title'];
        $update->alias = array_key_exists('alias', $data)
            ? $this->uniqueAlias((string) $data['alias'], (string) $translation['language'], $translationId)
            : (string) $translation['alias'];
        $update->browser_title = mb_substr(trim((string) ($data['browser_title'] ?? $translation['browser_title'])), 0, 255);
        $update->meta_description = mb_substr(trim((string) ($data['meta_description'] ?? $translation['meta_description'])), 0, 1000);
        $update->meta_keywords = mb_substr(trim((string) ($data['meta_keywords'] ?? $translation['meta_keywords'])), 0, 1000);
        $update->robots = mb_substr(trim((string) ($data['robots'] ?? $translation['robots'])), 0, 64);
        $update->state = array_key_exists('state', $data) ? (int) ((bool) $data['state']) : (int) $translation['state'];
        $update->modified = Factory::getDate()->toSql();
        $update->modified_by = (int) $this->identity->id;
        $this->db->updateObject('#__lmzpagebuilder_page_translations', $update, 'id', true);
        $this->clearCache();

        return $this->normalizeTranslation($this->loadTranslation($translationId));
    }

    /**
     * Idempotent migration ingress for already grouped native page data. This is
     * deliberately explicit and is not used by the editor runtime.
     *
     * Required: page_key, language, title. Supported migration fields:
     * alias, browser_title, meta_description, meta_keywords, robots,
     * published_html/css, draft_html/css and project_json.
     *
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    public function importNativePage(array $data): array
    {
        $this->assertAction('core.create');
        throw new RuntimeException(
            'Independent HTML/CSS imports are disabled by the shared-layout localization model. Use migrateAllExistingPages() for legacy rows or the source-language editor for structural imports.',
            409
        );

        // Kept below for one release as a readable record of the pre-2.4
        // importer. It is deliberately unreachable so no controller request
        // can bypass page_layouts/page_texts while upgrade scripts move to the
        // revision-safe migration service.
        $language = $this->languages->assertAvailable((string) ($data['language'] ?? ''));
        $title = $this->cleanTitle((string) ($data['title'] ?? ''));
        $pageKey = OutputFilter::stringURLSafe((string) ($data['page_key'] ?? ''));
        if ($pageKey === '') {
            throw new RuntimeException('A stable page_key is required for native migration.', 422);
        }
        $pageKey = mb_substr($pageKey, 0, 191);
        $publishedHtml = $this->sanitizer->sanitizeHtml((string) ($data['published_html'] ?? ''));
        $publishedCss = $this->sanitizer->sanitizeCss((string) ($data['published_css'] ?? ''));
        $draftHtml = $this->sanitizer->sanitizeHtml((string) ($data['draft_html'] ?? $publishedHtml));
        $draftCss = $this->sanitizer->sanitizeCss((string) ($data['draft_css'] ?? $publishedCss));
        $this->assertPayloadSize($publishedHtml, $publishedCss, $draftHtml, $draftCss);
        $this->db->transactionStart();

        try {
            $page = $this->findPageByKey($pageKey);
            $now = Factory::getDate()->toSql();
            if ($page === null) {
                $pageObject = new stdClass();
                $pageObject->page_key = $pageKey;
                $pageObject->title = $this->cleanTitle((string) ($data['logical_title'] ?? $title));
                $pageObject->state = isset($data['page_state']) ? (int) ((bool) $data['page_state']) : 1;
                $pageObject->ordering = (int) ($data['ordering'] ?? 0);
                $pageObject->access = max(1, (int) ($data['access'] ?? 1));
                $pageObject->created = $now;
                $pageObject->created_by = (int) $this->identity->id;
                $pageObject->modified = $now;
                $pageObject->modified_by = (int) $this->identity->id;
                $this->db->insertObject('#__lmzpagebuilder_pages', $pageObject, 'id');
                $page = (array) $pageObject;
            }

            $existing = $this->findTranslation((int) $page['id'], $language);
            if ($existing !== null && empty($data['overwrite'])) {
                $this->db->transactionCommit();

                return $this->normalizeTranslation($existing);
            }
            if ($existing !== null) {
                $this->assertAction('core.edit');
                $this->assertDocumentCheckout($existing);
            }

            $providedProject = $data['project_json'] ?? $data['draft_project_json'] ?? null;
            if (is_array($providedProject)) {
                $providedProject = $this->encodeJson($providedProject);
            }
            if (is_string($providedProject) && trim($providedProject) !== '') {
                $decodedProject = json_decode($providedProject, true);
                if (!is_array($decodedProject) || !isset($decodedProject['pages']) || !is_array($decodedProject['pages'])) {
                    throw new RuntimeException('Migration project_json must contain a pages list.', 422);
                }
                $decodedProject['custom'] = is_array($decodedProject['custom'] ?? null) ? $decodedProject['custom'] : [];
                $decodedProject['custom']['engine'] = 'lmz-grapesjs';
                $decodedProject['custom']['schemaVersion'] = 2;
                $decodedProject['custom']['source'] = ['pageId' => (int) $page['id'], 'language' => $language];
                $project = $this->encodeJson($decodedProject);
            } else {
                $project = $this->projectJson((int) $page['id'], $language, $title, $draftHtml, $draftCss);
            }
            $alias = $this->uniqueAlias(
                (string) ($data['alias'] ?? $title),
                $language,
                (int) ($existing['id'] ?? 0)
            );
            $translationState = isset($data['state']) ? (int) ((bool) $data['state']) : 1;
            $values = [
                'page_id' => (int) $page['id'],
                'language' => $language,
                'title' => $title,
                'alias' => $alias,
                'browser_title' => mb_substr(trim((string) ($data['browser_title'] ?? '')), 0, 255),
                'meta_description' => mb_substr(trim((string) ($data['meta_description'] ?? '')), 0, 1000),
                'meta_keywords' => mb_substr(trim((string) ($data['meta_keywords'] ?? '')), 0, 1000),
                'robots' => mb_substr(trim((string) ($data['robots'] ?? '')), 0, 64),
                'state' => $translationState,
                'engine' => 'grapesjs',
                'schema_version' => 2,
                'draft_project_json' => $project,
                'draft_html' => $draftHtml,
                'draft_css' => $draftCss,
                'published_html' => $publishedHtml,
                'published_css' => $publishedCss,
                'draft_hash' => $this->draftHash($project, $draftHtml, $draftCss),
                'published_hash' => $this->publishedHash($publishedHtml, $publishedCss),
                'modified' => $now,
                'modified_by' => (int) $this->identity->id,
                'published' => $translationState === 1
                    ? (isset($data['published_at']) ? (string) $data['published_at'] : $now) : null,
                'published_by' => $translationState === 1 ? (int) $this->identity->id : 0,
            ];

            if ($existing === null) {
                $row = (object) array_merge($values, [
                    'checked_out' => 0,
                    'checked_out_time' => null,
                    'checkout_token' => '',
                    'created' => $now,
                    'created_by' => (int) $this->identity->id,
                ]);
                $this->db->insertObject('#__lmzpagebuilder_page_translations', $row, 'id');
                $translationId = (int) $row->id;
            } else {
                $row = (object) array_merge(['id' => (int) $existing['id']], $values);
                $this->db->updateObject('#__lmzpagebuilder_page_translations', $row, 'id', true);
                $translationId = (int) $existing['id'];
            }

            (new SharedElementService($this->db, $this->identity))->syncPageUsages($translationId, $language, $draftHtml);
            $this->db->transactionCommit();
        } catch (Throwable $error) {
            $this->safeRollback();
            throw $error;
        }

        $this->clearCache();

        return $this->normalizeTranslation($this->loadTranslation($translationId));
    }

    /** @return array<string, mixed> */
    public function acquireByPage(int $pageId, string $language = ''): array
    {
        $this->assertAction('core.edit');
        $this->loadPage($pageId);
        $requestedLanguage = trim($language);
        $language = $requestedLanguage !== ''
            ? $this->languages->assertAvailable($requestedLanguage)
            : $this->languages->defaultCode();
        $translation = $this->findTranslation($pageId, $language);

        if ($translation === null && $requestedLanguage === '') {
            $translation = $this->firstTranslation($pageId);
        }
        if ($translation === null) {
            throw new RuntimeException('No builder translation exists for the selected page and language.', 404);
        }

        return $this->acquireTranslation((int) $translation['id']);
    }

    /** @return array<string, mixed> */
    public function acquireTranslation(int $translationId): array
    {
        $this->assertAction('core.edit');
        $this->db->transactionStart();

        try {
            $translation = $this->loadTranslation($translationId, true);
            $this->assertDocumentCheckout($translation);
            $now = Factory::getDate()->toSql();
            $token = bin2hex(random_bytes(32));
            $update = new stdClass();
            $update->id = $translationId;
            $update->checked_out = (int) $this->identity->id;
            $update->checked_out_time = $now;
            $update->checkout_token = $token;
            $this->db->updateObject('#__lmzpagebuilder_page_translations', $update, 'id', true);
            $this->localization->initializeTranslation(
                (int) $translation['page_id'],
                (string) $translation['language']
            );
            $translation = $this->loadTranslation($translationId, true);
            $this->db->transactionCommit();
        } catch (Throwable $error) {
            $this->safeRollback();
            throw $error;
        }

        return $this->editorDocument($translation);
    }

    /** @return array<string, mixed> */
    public function loadForEditor(int $translationId, string $leaseToken): array
    {
        $this->assertManage();
        $translation = $this->loadTranslation($translationId);
        $this->assertDocumentLease($translation, $leaseToken);
        $localized = $this->localization->editorState($translation);

        return ['project' => $localized['project'], 'document' => $this->documentMeta($translation, $localized)];
    }

    /** @return array<string, mixed> */
    public function saveDraft(
        int $translationId,
        string $expectedDraftHash,
        string $expectedLayoutHash,
        string $projectJson,
        string $html,
        string $css,
        string $leaseToken
    ): array {
        $this->assertAction('lmzpagebuilder.save', 'core.edit');
        $this->assertHash($expectedDraftHash, 'expected_draft_hash');
        $this->assertHash($expectedLayoutHash, 'expected_layout_hash');
        $this->assertPayloadSize($projectJson, $html, $css);
        $project = json_decode($projectJson, true);

        if (!is_array($project) || !isset($project['pages']) || !is_array($project['pages'])) {
            throw new RuntimeException('The GrapesJS project JSON must contain a pages list.', 422);
        }

        $safeHtml = $this->sanitizer->sanitizeHtml($html);
        $safeCss = $this->sanitizer->sanitizeCss($css);
        $this->db->transactionStart();

        try {
            $translation = $this->loadTranslation($translationId, true);
            $this->assertDocumentLease($translation, $leaseToken);

            if ($this->hasMeaningfulContent((string) $translation['draft_html']) && !$this->hasMeaningfulContent($safeHtml)) {
                throw new RuntimeException('An empty autosave was rejected so existing content is not overwritten.', 422);
            }
            $now = Factory::getDate()->toSql();
            $result = $this->localization->saveDraft(
                $translation,
                strtolower($expectedDraftHash),
                strtolower($expectedLayoutHash),
                $projectJson,
                $html,
                $css
            );
            $update = new stdClass();
            $update->id = $translationId;
            $update->checked_out = (int) $this->identity->id;
            $update->checked_out_time = $now;
            $update->modified = $now;
            $update->modified_by = (int) $this->identity->id;
            $this->db->updateObject('#__lmzpagebuilder_page_translations', $update, 'id', true);
            if ((bool) $result['translation_only']) {
                (new SharedElementService($this->db, $this->identity))->syncPageUsages(
                    $translationId,
                    (string) $translation['language'],
                    (string) $this->loadTranslation($translationId)['draft_html']
                );
            } else {
                $this->syncPageUsages((int) $translation['page_id']);
            }
            $this->db->transactionCommit();
        } catch (Throwable $error) {
            $this->safeRollback();
            throw $error;
        }

        $this->clearCache();

        return [
            'draft_hash' => (string) $result['draft_hash'],
            'published_text_hash' => (string) $result['published_text_hash'],
            'layout_draft_hash' => (string) $result['layout_draft_hash'],
            'layoutDraftHash' => (string) $result['layout_draft_hash'],
            'layout_published_hash' => (string) $result['layout_published_hash'],
            'version' => $this->versionMetaForTranslation($translation, $result),
            'translation_only' => (bool) $result['translation_only'],
            'modified' => $now,
            'html_sanitized' => (bool) $result['html_sanitized'],
        ];
    }

    /** @return array<string, mixed> */
    public function publish(
        int $translationId,
        string $expectedPublishedHash,
        string $expectedDraftHash,
        string $expectedLayoutHash,
        string $leaseToken,
        string $note = '',
        bool $createRevision = false
    ): array {
        $this->assertAction('lmzpagebuilder.publish', 'core.edit.state');
        $this->assertHash($expectedPublishedHash, 'expected_source_hash');
        $this->assertHash($expectedDraftHash, 'expected_draft_hash');
        $this->assertHash($expectedLayoutHash, 'expected_layout_hash');
        $note = mb_substr(trim($note), 0, 500);
        $this->db->transactionStart();

        try {
            $translation = $this->loadTranslation($translationId, true);
            $this->assertDocumentLease($translation, $leaseToken);

            $beforePublishedChange = $createRevision
                ? function (array $candidate) use ($note): void {
                    $this->addRevision($candidate, 'publish', $note);
                    $this->pruneRevisions((int) $candidate['id']);
                }
                : static function (array $candidate): void {
                    // Publishing is revision-free by default. The callback is
                    // required by the localization service and intentionally
                    // remains a no-op unless the editor explicitly opts in.
                };
            $result = $this->localization->publish(
                $translation,
                strtolower($expectedPublishedHash),
                strtolower($expectedDraftHash),
                strtolower($expectedLayoutHash),
                $beforePublishedChange
            );
            $now = (string) $result['modified'];
            $update = new stdClass();
            $update->id = $translationId;
            $update->checked_out = (int) $this->identity->id;
            $update->checked_out_time = $now;
            $this->db->updateObject('#__lmzpagebuilder_page_translations', $update, 'id', true);
            if ((bool) $result['translation_only']) {
                (new SharedElementService($this->db, $this->identity))->syncPageUsages(
                    $translationId,
                    (string) $translation['language'],
                    (string) $this->loadTranslation($translationId)['draft_html']
                );
            } else {
                $this->syncPageUsages((int) $translation['page_id']);
            }
            if ($createRevision) {
                $this->pruneRevisions($translationId);
            }
            $this->db->transactionCommit();
        } catch (Throwable $error) {
            $this->safeRollback();
            throw $error;
        }

        $this->clearCache();
        $publishedAfterPublish = (int) ($translation['page_state'] ?? 1) === 1
            && !hash_equals($this->publishedHash('', ''), (string) $result['published_hash']);

        return [
            'source_hash' => (string) $result['source_hash'],
            'published_hash' => (string) $result['published_hash'],
            'published_text_hash' => (string) $result['published_text_hash'],
            'draft_hash' => (string) $result['draft_hash'],
            'layout_draft_hash' => (string) $result['layout_draft_hash'],
            'layoutDraftHash' => (string) $result['layout_draft_hash'],
            'layout_published_hash' => (string) $result['layout_published_hash'],
            'version' => $this->versionMetaForTranslation($translation, $result, $publishedAfterPublish),
            'translation_only' => (bool) $result['translation_only'],
            'modified' => $now,
            'page_id' => (int) $translation['page_id'],
            'translation_id' => $translationId,
        ];
    }

    /** @return array<string, mixed> */
    public function discardDraft(int $translationId, string $leaseToken): array
    {
        $this->assertAction('core.edit');
        $this->db->transactionStart();
        try {
            $translation = $this->loadTranslation($translationId, true);
            $this->assertDocumentLease($translation, $leaseToken);
            $result = $this->localization->discardDraft($translation);
            $now = Factory::getDate()->toSql();
            $update = new stdClass();
            $update->id = $translationId;
            $update->modified = $now;
            $update->modified_by = (int) $this->identity->id;
            $this->db->updateObject('#__lmzpagebuilder_page_translations', $update, 'id', true);
            $this->db->transactionCommit();
        } catch (Throwable $error) {
            $this->safeRollback();
            throw $error;
        }

        $this->clearCache();
        $fresh = $this->loadTranslation($translationId);

        return [
            'draft_hash' => (string) $result['draft_hash'],
            'published_hash' => (string) $fresh['published_hash'],
            'layout_draft_hash' => (string) $result['layout_draft_hash'],
            'layout_published_hash' => (string) $fresh['layout_published_hash'],
            'version' => $this->versionMetaForTranslation($fresh, $result),
            'translation_only' => (bool) $result['translation_only'],
        ];
    }

    /** @return array<int, array<string, mixed>> */
    public function revisions(int $translationId, string $leaseToken): array
    {
        $this->assertManage();
        $translation = $this->loadTranslation($translationId);
        $this->assertDocumentLease($translation, $leaseToken);
        $query = $this->db->getQuery(true)
            ->select([
                $this->db->quoteName('r.id'),
                $this->db->quoteName('r.operation'),
                $this->db->quoteName('r.snapshot_hash', 'source_hash'),
                $this->db->quoteName('r.note'),
                $this->db->quoteName('r.created'),
                $this->db->quoteName('r.created_by'),
                $this->db->quoteName('u.name', 'created_by_name'),
            ])
            ->from($this->db->quoteName('#__lmzpagebuilder_page_revisions', 'r'))
            ->leftJoin($this->db->quoteName('#__users', 'u') . ' ON ' . $this->db->quoteName('u.id') . ' = ' . $this->db->quoteName('r.created_by'))
            ->where($this->db->quoteName('r.translation_id') . ' = ' . $translationId)
            ->order($this->db->quoteName('r.id') . ' DESC');

        return $this->db->setQuery($query, 0, $this->revisionLimit)->loadAssocList() ?: [];
    }

    /** @return array<string, mixed> */
    public function rollback(
        int $revisionId,
        string $expectedPublishedHash,
        string $expectedDraftHash,
        string $expectedLayoutHash,
        string $leaseToken
    ): array {
        $this->assertAction('lmzpagebuilder.rollback', 'core.edit.state');
        $this->assertHash($expectedPublishedHash, 'expected_source_hash');
        $this->assertHash($expectedDraftHash, 'expected_draft_hash');
        $this->assertHash($expectedLayoutHash, 'expected_layout_hash');
        $revisionPointer = $this->loadRevision($revisionId);
        $translationId = (int) $revisionPointer['translation_id'];
        $this->db->transactionStart();

        try {
            $translation = $this->loadTranslation($translationId, true);
            $revision = $this->loadRevision($revisionId, true);
            $this->assertDocumentLease($translation, $leaseToken);
            $metadata = json_decode((string) $revision['metadata_json'], true);
            $metadata = is_array($metadata) ? $metadata : [];
            $revisionTitle = isset($metadata['title'])
                ? $this->cleanTitle((string) $metadata['title']) : (string) $translation['title'];
            $result = $this->localization->rollback(
                $translation,
                $revision,
                strtolower($expectedPublishedHash),
                strtolower($expectedDraftHash),
                strtolower($expectedLayoutHash),
                function (array $candidate) use ($revisionId): void {
                    $this->addRevision($candidate, 'rollback', 'Backup before rollback to revision #' . $revisionId);
                    $this->pruneRevisions((int) $candidate['id']);
                }
            );
            $now = Factory::getDate()->toSql();
            $update = new stdClass();
            $update->id = $translationId;
            $update->title = $revisionTitle;
            $update->alias = isset($metadata['alias'])
                ? $this->uniqueAlias((string) $metadata['alias'], (string) $translation['language'], $translationId)
                : (string) $translation['alias'];
            $update->browser_title = mb_substr(trim((string) ($metadata['browser_title'] ?? $translation['browser_title'])), 0, 255);
            $update->meta_description = mb_substr(trim((string) ($metadata['meta_description'] ?? $translation['meta_description'])), 0, 1000);
            $update->meta_keywords = mb_substr(trim((string) ($metadata['meta_keywords'] ?? $translation['meta_keywords'])), 0, 1000);
            $update->robots = mb_substr(trim((string) ($metadata['robots'] ?? $translation['robots'])), 0, 64);
            $update->state = 1;
            $update->published = $now;
            $update->published_by = (int) $this->identity->id;
            $update->checked_out = (int) $this->identity->id;
            $update->checked_out_time = $now;
            $update->modified = $now;
            $update->modified_by = (int) $this->identity->id;
            $this->db->updateObject('#__lmzpagebuilder_page_translations', $update, 'id', true);
            if ((bool) $result['translation_only']) {
                (new SharedElementService($this->db, $this->identity))->syncPageUsages(
                    $translationId,
                    (string) $translation['language'],
                    (string) $this->loadTranslation($translationId)['draft_html']
                );
            } else {
                $this->syncPageUsages((int) $translation['page_id']);
            }
            $this->pruneRevisions($translationId);
            $this->db->transactionCommit();
        } catch (Throwable $error) {
            $this->safeRollback();
            throw $error;
        }

        $this->clearCache();

        return [
            'source_hash' => (string) $result['source_hash'],
            'published_hash' => (string) $result['published_hash'],
            'draft_hash' => (string) $result['draft_hash'],
            'layout_draft_hash' => (string) $result['layout_draft_hash'],
            'layoutDraftHash' => (string) $result['layout_draft_hash'],
            'translation_only' => (bool) $result['translation_only'],
            'document_id' => $translationId,
            'translation_id' => $translationId,
        ];
    }

    /** @return array{checked_out_time: string} */
    public function touch(int $translationId, string $leaseToken): array
    {
        $this->assertAction('core.edit');
        $this->db->transactionStart();

        try {
            $translation = $this->loadTranslation($translationId, true);
            $this->assertDocumentLease($translation, $leaseToken);
            $now = Factory::getDate()->toSql();
            $update = new stdClass();
            $update->id = $translationId;
            $update->checked_out_time = $now;
            $this->db->updateObject('#__lmzpagebuilder_page_translations', $update, 'id', true);
            $this->db->transactionCommit();
        } catch (Throwable $error) {
            $this->safeRollback();
            throw $error;
        }

        return ['checked_out_time' => $now];
    }

    public function release(int $translationId, string $leaseToken): void
    {
        $this->assertManage();
        $this->db->transactionStart();

        try {
            $translation = $this->loadTranslation($translationId, true);
            $this->assertDocumentLease($translation, $leaseToken);
            $update = new stdClass();
            $update->id = $translationId;
            $update->checked_out = 0;
            $update->checked_out_time = null;
            $update->checkout_token = '';
            $this->db->updateObject('#__lmzpagebuilder_page_translations', $update, 'id', true);
            $this->db->transactionCommit();
        } catch (Throwable $error) {
            $this->safeRollback();
            throw $error;
        }
    }

    /** @return array<string, mixed> */
    private function editorDocument(array $translation): array
    {
        $translation = $this->normalizeTranslation($translation);
        $localized = $this->localization->editorState($translation);
        $translation['document_id'] = (int) $translation['id'];
        $translation['translation_id'] = (int) $translation['id'];
        $translation['project_json'] = json_encode($localized['project'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
        $translation['draft_project_json'] = $translation['project_json'];
        $translation['draft_html'] = (string) $localized['html'];
        $translation['draft_css'] = (string) $localized['css'];
        $translation['draft_hash'] = (string) $localized['draft_hash'];
        $translation['source_hash'] = (string) $translation['published_hash'];
        $translation['published_text_hash'] = (string) $localized['published_text_hash'];
        $translation['layout_draft_hash'] = (string) $localized['layout_draft_hash'];
        $translation['layoutDraftHash'] = (string) $localized['layout_draft_hash'];
        $translation['layout_published_hash'] = (string) $localized['layout_published_hash'];
        $translation['version'] = $this->versionMetaForTranslation($translation, $localized);
        $translation['source_language'] = (string) $localized['source_language'];
        $translation['translation_only'] = (bool) $localized['translation_only'];

        return $translation;
    }

    /** @return array<string, mixed> */
    private function documentMeta(array $translation, ?array $localized = null): array
    {
        $translation = $this->normalizeTranslation($translation);
        $localized ??= $this->localization->editorState($translation);

        return [
            'id' => (int) $translation['id'],
            'document_id' => (int) $translation['id'],
            'translation_id' => (int) $translation['id'],
            'page_id' => (int) $translation['page_id'],
            'title' => (string) $translation['title'],
            'language' => (string) $translation['language'],
            'source_hash' => (string) $translation['published_hash'],
            'published_hash' => (string) $translation['published_hash'],
            'draft_hash' => (string) $localized['draft_hash'],
            'published_text_hash' => (string) $localized['published_text_hash'],
            'layout_draft_hash' => (string) $localized['layout_draft_hash'],
            'layoutDraftHash' => (string) $localized['layout_draft_hash'],
            'layout_published_hash' => (string) $localized['layout_published_hash'],
            'version' => $this->versionMetaForTranslation($translation, $localized),
            'source_language' => (string) $localized['source_language'],
            'translation_only' => (bool) $localized['translation_only'],
            'modified' => (string) $translation['modified'],
            'modified_by' => (int) $translation['modified_by'],
        ];
    }

    /** @return array<string, mixed> */
    private function loadPage(int $pageId): array
    {
        if ($pageId <= 0) {
            throw new RuntimeException('A valid logical page ID is required.', 422);
        }

        $query = $this->db->getQuery(true)
            ->select('*')
            ->from($this->db->quoteName('#__lmzpagebuilder_pages'))
            ->where($this->db->quoteName('id') . ' = ' . $pageId);
        $row = $this->db->setQuery($query)->loadAssoc();

        if (!$row) {
            throw new RuntimeException('Logical builder page not found.', 404);
        }

        return $row;
    }

    /** @return array<string, mixed>|null */
    private function findPageByKey(string $pageKey): ?array
    {
        $query = $this->db->getQuery(true)
            ->select('*')
            ->from($this->db->quoteName('#__lmzpagebuilder_pages'))
            ->where($this->db->quoteName('page_key') . ' = ' . $this->db->quote($pageKey));
        $row = $this->db->setQuery($query)->loadAssoc();

        return $row ?: null;
    }

    /** @return array<string, mixed>|null */
    private function findTranslation(int $pageId, string $language): ?array
    {
        $query = $this->db->getQuery(true)
            ->select('*')
            ->from($this->db->quoteName('#__lmzpagebuilder_page_translations'))
            ->where($this->db->quoteName('page_id') . ' = ' . $pageId)
            ->where($this->db->quoteName('language') . ' = ' . $this->db->quote($language));
        $row = $this->db->setQuery($query)->loadAssoc();

        return $row ?: null;
    }

    /** @return array<string, mixed>|null */
    private function firstTranslation(int $pageId): ?array
    {
        $query = $this->db->getQuery(true)
            ->select('*')
            ->from($this->db->quoteName('#__lmzpagebuilder_page_translations'))
            ->where($this->db->quoteName('page_id') . ' = ' . $pageId)
            ->order($this->db->quoteName('id') . ' ASC');
        $row = $this->db->setQuery($query, 0, 1)->loadAssoc();

        return $row ?: null;
    }

    /** @return array<string, mixed> */
    private function loadTranslation(int $translationId, bool $forUpdate = false): array
    {
        if ($translationId <= 0) {
            throw new RuntimeException('A valid builder translation ID is required.', 422);
        }

        $query = $this->db->getQuery(true)
            ->select('t.*')
            ->select($this->db->quoteName('p.page_key'))
            ->select($this->db->quoteName('p.title', 'page_title'))
            ->select($this->db->quoteName('p.state', 'page_state'))
            ->from($this->db->quoteName('#__lmzpagebuilder_page_translations', 't'))
            ->innerJoin($this->db->quoteName('#__lmzpagebuilder_pages', 'p') . ' ON ' . $this->db->quoteName('p.id') . ' = ' . $this->db->quoteName('t.page_id'))
            ->where($this->db->quoteName('t.id') . ' = ' . $translationId);
        $sql = (string) $query . ($forUpdate ? ' FOR UPDATE' : '');
        $row = $this->db->setQuery($sql)->loadAssoc();

        if (!$row) {
            throw new RuntimeException('Builder translation not found.', 404);
        }

        return $row;
    }

    /** @return array<string, mixed> */
    private function loadRevision(int $revisionId, bool $forUpdate = false): array
    {
        $query = $this->db->getQuery(true)
            ->select('*')
            ->from($this->db->quoteName('#__lmzpagebuilder_page_revisions'))
            ->where($this->db->quoteName('id') . ' = ' . max(0, $revisionId));
        $sql = (string) $query . ($forUpdate ? ' FOR UPDATE' : '');
        $row = $this->db->setQuery($sql)->loadAssoc();

        if (!$row) {
            throw new RuntimeException('Revision not found.', 404);
        }

        return $row;
    }

    private function insertEmptyTranslation(int $pageId, string $language, string $title, string $alias, string $now): void
    {
        $alias = $this->uniqueAlias($alias !== '' ? $alias : $title, $language);
        $project = $this->projectJson($pageId, $language, $title, '', '');
        $translation = new stdClass();
        $translation->page_id = $pageId;
        $translation->language = $language;
        $translation->title = $title;
        $translation->alias = $alias;
        $translation->browser_title = '';
        $translation->meta_description = '';
        $translation->meta_keywords = '';
        $translation->robots = '';
        $translation->state = 0;
        $translation->engine = 'grapesjs';
        $translation->schema_version = 2;
        $translation->draft_project_json = $project;
        $translation->draft_html = '';
        $translation->draft_css = '';
        $translation->published_html = '';
        $translation->published_css = '';
        $translation->draft_hash = $this->draftHash($project, '', '');
        $translation->published_hash = $this->publishedHash('', '');
        $translation->checked_out = 0;
        $translation->checked_out_time = null;
        $translation->checkout_token = '';
        $translation->created = $now;
        $translation->created_by = (int) $this->identity->id;
        $translation->modified = $now;
        $translation->modified_by = (int) $this->identity->id;
        $translation->published = null;
        $translation->published_by = 0;
        $this->db->insertObject('#__lmzpagebuilder_page_translations', $translation, 'id');
    }

    /** @param array<string, mixed> $translation */
    private function addRevision(array $translation, string $operation, string $note): void
    {
        $html = $this->sanitizer->sanitizeHtml((string) $translation['published_html']);
        $css = $this->sanitizer->sanitizeCss((string) $translation['published_css']);
        $revision = new stdClass();
        $revision->translation_id = (int) $translation['id'];
        $revision->operation = $operation;
        $revisionProject = (string) ($translation['revision_project_json'] ?? '');
        $decodedProject = json_decode($revisionProject, true);
        $revision->project_json = is_array($decodedProject)
            && isset($decodedProject['pages'])
            && is_array($decodedProject['pages'])
            ? $revisionProject
            : $this->projectJson(
                (int) $translation['page_id'],
                (string) $translation['language'],
                (string) $translation['title'],
                $html,
                $css
            );
        $revision->html = $html;
        $revision->css = $css;
        $revision->snapshot_hash = $this->publishedHash($html, $css);
        $revision->metadata_json = $this->encodeJson([
            'title' => (string) $translation['title'],
            'alias' => (string) $translation['alias'],
            'browser_title' => (string) $translation['browser_title'],
            'meta_description' => (string) $translation['meta_description'],
            'meta_keywords' => (string) $translation['meta_keywords'],
            'robots' => (string) $translation['robots'],
            'language' => (string) $translation['language'],
        ]);
        $revision->note = mb_substr($note, 0, 500);
        $revision->created = Factory::getDate()->toSql();
        $revision->created_by = (int) $this->identity->id;
        $this->db->insertObject('#__lmzpagebuilder_page_revisions', $revision, 'id');
    }

    private function projectJson(int $pageId, string $language, string $title, string $html, string $css): string
    {
        $component = $css !== '' ? '<style>' . $css . '</style>' . $html : $html;

        return $this->encodeJson([
            'assets' => [],
            'styles' => [],
            'pages' => [[
                'id' => 'lmz-page-' . $pageId . '-' . strtolower(str_replace('-', '_', $language)),
                'name' => $title,
                'component' => $component,
            ]],
            'custom' => [
                'engine' => 'lmz-grapesjs',
                'schemaVersion' => 2,
                'source' => ['pageId' => $pageId, 'language' => $language],
            ],
        ]);
    }

    /** @return array<string, mixed> */
    private function normalizeTranslation(array $translation): array
    {
        foreach (['id', 'page_id', 'state', 'page_state', 'schema_version', 'checked_out', 'created_by', 'modified_by', 'published_by'] as $field) {
            if (isset($translation[$field])) {
                $translation[$field] = (int) $translation[$field];
            }
        }

        $translation['document_id'] = (int) $translation['id'];
        $translation['source_hash'] = (string) $translation['published_hash'];
        $translation['has_published_content'] = $this->hasMeaningfulContent((string) $translation['published_html'])
            || trim((string) $translation['published_css']) !== '';
        $translation['draft_differs'] = (string) $translation['draft_html'] !== (string) $translation['published_html']
            || (string) $translation['draft_css'] !== (string) $translation['published_css'];

        return $translation;
    }

    /**
     * @param array<string, mixed> $translation
     * @param array<string, mixed> $localized
     * @return array{status: string, online_fingerprint: string, draft_fingerprint: string}
     */
    private function versionMetaForTranslation(
        array $translation,
        array $localized,
        ?bool $published = null
    ): array {
        $translation = $this->normalizeTranslation($translation);
        $published ??= (int) ($translation['page_state'] ?? 1) === 1
            && (int) ($translation['state'] ?? 0) === 1
            && (bool) ($translation['has_published_content'] ?? false);

        return PageLocalizationService::versionMeta(
            (string) ($localized['draft_hash'] ?? ''),
            (string) ($localized['published_text_hash'] ?? ''),
            (string) ($localized['layout_draft_hash'] ?? ''),
            (string) ($localized['layout_published_hash'] ?? ''),
            $published
        );
    }

    /** @return array<int, array{url: string, language: string}> */
    private function menuMap(): array
    {
        $query = $this->db->getQuery(true)
            ->select($this->db->quoteName(['id', 'link', 'language']))
            ->from($this->db->quoteName('#__menu'))
            ->where($this->db->quoteName('client_id') . ' = 0')
            ->where($this->db->quoteName('published') . ' = 1')
            ->where($this->db->quoteName('link') . ' LIKE ' . $this->db->quote('%option=com_lmzpagebuilder%'));
        $rows = $this->db->setQuery($query)->loadAssocList() ?: [];
        $map = [];

        foreach ($rows as $row) {
            if (!preg_match('~(?:^|[?&])(?:id|page_id)=(\d+)~', (string) $row['link'], $match)) {
                continue;
            }
            $pageId = (int) $match[1];
            $language = (string) $row['language'];
            $map[$pageId][$language] = rtrim(Uri::root(), '/') . '/index.php?Itemid=' . (int) $row['id'];
        }

        return $map;
    }

    private function cleanTitle(string $title): string
    {
        $title = trim(preg_replace('/\s+/u', ' ', strip_tags($title)) ?? '');
        if ($title === '') {
            throw new RuntimeException('A page title is required.', 422);
        }

        return mb_substr($title, 0, 255);
    }

    private function uniquePageKey(string $candidate): string
    {
        $base = OutputFilter::stringURLSafe($candidate);
        $base = mb_substr($base !== '' ? $base : 'page', 0, 175);
        $key = $base;
        $suffix = 2;

        while ($this->pageKeyExists($key)) {
            $key = mb_substr($base, 0, 175 - strlen((string) $suffix) - 1) . '-' . $suffix++;
        }

        return $key;
    }

    private function pageKeyExists(string $key): bool
    {
        $query = $this->db->getQuery(true)
            ->select('COUNT(*)')
            ->from($this->db->quoteName('#__lmzpagebuilder_pages'))
            ->where($this->db->quoteName('page_key') . ' = ' . $this->db->quote($key));

        return (int) $this->db->setQuery($query)->loadResult() > 0;
    }

    private function uniqueAlias(string $candidate, string $language, int $ignoreId = 0): string
    {
        $base = OutputFilter::stringURLSafe($candidate);
        $base = mb_substr($base !== '' ? $base : 'page', 0, 175);
        $alias = $base;
        $suffix = 2;

        while ($this->aliasExists($alias, $language, $ignoreId)) {
            $alias = mb_substr($base, 0, 175 - strlen((string) $suffix) - 1) . '-' . $suffix++;
        }

        return $alias;
    }

    private function aliasExists(string $alias, string $language, int $ignoreId): bool
    {
        $query = $this->db->getQuery(true)
            ->select('COUNT(*)')
            ->from($this->db->quoteName('#__lmzpagebuilder_page_translations'))
            ->where($this->db->quoteName('alias') . ' = ' . $this->db->quote($alias))
            ->where($this->db->quoteName('language') . ' = ' . $this->db->quote($language));
        if ($ignoreId > 0) {
            $query->where($this->db->quoteName('id') . ' != ' . $ignoreId);
        }

        return (int) $this->db->setQuery($query)->loadResult() > 0;
    }

    private function draftHash(string $projectJson, string $html, string $css): string
    {
        return hash('sha256', $projectJson . "\0" . $html . "\0" . $css);
    }

    private function publishedHash(string $html, string $css): string
    {
        return hash('sha256', $html . "\0" . $css);
    }

    /** @param mixed $value */
    private function encodeJson($value): string
    {
        $json = json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);

        return (string) $json;
    }

    private function hasMeaningfulContent(string $html): bool
    {
        if (preg_match('~<(?:img|svg|video|audio|canvas|form|input|textarea|select|button)\b~i', $html)) {
            return true;
        }

        $text = html_entity_decode(strip_tags($html), ENT_QUOTES | ENT_HTML5, 'UTF-8');

        return trim(preg_replace('/\s+/u', ' ', $text) ?? '') !== '';
    }

    private function assertPayloadSize(string ...$values): void
    {
        if (array_sum(array_map('strlen', $values)) > $this->maxPayloadBytes) {
            throw new RuntimeException('The builder payload exceeds the configured size limit.', 413);
        }
    }

    private function assertHash(string $hash, string $field): void
    {
        if (!preg_match('/^[a-f0-9]{64}$/', strtolower($hash))) {
            throw new RuntimeException($field . ' must be a SHA-256 hash.', 428);
        }
    }

    /** @param array<string, mixed> $document */
    private function assertDocumentCheckout(array $document): void
    {
        $owner = (int) ($document['checked_out'] ?? 0);
        if ($owner === 0 || $owner === (int) $this->identity->id || $this->checkoutIsStale((string) ($document['checked_out_time'] ?? ''))) {
            return;
        }

        throw new RuntimeException('The builder translation is checked out by another user.', 423);
    }

    /** @param array<string, mixed> $document */
    private function assertDocumentLease(array $document, string $leaseToken): void
    {
        if (!preg_match('/^[a-f0-9]{64}$/', strtolower($leaseToken))) {
            throw new RuntimeException('A valid editor lease is required. Reopen the editor.', 409);
        }
        if ((int) ($document['checked_out'] ?? 0) !== (int) $this->identity->id) {
            throw new RuntimeException('This editor no longer owns the translation checkout.', 423);
        }

        $stored = strtolower((string) ($document['checkout_token'] ?? ''));
        if ($stored === '' || !hash_equals($stored, strtolower($leaseToken))) {
            throw new RuntimeException('A newer editor session owns this translation. Reload before continuing.', 409);
        }
    }

    private function checkoutIsStale(string $date): bool
    {
        $timestamp = strtotime($date . ' UTC');

        return $timestamp === false || $timestamp < time() - ($this->checkoutMinutes * 60);
    }

    private function assertManage(): void
    {
        if ((int) ($this->identity->id ?? 0) <= 0 || !$this->isAllowed('core.manage')) {
            throw new RuntimeException('LMZ Page Builder management permission is required.', 403);
        }
    }

    private function assertAction(string $action, ?string $fallback = null): void
    {
        $this->assertManage();
        if (!$this->isAllowed($action) && ($fallback === null || !$this->isAllowed($fallback))) {
            throw new RuntimeException('Permission denied for action ' . $action . '.', 403);
        }
    }

    private function isAllowed(string $action): bool
    {
        return (bool) $this->identity->authorise('core.admin', 'com_lmzpagebuilder')
            || (bool) $this->identity->authorise($action, 'com_lmzpagebuilder');
    }

    private function pruneRevisions(int $translationId): void
    {
        $query = $this->db->getQuery(true)
            ->select($this->db->quoteName('id'))
            ->from($this->db->quoteName('#__lmzpagebuilder_page_revisions'))
            ->where($this->db->quoteName('translation_id') . ' = ' . $translationId)
            ->order($this->db->quoteName('id') . ' DESC');
        $ids = array_slice(array_map('intval', $this->db->setQuery($query)->loadColumn() ?: []), $this->revisionLimit);

        if ($ids !== []) {
            $delete = $this->db->getQuery(true)
                ->delete($this->db->quoteName('#__lmzpagebuilder_page_revisions'))
                ->where($this->db->quoteName('id') . ' IN (' . implode(',', $ids) . ')');
            $this->db->setQuery($delete)->execute();
        }
    }

    private function syncPageUsages(int $pageId): void
    {
        $query = $this->db->getQuery(true)
            ->select($this->db->quoteName(['id', 'language', 'draft_html']))
            ->from($this->db->quoteName('#__lmzpagebuilder_page_translations'))
            ->where($this->db->quoteName('page_id') . ' = ' . $pageId);
        $service = new SharedElementService($this->db, $this->identity);

        foreach ($this->db->setQuery($query)->loadAssocList() ?: [] as $translation) {
            $service->syncPageUsages(
                (int) $translation['id'],
                (string) $translation['language'],
                (string) $translation['draft_html']
            );
        }
    }

    private function safeRollback(): void
    {
        try {
            $this->db->transactionRollback();
        } catch (Throwable $ignored) {
            // Preserve the original failure.
        }
    }

    private function clearCache(): void
    {
        foreach (['com_lmzpagebuilder', 'com_modules', 'com_templates', 'page'] as $group) {
            try {
                Factory::getCache($group)->clean();
            } catch (Throwable $ignored) {
                // One unavailable cache backend must not block a save/publish.
            }
        }
    }
}
