<?php
/**
 * LMZ Builder - System-Plugin: Icon-Feld fuer Menuepunkte.
 */

defined('_JEXEC') or die;

use Joomla\CMS\Extension\PluginInterface;
use Joomla\CMS\Factory;
use Joomla\CMS\Plugin\PluginHelper;
use Joomla\DI\Container;
use Joomla\DI\ServiceProviderInterface;
use Joomla\Event\DispatcherInterface;
use LMZ\Plugin\System\Lmzbuildermenu\Extension\LmzbuilderMenu;

return new class () implements ServiceProviderInterface {
    public function register(Container $container): void
    {
        $container->set(
            PluginInterface::class,
            function (Container $container) {
                $config = (array) PluginHelper::getPlugin('system', 'lmzbuildermenu');
                $plugin = new LmzbuilderMenu(
                    $container->get(DispatcherInterface::class),
                    $config
                );
                $plugin->setApplication(Factory::getApplication());

                return $plugin;
            }
        );
    }
};
