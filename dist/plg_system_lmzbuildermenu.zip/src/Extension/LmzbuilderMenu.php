<?php
/**
 * LMZ Builder - fuegt jedem Joomla-Menuepunkt ein Icon-Feld (mit FontAwesome-
 * Icon-Picker) und einen "nur Icon"-Schalter hinzu. Die Werte werden in den
 * Menuepunkt-Parametern gespeichert und vom lmz_builder-Template in der
 * Navigation ausgewertet.
 */

namespace LMZ\Plugin\System\Lmzbuildermenu\Extension;

defined('_JEXEC') or die;

use Joomla\CMS\Form\Form;
use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\CMS\Uri\Uri;
use Joomla\Event\SubscriberInterface;

final class LmzbuilderMenu extends CMSPlugin implements SubscriberInterface
{
    protected $autoloadLanguage = true;

    public static function getSubscribedEvents(): array
    {
        return ['onContentPrepareForm' => 'onContentPrepareForm'];
    }

    public function onContentPrepareForm($event): void
    {
        /* Ereignisobjekt (Joomla 5) oder klassische Argumente (Fallback). */
        $form = \is_object($event) && method_exists($event, 'getForm')
            ? $event->getForm()
            : ($event instanceof Form ? $event : null);

        if (!$form instanceof Form || $form->getName() !== 'com_menus.item') {
            return;
        }

        Form::addFormPath(\dirname(__DIR__, 2) . '/forms');
        $form->loadFile('menu', false);

        $app = $this->getApplication();
        if (!$app || !$app->isClient('administrator')) {
            return;
        }

        /* Icon-Picker + FontAwesome nur im Menue-Editor laden. */
        $document = $app->getDocument();
        if (!$document || !method_exists($document, 'getWebAssetManager')) {
            return;
        }
        $base = Uri::root(true) . '/media/com_lmzpagebuilder';
        $wa = $document->getWebAssetManager();
        $wa->registerAndUseStyle('lmzbuilder.fontawesome', $base . '/fontawesome/css/all.min.css');
        $wa->registerAndUseStyle('lmzbuilder.iconpicker', $base . '/css/rt-icon-picker.css');
        $wa->registerAndUseScript('lmzbuilder.iconpicker', $base . '/js/rt-icon-picker.js', [], ['defer' => true]);
        $document->addScriptDeclaration(
            "document.addEventListener('DOMContentLoaded', function () {"
            . " document.querySelectorAll('input.rt-icon-picker-field').forEach(function (el) {"
            . " if (window.RtIconPicker && typeof window.RtIconPicker.attach === 'function') { window.RtIconPicker.attach(el); }"
            . " }); });"
        );
    }
}
