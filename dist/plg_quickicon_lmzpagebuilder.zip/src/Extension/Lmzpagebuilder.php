<?php

namespace LMZ\Plugin\Quickicon\Lmzpagebuilder\Extension;

defined('_JEXEC') or die;

use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\Event\SubscriberInterface;
use Joomla\Module\Quickicon\Administrator\Event\QuickIconsEvent;

final class Lmzpagebuilder extends CMSPlugin implements SubscriberInterface
{
    protected $autoloadLanguage = true;

    public static function getSubscribedEvents(): array
    {
        return ['onGetIcons' => 'onGetIcons'];
    }

    public function onGetIcons(QuickIconsEvent $event): void
    {
        if ($event->getContext() !== 'mod_quickicon'
            || !$this->getApplication()->getIdentity()->authorise('core.manage', 'com_lmzpagebuilder')) {
            return;
        }

        $result = $event->getArgument('result', []);
        $result[] = [[
            'link' => 'index.php?option=com_lmzpagebuilder&view=projects',
            'image' => 'icon-grid-2',
            'icon' => '',
            'text' => $this->getApplication()->getLanguage()->_('PLG_QUICKICON_LMZPAGEBUILDER_LABEL'),
            'id' => 'plg_quickicon_lmzpagebuilder',
            'group' => 'MOD_QUICKICON_SITE',
        ]];
        $event->setArgument('result', $result);
    }
}
